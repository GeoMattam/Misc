# FastAPIBase

A lightweight and modular FastAPI project template designed for rapid backend development with scalability in mind.

## Project Structure
FASTAPIBASE/
├── logs/ # Application logs
├── services/ # Business logic and service layer
├── utils/ # Helper utilities
├── venv/ # Virtual environment (excluded from version control)
├── .env # Environment variables (e.g., DB credentials, API keys)
├── main.py # FastAPI application entry point
├── requirements.txt # Python dependencies
├── setup.txt # Setup instructions or configuration notes

## Requirements
- Python 3.10.10+
- FastAPI
- Uvicorn (for ASGI server)

## Install all dependencies:
pip install -r requirements.txt

## Running the Application
uvicorn main:app --reload
or
uvicorn main:app --host 0.0.0.0 --port 8085
or
uvicorn main:app --host 0.0.0.0 --port 8085 --reload
Access the API docs at: http://localhost:8085/docs