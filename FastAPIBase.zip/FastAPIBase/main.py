from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from utils.logging_config import app_logger,access_logger
from utils.config import ALLOWED_ORIGINS
import utils.constant as constant

from services.greeting_service import greeting_router
from services.employee_service import employee_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    app_logger.info(" App starting up...")
    yield
    app_logger.info(" App shutting down...")

app = FastAPI(
    title="Basic FastAPI App",
    description="A modular FastAPI backend with logging, routers, and middleware.",
    version="1.0.0",
    lifespan=lifespan
)

# Middleware: Request logging
@app.middleware("http")
async def log_requests(request: Request, call_next):
    try:
        access_logger.info(f"Incoming request: {request.method} {request.url}")
        response = await call_next(request)
        access_logger.info(f"Response status: {response.status_code} for {request.method} {request.url}")
        return response
    except Exception as e:
        app_logger.error(f"Unhandled middleware error: {e}")
        raise HTTPException(status_code=500, detail=constant.TECHNICAL_ERROR)
    
# Middleware: CORS setup using external config
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(employee_router, prefix="/api", tags=["Employee Service"])
app.include_router(greeting_router, prefix="/api", tags=["Greeting Service"])