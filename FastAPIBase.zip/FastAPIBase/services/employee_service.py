from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import pandas as pd

from utils.logging_config import app_logger
import utils.constant as constant

employee_router = APIRouter(prefix="/employees", tags=["Employee Service"])

class FilterRequest(BaseModel):
    department: str

@employee_router.post("/filter")
async def filter_employees(req: FilterRequest) -> dict:
    """
    Filters employees by department using a sample DataFrame.
    Returns the filtered records as JSON.
    """
    try:
        # DataFrame
        data: dict = {
            "id": [1, 2, 3, 4],
            "name": ["Alice", "Bob", "Charlie", "Diana"],
            "department": ["HR", "IT", "IT", "Marketing"],
            "salary": [60000, 75000, 72000, 65000]
        }
        df: pd.DataFrame = pd.DataFrame(data)

        # Filter based on input
        filtered_df: pd.DataFrame = df[df["department"] == req.department]

        # Convert to list of dicts and return
        result: list[dict] = filtered_df.to_dict(orient="records")
        return JSONResponse(
            status_code=200,  # This is the actual HTTP status code
            content={
                "status_code": 0,  # Your custom app-level status code
                "data": result
            }
        )
    except Exception as e:
        # Handle unexpected errors
        app_logger.error(f"Unhandled exception in /filter: {str(e)}")
        return {"status_code": 1, "data":constant.TECHNICAL_ERROR}