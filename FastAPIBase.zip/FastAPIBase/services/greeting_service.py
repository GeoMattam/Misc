from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from utils.logging_config import app_logger
import utils.constant as constant

greeting_router = APIRouter(prefix="/greeting", tags=["Greeting Service"])

@greeting_router.get("/hello", tags=["Greeting Service"])
async def say_hello():
    try:
        return {"status_code":0, "data": "Hello from Greeting router!"}
    except Exception as e:
        app_logger.error(f"Failed to return greeting in /hello: {str(e)}")
        raise HTTPException(status_code=500, detail=constant.TECHNICAL_ERROR)