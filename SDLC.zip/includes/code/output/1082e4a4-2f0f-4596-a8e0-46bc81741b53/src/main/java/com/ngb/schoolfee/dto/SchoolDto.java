```java
package com.ngb.schoolfee.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class SchoolDto {
    @NotBlank
    @Size(max = 255)
    private String schoolName;
    @NotBlank
    @Size(max = 255)
    private String location;
    @NotBlank
    @Size(max = 50)
    private String ngbAccountNumber;
    @NotBlank
    @Size(max = 100)
    private String glAccountNumber;
    @NotNull
    private List<FeeTypeDto> feeTypes;
}
```