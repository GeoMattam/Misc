```java
package com.ngb.schoolfee.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
public class School {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private String glAccountNumber;
    private Date registrationDate;
    private boolean isActive;

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;

    // Add other relevant fields, getters, and setters as needed.

}
```