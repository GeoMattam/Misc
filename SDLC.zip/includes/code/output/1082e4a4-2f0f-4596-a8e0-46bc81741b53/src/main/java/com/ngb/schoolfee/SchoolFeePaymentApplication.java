```java
package com.ngb.schoolfee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolFeePaymentApplication {

    public static void main(String[] args) {
        SpringApplication.run(SchoolFeePaymentApplication.class, args);
    }

}
```