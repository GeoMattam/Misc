package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.List;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    private String customerId;

    private String name;

    private String contactInfo;

    private String status; // ACTIVE, INACTIVE

    @OneToMany(mappedBy = "registeredByCustomer")
    private List<Student> students;

    @OneToMany(mappedBy = "customer")
    private List<CreditCard> creditCards;

    public boolean isActiveCardholder(){
        //This logic would ideally fetch from an external Cards system in a real application
        return this.status.equals("ACTIVE");
    }
}
```

```java