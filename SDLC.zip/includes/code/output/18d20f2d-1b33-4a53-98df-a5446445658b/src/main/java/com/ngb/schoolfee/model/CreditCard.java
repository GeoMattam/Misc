package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditCard {

    @Id
    private String cardNumber; //In a real system, this would be a token or masked value

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;


    private String cardType; // VISA_CONVENTIONAL, MASTERCARD etc.

    private LocalDate expiryDate;

    private double balance; // Current balance (may be dynamic/real-time)

    private String status; // ACTIVE, INACTIVE, BLOCKED

    @OneToMany(mappedBy = "creditCard")
    private List<Transaction> transactions;

    public boolean isCardActive() {
        return this.status.equals("ACTIVE");
    }

    public boolean hasSufficientBalance(double amount) {
        return this.balance >= amount;
    }
}
```

```java