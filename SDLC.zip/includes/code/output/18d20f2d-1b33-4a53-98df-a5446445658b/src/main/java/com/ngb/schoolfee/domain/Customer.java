package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CUSTOMER")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    @Column(name = "customer_id", length = 50, nullable = false, unique = true)
    private String customerId;

    @Column(name = "customer_name", length = 255, nullable = false)
    private String customerName;

    @Column(name = "contact_info", length = 255, nullable = false)
    private String contactInfo;

    @Column(name = "status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private CustomerStatus status = CustomerStatus.ACTIVE;


    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CreditCard> creditCards;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Student> students;

    public boolean isActiveCardholder() {
        return this.creditCards != null && !this.creditCards.isEmpty() && this.status == CustomerStatus.ACTIVE;
    }
}
```

```java