package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long studentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "registered_by_customer_id", nullable = false)
    private Customer registeredByCustomer;

    @Column(nullable = false)
    private String studentName;

    @Column(nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();

    @Column(nullable = false)
    private String status; // REGISTERED, DE-REGISTERED


    @OneToMany(mappedBy = "student")
    private List<Transaction> transactions;

    public boolean isRegistered(){
        return this.status.equals("REGISTERED");
    }
}
```

```java