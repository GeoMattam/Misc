package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "TRANSACTION")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @Column(name = "transaction_id", length = 50, nullable = false, unique = true)
    private String transactionId;

    @Column(name = "transaction_date_time", nullable = false, updatable = false)
    private LocalDateTime transactionDateTime = LocalDateTime.now();

    @Column(name = "amount", nullable = false, precision = 18, scale = 2)
    private BigDecimal amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_token", nullable = false)
    private CreditCard creditCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @Column(name = "remark", length = 20)
    private String remark;

    @Column(name = "status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status = TransactionStatus.PENDING;

    @Column(name = "posting_description", length = 40, nullable = false)
    private String postingDescription;

    @Column(name = "is_epp_converted", nullable = false)
    private boolean isEPPConverted = false;

    @Column(name = "gl_posting_status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private GLPostingStatus glPostingStatus = GLPostingStatus.PENDING;


    @Column(name = "is_loyalty_eligible", nullable = false)
    private boolean isLoyaltyEligible = true;

    @Column(name = "ivr_tin_used", nullable = false)
    private boolean ivrTinUsed = false;

    @Column(name = "channel_used", length = 50, nullable = false)
    private String channelUsed;


    @OneToMany(mappedBy = "transaction", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<EPPRequest> eppRequests;

    @OneToMany(mappedBy = "transaction", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AuditLog> auditLogs;


    public void updateStatus(TransactionStatus newStatus) {
        this.status = newStatus;
    }
}

```

```java