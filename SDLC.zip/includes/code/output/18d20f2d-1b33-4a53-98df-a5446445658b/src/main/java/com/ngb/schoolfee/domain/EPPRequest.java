package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "EPP_REQUEST")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequest {

    @Id
    @Column(name = "epp_request_id", length = 50, nullable = false, unique = true)
    private String eppRequestId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false, unique = true) //Ensures 1:1 with Transaction
    private Transaction transaction;

    @Column(name = "request_date_time", nullable = false, updatable = false)
    private LocalDateTime requestDateTime = LocalDateTime.now();

    @Column(name = "status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status = EPPStatus.PENDING;

    @Column(name = "rejection_reason", length = 255)
    private String rejectionReason;


    @Column(name = "approval_date_time")
    private LocalDateTime approvalDateTime;

    @Column(name = "no_loyalty_points_flag", nullable = false)
    private boolean noLoyaltyPointsFlag = true;

    @OneToMany(mappedBy = "eppRequest", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AuditLog> auditLogs;

    public void updateStatus(EPPStatus newStatus, String reason) {
        this.status = newStatus;
        this.rejectionReason = reason;
    }
}
```

```java