package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class EPPResponse {
    private String eppRequestId;
    private String status;
}
```

```java