package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.CardType;
import lombok.Data;

@Data
public class GLPostingRequest {
    private String transactionId;
    private CardType cardType;
    private double amount;
    private String description;
    private String schoolAccountNumber;
}
```

```java