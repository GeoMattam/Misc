package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @OneToOne
    @JoinColumn(name = "transaction_id", unique = true, nullable = false)
    private Transaction transaction;

    @Column(nullable = false, updatable = false)
    private LocalDateTime requestDateTime = LocalDateTime.now();

    @Column(nullable = false)
    private String status; // PENDING, APPROVED, REJECTED

    private String rejectionReason;

    private LocalDateTime approvalDateTime;

    @Column(nullable = false)
    private Boolean noLoyaltyPointsFlag = true;

    public void updateStatus(String newStatus, String reason) {
        this.status = newStatus;
        if (newStatus.equals("REJECTED")) {
            this.rejectionReason = reason;
        }
        if(newStatus.equals("APPROVED")){
            this.approvalDateTime = LocalDateTime.now();
        }
    }
}
```

```java