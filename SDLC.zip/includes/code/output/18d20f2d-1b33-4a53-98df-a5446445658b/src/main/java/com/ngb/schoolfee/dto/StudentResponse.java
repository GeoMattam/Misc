package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class StudentResponse {
    private Long studentSystemId;
    private String studentName;
    private String studentId;
    private String schoolId;
    private String schoolName;
    private String status;
}
```

```java