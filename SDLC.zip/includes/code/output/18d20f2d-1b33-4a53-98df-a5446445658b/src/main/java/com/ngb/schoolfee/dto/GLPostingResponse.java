package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class GLPostingResponse {
    private String postingId;
    private String status;
}
```

```java