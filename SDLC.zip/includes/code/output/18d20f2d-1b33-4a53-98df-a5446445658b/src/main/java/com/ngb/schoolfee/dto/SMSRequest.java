package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class SMSRequest {
    private String phoneNumber;
    private String message;
    private String type; // OTP, CONFIRMATION, ALERT, REJECTION
}
```

```java