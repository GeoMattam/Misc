package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.Transaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, String> {
    Page<Transaction> findByCustomerId(String customerId, Pageable pageable);
    List<Transaction> findByCustomerId(String customerId);
}
```

```java