package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.EPPRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EPPRequestRepository extends JpaRepository<EPPRequest, String> {
    Optional<EPPRequest> findByTransactionTransactionId(String transactionId);
    boolean existsByTransactionTransactionId(String transactionId);
}
```

```java