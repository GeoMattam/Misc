```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.model.Customer;
import com.ngb.schoolfee.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public Customer getCustomer(String customerId) {
        Optional<Customer> customerOptional = customerRepository.findById(customerId);
        return customerOptional.orElseThrow(()-> new RuntimeException("Customer not found"));
    }
}
```