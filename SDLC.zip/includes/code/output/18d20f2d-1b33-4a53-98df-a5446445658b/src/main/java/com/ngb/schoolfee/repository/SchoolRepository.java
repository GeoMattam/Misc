package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SchoolRepository extends JpaRepository<School, String> {
    Optional<School> findBySchoolName(String schoolName);
    Optional<School> findByNgbAccountNumber(String accountNumber);
    boolean existsBySchoolName(String schoolName);
    boolean existsByNgbAccountNumber(String accountNumber);
}
```

```java