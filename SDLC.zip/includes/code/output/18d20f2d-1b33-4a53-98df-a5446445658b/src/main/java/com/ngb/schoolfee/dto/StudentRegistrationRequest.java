package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class StudentRegistrationRequest {
    private String studentName;
    private String studentId;
    private String studentIdConfirm;
    private String schoolId;
    private String otp; //For online/mobile
}
```

```java