package com.ngb.schoolfee.exception;

public class StudentManagementException extends RuntimeException {
    public StudentManagementException(String message) {
        super(message);
    }
}
```

```java