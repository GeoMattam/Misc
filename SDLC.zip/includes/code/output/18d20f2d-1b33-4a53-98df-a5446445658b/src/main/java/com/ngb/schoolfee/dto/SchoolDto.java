```java
package com.ngb.schoolfee.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class SchoolDto {

    private Long schoolId;

    @NotBlank(message = "School name is required")
    private String schoolName;

    @NotBlank(message = "Location is required")
    private String location;

    @NotBlank(message = "NGB Account Number is required")
    @Size(min = 10, max = 20, message = "NGB Account Number must be between 10 and 20 characters")
    private String ngbAccountNumber;

    private List<FeeTypeDto> feeTypes;

    private boolean isActive;

    // Add other fields as needed...
}
```