package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class EPPRequestStatusResponse {
    private Long eppRequestId;
    private Long transactionId;
    private String status;
    private String rejectionReason;
}
```

```java