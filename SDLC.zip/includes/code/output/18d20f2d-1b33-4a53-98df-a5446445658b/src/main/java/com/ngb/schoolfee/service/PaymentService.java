```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.TransactionDto;
import com.ngb.schoolfee.enums.TransactionStatus;
import com.ngb.schoolfee.exception.PaymentException;
import com.ngb.schoolfee.model.*;
import com.ngb.schoolfee.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class PaymentService {

    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private StudentService studentService;
    @Autowired
    private CreditCardService creditCardService;
    @Autowired
    private SchoolService schoolService;
    @Autowired
    private FeeTypeService feeTypeService;
    @Autowired
    private FinancialPostingService financialPostingService;
    @Autowired
    private NotificationService notificationService;
    @Autowired
    private AuditLogService auditLogService;
    @Autowired
    private EPPRequestService eppRequestService;



    @Transactional
    public TransactionDto initiateFeePayment(TransactionDto transactionDto, String customerId) {
        Student student = studentService.getStudent(transactionDto.getStudentId(), transactionDto.getSchoolId());
        CreditCard creditCard = creditCardService.getCreditCard(transactionDto.getCardNumber());
        School school = schoolService.getSchool(transactionDto.getSchoolId());
        FeeType feeType = feeTypeService.getFeeType(transactionDto.getFeeTypeId());

        if (!student.isRegistered()) {
            throw new PaymentException("Payment failed: Student not registered");
        }
        if (!creditCard.isCardActive()) {
            throw new PaymentException("Payment failed: Invalid card");
        }
        if (!creditCard.hasSufficientBalance(transactionDto.getAmount())) {
            throw new PaymentException("Payment failed: Insufficient balance");
        }

        String refId = UUID.randomUUID().toString();
        Transaction transaction = Transaction.builder()
                .amount(transactionDto.getAmount())
                .remark(transactionDto.getRemark())
                .status(TransactionStatus.PENDING.name())
                .isEPPConverted(transactionDto.isEPPConverted())
                .postingDescription("School Fee Payment")
                .creditCard(creditCard)
                .student(student)
                .school(school)
                .feeType(feeType)
                .glPostingStatus(GLPostingStatus.PENDING.name())
                .referenceId(refId)
                .build();

        transaction = transactionRepository.save(transaction);

        //Asynchronous Operations
        financialPostingService.postGLTransactions(transaction);
        notificationService.sendPaymentConfirmation(transaction);
        auditLogService.logPayment(transaction);

        if(transactionDto.isEPPConverted()) {
            eppRequestService.initiateEPPConversion(transaction.getTransactionId(), customerId);
        }


        return mapToDto(transaction);
    }

    public List<TransactionDto> getTransactionHistory(String customerId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Transaction> transactionPage = transactionRepository.findByCustomerId(customerId, pageable);
        return transactionPage.getContent().stream().map(this::mapToDto).collect(Collectors.toList());
    }

    public TransactionDto mapToDto(Transaction transaction) {
        TransactionDto transactionDto = new TransactionDto();
        transactionDto.setTransactionId(transaction.getTransactionId());
        transactionDto.setAmount(transaction.getAmount());
        transactionDto.setRemark(transaction.getRemark());
        transactionDto.setStatus(TransactionStatus.valueOf(transaction.getStatus()));
        transactionDto.setPostingDescription(transaction.getPostingDescription());
        transactionDto.setEPPConverted(transaction.isEPPConverted());
        transactionDto.setGlPostingStatus(transaction.getGlPostingStatus());
        transactionDto.setCardNumber(transaction.getCreditCard().getCardNumber());
        transactionDto.setStudentId(transaction.getStudent().getStudentId());
        transactionDto.setSchoolId(transaction.getSchool().getSchoolId());
        transactionDto.setFeeTypeId(transaction.getFeeType().getFeeTypeId());
        transactionDto.setTransactionDateTime(transaction.getTransactionDateTime());
        transactionDto.setLoyaltyEligible(transaction.isLoyaltyEligible());
        return transactionDto;
    }

    public Student getStudent(String studentId, Long schoolId) {
        Optional<Student> studentOptional = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId);
        return studentOptional.orElseThrow(()-> new PaymentException("Student Not Found"));
    }

    public School getSchool(Long schoolId) {
        Optional<School> schoolOptional = schoolRepository.findById(schoolId);
        return schoolOptional.orElseThrow(()-> new PaymentException("School Not Found"));
    }

    public FeeType getFeeType(Long feeTypeId) {
        Optional<FeeType> feeTypeOptional = feeTypeRepository.findById(feeTypeId);
        return feeTypeOptional.orElseThrow(() -> new PaymentException("Fee Type Not Found"));
    }
}
```