package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TransactionResponse {
    private Long transactionId;
    private String status;
    private String referenceId;
}
```

```java