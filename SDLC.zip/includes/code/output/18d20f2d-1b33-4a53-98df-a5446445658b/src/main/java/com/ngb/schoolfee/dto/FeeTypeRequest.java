package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class FeeTypeRequest {
    private String feeTypeName;
    private String description;
}
```

```java