package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class SMSResponse {
    private String notificationId;
    private String status;
}
```

```java