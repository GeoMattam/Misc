package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class FeePaymentRequest {
    private String customerId;
    private String studentSystemId;
    private String schoolId;
    private String feeTypeId;
    private String cardNumber;
    private double amount;
    private String remark;
    private String otp; //For online/mobile
    private String ivrTin; //For IVR
}
```

```java