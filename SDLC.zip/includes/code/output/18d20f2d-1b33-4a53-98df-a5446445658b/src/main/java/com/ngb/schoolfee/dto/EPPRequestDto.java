```java
package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.EPPStatus;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EPPRequestDto {

    private Long eppRequestId;
    private Long transactionId;
    private LocalDateTime requestDateTime;
    private EPPStatus status;
    private String rejectionReason;
    private boolean noLoyaltyPointsFlag;
    private LocalDateTime approvalDateTime;
}
```