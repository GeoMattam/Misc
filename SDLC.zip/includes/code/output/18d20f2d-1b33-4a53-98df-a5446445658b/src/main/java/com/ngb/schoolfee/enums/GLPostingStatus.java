package com.ngb.schoolfee.enums;

public enum GLPostingStatus {
    PENDING,
    POSTED,
    FAILED
}
```

```java