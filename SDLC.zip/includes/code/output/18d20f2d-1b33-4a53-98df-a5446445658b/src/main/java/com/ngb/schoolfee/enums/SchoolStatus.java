package com.ngb.schoolfee.enums;

public enum SchoolStatus {
    REGISTERED,
    ACTIVE,
    INACTIVE
}
```

```java