package com.ngb.schoolfee.enums;

public enum CreditCardStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}
```

```java