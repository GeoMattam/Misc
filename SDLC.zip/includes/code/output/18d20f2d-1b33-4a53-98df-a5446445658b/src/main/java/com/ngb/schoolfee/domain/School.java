package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "SCHOOL")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class School {

    @Id
    @Column(name = "school_id", length = 50, nullable = false, unique = true)
    private String schoolId;

    @Column(name = "school_name", length = 255, nullable = false, unique = true)
    private String schoolName;

    @Column(name = "location", length = 255, nullable = false)
    private String location;

    @Column(name = "ngb_account_number", length = 50, nullable = false, unique = true)
    private String ngbAccountNumber;

    @Column(name = "ngb_gl_account_config", length = 100, nullable = false)
    private String ngbGlAccountConfig;

    @Column(name = "registration_date", nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();

    @Column(name = "operational_since", nullable = false)
    private LocalDate operationalSince;

    @Column(name = "is_active", nullable = false)
    private boolean isActive = true;

    @Column(name = "min_students", nullable = false)
    private int minEnrolledStudents = 1000;

    @Column(name = "min_annual_fee_coll", nullable = false, precision = 18, scale = 2)
    private BigDecimal minAnnualFeeCollection = BigDecimal.valueOf(500000.00);

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;

    public boolean applyBusinessRules() {
        return operationalSince != null && operationalSince.isBefore(LocalDate.now().minusYears(3)) &&
               minEnrolledStudents >= 1000 && minAnnualFeeCollection.compareTo(BigDecimal.valueOf(500000.00)) >= 0;
    }
}
```

```java