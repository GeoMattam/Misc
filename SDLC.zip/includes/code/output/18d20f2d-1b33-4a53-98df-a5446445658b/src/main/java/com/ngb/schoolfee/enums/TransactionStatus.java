package com.ngb.schoolfee.enums;

public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILED,
    PENDING_EPP,
    CANCELLED
}
```

```java