package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class AuditLogResponse {
    private Long logId;
    private String status;
}
```


```java