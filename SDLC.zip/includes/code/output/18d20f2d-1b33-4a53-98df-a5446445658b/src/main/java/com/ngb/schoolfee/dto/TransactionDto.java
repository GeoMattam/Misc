```java
package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.TransactionStatus;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;


@Data
public class TransactionDto {

    private Long transactionId;
    private LocalDateTime transactionDateTime;
    @NotNull(message = "Amount cannot be null")
    @Min(value = 0, message = "Amount must be positive")
    private double amount;
    @Size(max = 20, message = "Remark cannot exceed 20 characters")
    private String remark;
    private TransactionStatus status;
    @Size(max = 40, message = "Posting description cannot exceed 40 characters")
    private String postingDescription;
    private boolean isEPPConverted;
    private String glPostingStatus;
    @NotNull(message = "Card Number cannot be null")
    private String cardNumber;
    @NotNull(message = "Student ID cannot be null")
    private String studentId;
    @NotNull(message = "School ID cannot be null")
    private Long schoolId;
    @NotNull(message = "Fee Type ID cannot be null")
    private Long feeTypeId;
    private boolean isLoyaltyEligible;

}

```