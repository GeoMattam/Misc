package com.ngb.schoolfee.enums;

public enum CardStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}
```

```java