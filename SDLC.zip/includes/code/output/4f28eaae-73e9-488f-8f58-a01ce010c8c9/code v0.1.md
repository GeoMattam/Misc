```java
###FilePath: src/main/java/com/ngb/schoolfee/model/School.java

package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "SCHOOL")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class School {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long schoolId;

    @Column(nullable = false, unique = true)
    private String schoolName;

    @Column(nullable = false)
    private String location;

    @Column(nullable = false, unique = true)
    private String ngbAccountNumber;

    @Column(nullable = false)
    private String ngbGlAccountConfig;

    @Column(nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();

    @Column(nullable = false)
    private Boolean isActive = true;

    @Column(nullable = false)
    private int minEnrolledStudents = 1000; //Business Rule

    @Column(nullable = false)
    private int operationalYears = 3; //Business Rule

    @Column(nullable = false)
    private double minAnnualFeeCollection = 500000.00; //Business Rule

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Student> students;


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/FeeType.java
package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "FEE_TYPE", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"school_id", "fee_type_name"})
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feeTypeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(nullable = false)
    private String feeTypeName;

    @Column
    private String description;

    @Column(nullable = false)
    private Boolean isActive = true;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/Customer.java

package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CUSTOMER")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    private String customerId;

    @Column(nullable = false)
    private String customerName;

    @Column(nullable = false)
    private String contactInfo; //Phone or Email

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CustomerStatus status = CustomerStatus.ACTIVE;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CreditCard> creditCards;


    @OneToMany(mappedBy = "registeredByCustomer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Student> students;

    public boolean isActiveCardholder(){
        return this.creditCards != null && !this.creditCards.isEmpty() && this.status == CustomerStatus.ACTIVE;
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/CreditCard.java

package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "CREDIT_CARD")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditCard {

    @Id
    private String cardToken; //Instead of storing card number directly, use a token.

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @Column(nullable = false)
    private String cardLast4Digits;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CardType cardType;

    @Column(nullable = false)
    private LocalDate expiryDate;

    @Column(nullable = false)
    private double balance;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CardStatus status = CardStatus.ACTIVE;


    @OneToMany(mappedBy = "creditCard", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Transaction> transactions;

    public boolean isCardActive(){
        return this.status == CardStatus.ACTIVE;
    }

    public boolean hasSufficientBalance(double amount){
        return this.balance >= amount;
    }

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/Student.java

package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "STUDENT", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"student_id", "school_id"})
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @Column(nullable = false)
    private String studentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(nullable = false)
    private String studentName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "registered_by_customer_id", nullable = false)
    private Customer registeredByCustomer;

    @Column(nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();


    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private StudentStatus status = StudentStatus.REGISTERED;

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Transaction> transactions;

    public boolean isRegistered(){
        return this.status == StudentStatus.REGISTERED;
    }

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/Transaction.java

package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "TRANSACTION")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column(nullable = false, unique = true)
    private String referenceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_token", nullable = false)
    private CreditCard creditCard;

    @Column(nullable = false)
    private double amount;

    @Column(nullable = false)
    private LocalDateTime transactionDateTime = LocalDateTime.now();

    @Column
    private String remark;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status = TransactionStatus.PENDING;

    @Column(nullable = false)
    private String postingDescription;

    @Column(nullable = false)
    private Boolean isEppConverted = false;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private GLPostingStatus glPostingStatus = GLPostingStatus.PENDING;

    @Column(nullable = false)
    private Boolean ivrTinUsed = false;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private PaymentChannel channelUsed;

    @Column(nullable = false)
    private Boolean isLoyaltyEligible = true;


    public void updateStatus(TransactionStatus newStatus){
        this.status = newStatus;
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/EPPRequest.java

package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "EPP_REQUEST", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"transaction_id"})
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false, unique = true)
    private Transaction transaction;

    @Column(nullable = false)
    private LocalDateTime requestDateTime = LocalDateTime.now();

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status = EPPStatus.PENDING;

    @Column
    private String rejectionReason;

    @Column(nullable = false)
    private Boolean noLoyaltyPointsFlag = true; // Business Rule

    @Column
    private LocalDateTime approvalDateTime;

    public void updateStatus(EPPStatus newStatus, String reason){
        this.status = newStatus;
        if(newStatus == EPPStatus.REJECTED){
            this.rejectionReason = reason;
        }
        this.approvalDateTime = LocalDateTime.now();
    }

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/AuditLog.java

package com.ngb.schoolfee.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "AUDIT_LOG")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logId;

    @Column(nullable = false)
    private String activityType;

    @Column
    private String entityIdAffected;

    @Column
    private String entityType;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime timestamp;

    @Column(nullable = false)
    private String performedByUserOrSystem;

    @Column
    private String details;

    @Column(nullable = false)
    private Boolean successStatus;

    @Column
    private String channel;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/CustomerStatus.java

package com.ngb.schoolfee.enums;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/CardType.java

package com.ngb.schoolfee.enums;

public enum CardType {
    VISA_CONVENTIONAL,
    VISA_ISLAMIC,
    MASTERCARD
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/CardStatus.java

package com.ngb.schoolfee.enums;

public enum CardStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/StudentStatus.java

package com.ngb.schoolfee.enums;

public enum StudentStatus {
    REGISTERED,
    DE_REGISTERED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/TransactionStatus.java

package com.ngb.schoolfee.enums;

public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILED,
    PENDING_EPP,
    CANCELLED,
    REJECTED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/GLPostingStatus.java

package com.ngb.schoolfee.enums;

public enum GLPostingStatus {
    PENDING,
    POSTED,
    FAILED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/EPPStatus.java

package com.ngb.schoolfee.enums;

public enum EPPStatus {
    PENDING,
    APPROVED,
    REJECTED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/PaymentChannel.java

package com.ngb.schoolfee.enums;

public enum PaymentChannel {
    ONLINE_BANKING,
    MOBILE_BANKING,
    IVR
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/SchoolRequestDTO.java

package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SchoolRequestDTO {
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private List<FeeTypeRequestDTO> feeTypes;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/SchoolResponseDTO.java

package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.model.FeeType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SchoolResponseDTO {
    private Long schoolId;
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private String ngbGlAccountConfig;
    private LocalDateTime registrationDate;
    private boolean isActive;
    private List<FeeType> feeTypes;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/FeeTypeRequestDTO.java

package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeTypeRequestDTO {
    private String feeTypeName;
    private String description;
}

```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/FeeTypeResponseDTO.java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeTypeResponseDTO {
    private Long feeTypeId;
    private String feeTypeName;
    private String description;
    private boolean isActive;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/StudentRequestDTO.java

package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentRequestDTO {
    private String studentName;
    private String studentId;
    private String studentIdConfirm;
    private String schoolId;
    private String otp; //For online/mobile
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/StudentResponseDTO.java

package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.StudentStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentResponseDTO {
    private String studentSystemId;
    private String studentName;
    private String studentId;
    private String schoolId;
    private String schoolName;
    private StudentStatus status;
    private LocalDateTime registrationDate;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/PaymentRequestDTO.java

package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequestDTO {
    private String customerId;
    private String studentSystemId;
    private String schoolId;
    private String feeTypeId;
    private String cardNumber;
    private double amount;
    private String remark;
    private String otp; //For online/mobile
    private String ivrTin; //For IVR
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/PaymentResponseDTO.java

package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResponseDTO {
    private String transactionId;
    private TransactionStatus status;
    private String referenceId;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/EPPRequestDTO.java

package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequestDTO {
    private String transactionId;
    private String customerId;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/EPPResponseDTO.java

package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.EPPStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPResponseDTO {
    private String eppRequestId;
    private EPPStatus status;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/TransactionHistoryResponseDTO.java

package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionHistoryResponseDTO {
    private String transactionId;
    private LocalDateTime date;
    private double amount;
    private String studentName;
    private String schoolName;
    private String feeTypeName;
    private String remark;
    private TransactionStatus status;
}
```


```java
###FilePath: src/main/java/com/ngb/schoolfee/exception/SchoolRegistrationException.java

package com.ngb.schoolfee.exception;

public class SchoolRegistrationException extends RuntimeException{
    public SchoolRegistrationException(String message) {
        super(message);
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/exception/StudentManagementException.java

package com.ngb.schoolfee.exception;

public class StudentManagementException extends RuntimeException{
    public StudentManagementException(String message) {
        super(message);
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/exception/PaymentProcessingException.java

package com.ngb.schoolfee.exception;

public class PaymentProcessingException extends RuntimeException{
    public PaymentProcessingException(String message) {
        super(message);
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/exception/EPPConversionException.java

package com.ngb.schoolfee.exception;

public class EPPConversionException extends RuntimeException{
    public EPPConversionException(String message) {
        super(message);
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/exception/GlobalExceptionHandler.java

package com.ngb.schoolfee.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(SchoolRegistrationException.class)
    public ResponseEntity<Map<String, Object>> handleSchoolRegistrationException(SchoolRegistrationException ex){
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", ex.getMessage());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(StudentManagementException.class)
    public ResponseEntity<Map<String, Object>> handleStudentManagementException(StudentManagementException ex){
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", ex.getMessage());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(PaymentProcessingException.class)
    public ResponseEntity<Map<String, Object>> handlePaymentProcessingException(PaymentProcessingException ex){
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", ex.getMessage());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EPPConversionException.class)
    public ResponseEntity<Map<String, Object>> handleEPPConversionException(EPPConversionException ex){
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", ex.getMessage());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }


    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex){
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", "An unexpected error occurred."); //Avoid exposing stack trace in production
        body.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/SchoolRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SchoolRepository extends JpaRepository<School, Long> {
    Optional<School> findByNgbAccountNumber(String ngbAccountNumber);
    boolean existsBySchoolNameAndLocation(String schoolName, String location);
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/FeeTypeRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.FeeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeeTypeRepository extends JpaRepository<FeeType, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/CustomerRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {
    Optional<Customer> findById(String id);
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/CreditCardRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.CreditCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CreditCardRepository extends JpaRepository<CreditCard, String> {
    Optional<CreditCard> findByCardNumber(String cardNumber);
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/StudentRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {
    boolean existsByStudentIdAndSchool_SchoolId(String studentId, Long schoolId);
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/TransactionRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/EPPRequestRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.EPPRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EPPRequestRepository extends JpaRepository<EPPRequest, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/AuditLogRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/SchoolManagementService.java

package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.FeeTypeRequestDTO;
import com.ngb.schoolfee.dto.SchoolRequestDTO;
import com.ngb.schoolfee.dto.SchoolResponseDTO;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.FeeType;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SchoolManagementService {

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private FeeTypeRepository feeTypeRepository;


    @Transactional
    public SchoolResponseDTO registerSchool(SchoolRequestDTO schoolRequestDTO) {
        if(schoolRepository.existsBySchoolNameAndLocation(schoolRequestDTO.getSchoolName(), schoolRequestDTO.getLocation())){
            throw new SchoolRegistrationException("School already registered with this name and location.");
        }

        School school = School.builder()
                .schoolName(schoolRequestDTO.getSchoolName())
                .location(schoolRequestDTO.getLocation())
                .ngbAccountNumber(schoolRequestDTO.getNgbAccountNumber())
                .ngbGlAccountConfig("GL-CONFIG-" + schoolRequestDTO.getSchoolName()) // Placeholder - actual GL mapping logic should be implemented
                .build();

        if(!school.applyBusinessRules()){
            throw new SchoolRegistrationException("School does not meet registration criteria.");
        }

        School savedSchool = schoolRepository.save(school);

        List<FeeType> feeTypes = schoolRequestDTO.getFeeTypes().stream()
                .map(feeTypeRequest -> FeeType.builder()
                        .school(savedSchool)
                        .feeTypeName(feeTypeRequest.getFeeTypeName())
                        .description(feeTypeRequest.getDescription())
                        .build())
                .collect(Collectors.toList());

        feeTypeRepository.saveAll(feeTypes);

        return SchoolResponseDTO.builder()
                .schoolId(savedSchool.getSchoolId())
                .schoolName(savedSchool.getSchoolName())
                .location(savedSchool.getLocation())
                .ngbAccountNumber(savedSchool.getNgbAccountNumber())
                .ngbGlAccountConfig(savedSchool.getNgbGlAccountConfig())
                .registrationDate(savedSchool.getRegistrationDate())
                .isActive(savedSchool.getIsActive())
                .feeTypes(feeTypes)
                .build();
    }


    public boolean validateSchoolEligibility(School school){
        return school.getMinEnrolledStudents() >= school.getMinEnrolledStudents() &&
                school.getOperationalYears() >= school.getOperationalYears() &&
                school.getMinAnnualFeeCollection() >= school.getMinAnnualFeeCollection();
    }


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/StudentManagementService.java

package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.StudentRequestDTO;
import com.ngb.schoolfee.dto.StudentResponseDTO;
import com.ngb.schoolfee.exception.StudentManagementException;
import com.ngb.schoolfee.model.AuditLog;
import com.ngb.schoolfee.model.Customer;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.repository.AuditLogRepository;
import com.ngb.schoolfee.repository.CustomerRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class StudentManagementService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private AuditLogRepository auditLogRepository;


    @Autowired
    private NotificationService notificationService;



    @Transactional
    public StudentResponseDTO registerStudent(StudentRequestDTO studentRequestDTO, String customerId) {
        if (!studentRequestDTO.getStudentId().equals(studentRequestDTO.getStudentIdConfirm())) {
            throw new StudentManagementException("Student IDs do not match.");
        }

        Customer customer = customerRepository.findById(customerId).orElseThrow(() -> new StudentManagementException("Customer not found."));
        if (!customer.isActiveCardholder()) {
            throw new StudentManagementException("Only active credit cardholders can register students.");
        }

        School school = schoolRepository.findById(Long.valueOf(studentRequestDTO.getSchoolId()))
                .orElseThrow(() -> new StudentManagementException("School not found."));

        if (studentRepository.existsByStudentIdAndSchool_SchoolId(studentRequestDTO.getStudentId(), school.getSchoolId())) {
            throw new StudentManagementException("Student already registered with this ID for this school.");
        }


        Student student = Student.builder()
                .studentId(studentRequestDTO.getStudentId())
                .studentName(studentRequestDTO.getStudentName())
                .school(school)
                .registeredByCustomer(customer)
                .build();

        Student savedStudent = studentRepository.save(student);

        AuditLog auditLog = AuditLog.builder()
                .activityType("STUDENT_REGISTRATION_SUCCESS")
                .entityIdAffected(savedStudent.getStudentId())
                .entityType("STUDENT")
                .performedByUserOrSystem(customerId)
                .details("Student registered successfully: " + savedStudent.getStudentName())
                .successStatus(true)
                .channel("ONLINE_BANK