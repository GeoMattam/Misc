package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.FeeTypeRequestDTO;
import com.ngb.schoolfee.dto.SchoolRequestDTO;
import com.ngb.schoolfee.dto.SchoolResponseDTO;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.FeeType;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SchoolManagementService {

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private FeeTypeRepository feeTypeRepository;


    @Transactional
    public SchoolResponseDTO registerSchool(SchoolRequestDTO schoolRequestDTO) {
        if(schoolRepository.existsBySchoolNameAndLocation(schoolRequestDTO.getSchoolName(), schoolRequestDTO.getLocation())){
            throw new SchoolRegistrationException("School already registered with this name and location.");
        }

        School school = School.builder()
                .schoolName(schoolRequestDTO.getSchoolName())
                .location(schoolRequestDTO.getLocation())
                .ngbAccountNumber(schoolRequestDTO.getNgbAccountNumber())
                .ngbGlAccountConfig("GL-CONFIG-" + schoolRequestDTO.getSchoolName()) // Placeholder - actual GL mapping logic should be implemented
                .build();

        if(!school.applyBusinessRules()){
            throw new SchoolRegistrationException("School does not meet registration criteria.");
        }

        School savedSchool = schoolRepository.save(school);

        List<FeeType> feeTypes = schoolRequestDTO.getFeeTypes().stream()
                .map(feeTypeRequest -> FeeType.builder()
                        .school(savedSchool)
                        .feeTypeName(feeTypeRequest.getFeeTypeName())
                        .description(feeTypeRequest.getDescription())
                        .build())
                .collect(Collectors.toList());

        feeTypeRepository.saveAll(feeTypes);

        return SchoolResponseDTO.builder()
                .schoolId(savedSchool.getSchoolId())
                .schoolName(savedSchool.getSchoolName())
                .location(savedSchool.getLocation())
                .ngbAccountNumber(savedSchool.getNgbAccountNumber())
                .ngbGlAccountConfig(savedSchool.getNgbGlAccountConfig())
                .registrationDate(savedSchool.getRegistrationDate())
                .isActive(savedSchool.getIsActive())
                .feeTypes(feeTypes)
                .build();
    }


    public boolean validateSchoolEligibility(School school){
        return school.getMinEnrolledStudents() >= school.getMinEnrolledStudents() &&
                school.getOperationalYears() >= school.getOperationalYears() &&
                school.getMinAnnualFeeCollection() >= school.getMinAnnualFeeCollection();
    }


}
```

```java