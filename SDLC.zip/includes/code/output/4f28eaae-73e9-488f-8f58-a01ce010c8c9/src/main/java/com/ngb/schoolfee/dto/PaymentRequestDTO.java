package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequestDTO {
    private String customerId;
    private String studentSystemId;
    private String schoolId;
    private String feeTypeId;
    private String cardNumber;
    private double amount;
    private String remark;
    private String otp; //For online/mobile
    private String ivrTin; //For IVR
}
```

```java