package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentRequestDTO {
    private String studentName;
    private String studentId;
    private String studentIdConfirm;
    private String schoolId;
    private String otp; //For online/mobile
}
```

```java