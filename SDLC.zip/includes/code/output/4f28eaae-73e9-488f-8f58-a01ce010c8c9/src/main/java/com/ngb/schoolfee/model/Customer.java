package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CUSTOMER")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    private String customerId;

    @Column(nullable = false)
    private String customerName;

    @Column(nullable = false)
    private String contactInfo; //Phone or Email

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CustomerStatus status = CustomerStatus.ACTIVE;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CreditCard> creditCards;


    @OneToMany(mappedBy = "registeredByCustomer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Student> students;

    public boolean isActiveCardholder(){
        return this.creditCards != null && !this.creditCards.isEmpty() && this.status == CustomerStatus.ACTIVE;
    }
}
```

```java