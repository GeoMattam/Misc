package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.EPPStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPResponseDTO {
    private String eppRequestId;
    private EPPStatus status;
}
```

```java