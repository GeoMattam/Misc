package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "EPP_REQUEST", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"transaction_id"})
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false, unique = true)
    private Transaction transaction;

    @Column(nullable = false)
    private LocalDateTime requestDateTime = LocalDateTime.now();

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status = EPPStatus.PENDING;

    @Column
    private String rejectionReason;

    @Column(nullable = false)
    private Boolean noLoyaltyPointsFlag = true; // Business Rule

    @Column
    private LocalDateTime approvalDateTime;

    public void updateStatus(EPPStatus newStatus, String reason){
        this.status = newStatus;
        if(newStatus == EPPStatus.REJECTED){
            this.rejectionReason = reason;
        }
        this.approvalDateTime = LocalDateTime.now();
    }

}
```

```java