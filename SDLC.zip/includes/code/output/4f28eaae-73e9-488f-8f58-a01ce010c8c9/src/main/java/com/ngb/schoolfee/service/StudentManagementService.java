package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.StudentRequestDTO;
import com.ngb.schoolfee.dto.StudentResponseDTO;
import com.ngb.schoolfee.exception.StudentManagementException;
import com.ngb.schoolfee.model.AuditLog;
import com.ngb.schoolfee.model.Customer;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.repository.AuditLogRepository;
import com.ngb.schoolfee.repository.CustomerRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class StudentManagementService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private AuditLogRepository auditLogRepository;


    @Autowired
    private NotificationService notificationService;



    @Transactional
    public StudentResponseDTO registerStudent(StudentRequestDTO studentRequestDTO, String customerId) {
        if (!studentRequestDTO.getStudentId().equals(studentRequestDTO.getStudentIdConfirm())) {
            throw new StudentManagementException("Student IDs do not match.");
        }

        Customer customer = customerRepository.findById(customerId).orElseThrow(() -> new StudentManagementException("Customer not found."));
        if (!customer.isActiveCardholder()) {
            throw new StudentManagementException("Only active credit cardholders can register students.");
        }

        School school = schoolRepository.findById(Long.valueOf(studentRequestDTO.getSchoolId()))
                .orElseThrow(() -> new StudentManagementException("School not found."));

        if (studentRepository.existsByStudentIdAndSchool_SchoolId(studentRequestDTO.getStudentId(), school.getSchoolId())) {
            throw new StudentManagementException("Student already registered with this ID for this school.");
        }


        Student student = Student.builder()
                .studentId(studentRequestDTO.getStudentId())
                .studentName(studentRequestDTO.getStudentName())
                .school(school)
                .registeredByCustomer(customer)
                .build();

        Student savedStudent = studentRepository.save(student);

        AuditLog auditLog = AuditLog.builder()
                .activityType("STUDENT_REGISTRATION_SUCCESS")
                .entityIdAffected(savedStudent.getStudentId())
                .entityType("STUDENT")
                .performedByUserOrSystem(customerId)
                .details("Student registered successfully: " + savedStudent.getStudentName())
                .successStatus(true)
                .channel("ONLINE_BANK