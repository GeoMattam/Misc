```java
###FilePath: src/main/java/com/ngb/schoolfee/model/School.java

package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "school")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class School {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long schoolId;

    @Column(unique = true, nullable = false)
    private String schoolName;

    @Column(nullable = false)
    private String location;

    @Column(unique = true, nullable = false)
    private String ngbAccountNumber;

    @Column(nullable = false)
    private String ngbGlAccountConfig;

    @Column(nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();

    @Column(nullable = false)
    private boolean isActive = true;

    @Column(nullable = false)
    private int minEnrolledStudents = 1000;

    @Column(nullable = false)
    private int operationalYears = 3;

    @Column(nullable = false, precision = 18, scale = 2)
    private double minAnnualFeeCollection = 500000.00;

    @Column(nullable = false)
    private LocalDate operationalSince;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/FeeType.java

package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "fee_type")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feeTypeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(nullable = false)
    private String feeTypeName;

    private String description;

    @Column(nullable = false)
    private boolean isActive = true;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/Customer.java

package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "customer")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    @Column(nullable = false, unique = true)
    private String customerId;

    @Column(nullable = false)
    private String customerName;

    @Column(nullable = false)
    private String contactInfo;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CustomerStatus status = CustomerStatus.ACTIVE;


    public enum CustomerStatus{
        ACTIVE, INACTIVE, BLOCKED
    }


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/CreditCard.java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "credit_card")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditCard {

    @Id
    @Column(nullable = false, unique = true)
    private String cardToken;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @Column(nullable = false)
    private String cardLast4Digits;

    @Column(nullable = false)
    private String cardType;

    @Column(nullable = false)
    private LocalDate expiryDate;

    @Column(nullable = false, precision = 18, scale = 2)
    private double balance;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CreditCardStatus status = CreditCardStatus.ACTIVE;

    public enum CreditCardStatus{
        ACTIVE, INACTIVE, BLOCKED
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/Student.java

package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "student")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@IdClass(StudentId.class)
public class Student {

    @Id
    @Column(nullable = false)
    private String studentId;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(nullable = false)
    private String studentName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "registered_by_customer_id", nullable = false)
    private Customer registeredByCustomer;

    @Column(nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private StudentStatus status = StudentStatus.REGISTERED;


    public enum StudentStatus{
        REGISTERED, DE_REGISTERED
    }


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/StudentId.java
package com.ngb.schoolfee.model;

import java.io.Serializable;

public class StudentId implements Serializable {
    private String studentId;
    private Long schoolId;

    public StudentId(){}

    public StudentId(String studentId, Long schoolId){
        this.studentId = studentId;
        this.schoolId = schoolId;
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/Transaction.java

package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "transaction")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column(nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime transactionDateTime;

    @Column(nullable = false, precision = 18, scale = 2)
    private double amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_token", nullable = false)
    private CreditCard creditCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @Column(length = 20)
    private String remark;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status = TransactionStatus.PENDING;

    @Column(nullable = false, length = 40)
    private String postingDescription;

    @Column(nullable = false)
    private boolean isEppConverted = false;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private GlPostingStatus glPostingStatus = GlPostingStatus.PENDING;

    @Column(nullable = false)
    private boolean isLoyaltyEligible = true;

    private boolean ivrTinUsed = false;

    @Column(nullable = false)
    private String channelUsed;


    public enum TransactionStatus{
        PENDING, SUCCESS, FAILED, CANCELLED, PENDING_EPP, REJECTED
    }

    public enum GlPostingStatus{
        PENDING, POSTED, FAILED
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/EPPRequest.java

package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "epp_request")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@IdClass(EppRequestId.class)
public class EPPRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @Id
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false)
    private Transaction transaction;

    @Column(nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime requestDateTime;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status = EPPStatus.PENDING;

    private String rejectionReason;

    @UpdateTimestamp
    private LocalDateTime approvalDateTime;

    @Column(nullable = false)
    private boolean noLoyaltyPointsFlag = true;


    public enum EPPStatus{
        PENDING, APPROVED, REJECTED
    }

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/EppRequestId.java
package com.ngb.schoolfee.model;

import java.io.Serializable;

public class EppRequestId implements Serializable {
    private Long eppRequestId;
    private Long transactionId;

    public EppRequestId(){}

    public EppRequestId(Long eppRequestId, Long transactionId){
        this.eppRequestId = eppRequestId;
        this.transactionId = transactionId;
    }
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/AuditLog.java

package com.ngb.schoolfee.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "audit_log")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logId;

    @Column(nullable = false)
    private String activityType;

    private String entityIdAffected;

    private String entityType;

    @Column(nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime timestamp;

    private String performedByUserId;

    private String channel;

    @Column(nullable = false)
    private boolean successStatus = true;

    @Lob
    @JsonIgnore
    private String details;


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/SchoolRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SchoolRepository extends JpaRepository<School, Long> {

    Optional<School> findByNgbAccountNumber(String ngbAccountNumber);
    Optional<School> findBySchoolNameAndLocation(String schoolName, String location);
    boolean existsBySchoolNameAndLocation(String schoolName, String location);


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/FeeTypeRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.FeeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeeTypeRepository extends JpaRepository<FeeType, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/CustomerRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {
    Optional<Customer> findByCustomerId(String customerId);
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/CreditCardRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.CreditCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CreditCardRepository extends JpaRepository<CreditCard, String> {
    Optional<CreditCard> findByCardToken(String cardToken);
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/StudentRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.model.StudentId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, StudentId> {

    List<Student> findByRegisteredByCustomerCustomerId(String customerId);
    Optional<Student> findByStudentIdAndSchoolSchoolId(String studentId, Long schoolId);
    boolean existsByStudentIdAndSchoolSchoolId(String studentId, Long schoolId);

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/TransactionRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByCreditCardCustomerCustomerIdOrderByTransactionDateTimeDesc(String customerId);

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/EPPRequestRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.EPPRequest;
import com.ngb.schoolfee.model.EppRequestId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EPPRequestRepository extends JpaRepository<EPPRequest, EppRequestId> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/AuditLogRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/SchoolRequest.java

package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class SchoolRequest {
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private List<FeeTypeRequest> feeTypes;
    private LocalDate operationalSince;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/SchoolResponse.java

package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class SchoolResponse {
    private Long schoolId;
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private String ngbGlAccountConfig;
    private LocalDateTime registrationDate;
    private boolean isActive;
    private List<FeeTypeResponse> feeTypes;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/FeeTypeRequest.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class FeeTypeRequest {
    private String feeTypeName;
    private String description;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/FeeTypeResponse.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class FeeTypeResponse {
    private Long feeTypeId;
    private String feeTypeName;
    private String description;
    private boolean isActive;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/StudentRequest.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class StudentRequest {
    private String studentName;
    private String studentId;
    private String studentIdConfirm;
    private Long schoolId;
    private String otp; //for online/mobile
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/StudentResponse.java

package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.model.Student;
import lombok.Data;

@Data
public class StudentResponse {
    private String studentSystemId;
    private String studentName;
    private String studentId;
    private Long schoolId;
    private String schoolName;
    private String status;


    public StudentResponse(Student student, String schoolName){
        this.studentSystemId = student.getStudentId();
        this.studentName = student.getStudentName();
        this.studentId = student.getStudentId();
        this.schoolId = student.getSchool().getSchoolId();
        this.schoolName = schoolName;
        this.status = student.getStatus().toString();
    }
}

```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/PaymentRequest.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class PaymentRequest {
    private String customerId;
    private String studentSystemId;
    private Long schoolId;
    private Long feeTypeId;
    private String cardToken;
    private double amount;
    private String remark;
    private String otp; //For online/mobile
    private String ivrTin; // For IVR
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/PaymentResponse.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class PaymentResponse {
    private Long transactionId;
    private String status;
    private String referenceId;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/EPPRequest.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class EPPRequest {
    private Long transactionId;
    private String customerId;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/EPPResponse.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class EPPResponse {
    private Long eppRequestId;
    private String status;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/GlPostingRequest.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class GlPostingRequest {
    private Long transactionId;
    private String cardType;
    private double amount;
    private String description;
    private String schoolAccountNumber;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/GlPostingResponse.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class GlPostingResponse {
    private Long postingId;
    private String status;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/SmsRequest.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class SmsRequest {
    private String phoneNumber;
    private String message;
    private String type;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/SmsResponse.java

package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class SmsResponse {
    private Long notificationId;
    private String status;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/TransactionHistoryResponse.java

package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TransactionHistoryResponse {
    private Long transactionId;
    private LocalDateTime date;
    private double amount;
    private String studentName;
    private String schoolName;
    private String feeTypeName;
    private String remark;
    private String status;
}
```


```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/TransactionLogResponse.java
package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TransactionLogResponse {
    private Long transactionId;
    private LocalDateTime transactionDateTime;
    private double amount;
    private String studentName;
    private String schoolName;
    private String feeTypeName;
    private String remark;
    private String status;
    private String postingDescription;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/SchoolService.java

package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.FeeTypeRequest;
import com.ngb.schoolfee.dto.SchoolRequest;
import com.ngb.schoolfee.dto.SchoolResponse;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SchoolService {

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private FeeTypeRepository feeTypeRepository;


    @Transactional
    public SchoolResponse registerSchool(SchoolRequest schoolRequest) {
        if(schoolRepository.existsBySchoolNameAndLocation(schoolRequest.getSchoolName(), schoolRequest.getLocation())){
            throw new SchoolRegistrationException("School with this name and location already exists.");
        }
        School school = School.builder()
                .schoolName(schoolRequest.getSchoolName())
                .location(schoolRequest.getLocation())
                .ngbAccountNumber(schoolRequest.getNgbAccountNumber())
                .operationalSince(schoolRequest.getOperationalSince())
                .build();

        school = schoolRepository.save(school);

        if(schoolRequest.getFeeTypes() != null){
            List<com.ngb.schoolfee.model.FeeType> feeTypes = schoolRequest.getFeeTypes().stream()
                    .map(feeTypeRequest -> com.ngb.schoolfee.model.FeeType.builder()
                            .school(school)
                            .feeTypeName(feeTypeRequest.getFeeTypeName())
                            .description(feeTypeRequest.getDescription())
                            .build()
                    )
                    .collect(Collectors.toList());

            feeTypeRepository.saveAll(feeTypes);
        }

        return mapToSchoolResponse(school);

    }

    private SchoolResponse mapToSchoolResponse(School school) {
        SchoolResponse schoolResponse = new SchoolResponse();
        schoolResponse.setSchoolId(school.getSchoolId());
        schoolResponse.setSchoolName(school.getSchoolName());
        schoolResponse.setLocation(school.getLocation());
        schoolResponse.setNgbAccountNumber(school.getNgbAccountNumber());
        schoolResponse.setNgbGlAccountConfig(school.getNgbGlAccountConfig());
        schoolResponse.setRegistrationDate(school.getRegistrationDate());
        schoolResponse.setIsActive(school.isActive());
        //add fee types mapping here
        return schoolResponse;
    }


    public SchoolResponse getSchoolDetails(Long schoolId){
        School school = schoolRepository.findById(schoolId).orElseThrow(
                () -> new SchoolRegistrationException("School with ID " + schoolId + " not found")
        );

        return mapToSchoolResponse(school);
    }

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/StudentService.java

package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.StudentRequest;
import com.ngb.schoolfee.dto.StudentResponse;
import com.ngb.schoolfee.exception.StudentRegistrationException;
import com.ngb.schoolfee.model.Customer;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.repository.CustomerRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private CustomerRepository customerRepository;


    @Transactional
    public StudentResponse registerStudent(StudentRequest studentRequest, String customerId) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(
                ()-> new StudentRegistrationException("Customer not found with ID: " + customerId)
        );

        if(!customer.getStatus().toString().equals("ACTIVE")){
            throw new StudentRegistrationException("Customer is not active.");
        }

        if(!studentRequest.getStudentId().equals(studentRequest.getStudentIdConfirm())){
            throw new StudentRegistrationException("Student IDs do not match.");
        }
        School school = schoolRepository.findById(studentRequest.getSchoolId()).orElseThrow(
                () -> new StudentRegistrationException("School not found with ID: " + studentRequest.getSchoolId())
        );

        if(studentRepository.existsByStudentIdAndSchoolSchoolId(studentRequest.getStudentId(), school.getSchoolId())){
            throw new StudentRegistrationException("Student already registered with this ID in this school.");
        }

        Student student = Student.builder()
                .studentId(studentRequest.getStudentId())
                .studentName(studentRequest.getStudentName())
                .school(school)
                .registeredByCustomer(customer)
                .build();

        student = studentRepository.save(student);

        return new StudentResponse(student, school.getSchoolName());
    }


    public List<StudentResponse> getStudentsByCustomerId(String customerId){
        Customer customer = customerRepository.findById(customerId).orElseThrow(
                ()-> new StudentRegistrationException("Customer not found with ID: " + customerId)
        );

        List<Student> students = studentRepository.findByRegisteredByCustomerCustomerId(customerId);

        return students.stream().map(student -> new StudentResponse(student, student.getSchool().getSchoolName()))
                .collect(Collectors.toList());
    }

    @Transactional
    public void amendStudent(String studentId, Long schoolId, StudentRequest studentRequest, String customerId) {
        Student student = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId)
                .orElseThrow(() -> new StudentRegistrationException("Student not found"));


        //add validation, authorization
        student.setStudentName(studentRequest.getStudentName());
        studentRepository.save(student);

    }

    @Transactional
    public void deregisterStudent(String studentId, Long schoolId){
        Student student = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId).orElseThrow(
                ()-> new StudentRegistrationException("Student with ID " + studentId + " not found in this school")
        );

        student.setStatus(Student.StudentStatus.DE_REGISTERED);
        studentRepository.save(student);
    }


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/PaymentService.java

package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.PaymentRequest;
import com.ngb.schoolfee.dto.PaymentResponse;
import com.ngb.schoolfee.exception.PaymentException;
import com.ngb.schoolfee.model.CreditCard;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.model.Transaction;
import com.ngb.schoolfee.repository.CreditCardRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import com.ngb.schoolfee.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CreditCardRepository creditCardRepository;

    @Autowired
    private FinancialPostingService financialPostingService;

    @Autowired
    private NotificationService notificationService;



    @Transactional
    public PaymentResponse initiateFeePayment(PaymentRequest paymentRequest) {
        Student student = studentRepository.findByStudentIdAndSchoolSchoolId(paymentRequest.getStudentSystemId(), paymentRequest.getSchoolId())
                .orElseThrow(() -> new PaymentException("Student not found"));

        CreditCard creditCard = creditCardRepository.findByCardToken(paymentRequest.getCardToken())
                .orElseThrow(() -> new PaymentException("Invalid Card"));

        if(creditCard.getBalance() < paymentRequest.getAmount()){
            throw new PaymentException("Insufficient balance.");
        }

        Transaction transaction = Transaction.builder()
                .amount(paymentRequest.getAmount())
                .remark(paymentRequest.getRemark())
                .creditCard(creditCard)
                .student(student)
                .school(student.getSchool())
                .feeType(student.getSchool().getFeeTypes().stream()
                        .filter(feeType -> feeType.getFeeTypeId().equals(paymentRequest.getFeeTypeId()))
                        .findFirst().orElseThrow(()-> new PaymentException("Invalid fee type")))
                .channelUsed("ONLINE_BANKING") //or MOBILE_BANKING, IVR
                .build();

        transaction = transactionRepository.save(transaction);

        financialPostingService.postTransaction(transaction);

        //send SMS Confirmation
        String smsMessage = "Your payment of " + paymentRequest.getAmount() + " for " + student.getStudentName() +
                " has been processed. Transaction ID:" + transaction.getTransactionId();

        notificationService.sendSms(creditCard.getCustomer().getContactInfo(), smsMessage, "CONFIRMATION");



        PaymentResponse paymentResponse = new PaymentResponse();
        paymentResponse.setTransactionId(transaction.getTransactionId());
        paymentResponse.setStatus(transaction.getStatus().toString());
        paymentResponse.setReferenceId(transaction.getTransactionId().toString());

        return paymentResponse;
    }

    public List<Transaction> getPaymentHistory(String customerId){
        return transactionRepository.findByCreditCardCustomerCustomerIdOrderByTransactionDateTimeDesc(customerId);
    }

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/FinancialPostingService.java

package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.GlPostingRequest;
import com.ngb.schoolfee.dto.GlPostingResponse;
import com.ngb.schoolfee.exception.FinancialPostingException;
import com.ngb.schoolfee.model.Transaction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FinancialPostingService {


    @Transactional
    public void postTransaction(Transaction transaction){
        GlPostingRequest glDebitRequest = mapToGlDebitRequest(transaction);
        GlPostingResponse glDebitResponse = postGlTransaction(glDebitRequest);

        if(!glDebitResponse.getStatus().equals("POSTED")){
            throw new FinancialPostingException("GL Debit Failed");
        }

        GlPostingRequest glCreditRequest = mapToGlCreditRequest(transaction);
        GlPostingResponse glCreditResponse = postGlTransaction(glCreditRequest);

        if(!glCreditResponse.getStatus().equals("POSTED")){
            throw new FinancialPostingException("GL Credit Failed");
        }

        transaction.setGlPostingStatus(Transaction.GlPostingStatus.POSTED);

    }

    private GlPostingRequest mapToGlDebitRequest(Transaction transaction){
        GlPostingRequest request = new GlPostingRequest();
        request.setAmount(transaction.getAmount());
        request.setTransactionId(transaction.getTransactionId());
        request.setDescription(transaction.getPostingDescription());
        request.setCardType(transaction.getCreditCard().getCardType());
        request.setSchoolAccountNumber(transaction.getSchool().getNgb