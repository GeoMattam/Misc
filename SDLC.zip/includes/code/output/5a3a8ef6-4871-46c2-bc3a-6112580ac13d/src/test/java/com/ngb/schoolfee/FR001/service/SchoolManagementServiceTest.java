```java
package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.FeeTypeRequest;
import com.ngb.schoolfee.FR001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.FR001.exception.SchoolRegistrationException;
import com.ngb.schoolfee.FR001.model.School;
import com.ngb.schoolfee.FR001.repository.SchoolRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SchoolManagementServiceTest {

    @Mock
    private SchoolRepository schoolRepository;

    @InjectMocks
    private SchoolManagementService schoolManagementService;


    @Test
    void registerSchool_success() {
        SchoolRegistrationRequest request = new SchoolRegistrationRequest();
        request.setSchoolName("Test School");
        request.setLocation("Test Location");
        request.setNgbAccountNumber("1234567890");
        request.setFeeTypes(List.of(new FeeTypeRequest()));

        when(schoolRepository.existsByNgbAccountNumber(request.getNgbAccountNumber())).thenReturn(false);
        when(schoolRepository.save(any(School.class))).thenReturn(School.builder().schoolId(1L).build());


        SchoolRegistrationResponse response = schoolManagementService.registerSchool(request);

        assertNotNull(response);
        assertEquals("REGISTERED", response.getStatus());
        assertEquals("School registered successfully.", response.getMessage());
        assertEquals("1", response.getSchoolId());
        verify(schoolRepository, times(1)).save(any(School.class));
    }

    @Test
    void registerSchool_existingAccount() {
        SchoolRegistrationRequest request = new SchoolRegistrationRequest();
        request.setNgbAccountNumber("1234567890");
        when(schoolRepository.existsByNgbAccountNumber(request.getNgbAccountNumber())).thenReturn(true);


        assertThrows(SchoolRegistrationException.class, () -> schoolManagementService.registerSchool(request));
        verify(schoolRepository, never()).save(any(School.class));

    }

}
```