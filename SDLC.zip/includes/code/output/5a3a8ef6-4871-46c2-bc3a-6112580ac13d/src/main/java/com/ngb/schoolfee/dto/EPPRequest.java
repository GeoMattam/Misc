package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class EPPRequest {
    private Long transactionId;
    private String customerId;
}
```

```java