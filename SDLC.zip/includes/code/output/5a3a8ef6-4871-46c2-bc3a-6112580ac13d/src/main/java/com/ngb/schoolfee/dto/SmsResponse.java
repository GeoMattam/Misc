package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class SmsResponse {
    private Long notificationId;
    private String status;
}
```

```java