package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.StudentRequest;
import com.ngb.schoolfee.dto.StudentResponse;
import com.ngb.schoolfee.exception.StudentRegistrationException;
import com.ngb.schoolfee.model.Customer;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.repository.CustomerRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private CustomerRepository customerRepository;


    @Transactional
    public StudentResponse registerStudent(StudentRequest studentRequest, String customerId) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(
                ()-> new StudentRegistrationException("Customer not found with ID: " + customerId)
        );

        if(!customer.getStatus().toString().equals("ACTIVE")){
            throw new StudentRegistrationException("Customer is not active.");
        }

        if(!studentRequest.getStudentId().equals(studentRequest.getStudentIdConfirm())){
            throw new StudentRegistrationException("Student IDs do not match.");
        }
        School school = schoolRepository.findById(studentRequest.getSchoolId()).orElseThrow(
                () -> new StudentRegistrationException("School not found with ID: " + studentRequest.getSchoolId())
        );

        if(studentRepository.existsByStudentIdAndSchoolSchoolId(studentRequest.getStudentId(), school.getSchoolId())){
            throw new StudentRegistrationException("Student already registered with this ID in this school.");
        }

        Student student = Student.builder()
                .studentId(studentRequest.getStudentId())
                .studentName(studentRequest.getStudentName())
                .school(school)
                .registeredByCustomer(customer)
                .build();

        student = studentRepository.save(student);

        return new StudentResponse(student, school.getSchoolName());
    }


    public List<StudentResponse> getStudentsByCustomerId(String customerId){
        Customer customer = customerRepository.findById(customerId).orElseThrow(
                ()-> new StudentRegistrationException("Customer not found with ID: " + customerId)
        );

        List<Student> students = studentRepository.findByRegisteredByCustomerCustomerId(customerId);

        return students.stream().map(student -> new StudentResponse(student, student.getSchool().getSchoolName()))
                .collect(Collectors.toList());
    }

    @Transactional
    public void amendStudent(String studentId, Long schoolId, StudentRequest studentRequest, String customerId) {
        Student student = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId)
                .orElseThrow(() -> new StudentRegistrationException("Student not found"));


        //add validation, authorization
        student.setStudentName(studentRequest.getStudentName());
        studentRepository.save(student);

    }

    @Transactional
    public void deregisterStudent(String studentId, Long schoolId){
        Student student = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId).orElseThrow(
                ()-> new StudentRegistrationException("Student with ID " + studentId + " not found in this school")
        );

        student.setStatus(Student.StudentStatus.DE_REGISTERED);
        studentRepository.save(student);
    }


}
```

```java