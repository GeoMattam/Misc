package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.model.StudentId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, StudentId> {

    List<Student> findByRegisteredByCustomerCustomerId(String customerId);
    Optional<Student> findByStudentIdAndSchoolSchoolId(String studentId, Long schoolId);
    boolean existsByStudentIdAndSchoolSchoolId(String studentId, Long schoolId);

}
```

```java