```java
package com.ngb.schoolfee.FR001.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "schools")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class School {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long schoolId;

    @NotBlank(message = "School name is required")
    @Size(max = 255, message = "School name must be less than 255 characters")
    private String schoolName;

    @NotBlank(message = "Location is required")
    @Size(max = 255, message = "Location must be less than 255 characters")
    private String location;

    @NotBlank(message = "NGB account number is required")
    @Size(max = 50, message = "NGB account number must be less than 50 characters")
    private String ngbAccountNumber;

    @NotBlank(message = "NGB GL account configuration is required")
    @Size(max = 100, message = "NGB GL account configuration must be less than 100 characters")
    private String ngbGlAccountConfig;

    @NotNull(message = "Operational since date is required")
    private LocalDate operationalSince;

    private boolean isActive = true;

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;


    @CreationTimestamp
    @Column(updatable = false)
    private Date registrationDate;

    @UpdateTimestamp
    private Date lastUpdatedDate;

    @NotNull(message = "Minimum enrolled students is required")
    private Integer minEnrolledStudents;

    @NotNull(message = "Minimum annual fee collection is required")
    private BigDecimal minAnnualFeeCollection;
}
```