package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.PaymentRequest;
import com.ngb.schoolfee.dto.PaymentResponse;
import com.ngb.schoolfee.exception.PaymentException;
import com.ngb.schoolfee.model.CreditCard;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.model.Transaction;
import com.ngb.schoolfee.repository.CreditCardRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import com.ngb.schoolfee.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CreditCardRepository creditCardRepository;

    @Autowired
    private FinancialPostingService financialPostingService;

    @Autowired
    private NotificationService notificationService;



    @Transactional
    public PaymentResponse initiateFeePayment(PaymentRequest paymentRequest) {
        Student student = studentRepository.findByStudentIdAndSchoolSchoolId(paymentRequest.getStudentSystemId(), paymentRequest.getSchoolId())
                .orElseThrow(() -> new PaymentException("Student not found"));

        CreditCard creditCard = creditCardRepository.findByCardToken(paymentRequest.getCardToken())
                .orElseThrow(() -> new PaymentException("Invalid Card"));

        if(creditCard.getBalance() < paymentRequest.getAmount()){
            throw new PaymentException("Insufficient balance.");
        }

        Transaction transaction = Transaction.builder()
                .amount(paymentRequest.getAmount())
                .remark(paymentRequest.getRemark())
                .creditCard(creditCard)
                .student(student)
                .school(student.getSchool())
                .feeType(student.getSchool().getFeeTypes().stream()
                        .filter(feeType -> feeType.getFeeTypeId().equals(paymentRequest.getFeeTypeId()))
                        .findFirst().orElseThrow(()-> new PaymentException("Invalid fee type")))
                .channelUsed("ONLINE_BANKING") //or MOBILE_BANKING, IVR
                .build();

        transaction = transactionRepository.save(transaction);

        financialPostingService.postTransaction(transaction);

        //send SMS Confirmation
        String smsMessage = "Your payment of " + paymentRequest.getAmount() + " for " + student.getStudentName() +
                " has been processed. Transaction ID:" + transaction.getTransactionId();

        notificationService.sendSms(creditCard.getCustomer().getContactInfo(), smsMessage, "CONFIRMATION");



        PaymentResponse paymentResponse = new PaymentResponse();
        paymentResponse.setTransactionId(transaction.getTransactionId());
        paymentResponse.setStatus(transaction.getStatus().toString());
        paymentResponse.setReferenceId(transaction.getTransactionId().toString());

        return paymentResponse;
    }

    public List<Transaction> getPaymentHistory(String customerId){
        return transactionRepository.findByCreditCardCustomerCustomerIdOrderByTransactionDateTimeDesc(customerId);
    }

}
```

```java