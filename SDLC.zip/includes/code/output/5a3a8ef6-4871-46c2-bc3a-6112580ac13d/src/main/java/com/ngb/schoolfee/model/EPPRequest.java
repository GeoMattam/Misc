package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "epp_request")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@IdClass(EppRequestId.class)
public class EPPRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @Id
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false)
    private Transaction transaction;

    @Column(nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime requestDateTime;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status = EPPStatus.PENDING;

    private String rejectionReason;

    @UpdateTimestamp
    private LocalDateTime approvalDateTime;

    @Column(nullable = false)
    private boolean noLoyaltyPointsFlag = true;


    public enum EPPStatus{
        PENDING, APPROVED, REJECTED
    }

}
```

```java