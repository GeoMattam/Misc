package com.ngb.schoolfee.model;

import java.io.Serializable;

public class StudentId implements Serializable {
    private String studentId;
    private Long schoolId;

    public StudentId(){}

    public StudentId(String studentId, Long schoolId){
        this.studentId = studentId;
        this.schoolId = schoolId;
    }
}
```

```java