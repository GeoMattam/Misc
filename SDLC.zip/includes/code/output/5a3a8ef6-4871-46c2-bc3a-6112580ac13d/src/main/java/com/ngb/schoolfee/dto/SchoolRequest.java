package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class SchoolRequest {
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private List<FeeTypeRequest> feeTypes;
    private LocalDate operationalSince;
}
```

```java