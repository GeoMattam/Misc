package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "transaction")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column(nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime transactionDateTime;

    @Column(nullable = false, precision = 18, scale = 2)
    private double amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_token", nullable = false)
    private CreditCard creditCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @Column(length = 20)
    private String remark;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status = TransactionStatus.PENDING;

    @Column(nullable = false, length = 40)
    private String postingDescription;

    @Column(nullable = false)
    private boolean isEppConverted = false;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private GlPostingStatus glPostingStatus = GlPostingStatus.PENDING;

    @Column(nullable = false)
    private boolean isLoyaltyEligible = true;

    private boolean ivrTinUsed = false;

    @Column(nullable = false)
    private String channelUsed;


    public enum TransactionStatus{
        PENDING, SUCCESS, FAILED, CANCELLED, PENDING_EPP, REJECTED
    }

    public enum GlPostingStatus{
        PENDING, POSTED, FAILED
    }
}
```

```java