package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.GlPostingRequest;
import com.ngb.schoolfee.dto.GlPostingResponse;
import com.ngb.schoolfee.exception.FinancialPostingException;
import com.ngb.schoolfee.model.Transaction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FinancialPostingService {


    @Transactional
    public void postTransaction(Transaction transaction){
        GlPostingRequest glDebitRequest = mapToGlDebitRequest(transaction);
        GlPostingResponse glDebitResponse = postGlTransaction(glDebitRequest);

        if(!glDebitResponse.getStatus().equals("POSTED")){
            throw new FinancialPostingException("GL Debit Failed");
        }

        GlPostingRequest glCreditRequest = mapToGlCreditRequest(transaction);
        GlPostingResponse glCreditResponse = postGlTransaction(glCreditRequest);

        if(!glCreditResponse.getStatus().equals("POSTED")){
            throw new FinancialPostingException("GL Credit Failed");
        }

        transaction.setGlPostingStatus(Transaction.GlPostingStatus.POSTED);

    }

    private GlPostingRequest mapToGlDebitRequest(Transaction transaction){
        GlPostingRequest request = new GlPostingRequest();
        request.setAmount(transaction.getAmount());
        request.setTransactionId(transaction.getTransactionId());
        request.setDescription(transaction.getPostingDescription());
        request.setCardType(transaction.getCreditCard().getCardType());
        request.setSchoolAccountNumber(transaction.getSchool().getNgb