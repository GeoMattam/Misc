package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.FeeTypeRequest;
import com.ngb.schoolfee.dto.SchoolRequest;
import com.ngb.schoolfee.dto.SchoolResponse;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SchoolService {

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private FeeTypeRepository feeTypeRepository;


    @Transactional
    public SchoolResponse registerSchool(SchoolRequest schoolRequest) {
        if(schoolRepository.existsBySchoolNameAndLocation(schoolRequest.getSchoolName(), schoolRequest.getLocation())){
            throw new SchoolRegistrationException("School with this name and location already exists.");
        }
        School school = School.builder()
                .schoolName(schoolRequest.getSchoolName())
                .location(schoolRequest.getLocation())
                .ngbAccountNumber(schoolRequest.getNgbAccountNumber())
                .operationalSince(schoolRequest.getOperationalSince())
                .build();

        school = schoolRepository.save(school);

        if(schoolRequest.getFeeTypes() != null){
            List<com.ngb.schoolfee.model.FeeType> feeTypes = schoolRequest.getFeeTypes().stream()
                    .map(feeTypeRequest -> com.ngb.schoolfee.model.FeeType.builder()
                            .school(school)
                            .feeTypeName(feeTypeRequest.getFeeTypeName())
                            .description(feeTypeRequest.getDescription())
                            .build()
                    )
                    .collect(Collectors.toList());

            feeTypeRepository.saveAll(feeTypes);
        }

        return mapToSchoolResponse(school);

    }

    private SchoolResponse mapToSchoolResponse(School school) {
        SchoolResponse schoolResponse = new SchoolResponse();
        schoolResponse.setSchoolId(school.getSchoolId());
        schoolResponse.setSchoolName(school.getSchoolName());
        schoolResponse.setLocation(school.getLocation());
        schoolResponse.setNgbAccountNumber(school.getNgbAccountNumber());
        schoolResponse.setNgbGlAccountConfig(school.getNgbGlAccountConfig());
        schoolResponse.setRegistrationDate(school.getRegistrationDate());
        schoolResponse.setIsActive(school.isActive());
        //add fee types mapping here
        return schoolResponse;
    }


    public SchoolResponse getSchoolDetails(Long schoolId){
        School school = schoolRepository.findById(schoolId).orElseThrow(
                () -> new SchoolRegistrationException("School with ID " + schoolId + " not found")
        );

        return mapToSchoolResponse(school);
    }

}
```

```java