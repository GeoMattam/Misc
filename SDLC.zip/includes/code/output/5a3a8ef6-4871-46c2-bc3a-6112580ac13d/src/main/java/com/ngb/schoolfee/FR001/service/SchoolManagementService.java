```java
package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.FR001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.FR001.exception.SchoolRegistrationException;
import com.ngb.schoolfee.FR001.model.School;
import com.ngb.schoolfee.FR001.repository.SchoolRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class SchoolManagementService {
    private final SchoolRepository schoolRepository;
    private static final Logger logger = LoggerFactory.getLogger(SchoolManagementService.class);

    public SchoolManagementService(SchoolRepository schoolRepository) {
        this.schoolRepository = schoolRepository;
    }

    @Transactional
    public SchoolRegistrationResponse registerSchool(SchoolRegistrationRequest request) {
        if (schoolRepository.existsByNgbAccountNumber(request.getNgbAccountNumber())) {
            throw new SchoolRegistrationException("School with this NGB account number already exists.");
        }

        School school = School.builder()
                .schoolName(request.getSchoolName())
                .location(request.getLocation())
                .ngbAccountNumber(request.getNgbAccountNumber())
                .ngbGlAccountConfig("GL-ACCOUNT-AUTO-CONFIGURED") // Placeholder, needs actual logic
                .operationalSince(LocalDate.now().minusYears(3)) // Assume 3 years ago for simplicity
                .minEnrolledStudents(1000)
                .minAnnualFeeCollection(new java.math.BigDecimal("500000.00"))
                .feeTypes(request.getFeeTypes().stream().map(this::createFeeType).collect(Collectors.toList()))
                .build();

        School savedSchool = schoolRepository.save(school);
        logger.info("School registered successfully: {}", savedSchool);

        SchoolRegistrationResponse response = new SchoolRegistrationResponse();
        response.setSchoolId(String.valueOf(savedSchool.getSchoolId()));
        response.setStatus("REGISTERED");
        response.setMessage("School registered successfully.");
        return response;
    }

    private com.ngb.schoolfee.FR001.model.FeeType createFeeType(FeeTypeRequest request) {
        return com.ngb.schoolfee.FR001.model.FeeType.builder()
                .feeTypeName(request.getName())
                .description(request.getDescription())
                .build();

    }

}

```