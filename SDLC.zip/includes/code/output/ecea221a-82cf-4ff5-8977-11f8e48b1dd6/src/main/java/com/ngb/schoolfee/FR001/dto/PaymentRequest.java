package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Data
public class PaymentRequest {
    @NotBlank
    private String customerId;

    @NotBlank
    private String studentSystemId;

    @NotBlank
    private String schoolId;

    @NotBlank
    private String feeTypeId;

    @NotBlank
    private String cardNumber;

    @NotNull
    @Positive
    private Double amount;

    @Size(max = 20)
    private String remark;

    private String otp; // For Online/Mobile
    private String ivrTin; // For IVR

}