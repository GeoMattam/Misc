package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @NotNull
    private LocalDateTime transactionDateTime = LocalDateTime.now();

    @NotNull
    private Double amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_number", nullable = false)
    private CreditCard creditCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_system_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @Size(max = 20)
    private String remark;

    @NotBlank
    private String status; // SUCCESS, FAILED, PENDING_EPP, CANCELLED

    @NotBlank
    @Size(max = 40)
    private String postingDescription;

    private Boolean isEPPConverted = false;

    @NotBlank
    private String glPostingStatus; // PENDING, POSTED, FAILED

    private Boolean isLoyaltyEligible = true; //Default: eligible. No loyalty points if converted to EPP

    // Add other fields as per requirements (e.g., unique reference ID, etc.)

}