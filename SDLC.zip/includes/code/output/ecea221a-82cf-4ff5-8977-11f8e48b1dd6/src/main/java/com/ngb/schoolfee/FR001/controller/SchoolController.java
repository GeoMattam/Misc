package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.FR001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.FR001.service.SchoolService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/schools")
public class SchoolController {

    private final SchoolService schoolService;

    public SchoolController(SchoolService schoolService) {
        this.schoolService = schoolService;
    }

    @PostMapping
    public ResponseEntity<SchoolRegistrationResponse> registerSchool(
            @RequestBody @Valid SchoolRegistrationRequest schoolRegistrationRequest) {
        SchoolRegistrationResponse response = schoolService.registerSchool(schoolRegistrationRequest);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }


    // Add other endpoints for school management as needed (e.g., GET, PUT, DELETE)
}