package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
public class FeeTypeRequest {
    @NotBlank
    @Size(max = 100)
    private String feeTypeName;
    @Size(max = 255)
    private String description;
}