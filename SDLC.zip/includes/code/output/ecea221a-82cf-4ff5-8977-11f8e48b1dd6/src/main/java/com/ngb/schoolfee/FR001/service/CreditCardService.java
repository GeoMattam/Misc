package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.model.CreditCard;
import com.ngb.schoolfee.FR001.repository.CreditCardRepository;
import org.springframework.stereotype.Service;

@Service
public class CreditCardService {

    private final CreditCardRepository creditCardRepository;

    public CreditCardService(CreditCardRepository creditCardRepository) {
        this.creditCardRepository = creditCardRepository;
    }

    public CreditCard findByCardNumber(String cardNumber){
        return creditCardRepository.findById(cardNumber).orElse(null);
    }

    //Add other methods as needed
}