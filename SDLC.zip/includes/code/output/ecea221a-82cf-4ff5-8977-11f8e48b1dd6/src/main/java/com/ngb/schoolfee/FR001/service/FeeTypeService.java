package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.FeeTypeRequest;
import com.ngb.schoolfee.FR001.model.FeeType;
import com.ngb.schoolfee.FR001.model.School;
import com.ngb.schoolfee.FR001.repository.FeeTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FeeTypeService {

    private final FeeTypeRepository feeTypeRepository;

    public FeeTypeService(FeeTypeRepository feeTypeRepository) {
        this.feeTypeRepository = feeTypeRepository;
    }

    @Transactional
    public void createFeeTypes(School school, List<FeeTypeRequest> feeTypeRequests){
        List<FeeType> feeTypes = feeTypeRequests.stream()
                .map(req -> FeeType.builder()
                        .feeTypeName(req.getFeeTypeName())
                        .description(req.getDescription())
                        .school(school)
                        .build())
                .collect(Collectors.toList());
        feeTypeRepository.saveAll(feeTypes);
    }

    // Add other service methods as needed
}