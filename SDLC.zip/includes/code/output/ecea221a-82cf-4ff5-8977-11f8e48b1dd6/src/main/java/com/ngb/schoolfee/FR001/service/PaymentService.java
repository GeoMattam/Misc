package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.PaymentRequest;
import com.ngb.schoolfee.FR001.dto.PaymentResponse;
import com.ngb.schoolfee.FR001.model.Transaction;
import com.ngb.schoolfee.FR001.repository.TransactionRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PaymentService {

    private final TransactionRepository transactionRepository;
    private final StudentService studentService;
    private final CreditCardService creditCardService;
    private final FinancialPostingService financialPostingService;
    private final NotificationService notificationService;

    public PaymentService(TransactionRepository transactionRepository, StudentService studentService,
                          CreditCardService creditCardService, FinancialPostingService financialPostingService,
                          NotificationService notificationService) {
        this.transactionRepository = transactionRepository;
        this.studentService = studentService;
        this.creditCardService = creditCardService;
        this.financialPostingService = financialPostingService;
        this.notificationService = notificationService;
    }

    @Transactional
    public PaymentResponse initiatePayment(PaymentRequest request) {
        //Implement Payment initiation logic here
        //Validate input data
        //Check student registration status
        //Check card details
        //Check balance
        //Process Payment
        //Send SMS
        //Update transaction status
        //Log audit entry

        PaymentResponse response = new PaymentResponse();
        Transaction transaction = Transaction.builder()
                .amount(request.getAmount())
                .creditCard(creditCardService.findByCardNumber(request.getCardNumber()))
                .student(studentService.getStudentById(Long.parseLong(request.getStudentSystemId())))
                .school(studentService.getStudentById(Long.parseLong(request.getStudentSystemId())).getSchool())
                .feeType(studentService.getStudentById(Long.parseLong(request.getStudentSystemId())).getSchool().getFeeTypes().stream().filter(f -> f.getFeeTypeName().equals(request.getFeeTypeId())).findFirst().orElse(null))
                .remark(request.getRemark())
                .status("PENDING")
                .glPostingStatus("PENDING")
                .postingDescription("Fee payment for " + studentService.getStudentById(Long.parseLong(request.getStudentSystemId())).getStudentName() + " at " + studentService.getStudentById(Long.parseLong(request.getStudentSystemId())).getSchool().getSchoolName())
                .build();
        transaction = transactionRepository.save(transaction);
        financialPostingService.postTransactionGL(transaction);
        response.setTransactionId(String.valueOf(transaction.getTransactionId()));
        response.setStatus("SUCCESS");
        notificationService.sendSMS(transaction.getCreditCard().getCustomer().getContactInfo(), "Payment confirmation for " + transaction.getAmount());
        return response;
    }

    public ResponseEntity<?> getPaymentHistory(String customerId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Transaction> transactions = transactionRepository.findAll(pageable);
        return ResponseEntity.ok(transactions);
    }
}