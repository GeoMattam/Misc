package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.FR001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.FR001.exception.SchoolRegistrationException;
import com.ngb.schoolfee.FR001.model.School;
import com.ngb.schoolfee.FR001.repository.SchoolRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SchoolService {

    private final SchoolRepository schoolRepository;
    private final FeeTypeService feeTypeService;


    public SchoolService(SchoolRepository schoolRepository, FeeTypeService feeTypeService) {
        this.schoolRepository = schoolRepository;
        this.feeTypeService = feeTypeService;
    }

    @Transactional
    public SchoolRegistrationResponse registerSchool(SchoolRegistrationRequest request) {
        School school = School.builder()
                .schoolName(request.getSchoolName())
                .location(request.getLocation())
                .ngbAccountNumber(request.getAccountNumber())
                .build();

        // Apply business rules
        if (!school.applyBusinessRules()) {
            throw new SchoolRegistrationException("School registration failed. Does not meet business rules.");
        }
        School savedSchool = schoolRepository.save(school);

        //Save fee types
        feeTypeService.createFeeTypes(savedSchool, request.getFeeTypes());

        SchoolRegistrationResponse response = new SchoolRegistrationResponse();
        response.setSchoolId(String.valueOf(savedSchool.getSchoolId()));
        response.setStatus("REGISTERED");
        return response;
    }


    // Add other service methods as needed
}