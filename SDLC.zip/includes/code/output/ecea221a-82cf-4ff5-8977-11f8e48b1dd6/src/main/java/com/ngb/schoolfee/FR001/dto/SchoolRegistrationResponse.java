package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

@Data
public class SchoolRegistrationResponse {
    private String schoolId;
    private String status; // REGISTERED, FAILED
    private String message;
}