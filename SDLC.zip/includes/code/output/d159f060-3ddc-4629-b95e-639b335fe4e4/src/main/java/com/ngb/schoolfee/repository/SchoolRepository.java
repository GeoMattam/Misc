package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.entity.School;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SchoolRepository extends JpaRepository<School, Long> {
}
```

```java