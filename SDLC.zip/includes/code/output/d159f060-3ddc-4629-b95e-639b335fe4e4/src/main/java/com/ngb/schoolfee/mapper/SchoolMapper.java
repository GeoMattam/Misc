package com.ngb.schoolfee.mapper;

import com.ngb.schoolfee.dto.SchoolDto;
import com.ngb.schoolfee.entity.School;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SchoolMapper {
    SchoolMapper INSTANCE = Mappers.getMapper(SchoolMapper.class);
    School toEntity(SchoolDto schoolDto);
    SchoolDto toDto(School school);
}
```

**3. Commons and Support (Partial):**

```java