package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.SchoolDto;

import java.util.List;

public interface SchoolService {
    SchoolDto registerSchool(SchoolDto schoolDto);
    List<SchoolDto> getAllSchools();
    //Add other methods as needed (update, delete, get by ID)

}
```

```java