package com.ngb.schoolfee.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class SchoolDto {
    private Long id;
    @NotBlank(message = "School name cannot be blank")
    @Size(max = 255, message = "School name must be less than 255 characters")
    private String schoolName;
    @NotBlank(message = "Location cannot be blank")
    @Size(max = 255, message = "Location must be less than 255 characters")
    private String location;
    @NotBlank(message = "NGb Account Number cannot be blank")
    @Size(max = 50, message = "NGb Account Number must be less than 50 characters")
    private String ngbAccountNumber;
    @NotBlank(message = "GL Account Number cannot be blank")
    @Size(max = 50, message = "GL Account Number must be less than 50 characters")
    private String glAccountNumber;
    private List<String> feeTypes;
}
```

```java