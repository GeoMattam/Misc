package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.SchoolDto;
import com.ngb.schoolfee.entity.School;
import com.ngb.schoolfee.mapper.SchoolMapper;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SchoolServiceImplTest {

    @Mock
    private SchoolRepository schoolRepository;
    @Mock
    private SchoolMapper schoolMapper;
    @InjectMocks
    private SchoolServiceImpl schoolService;

    @Test
    void registerSchool() {
        SchoolDto schoolDto = new SchoolDto();
        schoolDto.setSchoolName("Test School");
        schoolDto.setLocation("Test Location");
        schoolDto.setNgbAccountNumber("12345");
        schoolDto.setGlAccountNumber("67890");


        School schoolEntity = School.builder().schoolName("Test School").build();
        when(schoolMapper.toEntity(schoolDto)).thenReturn(schoolEntity);
        when(schoolRepository.save(schoolEntity)).thenReturn(schoolEntity);
        when(schoolMapper.toDto(schoolEntity)).thenReturn(schoolDto);


        SchoolDto result = schoolService.registerSchool(schoolDto);
        assertEquals(schoolDto, result);
        verify(schoolRepository).save(schoolEntity);
    }


    @Test
    void getAllSchools() {
        School school1 = School.builder().schoolName("School 1").build();
        School school2 = School.builder().schoolName("School 2").build();
        when(schoolRepository.findAll()).thenReturn(List.of(school1, school2));
        when(schoolMapper.toDto(school1)).thenReturn(new SchoolDto());
        when(schoolMapper.toDto(school2)).thenReturn(new SchoolDto());

        List<SchoolDto> result = schoolService.getAllSchools();
        assertNotNull(result);
        assertEquals(2, result.size());
    }
}
```

**6. README.md:**

```markdown