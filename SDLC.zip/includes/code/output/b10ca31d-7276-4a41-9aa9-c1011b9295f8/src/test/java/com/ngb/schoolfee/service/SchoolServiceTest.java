package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.FeeTypeRequestDTO;
import com.ngb.schoolfee.dto.SchoolRequestDTO;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SchoolServiceTest {

    @Mock
    private SchoolRepository schoolRepository;

    @Mock
    private FeeTypeService feeTypeService;

    @InjectMocks
    private SchoolService schoolService;

    @Test
    void registerSchool_success() {
        SchoolRequestDTO request = SchoolRequestDTO.builder()
                .schoolName("Test School")
                .location("Test Location")
                .ngbAccountNumber("1234567890")
                .operationalSince(LocalDate.now().minusYears(4))
                .feeTypes(List.of(FeeTypeRequestDTO.builder().feeTypeName("Tuition").build()))
                .build();

        when(schoolRepository.findBySchoolNameAndLocation(anyString(), anyString())).thenReturn(Optional.empty());
        when(schoolRepository.save(any(School.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(feeTypeService.createFeeTypes(anyLong(), anyList())).thenReturn(List.of(1L));


        SchoolResponseDTO response = schoolService.registerSchool(request);
        assertNotNull(response);
        assertEquals(request.getSchoolName(), response.getSchoolName());
        verify(schoolRepository, times(1)).save(any(School.class));
        verify(feeTypeService, times(1)).createFeeTypes(anyLong(), anyList());
    }


    @Test
    void registerSchool_existingSchool() {
        SchoolRequestDTO request = SchoolRequestDTO.builder()
                .schoolName("Test School")
                .location("Test Location")
                .ngbAccountNumber("1234567890")
                .build();

        School existingSchool = School.builder().schoolId(1L).build();
        when(schoolRepository.findBySchoolNameAndLocation(anyString(), anyString())).thenReturn(Optional.of(existingSchool));

        assertThrows(SchoolRegistrationException.class, () -> schoolService.registerSchool(request));
        verify(schoolRepository, never()).save(any(School.class));
        verify(feeTypeService, never()).createFeeTypes(anyLong(), anyList());
    }
}