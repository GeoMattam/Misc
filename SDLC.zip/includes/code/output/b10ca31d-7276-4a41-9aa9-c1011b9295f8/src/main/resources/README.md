To build and run the application:

1.  **Prerequisites:** Make sure you have Java 17+ and Maven installed.  Also, ensure PostgreSQL is running and you have created the database `school_fee_db` with appropriate user credentials (update `application.yaml` accordingly).
2.  **Build:** Navigate to the project root directory and run `mvn clean install`.
3.  **Run:** Execute `mvn spring-boot:run`.

The application will start on port 8080 (by default). You can then test the REST APIs using tools like Postman or curl.