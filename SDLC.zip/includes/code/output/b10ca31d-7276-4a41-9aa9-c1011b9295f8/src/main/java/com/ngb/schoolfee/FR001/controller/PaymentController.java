```java
package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.FeePaymentRequest;
import com.ngb.schoolfee.FR001.dto.FeePaymentResponse;
import com.ngb.schoolfee.FR001.service.PaymentOrchestrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentOrchestrationService paymentOrchestrationService;

    @Autowired
    public PaymentController(PaymentOrchestrationService paymentOrchestrationService) {
        this.paymentOrchestrationService = paymentOrchestrationService;
    }

    @PostMapping
    public ResponseEntity<FeePaymentResponse> initiateFeePayment(
            @Valid @RequestBody FeePaymentRequest request) {
        FeePaymentResponse response = paymentOrchestrationService.initiateFeePayment(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/history")
    public ResponseEntity<Object> getPaymentHistory(
            @RequestParam String customerId,
            @RequestParam(defaultValue = "6") int months) {
        return ResponseEntity.ok(paymentOrchestrationService.getPaymentHistory(customerId, months));

    }

}
```