```java
package com.ngb.schoolfee.FR001.model;

import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "schools")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class School {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "school_id", updatable = false, nullable = false)
    private UUID schoolId;

    @NotBlank
    @Size(max = 255)
    private String name;

    @NotBlank
    @Size(max = 255)
    private String location;

    @NotBlank
    @Size(max = 50)
    private String ngbAccountNumber;

    @NotBlank
    @Size(max = 100)
    private String ngbGlAccountConfig;

    @CreationTimestamp
    private LocalDate registrationDate;

    private boolean isActive;

    @NotNull
    private int minEnrolledStudents;

    @NotNull
    private int operationalYears;

    @NotNull
    private double minAnnualFeeCollection;

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;
}
```