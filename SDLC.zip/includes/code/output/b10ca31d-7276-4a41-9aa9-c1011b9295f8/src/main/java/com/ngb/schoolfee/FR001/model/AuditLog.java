```java
package com.ngb.schoolfee.FR001.model;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "audit_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLog {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "log_id", updatable = false, nullable = false)
    private UUID logId;

    private String activityType;

    private UUID entityIdAffected;

    private String entityType;

    @CreationTimestamp
    private LocalDateTime timestamp;

    private String performedByUserId;

    private String channel;

    private boolean successStatus;

    @Column(columnDefinition = "TEXT")
    private String details;

}
```