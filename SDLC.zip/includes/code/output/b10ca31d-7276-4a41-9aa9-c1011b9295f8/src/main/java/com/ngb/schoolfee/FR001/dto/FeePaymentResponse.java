```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

@Data
public class FeePaymentResponse {
    private String transactionId;
    private String status; // SUCCESS, FAILED, PENDING_EPP
    private String message;
    private String referenceId;
}
```