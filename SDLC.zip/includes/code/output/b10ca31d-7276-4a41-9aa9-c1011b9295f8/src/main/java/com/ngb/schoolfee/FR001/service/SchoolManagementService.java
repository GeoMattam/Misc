```java
package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.FR001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.FR001.exception.SchoolRegistrationException;
import com.ngb.schoolfee.FR001.model.School;
import com.ngb.schoolfee.FR001.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class SchoolManagementService {

    private final SchoolRepository schoolRepository;

    @Autowired
    public SchoolManagementService(SchoolRepository schoolRepository) {
        this.schoolRepository = schoolRepository;
    }


    @Transactional
    public SchoolRegistrationResponse registerSchool(SchoolRegistrationRequest request) {
        School school = School.builder()
                .name(request.getSchoolName())
                .location(request.getLocation())
                .ngbAccountNumber(request.getAccountNumber())
                .minEnrolledStudents(1000)
                .operationalYears(3)
                .minAnnualFeeCollection(500000.00)
                .isActive(true)
                .build();

        //Add Fee types
        // ... (Implementation to add fee types from request.feeTypes)

        try {
            School savedSchool = schoolRepository.save(school);
            return SchoolRegistrationResponse.builder()
                    .schoolId(savedSchool.getSchoolId().toString())
                    .status("REGISTERED")
                    .message("School registered successfully.")
                    .build();
        } catch (Exception e) {
            throw new SchoolRegistrationException("Failed to register school: " + e.getMessage());
        }
    }
}
```