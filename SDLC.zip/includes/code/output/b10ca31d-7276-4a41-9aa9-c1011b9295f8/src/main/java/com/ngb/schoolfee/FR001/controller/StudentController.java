```java
package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.StudentManagementRequest;
import com.ngb.schoolfee.FR001.dto.StudentManagementResponse;
import com.ngb.schoolfee.FR001.service.StudentManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentManagementService studentManagementService;

    @Autowired
    public StudentController(StudentManagementService studentManagementService) {
        this.studentManagementService = studentManagementService;
    }

    @PostMapping
    public ResponseEntity<StudentManagementResponse> manageStudent(
            @Valid @RequestBody StudentManagementRequest request) {
        StudentManagementResponse response = studentManagementService.manageStudent(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // Add other endpoints for Student Management as needed (GET, PUT, DELETE)

}
```