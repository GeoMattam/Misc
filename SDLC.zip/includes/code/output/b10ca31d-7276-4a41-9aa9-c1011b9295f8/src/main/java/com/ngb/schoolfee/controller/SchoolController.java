package com.ngb.schoolfee.controller;

import com.ngb.schoolfee.dto.SchoolRequestDTO;
import com.ngb.schoolfee.dto.SchoolResponseDTO;
import com.ngb.schoolfee.service.SchoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/schools")
public class SchoolController {

    private final SchoolService schoolService;

    @Autowired
    public SchoolController(SchoolService schoolService) {
        this.schoolService = schoolService;
    }

    @PostMapping
    public ResponseEntity<SchoolResponseDTO> registerSchool(@RequestBody SchoolRequestDTO schoolRequestDTO) {
        SchoolResponseDTO schoolResponseDTO = schoolService.registerSchool(schoolRequestDTO);
        return new ResponseEntity<>(schoolResponseDTO, HttpStatus.CREATED);
    }

    @GetMapping("/{schoolId}")
    public ResponseEntity<SchoolResponseDTO> getSchoolDetails(@PathVariable Long schoolId) {
        SchoolResponseDTO schoolResponseDTO = schoolService.getSchoolDetails(schoolId);
        return new ResponseEntity<>(schoolResponseDTO, HttpStatus.OK);
    }
}