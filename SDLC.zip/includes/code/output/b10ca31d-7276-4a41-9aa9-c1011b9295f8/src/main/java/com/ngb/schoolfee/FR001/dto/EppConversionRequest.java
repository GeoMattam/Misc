```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class EppConversionRequest {
    @NotBlank
    private String transactionId;
    @NotBlank
    private String customerId;
}
```