package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.SchoolRequestDTO;
import com.ngb.schoolfee.dto.SchoolResponseDTO;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SchoolService {

    private final SchoolRepository schoolRepository;
    private final FeeTypeService feeTypeService;

    @Autowired
    public SchoolService(SchoolRepository schoolRepository, FeeTypeService feeTypeService) {
        this.schoolRepository = schoolRepository;
        this.feeTypeService = feeTypeService;
    }

    public SchoolResponseDTO registerSchool(SchoolRequestDTO schoolRequestDTO) {
        //Validate data and Business Rules
        Optional<School> existingSchool = schoolRepository.findBySchoolNameAndLocation(schoolRequestDTO.getSchoolName(), schoolRequestDTO.getLocation());
        if (existingSchool.isPresent()) {
            throw new SchoolRegistrationException("School already registered: " + schoolRequestDTO.getSchoolName());
        }

        School school = School.builder()
                .schoolName(schoolRequestDTO.getSchoolName())
                .location(schoolRequestDTO.getLocation())
                .ngbAccountNumber(schoolRequestDTO.getNgbAccountNumber())
                .operationalSince(schoolRequestDTO.getOperationalSince())
                .build();

        School savedSchool = schoolRepository.save(school);
        if (schoolRequestDTO.getFeeTypes() != null) {
            List<Long> feeTypeIds = feeTypeService.createFeeTypes(savedSchool.getSchoolId(), schoolRequestDTO.getFeeTypes());
        }

        return mapToResponse(savedSchool);
    }

    public SchoolResponseDTO getSchoolDetails(Long schoolId) {
        Optional<School> school = schoolRepository.findById(schoolId);
        if (school.isEmpty()) {
            throw new SchoolRegistrationException("School not found");
        }
        return mapToResponse(school.get());
    }


    private SchoolResponseDTO mapToResponse(School school) {
        return SchoolResponseDTO.builder()
                .schoolId(school.getSchoolId())
                .schoolName(school.getSchoolName())
                .location(school.getLocation())
                .ngbAccountNumber(school.getNgbAccountNumber())
                .ngbGlAccountConfig(school.getNgbGlAccountConfig())
                .registrationDate(school.getRegistrationDate())
                .isActive(school.getIsActive())
                .feeTypes(feeTypeService.getFeeTypesBySchoolId(school.getSchoolId()).stream().map(feeTypeService::mapToResponse).collect(Collectors.toList()))
                .build();
    }
}