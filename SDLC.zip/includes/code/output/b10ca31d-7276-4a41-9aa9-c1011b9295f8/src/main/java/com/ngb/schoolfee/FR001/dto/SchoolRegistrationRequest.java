```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class SchoolRegistrationRequest {
    @NotBlank
    private String schoolName;
    @NotBlank
    private String location;
    @NotBlank
    private String accountNumber;
    @NotEmpty
    private List<FeeTypeRequest> feeTypes;
}
```