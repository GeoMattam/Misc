```java
package com.ngb.schoolfee.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(SchoolRegistrationException.class)
    public ResponseEntity<ErrorResponse> handleSchoolRegistrationException(SchoolRegistrationException ex) {
        return buildErrorResponse(ex, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(StudentManagementException.class)
    public ResponseEntity<ErrorResponse> handleStudentManagementException(StudentManagementException ex) {
        return buildErrorResponse(ex, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(PaymentProcessingException.class)
    public ResponseEntity<ErrorResponse> handlePaymentProcessingException(PaymentProcessingException ex) {
        return buildErrorResponse(ex, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EPPConversionException.class)
    public ResponseEntity<ErrorResponse> handleEPPConversionException(EPPConversionException ex) {
        return buildErrorResponse(ex, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(Exception ex) {
        return buildErrorResponse(ex, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    private ResponseEntity<ErrorResponse> buildErrorResponse(Exception ex, HttpStatus status) {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorCode(status.value());
        errorResponse.setMessage(ex.getMessage());
        return new ResponseEntity<>(errorResponse, status);
    }


    @Data
    public static class ErrorResponse{
        private Integer errorCode;
        private String message;
    }
}
```