```java
package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TransactionHistoryResponseDTO {
    private String transactionId;
    private LocalDateTime date;
    private Double amount;
    private String studentName;
    private String schoolName;
    private String feeTypeName;
    private String remark;
    private String status;
}
```