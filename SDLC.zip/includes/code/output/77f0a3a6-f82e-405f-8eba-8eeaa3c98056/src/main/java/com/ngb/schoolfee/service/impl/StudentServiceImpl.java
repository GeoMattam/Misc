package com.ngb.schoolfee.service.impl;

import com.ngb.schoolfee.dto.StudentRequest;
import com.ngb.schoolfee.dto.StudentResponse;
import com.ngb.schoolfee.enums.StudentStatus;
import com.ngb.schoolfee.exception.StudentManagementException;
import com.ngb.schoolfee.model.Customer;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.repository.CustomerRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import com.ngb.schoolfee.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;
    private final SchoolRepository schoolRepository;
    private final CustomerRepository customerRepository;

    @Override
    @Transactional
    public StudentResponse registerStudent(StudentRequest studentRequest, String customerId) throws StudentManagementException {
        // Validate Inputs
        validateStudentRequest(studentRequest);

        //Check if customer exists and has active card
        Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new StudentManagementException("Customer not found"));


        //Check if student already exists
        if (isStudentRegistered(studentRequest.getStudentId(), studentRequest.getSchoolId())) {
            throw new StudentManagementException("Student already registered");
        }

        //Find School
        School school = schoolRepository.findById(studentRequest.getSchoolId())
                .orElseThrow(() -> new StudentManagementException("School not found"));

        Student student = Student.builder()
                .studentId(studentRequest.getStudentId())
                .studentName(studentRequest.getStudentName())
                .registeredByCustomer(customer)
                .school(school)
                .registrationDate(LocalDateTime.now())
                .status(StudentStatus.REGISTERED)
                .lastUpdatedDate(LocalDateTime.now())
                .build();

        Student savedStudent = studentRepository.save(student);

        return StudentResponse.builder()
                .studentSystemId(savedStudent.getStudentId())
                .studentName(savedStudent.getStudentName())
                .studentId(savedStudent.getStudentId())
                .schoolId(savedStudent.getSchool().getSchoolId())
                .schoolName(savedStudent.getSchool().getSchoolName())
                .status(savedStudent.getStatus())
                .registrationDate(savedStudent.getRegistrationDate())
                .build();

    }

    @Override
    @Transactional
    public StudentResponse amendStudent(String studentId, Long schoolId, StudentRequest studentRequest) throws StudentManagementException {
        // Validate Inputs
        validateStudentRequest(studentRequest);

        //Find Student
        Student student = studentRepository.findById(studentId).orElseThrow(() -> new StudentManagementException("Student not found"));

        student.setStudentName(studentRequest.getStudentName());
        student.setSchool(schoolRepository.findById(studentRequest.getSchoolId())
                .orElseThrow(() -> new StudentManagementException("School not found")));
        student.setLastUpdatedDate(LocalDateTime.now());

        Student updatedStudent = studentRepository.save(student);

        return StudentResponse.builder()
                .studentSystemId(updatedStudent.getStudentId())
                .studentName(updatedStudent.getStudentName())
                .studentId(updatedStudent.getStudentId())
                .schoolId(updatedStudent.getSchool().getSchoolId())
                .schoolName(updatedStudent.getSchool().getSchoolName())
                .status(updatedStudent.getStatus())
                .registrationDate(updatedStudent.getRegistrationDate())
                .build();

    }

    @Override
    @Transactional
    public boolean deRegisterStudent(String studentId, Long schoolId, String customerId) throws StudentManagementException {
        Student student = studentRepository.findById(studentId).orElseThrow(() -> new StudentManagementException("Student not found"));

        if (!student.getRegisteredByCustomer().getCustomerId().equals(customerId)) {
            throw new StudentManagementException("You are not authorized to de-register this student.");
        }

        student.setStatus(StudentStatus.DE_REGISTERED);
        student.setLastUpdatedDate(LocalDateTime.now());

        studentRepository.save(student);
        return true;
    }

    @Override
    public List<StudentResponse> getStudentsByCustomer(String customerId) {
        return studentRepository.findAll()
                .stream()
                .filter(s -> s.getRegisteredByCustomer().getCustomerId().equals(customerId))
                .map(s -> StudentResponse.builder()
                        .studentSystemId(s.getStudentId())
                        .studentName(s.getStudentName())
                        .studentId(s.getStudentId())
                        .schoolId(s.getSchool().getSchoolId())
                        .schoolName(s.getSchool().getSchoolName())
                        .status(s.getStatus())
                        .registrationDate(s.getRegistrationDate())
                        .build())
                .collect(Collectors.toList());
    }

    @Override
    public boolean isStudentRegistered(String studentId, Long schoolId) {
        return studentRepository.existsById(studentId);
    }


    private void validateStudentRequest(StudentRequest studentRequest) throws StudentManagementException {
        if (studentRequest.getStudentName() == null || student