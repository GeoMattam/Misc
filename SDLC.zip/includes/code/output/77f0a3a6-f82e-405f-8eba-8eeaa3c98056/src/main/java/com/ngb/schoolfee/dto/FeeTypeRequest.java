package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FeeTypeRequest {
    private String feeTypeName;
    private String description;
}

```

```java