package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.StudentRequest;
import com.ngb.schoolfee.dto.StudentResponse;
import com.ngb.schoolfee.exception.StudentManagementException;
import com.ngb.schoolfee.model.Student;

import java.util.List;

public interface StudentService {
    StudentResponse registerStudent(StudentRequest studentRequest, String customerId) throws StudentManagementException;

    StudentResponse amendStudent(String studentId, Long schoolId, StudentRequest studentRequest) throws StudentManagementException;

    boolean deRegisterStudent(String studentId, Long schoolId, String customerId) throws StudentManagementException;

    List<StudentResponse> getStudentsByCustomer(String customerId);

    boolean isStudentRegistered(String studentId, Long schoolId);
}
```

```java