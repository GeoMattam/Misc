package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "epp_request")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", unique = true, nullable = false)
    private Transaction transaction;

    @Column(nullable = false)
    private LocalDateTime requestDateTime;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status;

    @Column(length = 255)
    private String rejectionReason;

    @Column(nullable = false)
    private boolean noLoyaltyPointsFlag = true;


    private LocalDateTime approvalDateTime;


}
```

```java