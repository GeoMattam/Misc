package com.ngb.schoolfee.enums;

public enum GLPostingStatus {
    PENDING, POSTED, FAILED, CARD_DEBIT_FAILED, GL_DEBIT_FAILED, SCHOOL_CREDIT_FAILED, EXCEPTION_OCCURRED
}
```

```java