package com.ngb.schoolfee.service.impl;

import com.ngb.schoolfee.dto.FeeTypeRequest;
import com.ngb.schoolfee.dto.SchoolRequest;
import com.ngb.schoolfee.dto.SchoolResponse;
import com.ngb.schoolfee.enums.SchoolStatus;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.FeeType;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.service.SchoolService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SchoolServiceImpl implements SchoolService {

    private final SchoolRepository schoolRepository;
    private final FeeTypeRepository feeTypeRepository;

    @Override
    @Transactional
    public SchoolResponse registerSchool(SchoolRequest schoolRequest) throws SchoolRegistrationException {
        School school = School.builder()
                .schoolName(schoolRequest.getSchoolName())
                .location(schoolRequest.getLocation())
                .ngbAccountNumber(schoolRequest.getNgbAccountNumber())
                .registrationDate(LocalDateTime.now())
                .isActive(true)
                .build();


        //Apply business rules
        if (!school.applyBusinessRules()) {
            throw new SchoolRegistrationException("School does not meet eligibility criteria.");
        }

        School savedSchool = schoolRepository.save(school);

        //Save fee types
        List<FeeType> feeTypes = schoolRequest.getFeeTypes().stream()
                .map(feeTypeRequest -> FeeType.builder()
                        .school(savedSchool)
                        .feeTypeName(feeTypeRequest.getFeeTypeName())
                        .description(feeTypeRequest.getDescription())
                        .build())
                .collect(Collectors.toList());

        feeTypeRepository.saveAll(feeTypes);


        return SchoolResponse.builder()
                .schoolId(savedSchool.getSchoolId())
                .schoolName(savedSchool.getSchoolName())
                .location(savedSchool.getLocation())
                .ngbAccountNumber(savedSchool.getNgbAccountNumber())
                .ngbGlAccountConfig(savedSchool.getNgbGlAccountConfig())
                .isActive(savedSchool.isActive())
                .registrationDate(savedSchool.getRegistrationDate())
                .feeTypes(feeTypes)
                .build();
    }



    @Override
    public SchoolResponse getSchoolDetails(Long schoolId) {
        School school = schoolRepository.findById(schoolId).orElseThrow(() -> new RuntimeException("School not found"));
        return SchoolResponse.builder()
                .schoolId(school.getSchoolId())
                .schoolName(school.getSchoolName())
                .location(school.getLocation())
                .ngbAccountNumber(school.getNgbAccountNumber())
                .ngbGlAccountConfig(school.getNgbGlAccountConfig())
                .isActive(school.isActive())
                .registrationDate(school.getRegistrationDate())
                .feeTypes(school.getFeeTypes())
                .build();
    }

    @Override
    @Transactional
    public SchoolResponse updateSchoolDetails(Long schoolId, SchoolRequest schoolRequest) {
        School school = schoolRepository.findById(schoolId).orElseThrow(() -> new RuntimeException("School not found"));

        school.setSchoolName(schoolRequest.getSchoolName());
        school.setLocation(schoolRequest.getLocation());
        school.setNgbAccountNumber(schoolRequest.getNgbAccountNumber());
        school.setIsActive(schoolRequest.getFeeTypes().stream().anyMatch(FeeTypeRequest::isActive));
        school.setLastUpdatedDate(LocalDateTime.now());


        School updatedSchool = schoolRepository.save(school);

        return SchoolResponse.builder()
                .schoolId(updatedSchool.getSchoolId())
                .schoolName(updatedSchool.getSchoolName())
                .location(updatedSchool.getLocation())
                .ngbAccountNumber(updatedSchool.getNgbAccountNumber())
                .ngbGlAccountConfig(updatedSchool.getNgbGlAccountConfig())
                .isActive(updatedSchool.isActive())
                .registrationDate(updatedSchool.getRegistrationDate())
                .feeTypes(updatedSchool.getFeeTypes())
                .build();
    }



    @Override
    public List<School> getAllSchools() {
        return schoolRepository.findAll();
    }


    @Override
    public List<School> getActiveSchools() {
        return schoolRepository.findAll().stream().filter(School::isActive).toList();
    }


}
```

```java