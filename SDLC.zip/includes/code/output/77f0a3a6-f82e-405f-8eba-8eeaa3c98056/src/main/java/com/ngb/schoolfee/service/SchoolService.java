package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.SchoolRequest;
import com.ngb.schoolfee.dto.SchoolResponse;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.School;

import java.util.List;

public interface SchoolService {
    SchoolResponse registerSchool(SchoolRequest schoolRequest) throws SchoolRegistrationException;

    SchoolResponse getSchoolDetails(Long schoolId);

    SchoolResponse updateSchoolDetails(Long schoolId, SchoolRequest schoolRequest);


    List<School> getAllSchools();


    List<School> getActiveSchools();


}
```

```java