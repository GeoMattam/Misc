package com.ngb.schoolfee.enums;

public enum StudentStatus {
    REGISTERED, DE_REGISTERED
}
```

```java