package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "transaction")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column(nullable = false, unique = true)
    private String referenceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_token", nullable = false)
    private CreditCard creditCard;

    @Column(nullable = false, precision = 18, scale = 2)
    private double amount;

    @Column(nullable = false)
    private LocalDateTime transactionDateTime;

    @Column(length = 20)
    private String remark;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status;

    @Column(nullable = false, length = 40)
    private String postingDescription;

    @Column(nullable = false)
    private boolean isEPPConverted;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private GLPostingStatus glPostingStatus;

    @Column(nullable = false)
    private boolean isLoyaltyEligible = true;


    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private PaymentChannel channelUsed;


    private boolean ivrTinUsed;

}
```

```java