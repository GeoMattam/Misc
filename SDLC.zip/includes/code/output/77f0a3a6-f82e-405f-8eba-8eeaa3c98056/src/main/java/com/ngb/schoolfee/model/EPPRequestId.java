```java
package com.ngb.schoolfee.model;

import java.io.Serializable;

public class EPPRequestId implements Serializable {
    private Long eppRequestId;
    private Long transactionId;

    public EPPRequestId() {}

    public EPPRequestId(Long eppRequestId, Long transactionId) {
        this.eppRequestId = eppRequestId;
        this.transactionId = transactionId;
    }


}
```