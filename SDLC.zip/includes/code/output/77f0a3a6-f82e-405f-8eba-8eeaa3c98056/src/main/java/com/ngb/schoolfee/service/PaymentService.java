```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.PaymentRequestDTO;
import com.ngb.schoolfee.dto.PaymentResponseDTO;
import com.ngb.schoolfee.exception.PaymentProcessingException;
import com.ngb.schoolfee.model.AuditLog;
import com.ngb.schoolfee.model.CreditCard;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.model.Transaction;
import com.ngb.schoolfee.repository.AuditLogRepository;
import com.ngb.schoolfee.repository.CreditCardRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import com.ngb.schoolfee.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class PaymentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private CreditCardRepository creditCardRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AuditLogRepository auditLogRepository;

    @Autowired
    private FinancialPostingService financialPostingService;


    public PaymentResponseDTO initiateFeePayment(PaymentRequestDTO paymentRequestDTO, String customerId) {

        Student student = studentRepository.findById(new Student.StudentId(paymentRequestDTO.getStudentSystemId(), paymentRequestDTO.getSchoolId()))
                .orElseThrow(() -> new PaymentProcessingException("Student not found or not registered."));


        School school = schoolRepository.findById(paymentRequestDTO.getSchoolId())
                .orElseThrow(() -> new PaymentProcessingException("School not found."));


        CreditCard creditCard = creditCardRepository.findById(paymentRequestDTO.getCardNumber())
                .orElseThrow(() -> new PaymentProcessingException("Credit card not found."));


        if (!creditCard.isCardActive() || !creditCard.hasSufficientBalance(paymentRequestDTO.getAmount())) {
            throw new PaymentProcessingException("Invalid or inactive card or insufficient balance.");
        }

        Transaction transaction = Transaction.builder()
                .transactionDateTime(LocalDateTime.now())
                .amount(paymentRequestDTO.getAmount())
                .creditCard(creditCard)
                .student(student)
                .school(school)
                .feeType(new FeeType()) //Placeholder -needs to be fetched
                .remark(paymentRequestDTO.getRemark())
                .status("PENDING_POSTING")
                .postingDescription("School Fee Payment")
                .isEPPConverted(false)
                .glPostingStatus("PENDING")
                .ivrTinUsed(false)
                .channelUsed("ONLINE_BANKING")
                .build();

        Transaction savedTransaction = transactionRepository.save(transaction);

        boolean postingSuccess = financialPostingService.postTransactionGL(savedTransaction);

        if (postingSuccess) {
            savedTransaction.setStatus("SUCCESS");
            transactionRepository.save(savedTransaction);
        } else {
            savedTransaction.setStatus("FAILED");
            transactionRepository.save(savedTransaction);
        }


        auditLogRepository.save(AuditLog.builder()
                .activityType("FEE_PAYMENT_" + (postingSuccess ? "SUCCESS" : "FAILED"))
                .entityIdAffected(String.valueOf(savedTransaction.getTransactionId()))
                .entityType("TRANSACTION")
                .timestamp(LocalDateTime.now())
                .performedByUserOrSystem(customerId)
                .details("{}")
                .successStatus(postingSuccess)
                .build());


        PaymentResponseDTO paymentResponseDTO = new PaymentResponseDTO();
        paymentResponseDTO.setTransactionId(String.valueOf(savedTransaction.getTransactionId()));
        paymentResponseDTO.setStatus(savedTransaction.getStatus());
        paymentResponseDTO.setReferenceId(UUID.randomUUID().toString());

        return paymentResponseDTO;
    }

}
```