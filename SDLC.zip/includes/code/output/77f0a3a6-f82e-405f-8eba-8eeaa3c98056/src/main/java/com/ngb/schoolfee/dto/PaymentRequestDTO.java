```java
package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class PaymentRequestDTO {
    private String customerId;
    private String studentSystemId;
    private Long schoolId;
    private Long feeTypeId;
    private String cardNumber;
    private Double amount;
    private String remark;
    private String otp; // For online/mobile
    private String ivrTin; // For IVR
}
```