```java
package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class FeeTypeResponseDTO {
    private Long feeTypeId;
    private String feeTypeName;
    private String description;
    private Boolean isActive;
}
```