```java
###FilePath: src/main/java/com/ngb/schoolfee/model/School.java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "school")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class School {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long schoolId;

    @Column(nullable = false, unique = true)
    private String schoolName;

    @Column(nullable = false)
    private String location;

    @Column(nullable = false, unique = true)
    private String ngbAccountNumber;

    @Column(nullable = false)
    private String ngbGlAccountConfig;

    @Column(nullable = false)
    private LocalDateTime registrationDate;

    @Column(nullable = false)
    private boolean isActive;


    @Column(nullable = false)
    private int minEnrolledStudents = 1000;

    @Column(nullable = false)
    private int operationalYears = 3;

    @Column(nullable = false, precision = 18, scale = 2)
    private double minAnnualFeeCollection = 500000.00;


    private LocalDateTime operationalSince;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/FeeType.java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "fee_type")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feeTypeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(nullable = false)
    private String feeTypeName;

    @Column(length = 255)
    private String description;

    @Column(nullable = false)
    private boolean isActive = true;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/Customer.java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "customer")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    @Column(nullable = false, unique = true)
    private String customerId;

    @Column(nullable = false)
    private String customerName;

    @Column(nullable = false)
    private String contactInfo; //Phone number or email

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CustomerStatus status;


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/CreditCard.java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "credit_card")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditCard {

    @Id
    @Column(nullable = false, unique = true)
    private String cardToken; //Instead of storing actual card number

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @Column(nullable = false)
    private String cardLast4Digits;


    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CardType cardType;

    @Column(nullable = false)
    private LocalDate expiryDate;

    @Column(nullable = false, precision = 18, scale = 2)
    private double balance;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CardStatus status;


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/Student.java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "student")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @Column(nullable = false)
    private String studentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(nullable = false)
    private String studentName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "registered_by_customer_id", nullable = false)
    private Customer registeredByCustomer;

    @Column(nullable = false)
    private LocalDateTime registrationDate;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private StudentStatus status;

    @Column(nullable = false)
    private LocalDateTime lastUpdatedDate;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/Transaction.java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "transaction")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column(nullable = false, unique = true)
    private String referenceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_token", nullable = false)
    private CreditCard creditCard;

    @Column(nullable = false, precision = 18, scale = 2)
    private double amount;

    @Column(nullable = false)
    private LocalDateTime transactionDateTime;

    @Column(length = 20)
    private String remark;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status;

    @Column(nullable = false, length = 40)
    private String postingDescription;

    @Column(nullable = false)
    private boolean isEPPConverted;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private GLPostingStatus glPostingStatus;

    @Column(nullable = false)
    private boolean isLoyaltyEligible = true;


    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private PaymentChannel channelUsed;


    private boolean ivrTinUsed;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/EPPRequest.java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "epp_request")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", unique = true, nullable = false)
    private Transaction transaction;

    @Column(nullable = false)
    private LocalDateTime requestDateTime;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status;

    @Column(length = 255)
    private String rejectionReason;

    @Column(nullable = false)
    private boolean noLoyaltyPointsFlag = true;


    private LocalDateTime approvalDateTime;


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/model/AuditLog.java
package com.ngb.schoolfee.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "audit_log")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logId;

    @Column(nullable = false)
    private String activityType;

    @Column(length = 50)
    private String entityIdAffected;

    @Column(length = 50)
    private String entityType;

    @CreationTimestamp
    @Column(nullable = false)
    private LocalDateTime timestamp;

    @Column(nullable = false, length = 100)
    private String performedByUserId;

    @Column(length = 50)
    private String channel;


    @Column(columnDefinition = "TEXT")
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String details;

    @Column(nullable = false)
    private boolean successStatus;

}

```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/CustomerStatus.java
package com.ngb.schoolfee.enums;

public enum CustomerStatus {
    ACTIVE, INACTIVE, BLOCKED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/CardType.java
package com.ngb.schoolfee.enums;

public enum CardType {
    VISA_CONVENTIONAL, VISA_ISLAMIC, MASTERCARD
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/CardStatus.java
package com.ngb.schoolfee.enums;

public enum CardStatus {
    ACTIVE, INACTIVE, BLOCKED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/StudentStatus.java
package com.ngb.schoolfee.enums;

public enum StudentStatus {
    REGISTERED, DE_REGISTERED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/TransactionStatus.java
package com.ngb.schoolfee.enums;

public enum TransactionStatus {
    PENDING, SUCCESS, FAILED, PENDING_EPP, CANCELLED, REJECTED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/GLPostingStatus.java
package com.ngb.schoolfee.enums;

public enum GLPostingStatus {
    PENDING, POSTED, FAILED, CARD_DEBIT_FAILED, GL_DEBIT_FAILED, SCHOOL_CREDIT_FAILED, EXCEPTION_OCCURRED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/EPPStatus.java
package com.ngb.schoolfee.enums;

public enum EPPStatus {
    PENDING, APPROVED, REJECTED
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/enums/PaymentChannel.java
package com.ngb.schoolfee.enums;

public enum PaymentChannel {
    ONLINE_BANKING, MOBILE_BANKING, IVR
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/SchoolRepository.java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SchoolRepository extends JpaRepository<School, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/FeeTypeRepository.java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.FeeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeeTypeRepository extends JpaRepository<FeeType, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/CustomerRepository.java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/CreditCardRepository.java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.CreditCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CreditCardRepository extends JpaRepository<CreditCard, String> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/StudentRepository.java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/TransactionRepository.java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/EPPRequestRepository.java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.EPPRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EPPRequestRepository extends JpaRepository<EPPRequest, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/repository/AuditLogRepository.java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/SchoolRequest.java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SchoolRequest {
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private List<FeeTypeRequest> feeTypes;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/SchoolResponse.java
package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.model.FeeType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SchoolResponse {
    private Long schoolId;
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private String ngbGlAccountConfig;
    private boolean isActive;
    private LocalDateTime registrationDate;
    private List<FeeType> feeTypes;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/FeeTypeRequest.java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FeeTypeRequest {
    private String feeTypeName;
    private String description;
}

```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/FeeTypeResponse.java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FeeTypeResponse {
    private Long feeTypeId;
    private String feeTypeName;
    private String description;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/StudentRequest.java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentRequest {
    private String studentName;
    private String studentId;
    private String studentIdConfirm;
    private Long schoolId;
    private String otp; //For online/mobile
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/StudentResponse.java
package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.StudentStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StudentResponse {
    private String studentSystemId;
    private String studentName;
    private String studentId;
    private Long schoolId;
    private String schoolName;
    private StudentStatus status;
    private LocalDateTime registrationDate;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/PaymentRequest.java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequest {
    private String customerId;
    private String studentSystemId;
    private Long schoolId;
    private Long feeTypeId;
    private String cardNumber;
    private double amount;
    private String remark;
    private String otp; //For online/mobile
    private String ivrTin; //For IVR
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/PaymentResponse.java
package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentResponse {
    private Long transactionId;
    private String referenceId;
    private TransactionStatus status;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/EPPRequestRequest.java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EPPRequestRequest {
    private Long transactionId;
    private String customerId;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/EPPRequestResponse.java
package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.EPPStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EPPRequestResponse {
    private Long eppRequestId;
    private Long transactionId;
    private EPPStatus status;
    private String rejectionReason;
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/TransactionHistoryResponse.java
package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionHistoryResponse {
    private Long transactionId;
    private LocalDateTime date;
    private double amount;
    private String studentName;
    private String schoolName;
    private String feeTypeName;
    private String remark;
    private TransactionStatus status;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/dto/TransactionLogResponse.java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionLogResponse {
    private Long transactionId;
    private String referenceId;
    private String studentName;
    private String schoolName;
    private String feeTypeName;
    private double amount;
    private LocalDateTime transactionDateTime;
    private String remark;

}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/SchoolService.java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.SchoolRequest;
import com.ngb.schoolfee.dto.SchoolResponse;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.School;

import java.util.List;

public interface SchoolService {
    SchoolResponse registerSchool(SchoolRequest schoolRequest) throws SchoolRegistrationException;

    SchoolResponse getSchoolDetails(Long schoolId);

    SchoolResponse updateSchoolDetails(Long schoolId, SchoolRequest schoolRequest);


    List<School> getAllSchools();


    List<School> getActiveSchools();


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/impl/SchoolServiceImpl.java
package com.ngb.schoolfee.service.impl;

import com.ngb.schoolfee.dto.FeeTypeRequest;
import com.ngb.schoolfee.dto.SchoolRequest;
import com.ngb.schoolfee.dto.SchoolResponse;
import com.ngb.schoolfee.enums.SchoolStatus;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.FeeType;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.service.SchoolService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SchoolServiceImpl implements SchoolService {

    private final SchoolRepository schoolRepository;
    private final FeeTypeRepository feeTypeRepository;

    @Override
    @Transactional
    public SchoolResponse registerSchool(SchoolRequest schoolRequest) throws SchoolRegistrationException {
        School school = School.builder()
                .schoolName(schoolRequest.getSchoolName())
                .location(schoolRequest.getLocation())
                .ngbAccountNumber(schoolRequest.getNgbAccountNumber())
                .registrationDate(LocalDateTime.now())
                .isActive(true)
                .build();


        //Apply business rules
        if (!school.applyBusinessRules()) {
            throw new SchoolRegistrationException("School does not meet eligibility criteria.");
        }

        School savedSchool = schoolRepository.save(school);

        //Save fee types
        List<FeeType> feeTypes = schoolRequest.getFeeTypes().stream()
                .map(feeTypeRequest -> FeeType.builder()
                        .school(savedSchool)
                        .feeTypeName(feeTypeRequest.getFeeTypeName())
                        .description(feeTypeRequest.getDescription())
                        .build())
                .collect(Collectors.toList());

        feeTypeRepository.saveAll(feeTypes);


        return SchoolResponse.builder()
                .schoolId(savedSchool.getSchoolId())
                .schoolName(savedSchool.getSchoolName())
                .location(savedSchool.getLocation())
                .ngbAccountNumber(savedSchool.getNgbAccountNumber())
                .ngbGlAccountConfig(savedSchool.getNgbGlAccountConfig())
                .isActive(savedSchool.isActive())
                .registrationDate(savedSchool.getRegistrationDate())
                .feeTypes(feeTypes)
                .build();
    }



    @Override
    public SchoolResponse getSchoolDetails(Long schoolId) {
        School school = schoolRepository.findById(schoolId).orElseThrow(() -> new RuntimeException("School not found"));
        return SchoolResponse.builder()
                .schoolId(school.getSchoolId())
                .schoolName(school.getSchoolName())
                .location(school.getLocation())
                .ngbAccountNumber(school.getNgbAccountNumber())
                .ngbGlAccountConfig(school.getNgbGlAccountConfig())
                .isActive(school.isActive())
                .registrationDate(school.getRegistrationDate())
                .feeTypes(school.getFeeTypes())
                .build();
    }

    @Override
    @Transactional
    public SchoolResponse updateSchoolDetails(Long schoolId, SchoolRequest schoolRequest) {
        School school = schoolRepository.findById(schoolId).orElseThrow(() -> new RuntimeException("School not found"));

        school.setSchoolName(schoolRequest.getSchoolName());
        school.setLocation(schoolRequest.getLocation());
        school.setNgbAccountNumber(schoolRequest.getNgbAccountNumber());
        school.setIsActive(schoolRequest.getFeeTypes().stream().anyMatch(FeeTypeRequest::isActive));
        school.setLastUpdatedDate(LocalDateTime.now());


        School updatedSchool = schoolRepository.save(school);

        return SchoolResponse.builder()
                .schoolId(updatedSchool.getSchoolId())
                .schoolName(updatedSchool.getSchoolName())
                .location(updatedSchool.getLocation())
                .ngbAccountNumber(updatedSchool.getNgbAccountNumber())
                .ngbGlAccountConfig(updatedSchool.getNgbGlAccountConfig())
                .isActive(updatedSchool.isActive())
                .registrationDate(updatedSchool.getRegistrationDate())
                .feeTypes(updatedSchool.getFeeTypes())
                .build();
    }



    @Override
    public List<School> getAllSchools() {
        return schoolRepository.findAll();
    }


    @Override
    public List<School> getActiveSchools() {
        return schoolRepository.findAll().stream().filter(School::isActive).toList();
    }


}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/StudentService.java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.StudentRequest;
import com.ngb.schoolfee.dto.StudentResponse;
import com.ngb.schoolfee.exception.StudentManagementException;
import com.ngb.schoolfee.model.Student;

import java.util.List;

public interface StudentService {
    StudentResponse registerStudent(StudentRequest studentRequest, String customerId) throws StudentManagementException;

    StudentResponse amendStudent(String studentId, Long schoolId, StudentRequest studentRequest) throws StudentManagementException;

    boolean deRegisterStudent(String studentId, Long schoolId, String customerId) throws StudentManagementException;

    List<StudentResponse> getStudentsByCustomer(String customerId);

    boolean isStudentRegistered(String studentId, Long schoolId);
}
```

```java
###FilePath: src/main/java/com/ngb/schoolfee/service/impl/StudentServiceImpl.java
package com.ngb.schoolfee.service.impl;

import com.ngb.schoolfee.dto.StudentRequest;
import com.ngb.schoolfee.dto.StudentResponse;
import com.ngb.schoolfee.enums.StudentStatus;
import com.ngb.schoolfee.exception.StudentManagementException;
import com.ngb.schoolfee.model.Customer;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.repository.CustomerRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import com.ngb.schoolfee.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;
    private final SchoolRepository schoolRepository;
    private final CustomerRepository customerRepository;

    @Override
    @Transactional
    public StudentResponse registerStudent(StudentRequest studentRequest, String customerId) throws StudentManagementException {
        // Validate Inputs
        validateStudentRequest(studentRequest);

        //Check if customer exists and has active card
        Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new StudentManagementException("Customer not found"));


        //Check if student already exists
        if (isStudentRegistered(studentRequest.getStudentId(), studentRequest.getSchoolId())) {
            throw new StudentManagementException("Student already registered");
        }

        //Find School
        School school = schoolRepository.findById(studentRequest.getSchoolId())
                .orElseThrow(() -> new StudentManagementException("School not found"));

        Student student = Student.builder()
                .studentId(studentRequest.getStudentId())
                .studentName(studentRequest.getStudentName())
                .registeredByCustomer(customer)
                .school(school)
                .registrationDate(LocalDateTime.now())
                .status(StudentStatus.REGISTERED)
                .lastUpdatedDate(LocalDateTime.now())
                .build();

        Student savedStudent = studentRepository.save(student);

        return StudentResponse.builder()
                .studentSystemId(savedStudent.getStudentId())
                .studentName(savedStudent.getStudentName())
                .studentId(savedStudent.getStudentId())
                .schoolId(savedStudent.getSchool().getSchoolId())
                .schoolName(savedStudent.getSchool().getSchoolName())
                .status(savedStudent.getStatus())
                .registrationDate(savedStudent.getRegistrationDate())
                .build();

    }

    @Override
    @Transactional
    public StudentResponse amendStudent(String studentId, Long schoolId, StudentRequest studentRequest) throws StudentManagementException {
        // Validate Inputs
        validateStudentRequest(studentRequest);

        //Find Student
        Student student = studentRepository.findById(studentId).orElseThrow(() -> new StudentManagementException("Student not found"));

        student.setStudentName(studentRequest.getStudentName());
        student.setSchool(schoolRepository.findById(studentRequest.getSchoolId())
                .orElseThrow(() -> new StudentManagementException("School not found")));
        student.setLastUpdatedDate(LocalDateTime.now());

        Student updatedStudent = studentRepository.save(student);

        return StudentResponse.builder()
                .studentSystemId(updatedStudent.getStudentId())
                .studentName(updatedStudent.getStudentName())
                .studentId(updatedStudent.getStudentId())
                .schoolId(updatedStudent.getSchool().getSchoolId())
                .schoolName(updatedStudent.getSchool().getSchoolName())
                .status(updatedStudent.getStatus())
                .registrationDate(updatedStudent.getRegistrationDate())
                .build();

    }

    @Override
    @Transactional
    public boolean deRegisterStudent(String studentId, Long schoolId, String customerId) throws StudentManagementException {
        Student student = studentRepository.findById(studentId).orElseThrow(() -> new StudentManagementException("Student not found"));

        if (!student.getRegisteredByCustomer().getCustomerId().equals(customerId)) {
            throw new StudentManagementException("You are not authorized to de-register this student.");
        }

        student.setStatus(StudentStatus.DE_REGISTERED);
        student.setLastUpdatedDate(LocalDateTime.now());

        studentRepository.save(student);
        return true;
    }

    @Override
    public List<StudentResponse> getStudentsByCustomer(String customerId) {
        return studentRepository.findAll()
                .stream()
                .filter(s -> s.getRegisteredByCustomer().getCustomerId().equals(customerId))
                .map(s -> StudentResponse.builder()
                        .studentSystemId(s.getStudentId())
                        .studentName(s.getStudentName())
                        .studentId(s.getStudentId())
                        .schoolId(s.getSchool().getSchoolId())
                        .schoolName(s.getSchool().getSchoolName())
                        .status(s.getStatus())
                        .registrationDate(s.getRegistrationDate())
                        .build())
                .collect(Collectors.toList());
    }

    @Override
    public boolean isStudentRegistered(String studentId, Long schoolId) {
        return studentRepository.existsById(studentId);
    }


    private void validateStudentRequest(StudentRequest studentRequest) throws StudentManagementException {
        if (studentRequest.getStudentName() == null || student