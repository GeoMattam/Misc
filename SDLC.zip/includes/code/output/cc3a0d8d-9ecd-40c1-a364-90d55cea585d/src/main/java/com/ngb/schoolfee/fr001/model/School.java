package com.ngb.schoolfee.fr001.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
public class School {
    @Id
    private String schoolId;
    private String name;
    private String location;
    private String accountnumber;
    private String ngbGlAccountConfig;
    private LocalDateTime registrationDate;
    private boolean isActive;
    private int minEnrolledStudents = 1000;
    private int operationalYears = 3;
    private double minAnnualFeeCollection = 500000.00;
    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;

    // Add other fields as needed, getters and setters

    public boolean applyBusinessRules() {
        // Implement business rule checks here...
        return true; // Placeholder
    }
}