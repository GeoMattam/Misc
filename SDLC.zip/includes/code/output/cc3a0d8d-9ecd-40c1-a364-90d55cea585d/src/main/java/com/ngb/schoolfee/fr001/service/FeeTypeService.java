package com.ngb.schoolfee.fr001.service;

import com.ngb.schoolfee.fr001.dto.FeeTypeRequest;
import com.ngb.schoolfee.fr001.model.FeeType;
import com.ngb.schoolfee.fr001.repository.FeeTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class FeeTypeService {

    private final FeeTypeRepository feeTypeRepository;

    @Autowired
    public FeeTypeService(FeeTypeRepository feeTypeRepository) {
        this.feeTypeRepository = feeTypeRepository;
    }

    public FeeType createFeeType(FeeTypeRequest request, String schoolId) {
        FeeType feeType = new FeeType();
        feeType.setFeeTypeId(UUID.randomUUID().toString());
        feeType.setName(request.getName());
        feeType.setDescription(request.getDescription());
        feeType.setSchoolId(schoolId); // Set school ID
        return feeTypeRepository.save(feeType);
    }

    // Add other methods for managing fee types as needed
}