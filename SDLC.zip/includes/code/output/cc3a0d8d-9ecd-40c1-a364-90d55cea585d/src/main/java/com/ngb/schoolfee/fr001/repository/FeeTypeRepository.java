package com.ngb.schoolfee.fr001.repository;

import com.ngb.schoolfee.fr001.model.FeeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeeTypeRepository extends JpaRepository<FeeType, String> {
    // Add custom query methods if needed
}