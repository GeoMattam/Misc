package com.ngb.schoolfee.fr001.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
public class FeeType {
    @Id
    private String feeTypeId;
    private String name;
    private String description;
    @ManyToOne
    @JoinColumn(name = "school_id")
    private School school;
    private boolean isActive = true;


    // Add other fields, getters, setters
}