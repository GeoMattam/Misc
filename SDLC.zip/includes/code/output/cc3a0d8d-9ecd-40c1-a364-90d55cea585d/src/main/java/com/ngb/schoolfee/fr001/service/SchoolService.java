package com.ngb.schoolfee.fr001.service;

import com.ngb.schoolfee.fr001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.fr001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.fr001.exception.SchoolRegistrationException;
import com.ngb.schoolfee.fr001.model.School;
import com.ngb.schoolfee.fr001.model.FeeType;
import com.ngb.schoolfee.fr001.repository.SchoolRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class SchoolService {

    private static final Logger logger = LoggerFactory.getLogger(SchoolService.class);

    private final SchoolRepository schoolRepository;
    private final FeeTypeService feeTypeService; // Inject FeeType service

    @Autowired
    public SchoolService(SchoolRepository schoolRepository, FeeTypeService feeTypeService) {
        this.schoolRepository = schoolRepository;
        this.feeTypeService = feeTypeService;
    }


    @Transactional
    public SchoolRegistrationResponse registerSchool(SchoolRegistrationRequest request) {
        SchoolRegistrationResponse response = new SchoolRegistrationResponse();
        try {
            // Validate school eligibility -  Implementation omitted for brevity, but should include business rules checks
            boolean isEligible = validateSchoolEligibility(request);
            if (!isEligible) {
                throw new SchoolRegistrationException("School does not meet eligibility criteria.");
            }


            School school = new School();
            school.setSchoolId(UUID.randomUUID().toString());
            school.setName(request.getSchoolName());
            school.setLocation(request.getLocation());
            school.setAccountnumber(request.getAccountNumber());
            school.setRegistrationDate(LocalDateTime.now());
            school.setIsActive(true);

            List<FeeType> feeTypes = request.getFeeTypes().stream()
                    .map(req -> feeTypeService.createFeeType(req, school.getSchoolId())) //Use FeeTypeService
                    .collect(Collectors.toList());
            school.setFeeTypes(feeTypes);

            schoolRepository.save(school);
            response.setSchoolId(school.getSchoolId());
            response.setStatus("REGISTERED");
            response.setMessage("School registered successfully.");
            logger.info("School registered successfully: {}", school);

        } catch (SchoolRegistrationException e) {
            response.setStatus("FAILED");
            response.setMessage(e.getMessage());
            logger.error("School registration failed: {}", e.getMessage());
        } catch (Exception e) {
            response.setStatus("FAILED");
            response.setMessage("An unexpected error occurred.");
            logger.error("School registration failed due to an unexpected error: {}", e.getMessage());
        }
        return response;
    }


    // Implement validation of school eligibility based on business rules
    private boolean validateSchoolEligibility(SchoolRegistrationRequest request) {
        // Replace this with your actual eligibility checks based on business rules
        // ...
        return true; // Placeholder - replace with actual business rule validation logic
    }

}