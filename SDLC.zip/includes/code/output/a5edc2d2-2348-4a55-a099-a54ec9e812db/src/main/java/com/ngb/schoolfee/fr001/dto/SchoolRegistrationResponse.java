package com.ngb.schoolfee.fr001.dto;

import lombok.Data;

@Data
public class SchoolRegistrationResponse {
    private String schoolId;
    private String status; // REGISTERED, FAILED
}