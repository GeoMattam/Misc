FR001 - School Registration (Card Operations Team)
|-- BR001 - A school must have a minimum of 1,000 enrolled students to qualify for registration in the NGB fee payment program.
|-- BR002 - School Must Be Operational for at Least 3 Years
|-- BR003 - The school must generate a minimum annual fee collection of €500,000.
+-- FR002 - Multiple Fee Types per School
FR003 - Student Registration/Amendment/De-registration (Online/Mobile Banking)
FR004 - Student Registration/Amendment/De-registration (Contact Center)
|-- NFR006 - Interoperability
+-- BR005 - Student ID Verification
FR005 - Fee Payment (Common)
|-- FR006 - Fee Payment (Online/Mobile Banking)
|   +-- BR009 - EPP Insufficient Balance
|-- FR007 - Fee Payment (IVR)
|   +-- BR008 - Daily Limits for IVR
|-- FR008 - Fee Posting
|-- BR004 - Active Cardholder Only
|-- BR006 - Registered Student Only
|-- BR007 - Insufficient Balance
|-- BR008 - Mandatory SMS Notifications
|-- BR009 - No Loyalty Points for EPP
+-- BR0010 - Transaction Logging
NFR001 - Security
NFR002 - Performance
NFR003 - Scalability
NFR004 - Reliability
NFR005 - Audit & Compliance