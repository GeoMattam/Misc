1.  General Conding Standards

    1.1 One Statement per Line: Improves readability and avoids errors.
    1.2 Line Length: Limit lines to 100–120 characters for better readability in all tools.
    1.3 DRY Principle: Avoid duplicating logic. Create reusable functions or modules.
    1.4 Comments and Documentation: Use comments to explain why, not what. Document all public APIs/functions with purpose, inputs, and expected outputs.
    1.5 Avoid Deep Nesting: Refactor code to reduce excessive levels of nesting (prefer early returns or break down into smaller functions)
    1.6 Consistent Naming Conventions: Use meaningful and consistent names for variables, functions, and classes (e.g., camelCase for variables/functions, PascalCase for classes).
    1.7 Proper Imports: Remove unused imports; avoid wildcard imports
    1.8 Exception Handling: Catch specific exceptions. Avoid catching Exception unless absolutely necessary.

2.  Language Coding Standards (Java)

    2.1 File Naming: Match class name and file name exactly (e.g., CustomerService.java).
    2.2 Indentation: Use 4 spaces per indentation level. Never mix tabs and spaces.
    2.3 Code Grouping: Group class members logically: constants → fields → constructors → methods → inner classes.
    2.4 Comments & Javadoc: Use meaningful comments and /** Javadoc */ for public classes and methods.
    2.5 Avoid Magic Numbers: Declare constants instead of embedding numbers/strings in logic.
    2.6 Braces Usage: Always use curly braces {} even for one-line if/for/while blocks.
    2.7 Logging over Print: Always use logging frameworks (e.g., SLF4J + Logback) instead of System.out.println.

3.  Language Idioms

    3.1 Using Enum Instead of Constants:
        public enum Status {
        ACTIVE, INACTIVE, PENDING
        }

    3.2 Immutable Objects:
        final class Point {
        private final int x, y;
        }

    3.3 Optional for Null Safety:
        Optional<User> user = userRepository.findById(id);
        user.ifPresent(u -> System.out.println(u.getName()));

    3.4 Try-with-Resources:
        try (BufferedReader br = new BufferedReader(new FileReader("file.txt"))) {
        // Auto-closes the resource
        }

4.  Design Patterns

    4.1 Singleton: Prefer Spring’s singleton-scoped beans (default behavior); avoid manual singletons using static blocks.
    4.2 Factory Pattern: Use @Component + conditional creation logic or @Bean methods inside @Configuration classes.
    4.3 Builder Pattern: Use Lombok’s @Builder for DTOs and complex object construction to reduce boilerplate.
    4.4 Strategy Pattern: Define a Strategy interface and annotate implementations with @Component; inject dynamically using @Qualifier or a Map<String, Strategy>.
    4.5 Facade Pattern: Provide a simplified interface (FacadeService) to a complex subsystem (or multiple services).
    4.6 Proxy Pattern: Use Spring AOP (@Around, @Before, etc.) to implement cross-cutting concerns like logging, metrics, and transactions.
    4.7 Decorator Pattern: Chain services by injecting and wrapping implementations (@Primary, @Qualifier).
    4.8 Adapter Pattern: Create Adapter classes for third-party or legacy APIs to align with internal interfaces.

5.  Design Paradigms

    5.1. Object-Oriented Design (OOD):  
    What: Structure applications using objects that encapsulate data and behavior.
    Spring Boot Fit: Everything is a bean/service/component—perfectly aligns with OOD.
    Key Principles: SOLID, Encapsulation, Abstraction, Inheritance, Polymorphism.
    Example: UserService encapsulates business logic, not exposed directly via UserController.

    5.2. Layered Architecture (N-Tier): 
    What: Divide the system into layers (Presentation → Service → Repository → Data).
    Spring Boot Fit: Aligns perfectly with MVC, REST APIs, and Spring Data.
    Best Practice: Each layer communicates only with adjacent layers.
    Example: Controller → Service → Repository → Entity

    5.3. Domain-Driven Design (DDD):    
    What: Focus on modeling the domain with rich domain objects and bounded contexts.
    Spring Boot Fit: Ideal for microservices & modular monoliths.
    Best Practice: Distinguish Entity, Value Object, Aggregate, and Service.
    Example: Loan domain with Loan, LoanApplication, and LoanService.

    5.4 Event-Driven Architecture:      
    What: Components communicate through events rather than direct calls.
    Spring Boot Fit: Use ApplicationEventPublisher, Spring Cloud Stream, Kafka.
    Best Practice: Emit events for state changes and decouple services.
    Example: After a user registers, publish a UserRegisteredEvent.

    5.5 Reactive Programming (Functional Paradigm):     
    What: Non-blocking, asynchronous data flow using streams and observables.
    Spring Boot Fit: Via Spring WebFlux, ideal for I/O-heavy apps.
    Best Practice: Use Mono, Flux, and reactive repositories.
    Example: Reactive API to stream chat messages or LLM response generation.

    5.6. Microservices Architecture:    
    What: Decompose app into small, independently deployable services.
    Spring Boot Fit: Lightweight, starter-based design makes microservices ideal.
    Best Practice: One domain per service, isolated DB, REST/gRPC communication.
    Example: Auth Service, User Service, and Chat Service as separate Spring Boot apps.

    5.7. Clean Architecture:    
    What: Domain is the core; frameworks, DBs, and UI are external layers.
    Spring Boot Fit: Use packages like domain, application, infra, web.
    Best Practice: Define interfaces in core; adapters outside.
    Example: Domain layer has LLMService, Infra layer implements OpenAILLMService.

6.  Object Oriented Idioms

    6.1 Favor Composition Over Inheritance: Instead of deep hierarchies, prefer assembling behavior from multiple components.
    6.2 Encapsulate What Varies: Hide what changes (algorithms, logic) behind stable interfaces or abstractions.
    6.3 Programming to Interface: Declare variables as interfaces (List, Map) rather than implementation (ArrayList).
    6.4 Tell, Don’t Ask: Ask an object to do something, not for its state to make decisions externally.
    6.5 Immutable Objects: Use final fields and no setters; good for DTOs and thread-safe classes.
    6.6 Don’t Repeat Yourself (DRY): Reuse code via abstraction, inheritance, or utility methods to avoid duplication.
    6.7 Single Responsibility Principle (SRP): Each class should have one reason to change. Keep focused logic.
    6.8 Open/Closed Principle (OCP): Classes should be open for extension, but closed for modification. Use interfaces and inheritance smartly.


7.  Security Guidelines

    7.1 Input Validation: Validate all user inputs on both client and server sides (e.g., using regex, types).
    7.2 Output Encoding: Escape outputs to prevent XSS (Cross-Site Scripting).
    7.3 Authentication: Use strong password policies, MFA, and avoid storing plaintext credentials.
    7.4 Authorization: Enforce Role-Based Access Control (RBAC) or Attribute-Based Access Control (ABAC).
    7.5 Secrets Management: Store secrets using vaults (e.g., HashiCorp Vault, AWS Secrets Manager); never in code.
    7.6 Rate Limiting: Protect endpoints against brute-force and DoS attacks using throttling techniques.
    7.7 Data Protection: Encrypt sensitive data in transit (TLS) and at rest (AES-256).
    7.8 Logging & Monitoring: Log access violations, privilege escalations, and unusual patterns (SIEM systems).
    7.9 Code Injection Prevention: Sanitize SQL queries, command executions, etc. Use ORM frameworks to mitigate.
    7.10 Security Headers: Add headers like X-Content-Type-Options, X-Frame-Options, Content-Security-Policy.
    7.11 Error Handling: Avoid exposing stack traces or sensitive data in error responses.

8.  Proformance Standards
    
    8.1 Efficient Data Structures: Choose the right collection (e.g., HashMap over List for lookup).
    8.2 Minimize Object Creation: Reuse objects where possible; avoid unnecessary instantiations inside loops.
    8.3 Use StringBuilder: Avoid string concatenation in loops; use StringBuilder for performance.
    8.4 Batch Processing: Process data in chunks instead of item-by-item for large datasets.
    8.5 Lazy Initialization: Don’t load or compute resources unless needed.
    8.6 Limit Logging in Hot Paths: Avoid excessive logging in loops or real-time request processing.
    8.7 Parallelism & Concurrency: Use Java’s ExecutorService or CompletableFuture for async tasks.
    8.8 Memory Management: Avoid memory leaks by unbinding listeners, closing resources, and avoiding static holders.
    8.9 Connection Pooling: Use pools (JDBC, HTTP) to reuse resources instead of repeated creation.
    8.10 Minimize I/O Blocking: Buffer reads/writes, use NIO or async I/O if applicable.
    8.11 Reduce External Calls: Cache external data, debounce user actions, use async patterns.


9.  SCA (Software Composition Analysis)
    
    9.1 Enforce Version Pinning:
        a. Avoid floating versions (+, LATEST, or version ranges).
        b. Pin dependencies to specific versions:
            xml
            <version>2.9.0</version>

    9.2. Audit Software Licenses
        a. Monitor for GPL, AGPL, SSPL licenses that may violate policy.
        b. Prefer MIT, Apache 2.0, BSD-licensed components.
        c. Tools like Snyk and WhiteSource support license compliance rules.

    9.3. Control Dependency Sources
        a. Use centralized artifact repositories (Nexus, Artifactory) for internal packages.
        b. Whitelist approved repositories and block unknown sources.

10 SAST ( Static Application Secuirty Testing)

    10.1. Baseline Your Security Ruleset
        a.Injection flaws (SQL, LDAP, Command)
        b.Insecure deserialization
        c.Hardcoded secrets / credentials
        d.Broken access controls
        e.Sensitive data exposure
        f.Improper error handling
        g.Use of dangerous APIs

    10.2. Secure Coding Standards Enforcement
        a. Ensure SAST checks align with Java + Spring Boot security idioms:
        b. No use of System.out for logging → enforce SLF4J.
        c. No SQL building with string concatenation → use JPA or PreparedStatement.
        d. Validate all @RequestParam, @RequestBody inputs → use @Valid & DTOs.
        e. Use @ControllerAdvice to handle and sanitize error responses.
        f. Avoid exposing full stack traces.

    10.3. Hardcoded Secrets Detection
        a. Use tools like Gitleaks, TruffleHog, or Snyk Code to detect:
            API keys
            Passwords
            JWT secrets
        b. Prevent commits with sensitive data using pre-commit hooks.