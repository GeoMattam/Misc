## 3. System Overview

### 3.1 System Description

The School Fee Payment System is a strategic initiative by New Gen Bank (NGB) to expand its card business into the education sector. Its primary purpose is to enable NGB Credit Card holders to conveniently pay school fees for registered students at partner schools. The system facilitates end-to-end processing from school and student registration to multi-channel fee payment, optional conversion to Easy Payment Plans (EPP), and real-time fee posting to relevant accounts. It integrates with various NGB digital channels like Online Banking, Mobile Banking, and IVR, ensuring a secure, scalable, and auditable transaction process.

### 3.2 System Context

The System Context diagram illustrates the School Fee Payment System's position within the broader NGB ecosystem, showing its interactions with external users and other NGB systems.

```plantuml
@startuml
!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Container.puml

title System Context Diagram for School Fee Payment System

Person(cardOperationsTeam, "NGB Card Operations Team", "Registers schools via dedicated UI.")
Person(productTeam, "NGB Product Team", "Provides school registration data (e.g., via email/Excel).")
Person(customer, "NGB Customer (Cardholder)", "Manages students and pays fees via NGB digital channels.")
Person(contactCenterAgent, "NGB Contact Center Agent", "Assists customers with student management and IVR payments via E-Form.")
System_Ext(schools, "Schools", "Recipients of fee payments; receive daily transaction reports.")

System(schoolFeePaymentSystem, "School Fee Payment System", "Enables school fee payments using NGB Credit Cards.")

System_Ext(onlineBanking, "NGB Online Banking", "Customer-facing web channel for banking services.")
System_Ext(mobileBanking, "NGB Mobile Banking", "Customer-facing mobile application for banking services.")
System_Ext(ivrSystem, "NGB IVR System", "NGB's Interactive Voice Response system for automated services.")
System_Ext(cardsSystem, "NGB Cards System", "Manages credit card accounts, processes debits and balance checks.")
System_Ext(glSystem, "NGB GL System", "Handles General Ledger postings for all financial transactions.")
System_Ext(crmSystem, "NGB CRM System", "Manages customer data; integrates with E-Form workflows.")
System_Ext(icrsSystem, "NGB ICRS", "Stores IVR transaction records for auditing.")
System_Ext(smsGateway, "SMS Gateway", "Sends automated SMS alerts and confirmations.")
System_Ext(emailSystem, "Email System", "Used for receiving data from product team and sending reports to schools.")


Rel(cardOperationsTeam, schoolFeePaymentSystem, "Registers Schools", "UI interaction")
Rel(productTeam, emailSystem, "Sends School Data", "Excel format")
Rel(emailSystem, schoolFeePaymentSystem, "Imports School Data", "Batch process / Manual processing")

Rel(customer, onlineBanking, "Accesses", "Web UI")
Rel(customer, mobileBanking, "Accesses", "Mobile App UI")
Rel(customer, ivrSystem, "Interacts with", "Voice/Menu navigation")

Rel(onlineBanking, schoolFeePaymentSystem, "Initiates Student Management & Payments", "API calls")
Rel(mobileBanking, schoolFeePaymentSystem, "Initiates Student Management & Payments", "API calls")
Rel(ivrSystem, schoolFeePaymentSystem, "Initiates Payments & Authentication", "API calls")

Rel(contactCenterAgent, crmSystem, "Uses E-Form", "Data entry & workflow")
Rel(crmSystem, schoolFeePaymentSystem, "Manages Student Data / Triggers EPP Requests", "API calls")
Rel(contactCenterAgent, ivrSystem, "Assists Customer", "System control")

Rel(schoolFeePaymentSystem, cardsSystem, "Debits Credit Cards / Checks Balance", "API calls")
Rel(schoolFeePaymentSystem, glSystem, "Posts Debits/Credits to GL Accounts", "Real-time API calls")
Rel(schoolFeePaymentSystem, smsGateway, "Sends Alerts & Confirmations", "API calls")
Rel(schoolFeePaymentSystem, icrsSystem, "Logs IVR Transaction Records", "API calls")
Rel(schoolFeePaymentSystem, emailSystem, "Sends Daily Reports to Schools", "Automated Excel Reports")

Rel(schoolFeePaymentSystem, schools, "Credits School Bank Account", "Automated Bank Transfer")

@enduml
```

### 3.3 Key Objectives & Goals

The primary objectives and goals of the School Fee Payment System are:
*   **Business Expansion:** To expand New Gen Bank's cards business by penetrating the school sector, starting with a pilot at Europe School.
*   **Customer Convenience:** To provide NGB Credit Card holders with convenient, multi-channel options (Online Banking, Mobile Banking, IVR) for paying school fees.
*   **Operational Efficiency:** To streamline the processes for school registration, student management (registration, amendment, de-registration), and fee collection.
*   **Financial Flexibility:** To offer cardholders the option to convert fee payments into Easy Payment Plans (EPP), enhancing their financial management.
*   **Transaction Integrity:** To ensure secure, real-time, and accurate debiting of credit cards and posting to General Ledger and school accounts.
*   **Auditability & Compliance:** To maintain comprehensive, traceable transaction logs and generate necessary reports for audit and compliance purposes.
*   **Scalability:** To support a growing number of schools and students, accommodating multiple transactions efficiently.

### 3.4 Stakeholders

The key stakeholders involved in the School Fee Payment System initiative include:

**Business Stakeholders:**
*   **NGB Cards Management:** Overall owner and driver of the initiative, focused on expanding card business.
*   **NGB Direct Banking (Online & Mobile):** Responsible for the digital channels used for payment.
*   **NGB Contact Centre:** Involved in student management via E-Forms and assisting IVR payments.
*   **NGB Card Operations Team:** Responsible for registering schools in the system.
*   **NGB Product Team:** Provides initial school data for registration.
*   **Schools (e.g., Europe School):** The beneficiaries receiving fee payments, and recipients of transaction reports.
*   **NGB Customers (Cardholders):** The end-users making fee payments.

**Technical Stakeholders:**
*   **NGB IT Department:** Responsible for system development, maintenance, and infrastructure.
*   **Teams managing Online Banking System:** Ensure integration and proper functionality.
*   **Teams managing Mobile Banking System:** Ensure integration and proper functionality.
*   **Teams managing IVR System:** Ensure integration and proper functionality.
*   **Teams managing Cards System:** Responsible for card-related transactions and data.
*   **Teams managing GL System:** Responsible for financial postings.
*   **Teams managing CRM System:** Involved in E-Form integration and customer data.
*   **Teams managing ICRS:** Responsible for IVR transaction logging.
*   **NGB Security & Compliance Teams:** Ensure adherence to security standards and regulatory requirements.

Here's the architectural outline for the School Fee Payment System based on the provided requirements.

---

## 4. Architectural Design

### 4.1 Architectural Overview

The NGB School Fee Payment System will be designed as a **service-oriented architecture (SOA)**, potentially leveraging **microservices** for core functionalities to ensure scalability, resilience, and maintainability. It will act as an intermediary layer, connecting various NGB digital channels (Online Banking, Mobile Banking, IVR) and internal systems (Cards System, GL, CRM) with a dedicated backend for school and student management, fee processing, and easy payment plan (EPP) conversions.

The architecture will consist of:
1.  **Channel Integration Layer**: Provides standardized APIs for various NGB digital channels, ensuring secure and consistent access to the system's functionalities. An API Gateway will serve as the single entry point.
2.  **Core Business Services**:
    *   **School & Student Management Service**: Manages the registration, amendment, and de-registration of schools and students, including the internal UI for the Card Operations Team.
    *   **Fee Payment Service**: Handles the processing of fee payments, including validation, debiting credit cards, and coordinating GL postings.
    *   **EPP Management Service**: Facilitates the conversion of fee payments into Easy Payment Plans, including validation against business rules.
    *   **Reporting Service**: Responsible for generating and dispatching daily Excel reports to registered schools.
3.  **Integration Layer**: Contains adapters and connectors to interact with existing NGB core banking systems like the Cards System, GL System, CRM, and SMS Gateway. This layer will abstract the complexities of external system communication.
4.  **Data Persistence Layer**: Securely stores all operational data, including school details, student records, fee types, and transaction logs, ensuring auditability and traceability.
5.  **Cross-Cutting Concerns**: Security (OTP, access controls), Logging, Monitoring, and Error Handling will be implemented across all layers to ensure non-functional requirements are met. Asynchronous messaging will be used for critical operations like GL postings and SMS alerts to enhance performance and reliability.

This modular approach ensures high cohesion within services and loose coupling between them, supporting real-time processing, high availability, and future enhancements.

### 4.2 Technology Stack

The system will primarily leverage the Java ecosystem, combined with robust enterprise-grade technologies to meet performance, security, and scalability requirements.

*   **Backend Language & Framework**:
    *   **Java**: Latest LTS version (e.g., Java 17/21).
    *   **Spring Boot**: For building RESTful APIs and microservices, providing rapid development and robust features.
    *   **Spring Cloud**: For microservices patterns (e.g., Service Discovery, Load Balancing, Circuit Breakers).
*   **Build Tool**:
    *   **Maven** or **Gradle**: For dependency management and project building.
*   **Database**:
    *   **PostgreSQL** or **Oracle Database**: Robust relational database for transactional data (Schools, Students, Fee Types, Transactions, EPP details).
    *   **JPA/Hibernate**: For Object-Relational Mapping (ORM).
*   **API Management**:
    *   **Spring Cloud Gateway** or **Netflix Zuul**: As an API Gateway for routing, security, and rate limiting.
*   **Messaging/Asynchronous Processing**:
    *   **Apache Kafka** or **RabbitMQ**: For asynchronous communication between services, real-time GL postings, and reliable SMS notifications.
*   **Security**:
    *   **Spring Security**: For authentication and authorization (integrating with NGB's IAM system).
    *   **JWT (JSON Web Tokens)** or **OAuth2**: For secure API access.
    *   **Internal NGB OTP Service**: Integration for multi-factor authentication.
*   **Reporting**:
    *   **Apache POI**: Java API for Microsoft Office documents, specifically for generating Excel reports.
*   **Containerization & Orchestration**:
    *   **Docker**: For containerizing applications.
    *   **Kubernetes**: For orchestrating, deploying, and scaling containerized applications.
*   **Monitoring & Logging**:
    *   **Prometheus & Grafana**: For metrics collection and visualization.
    *   **ELK Stack (Elasticsearch, Logstash, Kibana)**: For centralized logging and analysis.
*   **CI/CD**:
    *   **Jenkins**, **GitLab CI/CD**, or **Azure DevOps**: For automated build, test, and deployment pipelines.
*   **Version Control**:
    *   **Git** (e.g., GitHub Enterprise, GitLab).

### 4.3 Architecture Diagram

```plantuml
@startuml
!theme mars

skinparam {
  shadowing true
  ParticipantPadding 20
  BoxPadding 10
  RectanglePadding 10
  BorderColor #5E81AC
  BackgroundColor #ECEFF4
  FontColor #2E3440
  ArrowColor #88C0D0
  ArrowThickness 2
  RoundCorner 5
  Padding 10
}

skinparam component {
  BorderColor #81A1C1
  BackgroundColor #D8DEE9
  FontColor #3B4252
}

skinparam database {
  BorderColor #A3BE8C
  BackgroundColor #ECEFF4
  FontColor #3B4252
}

skinparam cloud {
  BorderColor #BF616A
  BackgroundColor #ECEFF4
  FontColor #3B4252
}

skinparam rectangle {
  BorderColor #B48EAD
  BackgroundColor #ECEFF4
  FontColor #3B4252
}

skinparam actor {
  BorderColor #BF616A
  FontColor #BF616A
}

title NGB School Fee Payment System - Component Architecture

rectangle "External NGB Channels" {
  component "Online Banking App" as OB
  component "Mobile Banking App" as MB
  component "IVR System" as IVR_SYS
  component "Contact Center E-Form" as EFORM
}

cloud "API Gateway" as APIGW

rectangle "NGB School Fee Payment Platform" {

  rectangle "Application Services" as AppServices {
    component "School & Student\nManagement Service" as SSMS
    component "Fee Payment Service" as FPS
    component "EPP Management Service" as EPPS
    component "Reporting Service" as RS
  }

  rectangle "Core Data" {
    database "Application Database\n(PostgreSQL/Oracle)" as DB {
      folder "School Data"
      folder "Student Data"
      folder "Fee Types"
      folder "Transaction Logs"
      folder "EPP Plans"
    }
  }

  rectangle "Integration Adapters" as Integration {
    component "Cards System Adapter" as CSA
    component "GL System Adapter" as GLSA
    component "SMS Gateway Adapter" as SMSA
    component "CRM System Adapter" as CRMA
    component "NGB OTP Service Adapter" as OTPA
  }
}

rectangle "NGB Core Systems" {
  component "Cards System" as CS_EXT
  component "NGB GL System" as GL_EXT
  component "NGB CRM System" as CRM_EXT
}

rectangle "External Entities" {
  component "SMS Gateway" as SMS_EXT
  rectangle "Registered Schools" as SCHOOLS_EXT
}

' Channel Interactions'
OB --> APIGW : Fee Payment / Student Mgt Request
MB --> APIGW : Fee Payment / Student Mgt Request
IVR_SYS --> APIGW : IVR Payment / Student Mgt Request
EFORM --> APIGW : Student Mgt / EPP Request

' API Gateway to Services'
APIGW --> SSMS : Manage Schools/Students
APIGW --> FPS : Process Fee Payments
APIGW --> EPPS : Manage EPP Conversions

' Internal Service Interactions'
SSMS --> DB : CRUD School/Student Data
FPS --> DB : Store Transactions / Retrieve Student Data
EPPS --> DB : Store EPP Plans / Retrieve Transactions
RS --> DB : Retrieve Transaction/School Data

FPS --> CSA : Debit Card Request
CSA --> CS_EXT : Debit Request / Card Info

FPS --> GLSA : GL Posting Request (Debit/Credit)
GLSA --> GL_EXT : GL Posting

SSMS --> OTPA : OTP Generation/Validation
FPS --> OTPA : OTP Generation/Validation
OTPA --> SMS_EXT : Send OTP

SMSA --> SMS_EXT : Send SMS Notification
FPS --> SMSA : Transaction Confirmation
SSMS --> SMSA : Registration/Amendment Confirmation
EPPS --> SMSA : EPP Status Notification

EFORM --> CRMA : Agent Data Entry / CRM Context
CRMA --> CRM_EXT : Customer/Student Lookup

RS --> SCHOOLS_EXT : Email Excel Reports

@enduml
```

### 4.4 Context Diagram

```plantuml
@startuml
!theme mars

skinparam {
  shadowing true
  ParticipantPadding 20
  BoxPadding 10
  RectanglePadding 10
  BorderColor #5E81AC
  BackgroundColor #ECEFF4
  FontColor #2E3440
  ArrowColor #88C0D0
  ArrowThickness 2
  RoundCorner 5
  Padding 10
}

skinparam system {
  BorderColor #81A1C1
  BackgroundColor #D8DEE9
  FontColor #3B4252
}

skinparam actor {
  BorderColor #BF616A
  FontColor #BF616A
}

skinparam system_ext {
  BorderColor #A3BE8C
  BackgroundColor #ECEFF4
  FontColor #3B4252
}

title NGB School Fee Payment System - Context Diagram

actor "NGB Cardholder" as Cardholder
actor "Card Operations Team" as CardOps
actor "Contact Center Agent" as CCAgent

system "NGB School Fee Payment Platform" as System {
  ' The central system is represented as a single block
}

system_ext "NGB Online Banking System" as OB_Sys
system_ext "NGB Mobile Banking System" as MB_Sys
system_ext "NGB IVR System" as IVR_Sys
system_ext "NGB Cards System" as Cards_Sys
system_ext "NGB General Ledger (GL) System" as GL_Sys
system_ext "NGB CRM System" as CRM_Sys
system_ext "SMS Gateway" as SMS_Gateway
system_ext "SMTP Server (for Reporting)" as SMTP_Server

rectangle "Registered Schools" as Schools

Cardholder --down--> OB_Sys : Access Payment Options
Cardholder --down--> MB_Sys : Access Payment Options
Cardholder --down--> IVR_Sys : Voice-based Transactions

CardOps --> System : School Registration Data (via UI)

CCAgent --> System : Student Management/EPP (via E-Form/IVR)
CCAgent --> CRM_Sys : Customer Authentication/Context

OB_Sys --right--> System : Student Mgt / Fee Payment Request
MB_Sys --right--> System : Student Mgt / Fee Payment Request
IVR_Sys --right--> System : Student Mgt / Fee Payment Request

System --right--> Cards_Sys : Credit Card Debit Request
Cards_Sys --left--> System : Debit Confirmation

System --right--> GL_Sys : GL Posting Request (Debit/Credit)
GL_Sys --left--> System : Posting Confirmation

System --down--> SMS_Gateway : Transaction/Notification SMS
SMS_Gateway --up--> System : SMS Delivery Status

System --right--> CRM_Sys : Student Registration Sync (Optional)
CRM_Sys --left--> System : Customer Info (for E-Form)

System --down--> SMTP_Server : Daily Excel Reports
SMTP_Server --right--> Schools : Email Excel Reports

@enduml
```

The architecture for the School Fee Payment system using NGB Credit Cards will be designed as a set of interconnected services, leveraging existing NGB infrastructure where appropriate. This approach promotes modularity, scalability, and maintainability, aligning with the functional and non-functional requirements.

---

### 5. Component Design

#### 5.1 Component List & Description

The system will be composed of the following key components/modules:

1.  **Admin Portal UI:**
    *   **Description:** A web-based user interface specifically for the NGB Card Operations Team. It provides functionalities for registering new schools, managing school details, and configuring fee types.
    *   **Role:** User interface for administrative functions related to school management.

2.  **School Management Service:**
    *   **Description:** A backend service responsible for managing all school-related data. This includes school registration, retrieval, and configuration of various fee types (e.g., School Fee, Bus Fee). It handles business rules like minimum student count, operational years, and annual fee collection.
    *   **Role:** Centralized repository and business logic for school entities.

3.  **Student Management Service:**
    *   **Description:** A backend service dedicated to managing student registrations, amendments, and de-registrations. It stores student details, links them to specific schools and NGB cardholders, and ensures unique student IDs.
    *   **Role:** Centralized repository and business logic for student entities.

4.  **Payment Orchestration Service:**
    *   **Description:** The core service orchestrating the fee payment process. It validates payment eligibility (registered student, active card), presents available cards and fee types, handles user remarks, initiates the debit/credit process, and manages EPP conversion requests.
    *   **Role:** Main transaction coordinator for fee payments.

5.  **Financial Posting Service:**
    *   **Description:** A critical backend service responsible for executing financial transactions. It handles the debiting of the NGB Credit Card, debiting the appropriate NGB GL Account (Visa/MasterCard), and crediting the School Account within NGB's Core Banking System. It ensures format constraints for transaction descriptions.
    *   **Role:** Ensures accurate and atomic financial ledger updates.

6.  **EPP Conversion Service:**
    *   **Description:** A specialized service that processes requests to convert fee payments into Easy Payment Plans. It validates eligibility for EPP, checks for sufficient balance at conversion time, and integrates with the E-Form Workflow System for further processing.
    *   **Role:** Manages the lifecycle and business rules for EPP conversions.

7.  **Notification Service:**
    *   **Description:** A shared utility service responsible for sending all types of SMS notifications, including registration confirmations, transaction confirmations, EPP rejections, and alerts.
    *   **Role:** Centralized outgoing communication (SMS).

8.  **Transaction & Audit Log Service:**
    *   **Description:** A dedicated service for persisting all transaction details, registration events, and key system activities. It ensures traceability, provides historical data for reporting, and maintains unique reference IDs for each transaction.
    *   **Role:** Provides immutable audit trail and historical data.

9.  **Reporting Service:**
    *   **Description:** A batch processing service responsible for generating daily Excel reports for each registered school. It fetches data from the Transaction & Audit Log Service and facilitates email delivery.
    *   **Role:** Generates and delivers compliance and operational reports.

#### 5.2 Component Interaction

Components will primarily communicate using RESTful APIs for synchronous operations and potentially message queues for asynchronous events (e.g., notifications, logging).

*   **School Registration:**
    *   `Admin Portal UI` sends school registration data to `School Management Service`.
    *   `School Management Service` stores data and potentially triggers internal GL configuration (via `Core Banking System Adapter`).

*   **Student Management (Registration/Amendment/De-registration):**
    *   `Online Banking` / `Mobile Banking` / `Contact Center E-Form` sends student data to `Student Management Service`.
    *   `Student Management Service` interacts with `Authentication Service` for OTP validation (for Online/Mobile) and `Notification Service` for SMS alerts.
    *   `Student Management Service` ensures data persistence.

*   **Fee Payment:**
    *   `Online Banking` / `Mobile Banking` / `IVR` sends payment requests to `Payment Orchestration Service`.
    *   `Payment Orchestration Service` validates student eligibility with `Student Management Service`.
    *   `Payment Orchestration Service` interacts with `Authentication Service` for OTP/TIN validation.
    *   Upon successful validation, `Payment Orchestration Service` initiates debit on `Cards System` via `Cards System Adapter`.
    *   Concurrently, `Payment Orchestration Service` instructs `Financial Posting Service` to debit GL and credit School Accounts.
    *   `Financial Posting Service` interacts with `Core Banking System Adapter` for GL and School account updates.
    *   Both `Payment Orchestration Service` and `Financial Posting Service` log detailed transaction information to `Transaction & Audit Log Service`.
    *   `Payment Orchestration Service` triggers `Notification Service` for transaction confirmation SMS.

*   **EPP Conversion:**
    *   `Payment Orchestration Service` forwards EPP conversion requests to `EPP Conversion Service`.
    *   `EPP Conversion Service` performs balance checks (potentially via `Cards System Adapter`).
    *   `EPP Conversion Service` creates/triggers an E-Form in the `E-Form Workflow System`.
    *   `EPP Conversion Service` sends rejection notifications via `Notification Service` if conditions are not met.

*   **Reporting:**
    *   `Reporting Service` periodically queries `Transaction & Audit Log Service` for relevant data.
    *   `Reporting Service` generates Excel reports and uses an `Email Gateway` to send them.

#### 5.3 Dependency Mapping

This section outlines the major internal and external dependencies for each core component.

*   **Admin Portal UI:**
    *   **Internal:** `School Management Service` (API)
    *   **External:** Web Browser

*   **School Management Service:**
    *   **Internal:** Database
    *   **External:** `Core Banking System Adapter` (for GL Account configuration - future direct integration)

*   **Student Management Service:**
    *   **Internal:** Database, `Notification Service`
    *   **External:** `Authentication Service` (for OTP)

*   **Payment Orchestration Service:**
    *   **Internal:** `Student Management Service`, `Financial Posting Service`, `EPP Conversion Service`, `Transaction & Audit Log Service`, `Notification Service`
    *   **External:** `Cards System Adapter`, `Authentication Service`

*   **Financial Posting Service:**
    *   **Internal:** `Transaction & Audit Log Service`
    *   **External:** `Cards System Adapter`, `Core Banking System Adapter`

*   **EPP Conversion Service:**
    *   **Internal:** `Notification Service`
    *   **External:** `E-Form Workflow System`, `Cards System Adapter` (for balance checks)

*   **Notification Service:**
    *   **Internal:** None (a utility consumed by others)
    *   **External:** `SMS Gateway`

*   **Transaction & Audit Log Service:**
    *   **Internal:** Database
    *   **External:** None

*   **Reporting Service:**
    *   **Internal:** `Transaction & Audit Log Service`
    *   **External:** `Email Gateway`

*   **Cards System Adapter:**
    *   **Internal:** None (an adapter for an external system)
    *   **External:** NGB `Cards System`

*   **Core Banking System Adapter:**
    *   **Internal:** None (an adapter for an external system)
    *   **External:** NGB `Core Banking System`

*   **Authentication Service (Existing NGB System):**
    *   **Internal:** None (a shared service)
    *   **External:** NGB Identity & Access Management Systems

*   **E-Form Workflow System (Existing NGB System):**
    *   **Internal:** None (a shared service)
    *   **External:** NGB `CRM`, NGB `Workflow Engine`

#### 5.4 Component Diagram

The following UML Component Diagram illustrates the structural relationships and interactions among the system's components.

```plantuml
@startuml
!theme mars

skinparam {
    component {
        backgroundColor LightGreen
        borderColor DarkGreen
        FontColor DarkGreen
        shadowing true
    }
    database {
        backgroundColor LightBlue
        borderColor DarkBlue
        FontColor DarkBlue
        shadowing true
    }
cloud {
        backgroundColor LightGray
        borderColor DarkGray
        FontColor DarkGray
        shadowing true
    }
    queue {
        backgroundColor LightYellow
        borderColor DarkOrange
        FontColor DarkOrange
        shadowing true
    }
    interface {
        borderColor DarkRed
        FontColor DarkRed
    }
    rectangle {
        borderColor Black
        FontColor Black
        backgroundColor WhiteSmoke
    }
    ArrowColor DarkSlateGray
    ArrowFontColor DarkSlateGray
    ArrowFontSize 10
}

title School Fee Payment System - Component Diagram

rectangle "NGB School Fee Payment Solution" {

    component "Admin Portal UI" as AdminUI
    component "School Management Service" as SMSvc
    component "Student Management Service" as StdSvc
    component "Payment Orchestration Service" as PayOrchSvc
    component "Financial Posting Service" as FinPostSvc
    component "EPP Conversion Service" as EPPConvSvc
    component "Notification Service" as NotifSvc
    component "Transaction & Audit Log Service" as TxnLogSvc
    component "Reporting Service" as ReportSvc

    database "Application Database" as AppDB

    AdminUI --> SMSvc : Manages Schools
    SMSvc --> AppDB : Stores School Data
    StdSvc --> AppDB : Stores Student Data

    PayOrchSvc -up-> StdSvc : Validates Student
    PayOrchSvc -down-> FinPostSvc : Initiates Postings
    PayOrchSvc -left-> EPPConvSvc : Requests EPP Conversion
    PayOrchSvc -right-> NotifSvc : Sends SMS
    PayOrchSvc -down-> TxnLogSvc : Logs Transactions

    FinPostSvc --> TxnLogSvc : Logs Financial Postings

    EPPConvSvc -right-> NotifSvc : Sends EPP Alerts
    EPPConvSvc -up-> PayOrchSvc : EPP Result

    ReportSvc --> TxnLogSvc : Fetches Data
}

rectangle "NGB Ecosystem (Existing Systems)" {
    cloud "Online Banking" as OB
    cloud "Mobile Banking" as MB
    cloud "IVR System" as IVR
    cloud "Contact Center E-Form System" as CCEForm

    cloud "Cards System" as CardSys
    cloud "Core Banking System" as CoreBankSys
    cloud "SMS Gateway" as SMSGateway
    cloud "Email Gateway" as EmailGateway
    cloud "Authentication Service" as AuthSvc
    cloud "E-Form Workflow System" as EFormWF
    cloud "CRM" as CRM
}

OB --down--> PayOrchSvc : Payment Request
MB --down--> PayOrchSvc : Payment Request
IVR --down--> PayOrchSvc : Payment Request

OB --down--> StdSvc : Student Mgmt
MB --down--> StdSvc : Student Mgmt
CCEForm --down--> StdSvc : Student Mgmt

PayOrchSvc --right--> CardSys : Debit CC
FinPostSvc --right--> CardSys : Debit GL/CC
FinPostSvc --right--> CoreBankSys : Debit GL / Credit School

NotifSvc --right--> SMSGateway : Send SMS

ReportSvc --right--> EmailGateway : Send Reports

PayOrchSvc --right--> AuthSvc : Authenticate (OTP/TIN)
StdSvc --right--> AuthSvc : Authenticate (OTP)

EPPConvSvc --right--> EFormWF : Create/Update E-Form
EFormWF -left-> CRM : Workflow Integration

note "Includes all Card Products (Visa Conventional, Islamic, MC)" as CardsNote
CardSys .. CardsNote

note "Includes GL Accounts & School Accounts" as CoreBankNote
CoreBankSys .. CoreBankNote

@enduml
```

```plantuml
@startuml
!theme plain
skinparam handwritten false
skinparam class {
    BorderColor #A3B8B9
    BackgroundColor #EDF2F4
    ArrowColor #A3B8B9
}
skinparam relationship {
    LineColor #A3B8B9
    FontColor #A3B8B9
    ArrowColor #A3B8B9
}

title "School Fee Payment System - Entity-Relationship Diagram"

entity "School" as School {
    **school_id** (PK)
    --
    school_name
    location
    ngb_account_number
    ngb_gl_account_config
    registration_date
    is_active
}

entity "FeeType" as FeeType {
    **fee_type_id** (PK)
    --
    fee_type_name
    description
    **school_id** (FK)
}

entity "Customer" as Customer {
    **customer_id** (PK)
    --
    customer_name
    contact_info
    status
}

entity "CreditCard" as CreditCard {
    **card_number** (PK)
    --
    **customer_id** (FK)
    card_type
    expiry_date
    balance
    status
}

entity "Student" as Student {
    **student_id** (PK)
    **school_id** (PK, FK)
    --
    student_name
    **registered_by_customer_id** (FK)
    registration_date
    status
}

entity "Transaction" as Transaction {
    **transaction_id** (PK)
    --
    transaction_date_time
    amount
    remark (20 char)
    status
    posting_description (40 char)
    is_epp_converted
    gl_posting_status
    **card_number** (FK)
    **student_id** (FK)
    **school_id** (FK)
    **fee_type_id** (FK)
}

entity "EPP_Request" as EPPRequest {
    **epp_request_id** (PK)
    **transaction_id** (PK, FK)
    --
    request_date_time
    status
    rejection_reason
}

entity "AuditLog" as AuditLog {
    **log_id** (PK)
    --
    activity_type
    entity_id_affected
    entity_type
    timestamp
    performed_by_user_or_system
    details
}

' Relationships
School ||--o{ FeeType : "offers"
School ||--o{ Student : "enrolls"
Customer ||--o{ CreditCard : "owns"
Customer ||--o{ Student : "registers"
CreditCard ||--o{ Transaction : "used in"
Student ||--o{ Transaction : "involved in"
FeeType ||--o{ Transaction : "selected for"

Transaction ||--o| EPPRequest : "can convert to"

' AuditLog relationships are more conceptual due to generic FKs
' AuditLog o-- Transaction
' AuditLog o-- Student
' AuditLog o-- School
' AuditLog o-- EPPRequest

@enduml
```

## 6. Data Design

### 6.1 Data Model: Describe the data model, including major entities and relationships.

The data model for the School Fee Payment system is designed around several core entities that represent the key participants and activities within the system.

*   **School:** This entity represents an educational institution registered with New Gen Bank (NGB) for fee collection. It holds fundamental information about the school and acts as a central point for managing associated fee types and student enrollments.
*   **FeeType:** This entity defines the various categories of fees that a particular school offers (e.g., "School Fee," "Bus Fee"). Each `FeeType` is directly associated with a `School`.
*   **Customer:** Represents an NGB credit cardholder. This entity is crucial for authenticating users who can register students and initiate fee payments. It's expected to be synchronized or referenced from the bank's core Customer Relationship Management (CRM) system.
*   **CreditCard:** This entity holds details of an NGB credit card owned by a `Customer`. It's the primary instrument for making payments and is likely synchronized from the bank's Cards System.
*   **Student:** Represents an individual student enrolled at a registered `School`. Students must be registered by an active `Customer` before any fee payments can be made on their behalf. The unique identification of a student is combined with the school they attend.
*   **Transaction:** This is the central transactional entity, recording every fee payment processed through the system. It captures details such as the amount, date, the `CreditCard` used, the `Student` for whom the payment was made, the `School` receiving the payment, and the specific `FeeType`. It also tracks the transaction's status and any relevant remarks.
*   **EPP_Request:** This entity captures requests from `Customer`s to convert a completed `Transaction` into an Easy Payment Plan (EPP). It maintains a one-to-one or one-to-zero-or-one relationship with a `Transaction`, indicating whether a payment is subject to an EPP.
*   **AuditLog:** This is a comprehensive logging entity designed for traceability and compliance. It records significant system activities, including registrations, amendments, de-registrations, payments, and EPP processing, detailing who performed the action, when, and on which entity.

**Relationships:**

*   A `School` **offers** multiple `FeeType`s (One-to-Many).
*   A `School` **enrolls** multiple `Student`s (One-to-Many).
*   A `Customer` **owns** multiple `CreditCard`s (One-to-Many).
*   A `Customer` **registers** multiple `Student`s (One-to-Many).
*   A `CreditCard` **is used in** multiple `Transaction`s (One-to-Many).
*   A `Student` **is involved in** multiple `Transaction`s (One-to-Many).
*   A `FeeType` **is selected for** each `Transaction` (One-to-Many).
*   A `Transaction` **can convert to** one `EPP_Request` (One-to-Zero-or-One).
*   `AuditLog` entries provide traceability for actions across various entities (`School`, `Student`, `Transaction`, `EPP_Request`), linked conceptually through `entity_id_affected` and `entity_type` fields.

### 6.2 Database Schema: Provide an overview of the database schema.

The database schema will comprise several tables, each corresponding to an entity described above, with defined primary keys (PKs) and foreign keys (FKs) to enforce referential integrity.

*   **`SCHOOL` Table:**
    *   `school_id` (PK, VARCHAR/INT) - Unique identifier for the school.
    *   `school_name` (VARCHAR) - Full name of the school.
    *   `location` (VARCHAR) - Geographical location.
    *   `ngb_account_number` (VARCHAR) - School's NGB account for crediting fees.
    *   `ngb_gl_account_config` (VARCHAR) - Internal GL account identifier or mapping.
    *   `registration_date` (DATE/TIMESTAMP) - Date the school was registered.
    *   `is_active` (BOOLEAN) - Status of the school registration.

*   **`FEE_TYPE` Table:**
    *   `fee_type_id` (PK, INT) - Unique identifier for the fee type.
    *   `school_id` (FK, INT) - References `SCHOOL.school_id`.
    *   `fee_type_name` (VARCHAR) - Name of the fee type (e.g., "School Fee").
    *   `description` (VARCHAR, NULLABLE) - Optional description.

*   **`CUSTOMER` Table:** (Likely a replicated or integrated table from core banking systems)
    *   `customer_id` (PK, VARCHAR/INT) - Unique identifier for the customer (cardholder).
    *   `customer_name` (VARCHAR) - Name of the customer.
    *   `contact_info` (VARCHAR) - Email or phone number.
    *   `status` (VARCHAR) - E.g., 'ACTIVE', 'INACTIVE'.

*   **`CREDIT_CARD` Table:** (Likely a replicated or integrated table from the Cards System)
    *   `card_number` (PK, VARCHAR) - Unique credit card number (masked/encrypted).
    *   `customer_id` (FK, VARCHAR/INT) - References `CUSTOMER.customer_id`.
    *   `card_type` (VARCHAR) - E.g., 'VISA_CONVENTIONAL', 'MASTERCARD'.
    *   `expiry_date` (DATE) - Card expiry date.
    *   `balance` (DECIMAL) - Current card balance (may be dynamic/real-time retrieved).
    *   `status` (VARCHAR) - E.g., 'ACTIVE', 'INACTIVE', 'BLOCKED'.

*   **`STUDENT` Table:**
    *   `student_id` (PK, VARCHAR/INT) - Unique identifier for the student within a school.
    *   `school_id` (PK, FK, INT) - References `SCHOOL.school_id`. (Forms a composite primary key with `student_id`).
    *   `student_name` (VARCHAR) - Full name of the student.
    *   `registered_by_customer_id` (FK, VARCHAR/INT) - References `CUSTOMER.customer_id`.
    *   `registration_date` (DATE/TIMESTAMP) - Date the student was registered.
    *   `status` (VARCHAR) - E.g., 'ACTIVE', 'DE-REGISTERED'.

*   **`TRANSACTION` Table:**
    *   `transaction_id` (PK, VARCHAR/UUID) - Unique reference ID for each payment.
    *   `transaction_date_time` (TIMESTAMP) - Timestamp of the transaction.
    *   `amount` (DECIMAL) - Payment amount.
    *   `card_number` (FK, VARCHAR) - References `CREDIT_CARD.card_number`.
    *   `student_id` (FK, VARCHAR/INT) - References `STUDENT.student_id`.
    *   `school_id` (FK, INT) - References `SCHOOL.school_id`.
    *   `fee_type_id` (FK, INT) - References `FEE_TYPE.fee_type_id`.
    *   `remark` (VARCHAR(20), NULLABLE) - Optional user-input remark.
    *   `status` (VARCHAR) - E.g., 'SUCCESS', 'FAILED', 'PENDING_EPP', 'CANCELLED'.
    *   `posting_description` (VARCHAR(40)) - Formatted description for GL posting.
    *   `is_epp_converted` (BOOLEAN) - Flag indicating if converted to EPP (default FALSE).
    *   `gl_posting_status` (VARCHAR) - Status of the GL posting (e.g., 'PENDING', 'POSTED', 'FAILED').

*   **`EPP_REQUEST` Table:**
    *   `epp_request_id` (PK, VARCHAR/UUID) - Unique identifier for the EPP request.
    *   `transaction_id` (PK, FK, VARCHAR/UUID) - References `TRANSACTION.transaction_id`. (Forms a composite primary key with `epp_request_id` and ensures 1:1 relationship).
    *   `request_date_time` (TIMESTAMP) - Timestamp of the EPP request.
    *   `status` (VARCHAR) - E.g., 'PENDING', 'APPROVED', 'REJECTED'.
    *   `rejection_reason` (VARCHAR, NULLABLE) - Reason if request is rejected.
    *   *(Further fields for installment details would be added here if required, e.g., `num_installments`, `installment_amount`)*

*   **`AUDIT_LOG` Table:**
    *   `log_id` (PK, BIGINT/UUID) - Unique log entry identifier.
    *   `activity_type` (VARCHAR) - E.g., 'STUDENT_REGISTRATION_SUCCESS', 'PAYMENT_FAILED'.
    *   `entity_id_affected` (VARCHAR) - ID of the primary entity involved (e.g., student_id, transaction_id).
    *   `entity_type` (VARCHAR) - Type of entity affected (e.g., 'STUDENT', 'TRANSACTION').
    *   `timestamp` (TIMESTAMP) - When the activity occurred.
    *   `performed_by_user_or_system` (VARCHAR) - Identifier of the user or system component.
    *   `details` (TEXT/JSONB) - Additional context or message (e.g., SMS content, error message).

### 6.3 Data Flow: Describe how data is created, read, updated, and deleted within the system.

Data flows through the system across various functional modules and interacts with internal and external systems.

**Data Creation (C - Create):**
*   **School Registration:**
    *   `SCHOOL` and associated `FEE_TYPE` records are *created* via a UI for the Card Operations Team or through an automated process for Excel uploads from the Product Team.
    *   An `AUDIT_LOG` entry is *created* for each successful school registration.
*   **Student Registration:**
    *   `STUDENT` records are *created* by customers through Online/Mobile Banking channels or by Contact Center agents using an E-Form after IVR authentication.
    *   `AUDIT_LOG` entries are *created* to record these new student registrations.
*   **Fee Payment:**
    *   Upon a successful payment transaction, a `TRANSACTION` record is *created*, capturing all relevant payment details.
    *   An `AUDIT_LOG` entry is *created* for payment confirmation.
*   **EPP Conversion Request:**
    *   When a customer opts to convert a payment to EPP, an `EPP_REQUEST` record is *created*, linked to the `TRANSACTION`.
    *   An `AUDIT_LOG` entry is *created* for the EPP request initiation.

**Data Reading (R - Read):**
*   **User Interface Displays:**
    *   Online/Mobile Banking interfaces *read* `SCHOOL` names for dropdown selection.
    *   They *read* the customer's registered `STUDENT`s and available `CREDIT_CARD`s for selection.
    *   `FEE_TYPE`s are *read* based on the selected `SCHOOL`.
    *   Transaction history views *read* `TRANSACTION` records (last 6 months) for display.
*   **System Validations:**
    *   Before processing payments, the system *reads* `CUSTOMER`, `CREDIT_CARD` (for status and balance), `SCHOOL`, and `STUDENT` data to perform various validations (e.g., active card, registered student, sufficient balance).
*   **Reporting:**
    *   The reporting module *reads* `SCHOOL`, `STUDENT`, and `TRANSACTION` data to generate daily Excel reports.
*   **External System Interactions:**
    *   The system *reads* real-time card balance information from the `Cards System` via API calls.

**Data Updates (U - Update):**
*   **Student Amendment:**
    *   Customers (Online/Mobile Banking) or Contact Center agents (E-Form) *update* existing `STUDENT` details.
    *   `AUDIT_LOG` entries are *created* for all amendments.
*   **Fee Posting:**
    *   The `TRANSACTION` record's `gl_posting_status` is *updated* after integration with the NGB General Ledger (GL) system (e.g., from 'PENDING' to 'POSTED' or 'FAILED').
    *   The `CREDIT_CARD` balance in the `Cards System` is *updated* by debiting the transaction amount.
*   **EPP Request Status:**
    *   The `EPP_REQUEST` record's `status` is *updated* (e.g., to 'APPROVED' or 'REJECTED') by the Cards Management team, potentially via an E-Form workflow.
    *   The corresponding `TRANSACTION` record's `is_epp_converted` flag is *updated*.
    *   `AUDIT_LOG` entries are *created* for EPP status changes.

**Data Deletion (D - Delete):**
*   **Student De-registration:**
    *   Student de-registration is handled as a "soft delete" by *updating* the `STUDENT.status` field to 'DE-REGISTERED'. This preserves historical data for audit purposes.
    *   An `AUDIT_LOG` entry is *created* for de-registration.
*   *(Note: Direct hard deletion of core transactional or registration data is generally avoided in financial systems due to audit, compliance, and historical reporting requirements.)*

**External Data Flow and Interactions:**
*   **Online/Mobile Banking:** User interfaces send and receive data for student management and fee payment.
*   **IVR:** Provides input and receives authentication from the system; directs agents for E-Form creation.
*   **CRM:** Provides customer master data and potentially receives updates on customer activities.
*   **Cards System:** Involved in real-time card validation, debiting, and potentially card balance inquiries.
*   **NGB Core Banking (GL):** Receives real-time fee posting instructions (debit credit card GL, credit school account).
*   **E-Form Workflow:** Facilitates data exchange and state management between Contact Center, Cards team, and system for student management and EPP processing.
*   **SMS Gateway:** Receives messages from the system for transactional alerts and confirmations.
*   **Email Service:** Used to send daily Excel reports to registered schools.
*   **ICRS (Internal Credit Risk System):** Receives `TRANSACTION` records specifically for IVR payments, as per requirements.

### 6.4 ER Diagram : Entity-Relationship diagram showing logical data structure.

The following PlantUML diagram illustrates the major entities and their relationships within the School Fee Payment System. Primary keys are marked with `**` and foreign keys are indicated with `(FK)`. Relationships are depicted using standard crow's foot notation.

```plantuml
@startuml
!theme plain
skinparam handwritten false
skinparam class {
    BorderColor #A3B8B9
    BackgroundColor #EDF2F4
    ArrowColor #A3B8B9
}
skinparam relationship {
    LineColor #A3B8B9
    FontColor #A3B8B9
    ArrowColor #A3B8B9
}

title "School Fee Payment System - Entity-Relationship Diagram"

entity "School" as School {
    **school_id** (PK)
    --
    school_name
    location
    ngb_account_number
    ngb_gl_account_config
    registration_date
    is_active
}

entity "FeeType" as FeeType {
    **fee_type_id** (PK)
    --
    fee_type_name
    description
    **school_id** (FK)
}

entity "Customer" as Customer {
    **customer_id** (PK)
    --
    customer_name
    contact_info
    status
}

entity "CreditCard" as CreditCard {
    **card_number** (PK)
    --
    **customer_id** (FK)
    card_type
    expiry_date
    balance
    status
}

entity "Student" as Student {
    **student_id** (PK)
    **school_id** (PK, FK)
    --
    student_name
    **registered_by_customer_id** (FK)
    registration_date
    status
}

entity "Transaction" as Transaction {
    **transaction_id** (PK)
    --
    transaction_date_time
    amount
    remark (20 char)
    status
    posting_description (40 char)
    is_epp_converted
    gl_posting_status
    **card_number** (FK)
    **student_id** (FK)
    **school_id** (FK)
    **fee_type_id** (FK)
}

entity "EPP_Request" as EPPRequest {
    **epp_request_id** (PK)
    **transaction_id** (PK, FK)
    --
    request_date_time
    status
    rejection_reason
}

entity "AuditLog" as AuditLog {
    **log_id** (PK)
    --
    activity_type
    entity_id_affected
    entity_type
    timestamp
    performed_by_user_or_system
    details
}

' Relationships
School ||--o{ FeeType : "offers"
School ||--o{ Student : "enrolls"
Customer ||--o{ CreditCard : "owns"
Customer ||--o{ Student : "registers"
CreditCard ||--o{ Transaction : "used in"
Student ||--o{ Transaction : "involved in"
FeeType ||--o{ Transaction : "selected for"

Transaction ||--o| EPPRequest : "can convert to"

' AuditLog relationships are more conceptual due to generic FKs
' AuditLog o-- Transaction
' AuditLog o-- Student
' AuditLog o-- School
' AuditLog o-- EPPRequest

@enduml
```

### 7. Interface Design

#### 7.1 User Interface

The system will expose various user interfaces tailored for different user roles and channels:

*   **Card Operations UI (Web-based):**
    *   **Purpose:** Dedicated interface for the NGB Card Operations Team to manage school registrations.
    *   **Key Screens/Flows:**
        *   **School Registration Form:** Allows input of School Name, Location, and NGB Account Number.
        *   Confirmation/Error messages post-registration.

*   **Online Banking UI (Web & Mobile Application):**
    *   **Purpose:** For NGB customers to manage student registrations, make fee payments, and view history.
    *   **Key Screens/Flows:**
        *   **Student Management:**
            *   Student Registration Form: Input Student Name, Student ID (twice for confirmation), select School (dropdown).
            *   Student Amendment/De-registration: Select existing student, modify details or de-register.
            *   OTP authentication is mandatory for these actions.
        *   **Fee Payment:**
            *   Payment Initiation: Display active NGB Credit Cards for selection, dropdowns for registered students and fee types (based on selected school). Optional 20-character remark field.
            *   Payment Confirmation: Summary of transaction details.
            *   EPP Conversion Option: Checkbox or button to initiate Easy Payment Plan conversion.
        *   **Transaction History:** View payments for the last 6 months, including details like amount, date, student, and remarks.

*   **Contact Center E-Form (Agent Application):**
    *   **Purpose:** A digital form used by Contact Center Agents to assist customers with student management.
    *   **Key Screens/Flows:**
        *   **Student Management Form:** Manual input fields for Student Name, Student ID (copy-paste restricted), School, to register, amend, or de-register students based on customer's IVR authentication and verbal instructions.
        *   Integration with CRM for E-Form workflow and record keeping.

*   **IVR System (Voice-based):**
    *   **Purpose:** An interactive voice response system for NGB customers to make fee payments.
    *   **Key Features/Flows:**
        *   **Authentication:** Via IVR TIN.
        *   **Navigation:** Voice-guided menu options for selecting students, fee types, and initiating payments.
        *   **Student Name Playback:** Optional Text-To-Speech (TTS) for confirming registered student names.
        *   **Payment Confirmation:** Voice confirmation of transaction details.
        *   OTP verification and configurable daily limits apply.
        *   For EPP conversion requests originating from IVR, an E-Form is created by the agent.

#### 7.2 External Interfaces

The School Fee Payment System (SFPS) will integrate with several key internal and external systems to fulfill its functional and non-functional requirements:

*   **Online Banking System (OBS) & Mobile Banking System (MBS):** Act as primary user-facing channels, consuming services from SFPS for student management and fee payment.
*   **IVR System:** Integrates with SFPS to facilitate voice-based fee payments and agent-assisted student management.
*   **CRM System:** Used for managing customer relationships, triggering E-Form workflows for EPP conversions, and tracking agent-assisted student management activities.
*   **Cards System:** Core banking system responsible for managing credit cards, retrieving active card details, and processing debit transactions.
*   **GL Account System:** Manages the bank's General Ledger. SFPS integrates for real-time debiting of NGB GL accounts (Visa Conventional/Islamic/MasterCard) and crediting school accounts.
*   **SMS Gateway:** Used for sending mandatory SMS alerts (OTP, registration/amendment/de-registration confirmation, payment confirmation, EPP rejection).
*   **Email System:** For receiving school registration data in Excel format from the Product Team and for automatically sending daily transaction reports in Excel format to registered schools.
*   **ICRS (IVR Customer Relationship System/Reporting System):** To update and maintain transaction records specifically originating from the IVR channel.

#### 7.3 Interface Diagrams

The following diagram illustrates the high-level system context and key interfaces between the School Fee Payment System and its interacting components, users, and external systems.

```plantuml
@startuml
!theme mars

title School Fee Payment System - System Context Diagram

actor "Card Operations Team" as OpsTeam
actor "NGB Customer" as Customer
actor "Contact Center Agent" as CCAgent
actor "Product Team" as ProdTeam
boundary "School Fee Payment System\n(SFPS)" as SFPS {
    rectangle "Core Services" {
        component "School Registration\nService" as SchoolRegSvc
        component "Student Management\nService" as StudentMgmtSvc
        component "Fee Payment\nService" as FeePaymentSvc
        component "EPP Conversion\nService" as EPPConvSvc
        component "Fee Posting\nEngine" as FeePostingEngine
        component "Reporting\nService" as ReportingSvc
    }
}

rectangle "NGB Eco-system" {
  cloud "Online Banking System\n(OBS)" as OBS
  cloud "Mobile Banking System\n(MBS)" as MBS
  cloud "IVR System" as IVRS
  database "CRM System" as CRM
  database "Cards System" as CardsSys
  database "GL Account System" as GLAccSys
  queue "SMS Gateway" as SMSGw
  queue "Email System" as EmailSys
  database "ICRS" as ICRS
}

' Human-System Interactions
OpsTeam --( SchoolRegSvc : Manage Schools (UI)
ProdTeam --> SchoolRegSvc : School Data (Excel via Email)
Customer --( OBS : Access
Customer --( MBS : Access
Customer --( IVRS : Access

' Channel-SFPS Interactions
OBS <--> FeePaymentSvc : Student Mgmt & Payment APIs
MBS <--> FeePaymentSvc : Student Mgmt & Payment APIs
IVRS --> FeePaymentSvc : Payment Requests
IVRS --> StudentMgmtSvc : Student Mgmt Requests (via agent)
CCAgent --( StudentMgmtSvc : Student Mgmt (E-Form)

' SFPS-External System Interactions
FeePaymentSvc --> SMSGw : Send OTP/Alerts
StudentMgmtSvc --> SMSGw : Send Alerts
FeePaymentSvc --> CardsSys : Debit Card Auth/Capture
FeePostingEngine --> CardsSys : Debit Card Posting
FeePostingEngine --> GLAccSys : GL Debit/Credit Posting
EPPConvSvc --> CRM : EPP Workflow Initiation (E-Form)
StudentMgmtSvc --> CRM : Student Mgmt Workflow (E-Form)
ReportingSvc --> EmailSys : Send Daily Reports (Excel)
FeePaymentSvc --> ICRS : Update IVR Transactions

' Internal SFPS Flows (simplified)
FeePaymentSvc --> EPPConvSvc : EPP Request
FeePaymentSvc --> FeePostingEngine : Initiate Posting

@enduml
```

#### 7.4 Protocols/Formats

The choice of protocols and data formats will prioritize security, performance, and interoperability within the banking ecosystem.

*   **User Interface (OBS, MBS, Card Operations UI) to SFPS Backend:**
    *   **Protocol:** HTTPS
    *   **Format:** RESTful APIs with JSON payloads.
    *   **Authentication:** OAuth2.0/OpenID Connect for customers (via OBS/MBS), internal SSO/LDAP for Card Operations Team.

*   **SFPS Backend to Core Banking Systems (Cards System, GL Account System):**
    *   **Protocols:**
        *   **SOAP/XML over HTTPS:** Common for existing enterprise banking systems, ensuring robust transaction integrity and security.
        *   **REST/JSON over HTTPS:** For newer services or modernizing integrations.
        *   **Message Queues (e.g., IBM MQ, Kafka):** For asynchronous, reliable transaction processing and status updates, especially for GL postings and card debits.
    *   **Formats:** XML (for SOAP), JSON (for REST).

*   **SFPS Backend to CRM System:**
    *   **Protocols:** REST/JSON over HTTPS for E-Form initiation and workflow management.
    *   **Formats:** JSON.

*   **SFPS Backend to SMS Gateway:**
    *   **Protocols:** REST API over HTTPS.
    *   **Formats:** JSON.

*   **SFPS Backend to Email System:**
    *   **Protocols:** SMTP for sending emails.
    *   **Formats:** Excel for attached reports (daily school reports). Incoming school registration data will also be in Excel format via email.

*   **IVR System to SFPS Backend:**
    *   **Protocols:** Could be a direct API integration (SOAP/REST over HTTPS) or mediated via an Enterprise Service Bus (ESB) for routing and transformation.
    *   **Formats:** XML or JSON, depending on the IVR platform's integration capabilities.

*   **SFPS Backend to ICRS:**
    *   **Protocols:** REST/JSON over HTTPS or potentially direct database connection (for simple updates) or file transfer (SFTP) depending on ICRS capabilities.
    *   **Formats:** JSON or Flat File.

*   **General Data Formats:**
    *   **Internal Microservices:** JSON for inter-service communication.
    *   **Logging & Auditing:** Standardized structured logging (e.g., JSON logs).

## 8. Deployment Architecture

### 8.1 Deployment Diagram (High-Level)

This diagram illustrates the macro-level physical deployment of the School Fee Payment System (SFPS) within the New Gen Bank (NGB) infrastructure, showing how it interacts with existing bank systems and external users.

```plantuml
@startuml
skinparam handwritten false
skinparam titleFontSize 20
skinparam actor {
  FontColor #333333
  BorderColor #555555
  ArrowColor #555555
}
skinparam node {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #DDEEFF
}
skinparam database {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #CCEEFF
}
skinparam cloud {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #FFEEEE
}
skinparam rectangle {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #FFEECC
}
skinparam component {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #DDDDDD
}
skinparam package {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #F0F8FF
}

title 8.1 Deployment Diagram (High-Level)

actor "NGB Customer" as Customer
actor "Card Operations Team" as CardOps
actor "Product Team" as ProductTeam

cloud "External Networks" as Network {
  node "Mobile Device" as MobileApp
  node "Web Browser" as OnlineBanking
}

node "NGB Data Center" as NGB_DC {
  rectangle "School Fee Payment System (SFPS)" as SFPS_Rect {
    component "SFPS Core Application" as SFPS_Core
  }

  node "Existing NGB Systems" as Existing_Systems {
    component "Online Banking Core" as OB_Core
    component "Mobile Banking Core" as MB_Core
    component "IVR System" as IVR_Sys
    component "CRM System" as CRM
    component "Cards System" as CardsSys
    component "NGB GL Account / Core Banking" as GL_Core
  }
  node "Email Server" as EmailSrv
}

Customer -- Network
Network -- OnlineBanking : Accesses
Network -- MobileApp : Accesses

OnlineBanking -- OB_Core : Integrates
MobileApp -- MB_Core : Integrates
Customer -- IVR_Sys : Calls

CardOps -- OnlineBanking : Uses UI for School Reg.
ProductTeam --> EmailSrv : Sends School Data (Excel)

OB_Core -- SFPS_Core : Invokes SFPS Services
MB_Core -- SFPS_Core : Invokes SFPS Services
IVR_Sys -- SFPS_Core : Invokes SFPS Services

SFPS_Core -- CardsSys : Card Validation & Debit
SFPS_Core -- GL_Core : GL Debit & School Account Credit
SFPS_Core -- CRM : E-Form Generation, Customer Data
SFPS_Core --> EmailSrv : Sends Daily Reports & Alerts
SFPS_Core --> IVR_Sys : (for voice prompts, if applicable)

@enduml
```

### 8.2 Deployment Diagram (Detailed View)

This diagram provides a more granular view of the School Fee Payment System's internal components, showcasing how they are deployed across various infrastructure nodes and interact with each other and existing NGB systems.

```plantuml
@startuml
skinparam handwritten false
skinparam titleFontSize 20
skinparam actor {
  FontColor #333333
  BorderColor #555555
  ArrowColor #555555
}
skinparam node {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #DDEEFF
}
skinparam database {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #CCEEFF
}
skinparam cloud {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #FFEEEE
}
skinparam rectangle {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #FFEECC
}
skinparam component {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #DDDDDD
}
skinparam package {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #F0F8FF
}

title 8.2 Deployment Diagram (Detailed View)

node "Customer Access Tier" {
  component "Online Banking Front-End (Web)" as OB_FE
  component "Mobile Banking App" as MB_APP
  component "IVR System" as IVR_SYS
}

node "NGB Data Center" as NGB_DC {

  node "Integration Gateway Layer" as IntegrationGateway {
    component "API Gateway / ESB" as APIGateway
  }

  node "SFPS Application Cluster" as SFPS_Cluster {
    rectangle "Load Balancer" as LB
    node "Application Server (SFPS-Node 1)" as AS1 {
      component "School Registration Service" as RegSvc
      component "Student Management Service" as StudentSvc
      component "Fee Payment Orchestrator" as PaymentSvc
      component "EPP Conversion Service" as EPP_Svc
      component "Reporting Service" as ReportSvc
      component "Alerts & Notification Service" as AlertSvc
    }
    node "Application Server (SFPS-Node 2)" as AS2 {
      RegSvc .. AS2
      StudentSvc .. AS2
      PaymentSvc .. AS2
      EPP_Svc .. AS2
      ReportSvc .. AS2
      AlertSvc .. AS2
    }
    LB --> AS1 : Distributes Traffic
    LB --> AS2 : Distributes Traffic
  }

  node "SFPS Database Cluster" as DB_Cluster {
    database "SFPS Database (Primary)" as DB_Primary
    database "SFPS Database (Replica)" as DB_Replica
    DB_Primary -left- DB_Replica : Async Data Replication
  }

  node "Messaging Infrastructure" as MessagingInfra {
    component "Message Queue (e.g., Kafka/RabbitMQ)" as MQ
  }

  node "Existing NGB Core Systems" as Existing_Systems {
    component "Cards System API" as Cards_API
    component "Core Banking (GL) API" as GL_API
    component "CRM API (E-Form / Customer)" as CRM_API
    component "SMS Gateway" as SMS_GW
    component "Email Server" as Email_Server
    component "Online Banking Core" as OB_Core
    component "Mobile Banking Core" as MB_Core
    component "IVR Integration Service" as IVR_Integration
  }

  OB_FE --> OB_Core : Customer Interactions
  MB_APP --> MB_Core : Customer Interactions
  IVR_SYS --> IVR_Integration : Voice/DTMF Commands

  OB_Core -- APIGateway : SFPS Service Calls
  MB_Core -- APIGateway : SFPS Service Calls
  IVR_Integration -- APIGateway : SFPS Service Calls

  APIGateway --> LB : SFPS API Requests

  AS1 -- MQ : Publish Events/Messages
  AS2 -- MQ

  MQ --> Cards_API : Async Card Debit Request
  MQ --> GL_API : Async GL Posting Request
  MQ --> CRM_API : Async E-Form Creation / CRM Update
  MQ --> SMS_GW : Async SMS Notification Request
  MQ --> Email_Server : Async Report Dispatch Trigger

  AS1 -- DB_Primary : Read/Write SFPS Data
  AS2 -- DB_Primary : Read/Write SFPS Data

  ReportSvc --> DB_Primary : Query for Reports
  ReportSvc --> Email_Server : Send Generated Reports

  RegSvc -- APIGateway : (For Card Ops UI within OB_FE)

}
@enduml
```

### 8.3 Environment Strategy

To ensure robust development, testing, and deployment, the following environment strategy will be adopted:

1.  **Development (DEV) Environment:**
    *   **Purpose:** Local development, unit testing, and initial integration testing.
    *   **Setup:** Individual developer workstations will have local development environments. A shared integrated DEV environment will be used for early-stage component integration and testing of core SFPS services. External NGB systems will typically be mocked or accessed via dedicated DEV instances.
    *   **Deployment:** Continuous integration (CI) pipeline deploys code changes automatically or on-demand to the shared DEV environment.

2.  **System Integration Testing (SIT) Environment:**
    *   **Purpose:** End-to-end integration testing of the SFPS with all interconnected NGB core systems (Online Banking, Mobile Banking, IVR, CRM, Cards System, GL Account).
    *   **Setup:** A dedicated environment that closely mirrors the production architecture, using test data. All integrated NGB systems will have their SIT instances connected.
    *   **Deployment:** Automated deployment via CI/CD pipeline from successful DEV builds. Rigorous automated and manual integration test cases are executed here.

3.  **User Acceptance Testing (UAT) Environment:**
    *   **Purpose:** Business users validate the system's functionality against the specified requirements and business rules. Performance and usability are also assessed.
    *   **Setup:** An environment that is a near-replica of the production setup, populated with realistic (anonymized/synthesized) test data. It provides the business teams with a stable platform for comprehensive testing.
    *   **Deployment:** Deployment of builds that have successfully passed SIT. Business users conduct acceptance tests, and sign-off is required before promotion to production.

4.  **Production (PROD) Environment:**
    *   **Purpose:** The live operational environment serving NGB customers and internal teams.
    *   **Setup:** Highly available, secure, and performant infrastructure, configured for maximum uptime and resilience. Strict access controls, robust monitoring, and comprehensive logging are in place.
    *   **Deployment:** Controlled deployment of UAT-approved builds, typically during scheduled maintenance windows, with comprehensive rollback plans. Post-deployment smoke tests are mandatory.

5.  **Disaster Recovery (DR) Environment:**
    *   **Purpose:** To ensure business continuity and minimize downtime in the event of a catastrophic failure in the primary PROD environment.
    *   **Setup:** A geographically separate site with infrastructure and data replication from the primary PROD environment.
    *   **Deployment:** Data is replicated in near real-time. Regular DR drills are conducted to validate recovery procedures and meet defined RTO (Recovery Time Objective) and RPO (Recovery Point Objective).

**Deployment Flow:**
Code changes will follow a structured promotion path:
`Developer Local -> Shared DEV -> SIT -> UAT -> PROD`
A CI/CD pipeline will automate builds, testing, and deployments across these environments, ensuring consistency, speed, and quality.

### 8.4 Scalability and Resilience

The architecture is designed with inherent scalability and resilience to meet the non-functional requirements of performance, reliability, and support for multiple schools, students, and transactions.

**Scalability:**

*   **Horizontal Scaling of Application Servers:** The "SFPS Application Cluster" utilizes a Load Balancer distributing requests across multiple application server instances (AS1, AS2, etc.). New instances can be added or removed dynamically based on demand, allowing the system to handle increasing transaction volumes and user concurrency without significant code changes.
*   **Database Scaling:**
    *   **Read Replicas:** The "SFPS Database Cluster" includes a primary database and one or more read replicas. This offloads read-heavy operations (e.g., viewing transaction history, generating reports) from the primary write database, improving overall database performance and throughput.
    *   **Connection Pooling:** Efficient database connection pooling in the application layer will minimize overhead and maximize resource utilization.
*   **Asynchronous Processing with Message Queues:** The use of a Message Queue (MQ) for tasks like GL postings, SMS notifications, and EPP processing decouples the core transaction flow from downstream system dependencies. This prevents bottlenecks and allows each service (e.g., Cards System API, GL API) to process messages at its own pace, independently scaling its processing capacity.
*   **Stateless Application Design:** Application servers are designed to be largely stateless, meaning session-specific data is not stored directly on the server. This facilitates easier horizontal scaling and load balancing, as any server can handle any request.
*   **API Gateway:** The API Gateway acts as a central entry point, capable of rate limiting, caching, and routing, which can help manage and scale access to the backend services.

**Resilience (Reliability and High Availability):**

*   **Redundancy at All Layers:**
    *   **Load Balancer:** Provides redundancy for the application cluster. If an application server fails, the load balancer automatically redirects traffic to healthy instances.
    *   **Application Cluster:** Multiple identical application server instances ensure that the failure of one server does not lead to system downtime.
    *   **Database Replication:** The Primary-Replica database setup provides data redundancy and enables quick failover to a replica in case of a primary database failure, minimizing data loss and downtime.
    *   **Clustered Message Queue:** The MQ itself will be deployed in a clustered, highly available configuration to ensure message persistence and reliable delivery even if individual MQ nodes fail.
*   **Asynchronous Processing for Reliability:** By queuing critical operations (like fee postings and SMS alerts), the system ensures that these actions are eventually performed, even if the target systems are temporarily unavailable. Messages are persisted in the queue and retried until successful.
*   **Transaction Logging and Traceability:** Every transaction is logged with a unique reference ID, ensuring traceability and aiding in reconciliation and audit processes, fulfilling reliability and audit requirements.
*   **SMS Confirmation:** Mandatory SMS alerts for key activities (registration, payment, EPP status) provide immediate confirmation to users, enhancing confidence and perceived reliability.
*   **Disaster Recovery (DR):** A geographically separate DR site with ongoing data replication will be maintained. In the event of a major regional outage, the system can be brought online at the DR site, ensuring business continuity with minimal data loss (defined by RPO) and downtime (defined by RTO).
*   **Monitoring, Alerting, and Self-Healing:** Comprehensive monitoring tools will continuously track system health, performance metrics, and potential issues. Automated alerts will notify operations teams of anomalies, and where possible, automated self-healing mechanisms will be implemented (e.g., restarting failed services).
*   **Graceful Degradation:** Services will be designed to handle failures of non-critical components gracefully. For example, if CRM E-Form generation is temporarily down, the core fee payment process should still complete, with the E-Form generation retried later or handled manually.

```plantuml
@startuml
left to right direction
skinparam packageStyle rectangle
skinparam actorStyle awesome

' Actors
actor "Card Operations Team" as COT
actor "Customer" as Cust
actor "Contact Center Agent" as CCA
actor "School" as School_Receiver #DDDDDD

' External Systems (represented as actors for interaction points)
actor "Cards System" as Ext_Cards
actor "NGB GL System" as Ext_GL
actor "IVR System" as Ext_IVR #lightblue

rectangle "School Fee Payment System" {
  ' Package for managing schools and students
  package "School & Student Management" {
    usecase "Register School" as UC_RegSchool
    usecase "Manage School Fee Types" as UC_ManageFeeTypes

    usecase "Manage Student Details" as UC_ManageStudentGeneral
    usecase "Manage Student Details\nvia Online/Mobile" as UC_ManageStudentOnline
    usecase "Manage Student Details\nvia Contact Center (E-Form)" as UC_ManageStudentCC
  }

  ' Package for fee payment and Easy Payment Plan (EPP) functionalities
  package "Fee Payment & EPP" {
    usecase "Make Fee Payment" as UC_PayFeeGeneral
    usecase "Make Fee Payment\nvia Online Banking" as UC_PayOnline
    usecase "Make Fee Payment\nvia Mobile Banking" as UC_PayMobile
    usecase "Make Fee Payment\nvia IVR" as UC_PayIVR

    usecase "Convert Payment to EPP" as UC_EPPGeneral
    usecase "Convert Payment to EPP\nvia Online/Mobile" as UC_EPPOnline
    usecase "Convert Payment to EPP\nvia Contact Center (E-Form)" as UC_EPPCC

    usecase "View Payment History" as UC_ViewHistory
  }

  ' Package for core system services (included functionalities)
  package "Core System Services" {
    usecase "(Perform OTP Authentication)" as UC_OTP <<include>>
    usecase "(Perform IVR TIN Authentication)" as UC_IVR_TIN <<include>>
    usecase "(Process Fee Posting)" as UC_FeePosting <<include>>
    usecase "(Generate E-Form for EPP)" as UC_GenEForm <<include>>
    usecase "(Send SMS Notification)" as UC_SendSMS <<include>>
    usecase "Generate Daily School Report" as UC_GenReport
  }
}

' Actor-Use Case Relationships (Who performs what)
COT -- UC_RegSchool
COT -- UC_ManageFeeTypes

Cust -- UC_ManageStudentOnline
Cust -- UC_PayOnline
Cust -- UC_PayMobile
Cust -- UC_PayIVR
Cust -- UC_EPPOnline
Cust -- UC_ViewHistory

CCA -- UC_ManageStudentCC
CCA -- UC_EPPCC

' Generalization Relationships (More specific use cases extend general ones)
UC_ManageStudentOnline .up.|> UC_ManageStudentGeneral
UC_ManageStudentCC .up.|> UC_ManageStudentGeneral

UC_PayOnline .up.|> UC_PayFeeGeneral
UC_PayMobile .up.|> UC_PayFeeGeneral
UC_PayIVR .up.|> UC_PayFeeGeneral

UC_EPPOnline .up.|> UC_EPPGeneral
UC_EPPCC .up.|> UC_EPPGeneral

' Include Relationships (One use case includes the functionality of another)
UC_ManageStudentOnline ..> UC_OTP
UC_PayOnline ..> UC_OTP
UC_PayMobile ..> UC_OTP
UC_EPPOnline ..> UC_OTP

UC_PayIVR ..> UC_IVR_TIN
UC_ManageStudentCC ..> UC_IVR_TIN
UC_EPPCC ..> UC_IVR_TIN

UC_PayFeeGeneral ..> UC_FeePosting : <<include>>
UC_EPPGeneral ..> UC_GenEForm : <<include>>

UC_RegSchool ..> UC_SendSMS : <<include>>
UC_ManageStudentGeneral ..> UC_SendSMS : <<include>>
UC_PayFeeGeneral ..> UC_SendSMS : <<include>>
UC_EPPGeneral ..> UC_SendSMS : <<include>>

' Use Case to External System Relationships (Interaction/Dependency with external systems)
UC_FeePosting -- Ext_Cards : Uses
UC_FeePosting -- Ext_GL : Uses

UC_PayIVR -- Ext_IVR : Interacts with
UC_IVR_TIN -- Ext_IVR : Authenticates via

UC_GenReport -- School_Receiver : Sends Report

@enduml
```

## 10. Behavioral & Structural Diagrams

### 10.1 Sequence Diagram: Fee Payment via Online/Mobile Banking

This sequence diagram illustrates the typical flow for a customer making a school fee payment using Online or Mobile Banking, including the required validations and integrations.

```plantuml
@startuml
skinparam handwritten false
skinparam participant {
    BorderColor RoyalBlue
    BackgroundColor AliceBlue
    ArrowColor DarkSlateGrey
}
skinparam actor {
    BorderColor DarkGreen
    BackgroundColor LightGreen
}
skinparam box {
    BorderColor MidnightBlue
    BackgroundColor LightSteelBlue
}

actor Customer
participant "Online/Mobile Banking App" as UI
participant "NGB School Fee Payment System" as NGBSystem
participant "NGB Cards System" as CardsSystem
participant "NGB GL System" as GLSystem
participant "SMS Gateway" as SMSGateway

box "NGB Bank Internal Systems"
    NGBSystem -[hidden]-> CardsSystem
    CardsSystem -[hidden]-> GLSystem
end box

Customer -> UI: Access Fee Payment
activate UI
UI -> NGBSystem: Request Registered Students/Schools (for Customer)
activate NGBSystem
NGBSystem --> UI: List of Students, Schools, Fee Types, Active Cards
deactivate NGBSystem

Customer -> UI: Select Student, School, Fee Type, Amount, Card, (Optional) Remark
activate UI
UI -> UI: Display Payment Summary
Customer -> UI: Confirm Payment

UI -> NGBSystem: Initiate Payment Request (with OTP)
activate NGBSystem
NGBSystem -> NGBSystem: Validate Input Data
NGBSystem -> NGBSystem: Perform OTP Authentication
alt OTP Validated
    NGBSystem -> CardsSystem: Verify Card Status & Balance
    activate CardsSystem
    CardsSystem --> NGBSystem: Card Status & Available Balance
    deactivate CardsSystem

    alt Sufficient Balance & Valid Card
        NGBSystem -> CardsSystem: Debit Credit Card (Amount, Desc: max 40 chars)
        activate CardsSystem
        CardsSystem --> NGBSystem: Debit Confirmation (Txn Ref ID)
        deactivate CardsSystem

        NGBSystem -> GLSystem: Post Debit GL Account (Visa/MC)
        activate GLSystem
        GLSystem --> NGBSystem: GL Debit Confirmation
        deactivate GLSystem

        NGBSystem -> GLSystem: Post Credit School Account
        activate GLSystem
        GLSystem --> NGBSystem: School Credit Confirmation
        deactivate GLSystem

        NGBSystem -> NGBSystem: Log Transaction (Unique Ref ID, All Details)
        NGBSystem -> SMSGateway: Send Payment Confirmation SMS
        activate SMSGateway
        SMSGateway --> NGBSystem: SMS Sent Ack
        deactivate SMSGateway
        NGBSystem --> UI: Payment Success Acknowledgment
        deactivate NGBSystem
        UI --> Customer: Display Success Message & Txn Ref ID
        deactivate UI
    else Insufficient Balance or Invalid Card
        CardsSystem --> NGBSystem: Payment Rejection
        deactivate CardsSystem
        NGBSystem --> UI: Payment Failure (Insufficient Balance/Invalid Card)
        deactivate NGBSystem
        UI --> Customer: Display Error Message
        deactivate UI
    end alt
else OTP Invalid
    NGBSystem --> UI: OTP Validation Failed
    deactivate NGBSystem
    UI --> Customer: Display OTP Error
    deactivate UI
end alt

@enduml
```

### 10.2 Activity Diagram: Student Registration/Amendment/De-registration

This activity diagram illustrates the workflow for managing student registrations, amendments, and de-registrations, covering both online/mobile banking and contact center channels.

```plantuml
@startuml
skinparam activity {
    BorderColor DarkBlue
    BackgroundColor LightBlue
    ArrowColor Black
}
skinparam note {
    BorderColor DarkGreen
    BackgroundColor LightGreen
}

start
:Customer/Agent initiates Student Management;

if (Channel is Online/Mobile Banking) then (Online/Mobile)
    :Customer logs in;
    :Authenticate User (OTP Mandatory);
    note right: SMS for registration/amendment/de-registration
    if (Authentication Successful) then (Authenticated)
        :Customer inputs Student Name, Student ID (twice), Select School (Dropdown);
        note right: Student ID must be entered twice and match
        if (Student IDs Match) then (IDs Match)
            :Submit request to NGB System;
            :NGB System processes Student Registration / Amendment / De-registration;
            :Send SMS Alert for confirmation;
        else (IDs Mismatch)
            :Display Error: Student IDs do not match;
            stop
        endif
    else (Authentication Failed)
        :Display Error: OTP Invalid;
        stop
    endif
else (Contact Center - E-Form)
    :Customer calls Contact Center;
    :Authenticate via IVR TIN;
    if (Authentication Successful) then (Authenticated)
        :Agent accesses E-Form;
        :Agent manually inputs Student Name, Student ID, Select School;
        note right: Restrict copy-paste on Student ID
        :NGB System processes Student Registration / Amendment / De-registration;
        :Send SMS Alert post-processing;
    else (Authentication Failed)
        :Agent informs Customer: IVR TIN Authentication Failed;
        stop
    endif
endif

:Log Student Management Activity;
end
@enduml
```

### 10.3 Class Diagram: Core Domain Model

This class diagram illustrates the main entities within the NGB School Fee Payment System, their attributes, and relationships.

```plantuml
@startuml
skinparam class {
    BorderColor DarkSlateGrey
    BackgroundColor LightYellow
    ArrowColor DarkSlateGrey
}
hide empty members

class School {
    - schoolId: String
    - name: String
    - location: String
    - ngbAccountNumber: String
    - ngbGlAccount: String
    - minEnrolledStudents: int
    - operationalYears: int
    - minAnnualFeeCollection: double
    --
    + registerSchool()
    + updateSchoolDetails()
}

class FeeType {
    - feeTypeId: String
    - name: String
    - description: String
    --
    + createFeeType()
}

class Customer {
    - customerId: String
    - name: String
    - isActiveCreditCardHolder: boolean
    --
    + authenticate()
}

class CreditCard {
    - cardNumber: String
    - customerId: String
    - expiryDate: Date
    - balance: double
    - status: String // Active, Inactive, Blocked
    --
    + debitCard(amount: double)
    + checkBalance(): double
}

class Student {
    - studentId: String
    - name: String
    - registeredByCustomerId: String
    - schoolId: String
    - status: String // Registered, De-registered
    --
    + registerStudent()
    + amendStudentDetails()
    + deRegisterStudent()
}

class Transaction {
    - transactionId: String
    - referenceId: String // Unique for each txn
    - customerId: String
    - studentId: String
    - schoolId: String
    - feeTypeId: String
    - cardNumber: String
    - amount: double
    - transactionDate: Date
    - remark: String (max 20 chars)
    - status: String // Success, Failed, Pending
    - isEPPConverted: boolean
    --
    + initiatePayment()
    + postTransaction()
    + logTransaction()
}

class EPPRequest {
    - eppRequestId: String
    - transactionId: String
    - originalAmount: double
    - conversionDate: Date
    - status: String // Pending, Approved, Rejected
    - rejectionReason: String
    --
    + convertToEPP()
}

class SMSNotification {
    - notificationId: String
    - recipientPhoneNumber: String
    - message: String
    - timestamp: Date
    - type: String // Confirmation, Alert, Error
    --
    + sendSMS()
}

class Report {
    - reportId: String
    - schoolId: String
    - generationDate: Date
    - type: String // Daily School Report
    - filePath: String
    --
    + generateReport()
    + emailReport()
}

School "1" -- "1..*" FeeType : has >
Customer "1" -- "0..*" Student : registers >
Customer "1" -- "1..*" CreditCard : owns >
Student "1" -- "1" School : belongs to >
Transaction "1" -- "1" Customer : initiated by >
Transaction "1" -- "1" Student : for >
Transaction "1" -- "1" School : to >
Transaction "1" -- "1" FeeType : type >
Transaction "1" -- "1" CreditCard : uses >
Transaction "1" -- "0..1" EPPRequest : can convert to >
SMSNotification "0..*" -- "1" Transaction : related to >
SMSNotification "0..*" -- "1" Student : related to >
Report "0..*" -- "1" School : for >

@enduml
```

### 10.4 Package Diagram: System Architecture Overview

This package diagram provides a high-level overview of the system's structure, grouping related components and illustrating dependencies between them and external systems.

```plantuml
@startuml
skinparam package {
    BorderColor DarkBlue
    BackgroundColor LightCyan
    ArrowColor Black
}
skinparam component {
    BorderColor Teal
    BackgroundColor LightYellow
    ArrowColor DarkGreen
}
skinparam rectangle {
    BorderColor DarkRed
    BackgroundColor LightCoral
}

' High-level packages representing logical modules
package "User Channels" as Channels {
    component "Online Banking UI" as OnlineBanking
    component "Mobile Banking UI" as MobileBanking
    component "Contact Center E-Form" as EForm
    component "IVR System Interface" as IVR
}

package "Core Business Logic" as CoreServices {
    component "School Management Service" as SchoolSvc
    component "Student Management Service" as StudentSvc
    component "Fee Payment Service" as PaymentSvc
    component "EPP Conversion Service" as EPPSvc
    component "Reporting Service" as ReportingSvc
    component "Notification Service" as NotificationSvc
    component "Audit & Logging Service" as AuditSvc
}

package "Integration Adapters" as Adapters {
    component "Cards System Adapter" as CardsAdapter
    component "GL System Adapter" as GLAdapter
    component "CRM Adapter" as CRMAdapter
    component "SMS Gateway Adapter" as SMSAdapter
    component "IVR System Adapter" as IVRAdapter
    component "ICRS System Adapter" as ICRSAdapter
}

' External Systems
rectangle "External Systems" {
    component "NGB Cards System" as CardsSystemExternal
    component "NGB GL System" as GLSystemExternal
    component "NGB CRM" as CRMExternal
    component "SMS Gateway" as SMSGatewayExternal
    component "Existing IVR Platform" as IVRPlatformExternal
    component "ICRS (Card Transaction Records)" as ICRSExternal
}

' Dependencies
Channels --> CoreServices : Uses
Channels --> Adapters : Direct IVR/E-Form via Adapters

CoreServices --> Adapters : Orchestrates external interactions

Adapters --> CardsSystemExternal : Interacts with
Adapters --> GLSystemExternal : Interacts with
Adapters --> CRMExternal : Interacts with
Adapters --> SMSGatewayExternal : Interacts with
Adapters --> IVRPlatformExternal : Interacts with
Adapters --> ICRSExternal : Interacts with

SchoolSvc .down.> AuditSvc : Logs events
StudentSvc .down.> AuditSvc : Logs events
PaymentSvc .down.> AuditSvc : Logs events
EPPSvc .down.> AuditSvc : Logs events

PaymentSvc --> NotificationSvc : Triggers SMS
StudentSvc --> NotificationSvc : Triggers SMS

ReportingSvc --> AuditSvc : For data
ReportingSvc --> PaymentSvc : For transaction data

@enduml
```

