import os
from dotenv import load_dotenv
import streamlit as st
from PIL import Image

import utils.constant as constant

# load .env file to environment
load_dotenv()

ROOT_PATH =  os.getenv('ROOT_PATH')
style_file_name = f"{ROOT_PATH}common/styles/style.css"

st.set_page_config(layout="wide",page_title = "TCS A.S.C.E.N.D")

with open(style_file_name) as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

image = Image.open('C:/Solutions/SDLC/includes/common/images/TCS_Logo.png')
st.image(image, caption='',width=200)

# image = Image.open('C:/Solutions/SDLC/includes/common/images/IntelliForge.png')
# resized_img = image.resize((300, 15))  # (width, height) in pixels
# st.image(resized_img, caption='', use_container_width =True)

st.markdown(constant.main_home_page, unsafe_allow_html=True) 
