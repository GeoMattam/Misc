import openai
import json
import os
from openai import OpenAI

client = OpenAI(api_key= "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")

from langchain_community.agent_toolkits import FileManagementToolkit

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"], #use current folder
).get_tools()

read_file, write_file, list_file = file_stores

ROOT_PATH =  os.getenv('ROOT_PATH')

srs_path = f"{ROOT_PATH}validation/hld/input/BRD_NGB.md"
hld_path = f"{ROOT_PATH}validation/hld/input/hld.md"

SRS = read_file.invoke({"file_path": srs_path})
HLD = read_file.invoke({"file_path": hld_path})


def fn_g_eval(srs: str, hld: str):
    prompt = f"""
                You are a software architect evaluating a High-Level Design (HLD) document that was generated based on a Software Requirements Specification (SRS).

                Below is the SRS:
                ---
                {srs}
                ---

                Below is the generated HLD:
                ---
                {hld}
                ---

                Please evaluate the HLD based on the following dimensions:

                1. Completeness - Does it address all functional and non-functional requirements from the SRS?
                2. Correctness - Are the components appropriate, feasible, and consistent with the SRS?
                3. Traceability - Can you map major HLD elements back to the corresponding SRS items?
                4. Clarity - Is the document clear, concise, and logically structured?
                5. Scalability - Does the design allow future extension and performance scaling?

                Give a score from 1 to 5 for each, and provide a short explanation for your reasoning.

                Return your answer in the following JSON format:
                ```json
                {{
                "Completeness": {{"score": _, "comment": "..."}},
                "Correctness": {{"score": _, "comment": "..."}},
                "Traceability": {{"score": _, "comment": "..."}},
                "Clarity": {{"score": _, "comment": "..."}},
                "Scalability": {{"score": _, "comment": "..."}}
                }}
                """

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )

    output_text = response.choices[0].message.content
    try:
        json_start = output_text.find('{')
        json_data = json.loads(output_text[json_start:])
        return json_data
    except Exception as e:
        return {"error": f"Failed to parse response: {e}", "raw_output": output_text}

if __name__ == "__main__":
    result = fn_g_eval(SRS, HLD)

    print("\n G-Eval Results:\n")
    for key, value in result.items():
        if isinstance(value, dict):
            print(f"{key}: {value['score']} ⭐ — {value['comment']}")
        else:
            print(f"{key}: {value}")