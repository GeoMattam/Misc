import re, os, subprocess
from pathlib import Path

plantuml_jar_path = "C:/Programs/plantuml-asl-1.2025.2.jar"

output_dir = "C:/Solutions/SDLC/includes/hld/output/design/7754589d-4899-49f9-b304-45176019d83f"
img_form = "png"
md_file = "C:/Solutions/SDLC/includes/hld/output/design/7754589d-4899-49f9-b304-45176019d83f/hld.md"

text = Path(md_file).read_text(encoding="utf-8")
pattern = re.compile(r"```plantuml\s*\n(.*?)\n```", re.DOTALL | re.IGNORECASE)

blocks = pattern.findall(text)
if not blocks:
    print("No PlantUML blocks found.")
    exit()

os.makedirs(output_dir, exist_ok=True)

replacements = []

for idx, code in enumerate(blocks):
    full_puml = code.strip()
    puml_path = Path(output_dir) / f"diagram_{idx}.puml"
    puml_path.write_text(full_puml, encoding="utf-8")
    
    img_name  = f"diagram_{idx}.{img_form}"
    img_path  = Path(output_dir) / img_name
    md_img = f"![Diagram {idx}](./{img_name})"
    img_file_path = f"{output_dir}/{img_name}"

    uml_file = str(puml_path)

    try:
        #result = subprocess.run(cmd,capture_output=True, text=True)
        result = subprocess.run([
        "java", "-jar", plantuml_jar_path, "-tpng", uml_file
        ], capture_output=True, text=True)
        
        replacements.append(md_img)

    except subprocess.CalledProcessError as e:
        replacements.append(full_puml)
        print("PlantUML execution failed:", e)

def _swap(match):
    return replacements.pop(0)

new_text = pattern.sub(_swap, text)

backup = md_file + ".bak"
Path(md_file).rename(backup)
Path(md_file).write_text(new_text, encoding="utf-8")