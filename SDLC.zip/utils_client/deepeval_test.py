from deepeval.test_case import LLMTestCase
from deepeval.metrics import GPTScoreMetric
from deepeval.evaluator import evaluate
import os

from langchain_community.agent_toolkits import FileManagementToolkit

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"], #use current folder
).get_tools()

read_file, write_file, list_file = file_stores

ROOT_PATH =  os.getenv('ROOT_PATH')

srs_path = f"{ROOT_PATH}validation/hld/input/BRD_NGB.md"
hld_path = f"{ROOT_PATH}validation/hld/input/hld.md"

srs = read_file.invoke({"file_path": srs_path})
hld = read_file.invoke({"file_path": hld_path})

# Optional: load API key from environment variable
os.environ["OPENAI_API_KEY"] = "your-api-key-here"  # Or use dotenv

# --- Evaluation Dimensions ---
metrics = [
    GPTScoreMetric(
        name="Completeness",
        evaluation_prompt="""
Evaluate how completely the High-Level Design (HLD) addresses both the functional and non-functional requirements listed in the Software Requirements Specification (SRS).
Score from 1 (poor) to 5 (excellent), and explain your reasoning.
"""
    ),
    GPTScoreMetric(
        name="Correctness",
        evaluation_prompt="""
Evaluate how correct and appropriate the components of the HLD are in relation to the requirements of the SRS.
Score from 1 (incorrect) to 5 (perfectly correct), and explain your reasoning.
"""
    ),
    GPTScoreMetric(
        name="Traceability",
        evaluation_prompt="""
Evaluate whether each part of the HLD can be clearly mapped back to specific requirements in the SRS.
Score from 1 (poor traceability) to 5 (excellent traceability), and explain your reasoning.
"""
    ),
    GPTScoreMetric(
        name="Clarity",
        evaluation_prompt="""
Evaluate how clearly and logically the HLD is written and structured.
Score from 1 (unclear) to 5 (very clear), and explain your reasoning.
"""
    ),
    GPTScoreMetric(
        name="Scalability",
        evaluation_prompt="""
Evaluate whether the HLD demonstrates that the system can scale well as user volume increases.
Score from 1 (not scalable) to 5 (highly scalable), and explain your reasoning.
"""
    )
]

# --- Create test case ---
test_case = LLMTestCase(
    input=f"SRS:\n{srs}",
    actual_output=f"HLD:\n{hld}",
    expected_output="",  # Not needed for GPTScoreMetric
    retrieval_context=""
)

# --- Run evaluation ---
evaluate(test_case, metrics)

# --- Display results ---
print("\n📊 G-Eval Style Results:\n")
for metric in metrics:
    print(f"{metric.name}: {metric.score} ⭐ — {metric.reasoning.strip()}\n")
