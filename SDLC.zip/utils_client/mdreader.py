
import re

def parse_markdown_sections(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Match sections that start with **1. Title** format
    sections = re.split(r"\n\*\*\d+\.\s+", content)
    headers = re.findall(r"\n\*\*(\d+\.\s+.+)", content)

    section_data = {}

    # Skip any preamble content before the first numbered section
    if not re.match(r"\*\*\d+\.\s+", content.splitlines()[0]):
        sections = sections[1:]

    for header, section in zip(headers, sections):
        title = re.sub(r"^\d+\.\s+", "", header).strip()
        body = section.strip()
        section_data[title] = body

    return section_data

# ---- Example usage ----
md_file = r"C:\Solutions\SDLC\includes\brd\output\design\8a3c76b3-9c44-4e6e-be3d-e625c02a3f60\brd_draft.md"
sections = parse_markdown_sections(md_file)

# Display and collect input for each section
user_inputs = {}
for title, body in sections.items():
    print(f"\n--- {title} ---")
    print(f"Template:\n{body}\n")
    user_input = input(f"Enter your content for '{title}':\n> ")
    user_inputs[title] = user_input

# Print or save the filled BRD
print("\n\n✅ Final Generated BRD:")
for title, content in user_inputs.items():
    print(f"\n## {title}\n{content}")