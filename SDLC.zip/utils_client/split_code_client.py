import os
import re

def extract_files_and_content(text):
    file_map = {}
    if "###FilePath:" in text:
        blocks = text.split("###FilePath:")
        for block in blocks:
            if block.strip():
                lines = block.strip().split('\n')
                file_path_line = lines[0].strip()
                content = "\n".join(lines[1:])

                if file_path_line:
                    file_path = file_path_line.strip()
                    file_name, file_extension = os.path.splitext(file_path)

                    if file_extension:
                        try:
                            file_map[file_path] = content.strip()                            
                        except Exception as e:
                            print(f"Error writing to {file_path}: {e}")
                    else:
                        print(f"Could not determine file extension for: {file_path}")
    else:
        print("No '###FilePath:' blocks found in the input text.")
    
    return  file_map

def parse_custom_format(input_text):
    file_map = {}
    file_code_pattern  = r"```(?:\s*)\n?(.+?)\n```[\r\n]+```(\w+)\n(.*?)```"
    matches_file_code = re.findall(file_code_pattern, input_text,re.DOTALL)
    
    if matches_file_code:
        for (index), (path,lang, code) in enumerate(matches_file_code):
            file_map[path.strip()] = code.strip()
    else:
        file_code_pattern  = r"```text?(?:\s*)([\w/.-]+)\n(.*?)```"
        matches_file_code = re.findall(file_code_pattern, input_text,re.DOTALL)
        
        if matches_file_code:
           for (index), (path, code) in enumerate(matches_file_code):
                file_map[path.strip()] = code.strip()
        else:    
            pattern = r"(?m)^(.*?\.java)\n\n([\s\S]+)"
            matches = re.findall(pattern, input_text)

            for (path, code) in matches:
                file_map[path.strip()] = code.strip()
    
    return file_map

def parse_custom_format_old(input_text):
    file_path_pattern = r"\n?```\n?(.*?\.(java|xml|yaml|md))\n?```\n?"
    code_pattern = r"\n?```\n?(java|markdown|yaml|xml)\s*\n([\s\S]*?)\n?```\n?"

    matches_file = re.findall(file_path_pattern, input_text)
    matches_code = re.findall(code_pattern, input_text)
    
    file_map = {}
    if matches_file:
        for (path, lang), (_, code) in zip(matches_file,matches_code):
            file_map[path.strip()] = code.strip()
    else:
        file_code_pattern  = r"```text?(?:\s*)([\w/.-]+)\n(.*?)```"
        matches_file_code = re.findall(file_code_pattern, input_text,re.DOTALL)
        
        if matches_file_code:
           for (index), (path, code) in enumerate(matches_file_code):
                file_map[path.strip()] = code.strip()
        else:    
            pattern = r"(?m)^(.*?\.java)\n\n([\s\S]+)"
            matches = re.findall(pattern, input_text)

            for (path, code) in matches:
                file_map[path.strip()] = code.strip()
    
    return file_map

def create_files(file_map, base_dir="C:/Solutions/SDLC/includes/utils"):
    for relative_path, content in file_map.items():
        full_path = os.path.join(base_dir, relative_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)
    print(f"✅ Created {len(file_map)} file(s) under: {os.path.abspath(base_dir)}")

# 🧪 Example Input
input_text1 = """
```
src/main/java/com/example/ngbschoolfees/model/School.java
```
```java

package com.example.schoolfees;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolFeesApplication {
    public static void main(String[] args) {
        SpringApplication.run(SchoolFeesApplication.class, args);
    }
}
```

```
src/main/java/com/example/ngbschoolfees/model/School1.java
```

```java
package com.example.schoolfees.config;

// config content here...
@Configuration
public class PersistenceConfig {
    // ...
}
```

"""

input_text = """
```
src/main/java/com/example/schoolfee/SchoolFeeApplication.java

package com.example.schoolfee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolFeeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SchoolFeeApplication.class, args);
    }

}
```

```
src/main/java/com/example/schoolfee/config/DatabaseConfig.java

package com.example.schoolfee.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Properties;

@Configuration
public class DatabaseConfig {

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.postgresql.Driver");
        dataSource.setUrl("jdbc:postgresql://localhost:5432/schoolfee");
        dataSource.setUsername("postgres");
        dataSource.setPassword("password");
        return dataSource;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource());
        em.setPackagesToScan("com.example.schoolfee.model");
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        em.setJpaProperties(additionalProperties());
        return em;
    }

    private Properties additionalProperties() {
        Properties properties = new Properties();
        properties.setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
        properties.setProperty("hibernate.show_sql", "true");
        properties.setProperty("hibernate.hbm2ddl.auto", "update"); //Careful in production!
        return properties;
    }

    @Bean
    public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(emf);
        return transactionManager;
    }
}
```
"""

input_text = """
```java
###FilePath:src/main/java/com/example/schoolfee/model/School.java
package com.example.schoolfee.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class School {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long schoolId;
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private String glAccountNumber;

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Student> students;

}
```

```java
###FilePath:src/main/java/com/example/schoolfee/model/FeeType.java
package com.example.schoolfee.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class FeeType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feeTypeId;
    private String feeTypeName;

    @ManyToOne
    @JoinColumn(name = "school_id")
    private School school;

}
```
"""

# Run Parser and File Generator
#file_map = parse_custom_format(input_text)
file_map = extract_files_and_content(input_text)
create_files(file_map)
