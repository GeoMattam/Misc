from typing import List
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage
from pydantic import BaseModel, Field
import OpenAI
from langchain_community.agent_toolkits import FileManagementToolkit

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"], #use current folder
).get_tools()

read_file, write_file, list_file = file_stores

SRS = read_file.invoke({"file_path": "input/srs.md"})
HLD = read_file.invoke({"file_path": "input/hld.md"})

TestLeadPrompt = """
**Role:** Regression Test Lead
**Task:** Collect information from user that helps to develop a high level design document also known as Macro Design Document \
for a software or application. 

You will receive following **pre-requisites** or **inputs**, \
1. Requirement document - {SRS} - contains use cases requirements, personas, non-functional requirements, \
use case interation diagram and others. \
2. High level design - {HLD} - contains design, best practices, guidelines and others. \

IMP: If any details are unclear or missing, you must ask the user for clarification. \
Do not proceed without resolving these uncertainties or unknowns. \
In case if you are making assumption, you must validate your assumptions with user and \
must get their confirmation before proceed.

**Clarification Strategy:**
- Your goal is, you must obtain all necessary information from user, \
that requires to build complete end to end regression test cases, \
- Ensure the questions are clear and focused on what is essential to generate test cases for regression testing \
- You may ask a set of questions at one time or one by one. \
You make a choice based on complexity of applicaiton or software and number of questions.

IMP: Restating again, you must proceed only after validating your understanding with user and getting their confirmaton.

**Steps:**

1. Identify missing or unclear details.
2. Ask for clarification and additional information from the user as necessary.
3. Verify your understanding with the user before proceeding to the next steps of creating test cases for regression testing.
4. Must ensure you understand 100% before calling the relevant tool.

"""

def get_messages_info(messages, srs, hld):
    return [SystemMessage(content=TestLeadPrompt.format(SRS=srs, HLD=hld))] + messages

class RegressionTestCase(BaseModel):
    """Instructions on how to prompt the LLM."""
    requirements: str
    additional_features: str
    business_domain: str
    architecture_style: str
    technology_choice: str
    architecture_decisions: str
    known_issues: str
    others: str 


#Original
#llm = ChatOpenAI(model=model_name, temperature=0, max_retries=1)
llm = OpenAI(base_url="https://generativelanguage.googleapis.com/v1beta/openai/", api_key=API_KEY)

llm_with_tool = llm.bind_tools([RegressionTestCase])

def information_gathering(state):
    messages = get_messages_info(state["messages"], state["srs"], state["hld"])

    response = llm_with_tool.invoke(messages)
    return {"messages": [response]}