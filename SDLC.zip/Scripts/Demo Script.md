Introduction
------------

Good Afternoon Everyone,

As part of our mission to modernize the software development lifecycle using Generative AI, we’ve brought all our innovations under a single brand – TCS A.S.C.E.N.D

In the last two sessions, we introduced some of our key AI-powered tools:
🔹 ClarifAI – helps understand and analyze business requirements
🔹 CodeSensi – a smart coding assistant that ensures security and best practices
🔹 CodeSpectre – a deep code analysis tool that helps optimize and clean up code

I’m Geo Mattam, and today, I’m excited to talk about another powerful tool in our GenAI suite – CodeGenie.

CodeGenie is like a smart co-developer. It uses large language models (LLMs) to help speed up and simplify different stages of the software development lifecycle. It is composed of multiple specialized modules

SRS to HLD: Converts Software Requirements (SRS) into High-Level Design (HLD) documents using our tool DesignSage
HLD to LLD: Breaks down HLD into detailed Low-Level Design (LLD)
Code & Unit Tests: Automatically generates code and corresponding unit test cases from the SRS, HLD, and LLD
Code Review: Uses AI agents to review code, suggest improvements, and refine it further

Let’s now take a closer look at DesignSage – our intelligent HLD generator that turns plain SRS documents into well-structured architectural designs.

DesignSage
----------

DesignSage – Smart HLD Generation with GenAI
DesignSage is a smart AI-based tool inside CodeGenie that helps automatically create High-Level Design (HLD) documents from the Software Requirements Specification (SRS). It combines AI agents and expert feedback to make the design process faster and more accurate.

🔍 1. Validation Layer – Checking the Input SRS
The first step is to check the quality of the SRS document.
An AI agent reviews the document to ensure:

It is complete and well-structured
Functional and non-functional requirements are clear
There are no missing or confusing terms

The agent then gives feedback. At this stage, a human (business analyst or architect) can add comments or fix any issues before moving to the next step.

🏗️ 2. HLD Generation – Creating the Design
Once the SRS is approved, DesignSage creates a draft HLD document.
It uses:

Predefined templates (custom or TCS-standard)
AI-driven generation based on the structure of the SRS

The HLD includes key elements like:

Modules
Components
Interfaces
Dependencies

🤖 3. Auto Review & Refinement – Improving the HLD
This step uses two AI agents in a loop:

Agent A (Critique Agent) performs syntactic and semantic review, identifies design inconsistencies, architectural anti-patterns, and missing links

Agent B (Refinement Agent) integrates feedback and regenerates improved versions of the HLD

This back-and-forth happens until the design reaches a good level—usually within 3 cycles.

🧑‍💻 4. Human Review – Final Checkpoint
After the automated review, the final HLD draft goes to a human reviewer.
They can:

Review the design and diagrams
Make final comments or changes
Approve the document for final use

📐 5. Visual Design – Auto Diagrams with PlantUML
DesignSage also creates diagrams like:

Sequence diagrams
Component diagrams
Deployment diagrams

It uses PlantUML to automatically generate these visuals from the HLD content, making the design easy to understand.