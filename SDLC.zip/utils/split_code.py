import os
import re

def parse_custom_format(input_text):
    file_map = {}
    file_code_pattern  = r"```(?:\s*)\n?(.+?)\n```[\r\n]+```(\w+)\n(.*?)```"
    matches_file_code = re.findall(file_code_pattern, input_text,re.DOTALL)
    
    if matches_file_code:
        for (index), (path,lang, code) in enumerate(matches_file_code):
            file_map[path.strip()] = code.strip()
    else:
        file_code_pattern  = r"```text?(?:\s*)([\w/.-]+)\n(.*?)```"
        matches_file_code = re.findall(file_code_pattern, input_text,re.DOTALL)
        
        if matches_file_code:
           for (index), (path, code) in enumerate(matches_file_code):
                file_map[path.strip()] = code.strip()
        else:    
            pattern = r"(?m)^(.*?\.java)\n\n([\s\S]+)"
            matches = re.findall(pattern, input_text)

            for (path, code) in matches:
                file_map[path.strip()] = code.strip()
    
    return file_map

def remove_fenced_code_tags(text):
    # Remove lines like ```java, ```xml, ```yaml, ```markdown
    removed_lang_text =  re.sub(r'```(java|xml|yaml|markdown)?\n?', '', text)
    removed_specialcharacter_text = re.sub(r'```', '', removed_lang_text)
    return removed_specialcharacter_text

def is_valid_file_path(file_path):
    # Basic validation: file path should contain a directory and a file name
    return file_path.endswith(('.java','.py', '.md', '.txt', '.sh', '.json', '.yaml', '.yml','.xml'))

def extract_files_and_content(text):
    file_map = {}
    if "###FilePath:" in text or "### FilePath:" in text:
        blocks = text.split("###FilePath:")
        if len(blocks) == 1 and "###FilePath:" not in text:
            blocks = text.split("### FilePath:")

        for block in blocks:
            if block.strip():
                lines = block.strip().split('\n')
                file_path_line = lines[0].strip()
                content = "\n".join(lines[1:])

                if file_path_line:
                    file_path = file_path_line.strip()
                    file_name, file_extension = os.path.splitext(file_path)

                    if file_extension:
                        try:
                            content = remove_fenced_code_tags(content)
                            file_map[file_path] = content.strip()                            
                        except Exception as e:
                            print(f"Error writing to {file_path}: {e}")
                    else:
                        print(f"Could not determine file extension for: {file_path}")
    else:
        print("No '###FilePath:' blocks found in the input text.")
    
    return  file_map
    
def create_files(file_map, base_dir):
    pattern = r"```(.*?)```"
    replacement = ''
    for relative_path, content in file_map.items():
        if is_valid_file_path(relative_path):
            full_path = os.path.join(base_dir, relative_path)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            with open(full_path, "w", encoding="utf-8") as f:
                #result = re.sub(pattern, replacement, content, flags=re.DOTALL)
                f.write(content)