import gzip, json, base64
import requests
class PromptHubClient:
    def __init__(self, base_url:str):
        self.base = base_url.rstrip("/")
    
    def upload_output(
            self,
            application_name: str,
            logged_in_user: str,
            framework: str,
            llm_model_name: str,
            prompt: str,
            output: str,
            refs: list [dict]
    ):
        prompt_zip = base64.b64encode(gzip.compress(prompt.encode("utf-8"))).decode("ascii")
        output_zip = base64.b64encode(gzip.compress(json.dumps(output).encode("utf-8"))).decode("ascii")

        payload = {
            "application_name": application_name,
            "logged_in_user": logged_in_user,
            "framework": framework,
            "llm_model_name": llm_model_name,
            "prompt": prompt_zip,
            "output": output_zip,
            "related_prompts": refs
        }
        
        print(f"URL: {self.base}/output-info")

        resp = requests.post(f"{self.base}/output-info", json=payload)
        resp.raise_for_status()
        return resp.json()