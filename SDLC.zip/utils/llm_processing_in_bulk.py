import csv
import openai
from openai import OpenAI
import os
from pathlib import Path
import unique_key as uniquekey

from client import PromptHubClient
client = PromptHubClient("http://localhost:9000/")

ROOT_PATH =  os.getenv('ROOT_PATH')
phase = "hld"

def llm_instance(model_instance):
    if model_instance == "Gemini":
        llm_client = OpenAI(
            api_key="AIzaSyAlpg24hVWAyD5lXZRTMYGbk7IseZE5CjI",
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/"
        )
    elif model_instance == "Ollama":
        llm_client = OpenAI(
            base_url = 'http://localhost:11434/v1',
            api_key='ollama', # required, but unused
        )
    return llm_client


def write_to_csv(row_data, is_first_time,myuuid):
    output_file_path = f"{ROOT_PATH}validation/{phase}/output/{myuuid}.csv" 
    fieldnames = ['prompt', 'prompt_output']

    mode = 'w' if is_first_time else 'a'
    with open(output_file_path, mode=mode, newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        if is_first_time:
            writer.writeheader()
        writer.writerow(row_data)

def validate_output_against_input(row_number,llm_client,lst_dict_document_details, content_template,model_instance,model_name,myuuid):
    is_first_time=False

    params = {}
    for dict_document_details in lst_dict_document_details:
        key_name = key_value = ""
        for key,value in dict_document_details.items():
            if key =="document_name":
                key_name = value
            elif key == "file_content":
                key_value = value
        params[key_name] = key_value

    #print("params:",params)

    if len(lst_dict_document_details) == 0:
        content = content_template
    else:
        content = content_template.format(**params)

    messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {
                "role": "user",
                "content": content
            }
        ]
    #print("messages:",messages)
    
    response = llm_client.chat.completions.create(
        model=model_name,
        n=1,
        messages=messages
    )

    str_messages = ''.join([str(d) for d in messages])

    result = client.upload_output(application_name="IOValidator",
                                    logged_in_user= "Geo",
                                    framework=model_instance,
                                    llm_model_name=model_name,
                                    prompt=str_messages,
                                    output=response.choices[0].message.content,
                                    refs=[])
    
    #return response.choices[0].message
    csv_records = {'prompt': content_template, 'prompt_output': response.choices[0].message.content}
    
    if row_number == 1:
        is_first_time = True

    write_to_csv(csv_records,is_first_time,myuuid)

def split_text(text):
    # First split by comma
    comma_split = text.split(',')

    # Then split each item by semicolon
    result = [part.split(':') for part in comma_split]

    return result


def main(file_path,llm_client,model_instance,model_name,myuuid):
    try:
        lst_dict_document_details = []
        
        with open(file_path, mode='r', newline='', encoding='utf-8') as file:
            reader = csv.DictReader(file)

            for row_number, row in enumerate(reader, start=1):
                files = row.get('files')       
                content_template = row.get('prompt')
                status = row.get('status')
                
                if status == "1":
                    #print(f"Row {row_number} - Files: {files}, Prompts: {content_template}")
                    print(f"Row {row_number}")

                    ls_files = split_text(files)

                    for file in ls_files:
                        dict_document_details = {}
                        file_path_input = f"{ROOT_PATH}validation/{phase}/input/{file[1]}" 
                        file_content = Path(file_path_input).read_text(encoding="utf-8")
                        dict_document_details["document_name"] = file[0]
                        dict_document_details["file_content"] = file_content
                        lst_dict_document_details.append(dict_document_details)

                    validate_output_against_input(row_number,llm_client, lst_dict_document_details, content_template,model_instance,model_name,myuuid)
                    
    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    bulk_csv_prompts_path = f"{ROOT_PATH}validation/{phase}/input/bulk_prompts.csv" 
    model_instance = "Gemini"
    model_name = "gemini-1.5-flash"
    myuuid = uniquekey.generate_uniquekey()

    llm_client  = llm_instance(model_instance)

    main(bulk_csv_prompts_path,llm_client,model_instance,model_name,myuuid)