import os
from dotenv import load_dotenv
#from langchain_google_genai import ChatGoogleGenerativeAI
#from langchain_google_genai import GoogleGenerativeAI
#from langchain_openai import ChatOpenAI
#from langchain_ollama.llms import OllamaLLM
#import google.generativeai as genai
from pydantic import BaseModel
from openai import OpenAI

from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages

# load .env file to environment
load_dotenv()


def llm_initialize(framework):
    client =None

    match framework:
        case "Gemini":
            API_KEY = os.getenv('GEMINI_API_KEY')
            MODEL_NAME = os.getenv('GEMINI_MODEL_NAME')
            client = OpenAI(base_url="https://generativelanguage.googleapis.com/v1beta/openai/", api_key=API_KEY)
        # case "OpenAI":
        #     API_KEY = os.getenv('OPEN_API_KEY')
        #     MODEL_NAME = os.getenv('OPEN_MODEL_NAME')
        #     client = ChatOpenAI(model=MODEL_NAME, temperature=0, max_retries=1)

        # case "Ollama":
        #     API_KEY = os.getenv('OPEN_API_KEY')
        #     MODEL_NAME = os.getenv('OLLAMA_MODEL_NAME')
        #     client = OllamaLLM(model="bakllava")
    
    return client

def call_llm_model(client,messages):
    response = client.chat.completions.create(
        #model="gemini-1.5-flash",
        model="gemini-2.5-flash",
        messages=messages)

    return response