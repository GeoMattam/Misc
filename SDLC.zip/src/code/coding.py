from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START,END
import os
from langchain_community.agent_toolkits import FileManagementToolkit

import src.code.coding_node as codingnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores
  
def initialize_workflow():

    workflow = StateGraph(codingnode.State)

    workflow.add_edge(START, "Seek Clarifications")

    workflow.add_node("Seek Clarifications", codingnode.information_gathering)
    workflow.add_node("Generate Code", codingnode.generate_code)
    # workflow.add_node("Review Code",codingnode.review_code)
    # workflow.add_node("Debug Code",codingnode.debug_code)
    workflow.add_node("Store Code", codingnode.store_code)

    # workflow.add_conditional_edges(
    #     "Review Code", 
    #     codingnode.is_reviewed, 
    #     #{"satisfied": "Store Code",  "enhance": "Debug Code"}
    #     {"satisfied": END,  "enhance": END}
    # )
    workflow.add_edge("Seek Clarifications", "Generate Code")
    # workflow.add_edge("Generate Code", "Review Code")
    # workflow.add_edge("Debug Code", "Review Code")
    
    workflow.add_edge("Generate Code", "Store Code")
    workflow.add_edge("Store Code", END)
    
    return workflow

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory) #, interrupt_after=['generate_requirements'])

    thread = {"configurable": {"thread_id": 22}}

    SRS = read_file.invoke({"file_path": f"{ROOT_PATH}code/input/BRD_NGB.md"})
    HLD = read_file.invoke({"file_path": f"{ROOT_PATH}code/input/ca40384e-c989-48bc-a984-0d0eda17b046.md"})
    LLD = read_file.invoke({"file_path": f"{ROOT_PATH}code/input/ca40384e-c989-48bc-a984-0d0eda17b046.md"})
    FORMAT = read_file.invoke({"file_path": f"{ROOT_PATH}code/input/spring_boot_ps.md"})
    standards = read_file.invoke({"file_path": f"{ROOT_PATH}code/input/standards/spring_boot_standards.md"}) 
    RequirementTree = read_file.invoke({"file_path": f"{ROOT_PATH}code/input/standards/spring_boot_standards.md"}) 
    
    user_msg = "Generate the code"
    
    for output in graph.invoke(
        {
            "messages": [HumanMessage(content=user_msg)],
            "srs": [HumanMessage(content=SRS)],
            "requirementtree":[HumanMessage(content=RequirementTree)],
            "hld": [HumanMessage(content=HLD)],
            "lld": [HumanMessage(content=LLD)],
            "ps": [HumanMessage(content=FORMAT)],
            "standards": [HumanMessage(content=standards)],
            "iteration" : 1,
            "max_iteration": 2,
        }, 
        config=thread, 
        stream_mode="updates"):
        print(output)
        for key, value in output.items():
            print("***** Result from Agent: ",key)
            print("***** value: ",value)

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)