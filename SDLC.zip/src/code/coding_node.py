import os
import re
from typing import List
import uuid

from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from langchain_core.messages.utils import get_buffer_string

from pydantic import BaseModel, Field
from typing import Annotated
from typing_extensions import TypedDict
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.graph.message import add_messages

from prompts.code.prompt import *
import utils.llm_invoke as llminvoke
import utils.split_code as splitcode

phase="code"
ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(
    selected_tools=["read_file", "write_file", "list_directory"], #use current folder
).get_tools()

read_file, write_file, list_file = file_stores

client = llminvoke.llm_initialize("Gemini")

class State(TypedDict):
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    requirementtree:Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    lld: Annotated[list, add_messages]
    ps: Annotated[list, add_messages]
    standards: Annotated[list, add_messages]
    coding: str
    max_iteration: int
    iteration: int
    uuid: str
    

def information_gathering(state):
    myuuid = state["uuid"]
    coding = state.get('coding')

    messages = [
        {
            "role": "system", 
            "content": coding_devclarification_system_message_prompt
        },
        {
            "role": "user",
            "content": coding_devclarification_user_message_prompt
        }
    ]
    
    if coding:
        pass
    else:
        response = client.chat.completions.create(
            model="gemini-1.5-flash",
            messages=messages)


    return {"messages": [AIMessage(response.choices[0].message.content)],
            "uuid": str(myuuid)}
    
def generate_code(state):
    srs = state["srs"]
    requirementtree = state['requirementtree']
    hld = state["hld"]
    lld = state["lld"]
    ps = state["srs"]
    standards = state["standards"]
    myuuid = state["uuid"]
    last_message = state['messages'][-1].content
    iteration = state['iteration']
    

    messages = [
        {
            "role": "system", 
            "content": coding_system_message_prompt
        },
        {
            "role": "user",
            "content": f"{coding_user_message_prompt.format(srs=srs,requirement_tree=requirementtree,hld=hld,lld=lld,ps=ps,standards=standards)}"
        }
    ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)
    
    file_name = f"{ROOT_PATH}code/output/{myuuid}/code v0.{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

    return {
        "messages": [response.choices[0].message.content],
        "coding": response.choices[0].message.content,
        "iteration": iteration,
        "uuid": str(myuuid)     
    }

def generate_project_structure(state):
    code = state["coding"]
    myuuid = state["uuid"]
    
    messages = [
        {
            "role": "system", 
            "content": project_from_structured_markdown_system_message
        },
        {
            "role": "user",
            "content": f"{project_from_structured_markdown_user_message.format(code=code)}"
        }
    ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)
    
    file_name = f"{ROOT_PATH}code/output/{myuuid}/code.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

    return {
        "uuid": myuuid
    }

def review_code(state):
    print("inside review_code")
    hld = state['hld'][-1].content
    srs = state['srs'][-1].content
    coding = state['coding'][-1].content
    myuuid = state["uuid"]
    
    messages = [
        {
            "role": "system", 
            "content": coding_review_system_message_prompt
        },
        {
            "role": "user",
            "content": f"{coding_review_user_message_prompt.format(srs=srs,hld=hld,coding=coding)}"
        }
    ]

    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)
    
    #max_iteration = state['max_iteration']
    iteration = state['iteration'] + 1
    file_name = f"{ROOT_PATH}code/output/{myuuid}/code-review v0.{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

    return {
        "messages": [response.choices[0].message.content],
        "iteration": iteration
    }

def debug_code(state):
    print("inside debug_code")
    iteration = state['iteration']
    last_message = state['messages'][-1].content
    coding = state['coding'][-1].content
    hld = state['hld'][-1].content
    srs = state['srs'][-1].content
    myuuid = state["uuid"]
    
    messages = [
        {
            "role": "system", 
            "content": coding_debug_system_message_prompt
        },
        {
            "role": "user",
            "content": f"{coding_debug_user_message_prompt.format(srs=srs,hld=hld,coding=coding,last_message=last_message)}"
        }
    ]

    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)
    
    iteration = str(state['iteration'])
    
    file_name = f"{ROOT_PATH}code/output/{myuuid}/code v0.{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

        
    return {
        "messages": [response.choices[0].message.content] ,
        "coding": response.choices[0].message.content,
        "iteration": iteration
    }

def store_code(state):
    myuuid = state["uuid"]
    coding = state['coding']
    root_path = f"{ROOT_PATH}code/output/{myuuid}/"

    file_map = splitcode.extract_files_and_content(coding)
    
    if file_map:
        splitcode.create_files(file_map,root_path)

    return {"uuid": str(myuuid)}

def is_reviewed(state):
    print("inside is_reviewed")
    max_iteration = state['max_iteration']
    iteration = state['iteration']
    print(" ***** iteration *****", iteration)
    last_message = state['messages'][-1].content
    if 'satisfied' in last_message.lower():
        return 'satisfied'
    elif iteration > max_iteration:
        return 'satisfied'
    else:
        return 'enhance'