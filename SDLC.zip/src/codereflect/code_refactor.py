import time
import os
import logging

import prompts.codereflect.prompt as prompts
from typing import Dict, TypedDict, Optional 
from langgraph.graph import StateGraph, END, Graph
import utils.llm_invoke as llminvoke
from src.codereflect.code_refactor_node import *
from langchain_community.agent_toolkits import FileManagementToolkit

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

client = llminvoke.llm_initialize("Gemini")
#conditional edge function to determine whether the code is deployment ready

def is_code_deployment_ready (state):
    logging.info("Check to see if the code is deployment ready......")
    print(f"CodeReflect: Check to see if the code is deployment ready Iteration: {state.get('iterations')}......")

    feedback_classifier_prompt = prompts.feedback_classifier_prompt
    logging.info(f"Prompt used for (is_code_deployment_ready): \n {feedback_classifier_prompt}\n")
    
    feedback_classifier_prompt = feedback_classifier_prompt.format(state.get('code'), state.get('feedback'))
    
    st_time = time.time()

    messages = [
        {
            "role": "system", 
            "content": prompts.code_review_systemmessage
        },
        {
            "role": "user",
            "content": feedback_classifier_prompt
        }
    ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    deployment_ready_code  = response.choices[0].message.content

    deployment_ready  = 1 if 'yes' in deployment_ready_code else 0
    total_iterations = 1 if state.get('iterations') > 2 else 0

    if deployment_ready or total_iterations:
        print(state.get('iterations'))
    else:
        print(state.get('iterations'))
        
    return "result_handler" if deployment_ready or total_iterations else "code_reviewer"

def initialize_workflow():
    builder = StateGraph(CodeReflectState)
    logging.info("Welcome the automated code cleanup Genie......") 
    logging.info("Build the graph that will be used by CodeReflect......")

    #add the nodes to the graph
    builder.add_node("code_reviewer", code_reviewer) 
    builder.add_node("code_developer", code_developer)
    builder.add_node ("result_handler", result_handler)

    #add a conditional edge to check if the code is deployment ready
    #if it in deployment ready then the edge is set to result handler
    #else it is set to code developer to change the code to incorporate
    #review comments    
    builder.add_conditional_edges(
        "code_developer",
        is_code_deployment_ready,
        {
            "result_handler": "result_handler", 
            "code_reviewer": "code_reviewer"
        }
    )
    
    builder.set_entry_point ("code_reviewer")
    builder.add_edge("code_reviewer", "code_developer")
    builder.add_edge("result_handler", END)

    return builder

def run_workflow(builder):
    problem = "Generate code to train a Regression ML model using a tabular dataset following required preprocessing steps. \
                Ouput only the code and no other explanation"

    logging.info("Generating code for kick-starting CodeReflect.")

    st_time = time.time()

    code = read_file.invoke({"file_path": f"{ROOT_PATH}CodeReflect/input/requirement.java"})
    specialization = "Java"

    graph = builder.compile()
    
    conversation = graph.invoke(
        {
            "history":code,
            "code":code,
            "original_code": code,
            "specialization": specialization,
            'iterations':0
        },
        {"recursion_limit":100}
    )

if __name__ == "__main__":
    builder = initialize_workflow()
    run_workflow(builder)