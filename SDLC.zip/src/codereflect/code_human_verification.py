import os
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt,Command

import src.codereflect.code_human_verification_node as hldcodehumanverificationnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    workflow = StateGraph(hldcodehumanverificationnode.State)
    
    workflow.add_node("Information Gathering", hldcodehumanverificationnode.information_gathering)
    workflow.add_node("Human Approval", hldcodehumanverificationnode.human_approval)
    workflow.add_node("Clarified", hldcodehumanverificationnode.conclude_conversation)
    
    workflow.add_edge(START, "Information Gathering")
    workflow.add_edge("Information Gathering", "Human Approval")
    workflow.add_edge("Human Approval", "Clarified")
    workflow.add_edge("Clarified", END)

    workflow.add_conditional_edges(
          "Human Approval", 
          hldcodehumanverificationnode.is_clarified, 
          {"yes": "Clarified",  "no": "Human Approval"}
     )

    return workflow

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}

    code = read_file.invoke({"file_path": f"{ROOT_PATH}input/FunctionalSpecification.md"})
    specialization = "Java"
    user_msg = "Review the given code!"

    output = graph.invoke(
            {
                "history":code,
                "code":code,
                "original_code": code,
                "specialization": specialization,
                'iterations':0
            }
        )

    
    print(output)

    feedback = input("Enter your review comments:")

    # Resume the graph with the human's input
    graph.invoke(Command(resume=feedback), config=thread)

    if output:
        print("Code Generated!")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)