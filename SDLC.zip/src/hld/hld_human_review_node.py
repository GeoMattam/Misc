import os
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt, Command

import utils.llm_invoke as llminvoke
from prompts.hld.hld_prompts import *

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

llm_client = llminvoke.llm_initialize("Gemini")

class State(TypedDict):
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    hld_format: Annotated[list, add_messages]
    uuid: str
    iteration: int

def information_gathering(state:State):
    myuuid = state["uuid"]
    return {"uuid": str(myuuid),"messages": "NA"}

def update_hld(state:State):
    hld = state['hld'][-1].content
    format = state['hld_format'][-1].content
    last_message = state['messages'][-1].content
    srs = state['srs'][-1].content
    iteration = state['iteration']
    myuuid = state["uuid"]

    messages = [
        {
            "role": "system", 
            "content": review_hld_system_message_prompt
        },
        {
            "role": "user",
            "content": review_hld_user_message_prompt.format(srs=srs,hld=hld,review=last_message,format=format)
        }
    ]
    response = llm_client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    file_name = f"{ROOT_PATH}output/hld/manualreview/{myuuid}/hld v{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    iteration = state['iteration'] + 1

    return {
        "hld": [response.choices[0].message.content],
        "iteration": iteration,
        "messages": "NA",
        "uuid": str(myuuid)
    }   

def finalize_hld(state:State):
    myuuid = state["uuid"]
    hld_content = state['hld'][-1].content

    file_name = f"{ROOT_PATH}hld/output/manualreview/{myuuid}/hld_freezed.md"
    write_file.invoke({"file_path": file_name, "text": hld_content})
    
    return {
            "messages": "NA",
            "iteration" : state['iteration'],
            "uuid": str(myuuid),
            "hld": [hld_content]
        } 

def is_approved(state:State):
    last_message = state['messages'][-1].content
    print("is_approved:",last_message)
    
    if last_message.lower() not in ("approved", "approve"):
        return "enhance"
    else:
        return "approved"

def humanloop(state:State):
    myuuid = state["uuid"]  
    feedback = interrupt("Enter the feedback:")
    
    return {"messages": [HumanMessage(feedback)],
            "uuid": str(myuuid)}