import os
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langchain_community.agent_toolkits import FileManagementToolkit

import utils.llm_invoke as llminvoke
from prompts.hld.hld_prompts import *

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

llm_client = llminvoke.llm_initialize("Gemini")

class State(TypedDict):
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    hld_format: Annotated[list, add_messages]
    requirement_tree: Annotated[list, add_messages]
    HLDDocumentControl: str
    ApplicationIntroduction: str
    SystemOverview: str
    ArchitectureDesign: str
    ComponentDesign:str
    DataDesign: str
    InterfaceDesign: str
    DeploymentArchitecture:str
    UseCaseDesign:str
    BehavioralandStructuralDiagrams:str
    SecurityDesign: str
    PerformanceAndScalabilityDesign: str
    AssumptionsAndDependencies: str
    RisksAndMitigation:str
    Appendix:str
    uuid: str

def information_gathering(state:State):
    myuuid = state["uuid"]
    return {"uuid": str(myuuid)}


# Function to combine multiple markdown files
def combine_markdown_files(input_files, output_file):
    with open(output_file, 'w') as outfile:
        for file in input_files:
            # Check if the file exists
            if os.path.exists(file):
                with open(file, 'r') as infile:
                    content = infile.read()
                    outfile.write(content + '\n\n')  # Add new line between files
            else:
                print(f"Warning: {file} not found!")

def generate_hld(state:State):
        
        #hld_DocumentControl = state["HLDDocumentControl"]
        #hld_Introduction = state["ApplicationIntroduction"]
        hld_SystemOverview = state["SystemOverview"]
        hld_ArchitectureDesign = state["ArchitectureDesign"]
        hld_ComponentDesign  = state["ComponentDesign"]
        hld_DataDesign = state["DataDesign"]
        hld_InterfaceDesign = state["InterfaceDesign"]
        hld_DeploymentArchitecture  = state["DeploymentArchitecture"]
        hld_UseCaseDesign  = state["UseCaseDesign"]
        hld_BehavioralandStructuralDiagrams  = state["BehavioralandStructuralDiagrams"]
        #hld_SecurityDesign  = state["SecurityDesign"]
        #hld_PerformanceAndScalabilityDesign = state["PerformanceAndScalabilityDesign"]
        #hld_AssumptionsAndDependencies = state["AssumptionsAndDependencies"]
        #hld_RisksAndMitigation  = state["RisksAndMitigation"]
        #hld_Appendix = state["Appendix"]
        
        myuuid = state["uuid"]

        # List of markdown files you want to combine
        markdown_files = [  #hld_DocumentControl[0],
                            #hld_Introduction[0],
                            hld_SystemOverview[0],
                            hld_ArchitectureDesign[0],
                            hld_ComponentDesign[0],
                            hld_DataDesign[0],
                            hld_InterfaceDesign[0],
                            hld_DeploymentArchitecture[0],
                            hld_UseCaseDesign[0],
                            hld_BehavioralandStructuralDiagrams[0] #,
                            #hld_SecurityDesign[0],
                            #hld_PerformanceAndScalabilityDesign[0],
                            #hld_AssumptionsAndDependencies[0],
                            #hld_RisksAndMitigation[0],
                            #hld_Appendix[0]
                        ]
                            
        # Output file where combined content will be stored
        output_file = f"{ROOT_PATH}hld/output/design/{myuuid}/hld.md"

        # Combine the markdown files
        combine_markdown_files(markdown_files, output_file)

        return {"uuid": str(myuuid),
                "hld": [output_file]}

def fn_documentcontrol(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_documentcontrol_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/HLDDocumentControl.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "HLDDocumentControl": [file_name]
    }
    

def fn_introduction(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_introduction_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/Introduction.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "ApplicationIntroduction": [file_name]
    }
    

def fn_system_overview(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_systemoverview_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/SystemOverview.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "SystemOverview": [file_name]
    }
    

def fn_architecture_design(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_architecturedesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/ArchitectureDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "ArchitectureDesign": [file_name]
    }


def fn_component_design(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_componentdesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/ComponentDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "ComponentDesign": [file_name]
    }

def fn_data_design(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_datadesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/DataDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "DataDesign": [file_name]
    }

def fn_interface_design(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_interfacedesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/InterfaceDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "InterfaceDesign": [file_name]
    }

def fn_deployment_architecture(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_deploymentarchitecture_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/DeploymentArchitecture.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "DeploymentArchitecture": [file_name]
    }

def fn_usecase_design(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_usecasedesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/UseCaseDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "UseCaseDesign": [file_name]
    }

def fn_behavioral_structural_diagrams(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_behavioralstructuraldiagrams_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/BehavioralandStructuralDiagrams.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "BehavioralandStructuralDiagrams": [file_name]
    }

def fn_security_design(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_securitydesign_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/SecurityDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "SecurityDesign": [file_name]
    }


def fn_performance_scalability_design(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_performanceaandscalabilitydesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/PerformanceAndScalabilityDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "PerformanceAndScalabilityDesign": [file_name]
    }

def fn_assumptions_dependencies(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_assumptionsanddependencies_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/AssumptionsAndDependencies.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "AssumptionsAndDependencies": [file_name]
    }

def fn_risk_mitigation(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_risksandmitigation_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/RisksAndMitigation.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "RisksAndMitigation": [file_name]
    }

def fn_appendix(state:State):
    srs_document = state["srs"]
    hld_format = state["hld_format"]
    requirement_tree = state["requirement_tree"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": hld_system_message_prompt
            },
            {
                "role": "user",
                #"content": f"{hld_user_message_common_prompt.format(srs=srs_document,hld_format=hld_format,requirement_tree=requirement_tree)} \n\
                "content": f"{hld_user_message_common_prompt.format(srs=srs_document,requirement_tree=requirement_tree)} \n\
                {hld_user_message_appendix_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}hld/output/design/{myuuid}/Appendix.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "Appendix": [file_name]
    }