import os

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START ,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit

import src.hld.hld_design_node as hlddesignnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    workflow = StateGraph(hlddesignnode.State)

    workflow.add_edge(START, "Information Gathering")

    
    workflow.add_node("Information Gathering", hlddesignnode.information_gathering)
    #workflow.add_node("Document Control", hlddesignnode.fn_documentcontrol)
    #workflow.add_node("Introduction", hlddesignnode.fn_introduction)
    workflow.add_node("System Overview", hlddesignnode.fn_system_overview)
    workflow.add_node("Architecture Design", hlddesignnode.fn_architecture_design)
    workflow.add_node("Component Design", hlddesignnode.fn_component_design)
    workflow.add_node("Data Design", hlddesignnode.fn_data_design)
    workflow.add_node("Interface Design", hlddesignnode.fn_interface_design)
    workflow.add_node("Deployment Architecture", hlddesignnode.fn_deployment_architecture)
    workflow.add_node("Use Case Design", hlddesignnode.fn_usecase_design)
    workflow.add_node("Behavioral and Structural Diagrams", hlddesignnode.fn_behavioral_structural_diagrams)
    #workflow.add_node("Security Design", hlddesignnode.fn_security_design)
    #workflow.add_node("Performance Scalability Design", hlddesignnode.fn_performance_scalability_design)
    #workflow.add_node("Assumptions Dependencies", hlddesignnode.fn_assumptions_dependencies)
    #workflow.add_node("Risks and Mitigation", hlddesignnode.fn_risk_mitigation)
    #workflow.add_node("Appendix Details", hlddesignnode.fn_appendix)
    workflow.add_node("Generate HLD",hlddesignnode.generate_hld)
        
        
    #workflow.add_edge("Information Gathering", "Document Control")
    #workflow.add_edge("Information Gathering", "Introduction")
    workflow.add_edge("Information Gathering", "System Overview")
    workflow.add_edge("Information Gathering", "Architecture Design")
    workflow.add_edge("Information Gathering", "Component Design")
    workflow.add_edge("Information Gathering", "Data Design")
    workflow.add_edge("Information Gathering", "Interface Design")
    workflow.add_edge("Information Gathering", "Deployment Architecture")
    workflow.add_edge("Information Gathering", "Use Case Design")
    workflow.add_edge("Information Gathering", "Behavioral and Structural Diagrams")
    #workflow.add_edge("Information Gathering", "Security Design")
    #workflow.add_edge("Information Gathering", "Performance Scalability Design")
    #workflow.add_edge("Information Gathering", "Assumptions Dependencies")
    #workflow.add_edge("Information Gathering", "Risks and Mitigation")
    #workflow.add_edge("Information Gathering", "Appendix Details")
    
    #workflow.add_edge("Document Control","Generate HLD")
    #workflow.add_edge("Introduction","Generate HLD")
    workflow.add_edge("System Overview","Generate HLD")
    workflow.add_edge("Architecture Design","Generate HLD")
    workflow.add_edge("Component Design","Generate HLD")
    workflow.add_edge("Data Design","Generate HLD")
    workflow.add_edge("Interface Design","Generate HLD")
    workflow.add_edge("Deployment Architecture","Generate HLD")
    workflow.add_edge("Use Case Design","Generate HLD")
    workflow.add_edge("Behavioral and Structural Diagrams","Generate HLD")
    #workflow.add_edge("Security Design","Generate HLD")
    #workflow.add_edge("Performance Scalability Design","Generate HLD")
    #workflow.add_edge("Assumptions Dependencies","Generate HLD")
    #workflow.add_edge("Risks and Mitigation","Generate HLD")
    #workflow.add_edge("Appendix Details","Generate HLD")
    
    workflow.add_edge("Generate HLD", END)

    return workflow

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}

    SRS = read_file.invoke({"file_path": f"{ROOT_PATH}input/FunctionalSpecification.md"})
    FORMAT = read_file.invoke({"file_path": f"{ROOT_PATH}input/hld_design.md"})

    user_msg = "Generate High Level Design Document"
    output = graph.invoke(
        {
            "messages": [HumanMessage(content=user_msg)],
            "srs": [HumanMessage(content=SRS)],
            "hld_format": [HumanMessage(content=FORMAT)],
        }, 
        config=thread,
        stream_mode="updates")
        
    print("HLD Generated!")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)