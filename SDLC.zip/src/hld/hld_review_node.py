import os
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt, Command

import utils.llm_invoke as llminvoke
from prompts.hld.hld_prompts import *

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

llm_client = llminvoke.llm_initialize("Gemini")

class State(TypedDict):
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    hld_format: Annotated[list, add_messages]
    uuid: str
    iteration: int
    max_iteration: int
    
def information_gathering(state:State):
    myuuid = state["uuid"]
    return {"uuid": str(myuuid),"messages": "NA"}

def update_hld(state:State):
    hld = state['hld'][-1].content
    hld_format = state['hld_format'][-1].content
    last_message = state['messages'][-1].content
    srs = state['srs'][-1].content
    iteration = state['iteration']
    myuuid = state["uuid"]

    messages = [
        {
            "role": "system", 
            "content": review_hld_system_message_prompt
        },
        {
            "role": "user",
            "content": review_hld_user_message_prompt.format(srs=srs,hld=hld,review=last_message,hld_format=hld_format)
        }
    ]
    response = llm_client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    file_name = f"{ROOT_PATH}output/hld/automatedreview/{myuuid}/hld v{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "hld": [response.choices[0].message.content],
        "iteration": iteration,
        "messages": "NA",
        "uuid": str(myuuid)
    }   

def finalize_hld(state:State):
    myuuid = state["uuid"]
    hld_content = state['hld'][-1].content

    file_name = f"{ROOT_PATH}hld/output/automatedreview/{myuuid}/hld_freezed.md"
    write_file.invoke({"file_path": file_name, "text": hld_content})
    
    return {
            "messages": "NA",
            "iteration" : state['iteration'],
            "uuid": str(myuuid),
            "hld": [hld_content]
        } 

def reviewer(state:State):
    myuuid = state["uuid"]
    iteration = state['iteration'] + 1
    
    srs_document = state['srs'][-1].content
    hld = state['hld'][-1].content
    hld_format = state['hld_format'][-1].content
        
    messages = [
        {
            "role": "system", 
            "content": review_critique_hld_system_message_prompt
        },
        {
            "role": "user",
            "content": f"{review_critique_hld_user_message_prompt.format(srs=srs_document,hld=hld,hld_format=hld_format)}"
        }
    ]

    response = llm_client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    file_name = f"{ROOT_PATH}output/hld/automatedreview/{myuuid}/hld_feedback v{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "messages": [response.choices[0].message.content],
        "iteration" : iteration,
        "uuid": str(myuuid)
    }


def is_reviewed(state:State):
    max_iteration = state['max_iteration']
    iteration = state['iteration']
    last_message = state['messages'][-1].content
   
    if "Satisfied" in last_message.lower():
        return 'reviewed'
    elif iteration > max_iteration:
        return 'reviewed'
    else:
        return 'enhance'