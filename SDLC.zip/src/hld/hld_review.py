import os

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START ,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt,Command

import src.hld.hld_review_node as hldreviewnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    workflow = StateGraph(hldreviewnode.State)

    workflow.add_edge(START, "Information Gathering")

    workflow.add_node("Information Gathering", hldreviewnode.information_gathering)
    workflow.add_node("Review and Feedback",hldreviewnode.reviewer)
    workflow.add_node("Finalize HLD",hldreviewnode.finalize_hld)
    workflow.add_node("Update HLD",hldreviewnode.update_hld)

    workflow.add_conditional_edges(
        "Update HLD", 
        hldreviewnode.is_reviewed, 
        {"reviewed": "Finalize HLD",  "enhance": "Review and Feedback"}
    )
    
    workflow.add_edge("Information Gathering", "Review and Feedback")
    workflow.add_edge("Review and Feedback","Update HLD")
    workflow.add_edge("Finalize HLD",END)

    return workflow

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}

    srs = read_file.invoke({"file_path": f"{ROOT_PATH}input/FunctionalSpecification.md"})
    hld = read_file.invoke({"file_path": f"{ROOT_PATH}output/hld/design/intermediate/ef2ef3b3-ebd8-44df-90fc-c480ccc32c24/hld.md"})
    hld_format = read_file.invoke({"file_path": f"{ROOT_PATH}input/hld_design.md"})

    user_msg = "Generate High Level Design Document"
    
    for output in graph.invoke(
        {
            "messages": [HumanMessage(content=user_msg)],
            "srs": [HumanMessage(content=srs)],
            "hld": [HumanMessage(content=hld)],
            "hld_format": [HumanMessage(content=hld_format)],
            "iteration" : 0,
            "max_iteration": 2,
        }, 
        config=thread, 
        stream_mode="updates"):

        for key, value in output.items():
            if key == "Review and Feedback":
                try:
                    last_message = next(iter(output.values()))["messages"][-1]
                    print(last_message)
                except:
                    print("pass")
    
    print("Completed the Automated Reviews!")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)