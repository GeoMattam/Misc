import logging
import threading

import src.codetesting.code_testing_prompts as codetestingprompts

def process_testing(module_info,specification, unique_runnerid, model_location,model_name): 
    try:

        print(f"Generating Unit Testing for (module_info["name"]}...")
        
        full_file_path = f(module_info["path"]}/{module_info["name"]}'
        
        source code cgfilehandler.read_files(full_file_path)

        prompt_input = codetestingprompts.prompt_template(specification, "Code Testing" model location model,name,source code)

        processed content = model.invoke(prompt_input)

        psuedo_code cgdoccontent.fn_doc content(model_location processed content)

        cgfilehandler.output file("Code Testing", "Code Testing", module info["name"Lunique runnerid psuedo code)

        print("Created Unit Test for (module_info["name"]}")

    except Exception as e

        logging error Error at %s', 'process_testing', exc_info=e)

def main(specification model location.model,name,code_to_scan):
    try:
        unique_runnerid = cgutils.runnerid()

        lst_files = cgfilestoscan.file_to_scan(specification.code_to_scan)
        threads = []

        for file in lst_files:
            thread = threading.Thread(target=process_testing, args=(file, specification, unique_runnerid, model_location,model_name))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()
        
        print("Documentation generated.")

    except Exception as e:
        logging error('Error at %s', 'main', exc_info=e)