# Using chaining
import os
from datetime import datetime
import streamlit as st
from langchain.prompts import PromptTemplate
from langchain_community.vectorstores import FAISS
from langchain_ollama import OllamaLLM
from langchain_ollama import OllamaEmbeddings
from langchain.schema import Document
from langchain_google_genai import ChatGoogleGenerativeAI
from docx import Document as dox


os.environ["GOOGLE_API_KEY"] = "AIzaSyAlpg24hVWAyD5lXZRTMYGbk7Is"
model=ChatGoogleGenerativeAI(model="gemini-1.5-flash")
ROOT_PATH =  os.getenv('ROOT_PATH')

prompt_template_first = '''
<s>[INST]
You are a researcher tasked with answering questions about an SRS document. All output must be in plain text, without any JSON formatting. Don't add explanations beyond the raw output.
Please ensure your responses are socially unbiased and positive in nature.
If you don't know the answer, please don't share false information.

Output only raw text with the following details: 
- Requirement Type: <Type of Requirement: functional/performance/security/usability/etc.>
- Requirement Description: <Provide a detailed explanation of the requirement from the document>
- Stakeholders: <List of stakeholders>
Example Output:
"Requirement Type: functional
Requirement Description: The system should allow users to log in using their email and password.
Stakeholders: user, developer, QA"

Extract the following from the document and give the output in raw text format.
Ensure that you do not truncate the response, and provide all the requirements
</INST>

SRS: {requirement}
'''


prompt_template_second = '''
<s>[INST]
You are a researcher tasked with generating gherkin based user stories and acceptance criteria from the raw text that describes a requirement and its stakeholders. 
Please use the provided raw text and extract the necessary information to generate Gherkin user stories and acceptance criteria for each stakeholder.
Format your response in raw text, and ensure that each stakeholder has corresponding gherkin user stories and acceptance criteria.

Input: {raw_text}

Output Example:
Requirement:The system shall send an order confirmation to the user through email.
Feature: Sending an order confirmation email

  Scenario: Customer receives an order confirmation email after placing an order
    Given I am a logged-in customer
    And I have successfully placed an order
    When the order is confirmed by the system
    Then I should receive an email with the order details

  Scenario: Order confirmation email contains correct information
    Given I have placed an order for "Product A"
    When I receive the order confirmation email
    Then the email should contain my order details including "Product A" and the total amount

  Scenario: Order confirmation email is sent immediately after order completion
    Given I have placed an order
    When the order is successfully processed by the system
    Then the order confirmation email should be sent immediately to my registered email address

  Scenario: System retries sending order confirmation email in case of failure
    Given I have placed an order
    When the system fails to send the order confirmation email
    Then the system should retry sending the email after a delay and notify the admin if it fails multiple times

  Scenario: Admin monitors email delivery failures
    Given I am an admin
    When the system fails to send an order confirmation email multiple times
    Then I should be notified with an alert regarding the email delivery issue

  Scenario: Third-party email service encounters failure in email delivery
    Given I am using a third-party email service
    When the service fails to deliver an email
    Then the system should log the failure and retry the delivery based on the service's guidelines


Ensure that you do not truncate the response, and provide the full user stories and acceptance criteria for all stakeholders.
</INST>
'''

def generate_raw_text(requirement):
    prompt = PromptTemplate(input_variables=["requirement"], template=prompt_template_first)
    first_chain = prompt | model  # Use the LLM chain to generate raw text
    raw_text = first_chain.invoke(requirement).content # Get raw text from the first prompt
    return raw_text

def generate_user_stories_from_raw_text(raw_text):
    prompt = PromptTemplate(input_variables=["raw_text"], template=prompt_template_second)
    second_chain = prompt | model  
    user_stories = second_chain.invoke(raw_text).content 
    return user_stories

def extract_requirements_from_docx(docx_file_path):
    document = dox(docx_file_path)
    requirements = []

    full_text = "\n".join([para.text.strip() for para in document.paragraphs if para.text.strip()])
    requirements.append(full_text)

    return requirements


def create_faiss_index(requirements, embedding):
    docs = [Document(page_content=req) for req in requirements]
    vector_store = FAISS.from_documents(docs, embedding)
    return vector_store

def retrieve_requirement(query, vector_store, k=1):
    docs = vector_store.similarity_search(query, k=k)
    return docs[0].page_content if docs else None


def process_srs_and_generate_stories(docx_file_path, output_directory):
    os.makedirs(output_directory, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file_path = os.path.join(output_directory, f"user_stories_{timestamp}.txt")

    with open(output_file_path, 'w', encoding='utf-8') as output_file:
        requirements = extract_requirements_from_docx(docx_file_path)
        embedding = OllamaEmbeddings(model="nomic-embed-text")
        faiss_index = create_faiss_index(requirements, embedding)

        for i, requirement in enumerate(requirements):
            relevant_requirement = retrieve_requirement(requirement, faiss_index)
            
            # Step 1: Generate raw text for requirement, type, stakeholders
            raw_text = generate_raw_text(relevant_requirement)
            
            # Step 2: Generate user stories from raw text output
            user_stories = generate_user_stories_from_raw_text(raw_text)

            output_file.write(f"Chunk {i}:\n")
            output_file.write(f"Raw Text: {raw_text}\n")
            output_file.write(f"Generated User Stories:\n{user_stories}\n")
            output_file.write("-" * 50 + "\n")

    return output_file_path


st.set_page_config(page_title="SRS to User Stories Generator", page_icon="📄", layout="wide")


with st.sidebar:
    st.header("SRS to User Stories Generator")
    st.subheader("Upload your SRS document (in .docx format)")


st.title("SRS to User Stories Generator 📄")
st.markdown("""
This tool allows you to upload an SRS (Software Requirements Specification) document and generates **user stories** and **acceptance criteria**.
Simply upload the document, and click the button below to generate the user stories.
""")

uploaded_file = st.file_uploader("Choose a `.docx` file", type=["docx"], label_visibility="collapsed")

if uploaded_file:
    st.success("File uploaded successfully! 🎉")

    output_directory_path = f"{ROOT_PATH}/srs/ouput"
    output_directory = st.text_input("Output Directory", output_directory_path, help="Specify the directory to save the generated file.")

    if st.button("Generate User Stories 🔄"):
        with st.spinner('Processing... Please wait.'):

            # Show a progress bar
            progress_bar = st.progress(0)
            output_file_path = process_srs_and_generate_stories(uploaded_file, output_directory)
            
            for i in range(100):
                progress_bar.progress(i + 1)  # Simulating progress during processing
            
            st.success("User stories generated successfully! 🎉")

            # Provide download link for the output file
            st.markdown("#### Download the user stories below:")
            st.download_button(
                label="Download User Stories 📥",
                data=open(output_file_path, 'rb'),
                file_name=f"user_stories_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                mime="text/plain",
                use_container_width=True
            )
else:
    st.warning("Please upload an SRS document to get started.")
