import os

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START ,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit

import src.codereview.code_review_node as codereviewnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    parallel_builder = StateGraph(codereviewnode.State)

    parallel_builder.add_node("information_gathering", codereviewnode.information_gathering)
    parallel_builder.add_node("quality", codereviewnode.quality)
    parallel_builder.add_node("coding_standards", codereviewnode.coding_standards)
    #parallel_builder.add_node("security_vulnerabilities", codereviewnode.security_vulnerabilities)
    #parallel_builder.add_node("complexity", codereviewnode.complexity)
    parallel_builder.add_node("documentation", codereviewnode.documentation)
    parallel_builder.add_node("aggregator", codereviewnode.aggregator)

    # Add edges to connect nodes
    parallel_builder.add_edge(START, "information_gathering")
    parallel_builder.add_edge("information_gathering", "quality")
    parallel_builder.add_edge("information_gathering", "coding_standards")
    #parallel_builder.add_edge("information_gathering", "security_vulnerabilities")
    #parallel_builder.add_edge("information_gathering", "complexity")
    parallel_builder.add_edge("information_gathering", "documentation")

    parallel_builder.add_edge("quality", "aggregator")
    parallel_builder.add_edge("coding_standards", "aggregator")
    #parallel_builder.add_edge("security_vulnerabilities", "aggregator")
    #parallel_builder.add_edge("complexity", "aggregator")
    parallel_builder.add_edge("documentation", "aggregator")

    parallel_builder.add_edge("aggregator", END)

    return parallel_builder
    
def execute_workflow(parallel_builder):
    parallel_workflow = parallel_builder.compile()

    code = read_file.invoke({"file_path": f"{ROOT_PATH}codereview/input/requirement.java"})
    codingstandards = read_file.invoke({"file_path": f"{ROOT_PATH}codereview/input/JavaSpringBoot_CodingStandards.md"})
    specialization = "Java"

    # Invoke
    state = parallel_workflow.invoke({"topic": "Understand the quality ,security vulnerabilities , \
                                       complexity and documentation details  about you program!",
                                       "code":code,
                                       "codingstandards":codingstandards,
                                       "specialization":specialization})
   
   
    combined_details = state["combined_details"]
    print(combined_details)
   
if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)
