import os
import uuid
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langchain_community.agent_toolkits import FileManagementToolkit

import utils.llm_invoke as llminvoke
from prompts.codereview.prompt import *

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

client = llminvoke.llm_initialize("Gemini")

# Graph state
class State(TypedDict):
    uuid: str
    topic: str
    code: str
    codingstandards: str
    specialization: str
    quality_details: str
    codingstandards_details: str
    securityvulnerabilities_details: str
    complexity_details: str
    documentation_details: str
    combined_details: str


def information_gathering(state):
    myuuid = uuid.uuid4()
    return {"uuid": str(myuuid)}

def quality(state: State):
    myuuid = state["uuid"]
    topic = state['topic']
    code = state['code']
    codingstandards = state['codingstandards']
    specialization = state['specialization']

    messages = [
        {
            "role": "system", 
            "content": code_quality_systemmessage_java
        },
        {
            "role": "user",
            "content": code_quality_usermessage_java.format(code=code,codingstandards=codingstandards)
        }
    ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    
    return {
        "quality_details": [response.choices[0].message.content],
    }


# Nodes
def coding_standards(state: State):
    myuuid = state["uuid"]
    topic = state['topic']
    code = state['code']
    codingstandards = state['codingstandards']
    specialization = state['specialization']

    messages = [
        {
            "role": "system", 
            "content": code_review_systemmessage_java
        },
        {
            "role": "user",
            "content": code_review_usermessage_java.format(code=code,codingstandards=codingstandards)
        }
    ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    
    return {
        "codingstandards_details": [response.choices[0].message.content],
    }

def security_vulnerabilities(state: State):
    myuuid = state["uuid"]
    topic = state['topic']
    code = state['code']
    codingstandards = state['codingstandards']
    specialization = state['specialization']

    messages = [
        {
            "role": "system", 
            "content": code_security_vulnerabilities_systemmessage_java
        },
        {
            "role": "user",
            "content": code_security_vulnerabilities_usermessage_java.format(code=code,codingstandards=codingstandards)
        }
    ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    
    return {
        "security_vulnerabilities": [response.choices[0].message.content],
    }

'''
def complexity(state: State):
    """ LLM call to generate complexity"""

    return {"complexity": msg.content}
'''
def documentation(state: State):
    myuuid = state["uuid"]
    topic = state['topic']
    code = state['code']
    codingstandards = state['codingstandards']
    specialization = state['specialization']

    messages = [
        {
            "role": "system", 
            "content": code_documentation_systemmessage_java
        },
        {
            "role": "user",
            "content": code_documentation_usermessage_java.format(code=code,codingstandards=codingstandards)
        }
    ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    
    return {
        "documentation_details": [response.choices[0].message.content],
    }

def aggregator(state: State):
    """Combine the code review details into a single output"""

    combined = f"Here's a quality ,security vulnerabilities , complexity and documentation details  about you program!\n\n"
    combined += f"Quality Details:\n{state['quality_details'][0]}\n\n"
    combined += f"Coding Standard Details:\n{state['codingstandards_details'][0]}\n\n"    
    #combined += f"Security Vulnerabilities Details:\n{state['securityvulnerabilities_details']}\n\n"
    # combined += f"Complexity Details:\n{state['complexity_details']}\n\n"
    combined += f"Documentation Details:\n{state['documentation_details'][0]}"

    return {"combined_details": combined}