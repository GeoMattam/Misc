import os

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START ,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit

import src.brd.brd_design_node as brddesignnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    workflow = StateGraph(brddesignnode.State)

    workflow.add_edge(START, "Information Gathering")

    workflow.add_node("Information Gathering", brddesignnode.information_gathering)
    workflow.add_node("Generate BRD",brddesignnode.generate_brd)

    workflow.add_edge("Information Gathering","Generate BRD")
    workflow.add_edge("Generate BRD", END)

    return workflow

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}

    FORMAT = read_file.invoke({"file_path": f"{ROOT_PATH}input/brd_format.md"})

    user_msg = "Generate Business Design Document"
    output = graph.invoke(
        {
            "messages": [HumanMessage(content=user_msg)],
            "brd_format": [HumanMessage(content=FORMAT)],
        }, 
        config=thread,
        stream_mode="updates")
        
    print("BRD Generated!")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)