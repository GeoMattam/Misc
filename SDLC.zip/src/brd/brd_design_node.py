import os
import uuid
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langchain_community.agent_toolkits import FileManagementToolkit

import utils.llm_invoke as llminvoke
from prompts.brd.prompt import *

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

llm_client = llminvoke.llm_initialize("Gemini")

class State(TypedDict):
    messages: Annotated[list, add_messages]
    brd: Annotated[list, add_messages]
    brd_format: Annotated[list, add_messages]
    brd_file_path: str
    uuid: str

def information_gathering(state:State):
    myuuid = uuid.uuid4()
    return {"uuid": str(myuuid)}

def generate_brd(state:State):
    brd_input = state["messages"]    
    brd_fromat = state["brd"]
    myuuid = state["uuid"]

    messages = [
        {
            "role": "system", 
            "content": brd_creation_system_message_prompt
        },
        {
            "role": "user",
            "content": f"{brd_creation_user_message_prompt.format(brd_format=brd_fromat,brd_input=brd_input)} "
        }
    ]
    
    response = llminvoke.call_llm_model(llm_client,messages)

    file_name = f"{ROOT_PATH}brd/output/design/{myuuid}/brd_draft.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

    return {"uuid": str(myuuid),
            "brd_file_path": [file_name]}