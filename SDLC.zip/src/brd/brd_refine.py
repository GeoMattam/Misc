import os

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START ,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt,Command

import src.brd.brd_refine_node as brdrefinenode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    workflow = StateGraph(brdrefinenode.State)

    workflow.add_edge(START, "Information Gathering")

    workflow.add_node("Information Gathering", brdrefinenode.information_gathering)
    workflow.add_node("Review and Feedback",brdrefinenode.reviewer)
    workflow.add_node("Human In The Loop",brdrefinenode.humanloop)
    workflow.add_node("Finalize BRD",brdrefinenode.finalize_brd)
    workflow.add_node("Update BRD",brdrefinenode.update_brd)

    workflow.add_conditional_edges(
        "Review and Feedback", 
        brdrefinenode.is_reviewed, 
        {"reviewed": "Human In The Loop",  "enhance": "Update BRD"}
    )

    workflow.add_conditional_edges(
        "Human In The Loop", 
        brdrefinenode.is_approved, 
        {"approved": "Finalize BRD",  "enhance": "Review and Feedback"}
    )
    
    workflow.add_edge("Information Gathering", "Review and Feedback")
    workflow.add_edge("Update BRD","Review and Feedback")
    workflow.add_edge("Finalize BRD",END)

    return workflow

def human_loop(feedback,graph,thread,output):
    if feedback.lower() in ("approved", "approve"):
        pass
    else:
        feedback = input("Enter your review comments:")

        # Resume the graph with the human's input
        output = graph.invoke(Command(resume=feedback), config=thread)

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}

    brd_content = read_file.invoke({"file_path": f"{ROOT_PATH}output/hld/design/intermediate/ef2ef3b3-ebd8-44df-90fc-c480ccc32c24/hld.md"})
    brd_format = read_file.invoke({"file_path": f"{ROOT_PATH}input/hld_design.md"})
    brd_additional_content = ""

    
    for output in graph.invoke(
        {
            "brd_additional_content": [HumanMessage(content=brd_additional_content)],
            "brd_content": [HumanMessage(content=brd_content)],
            "brd_format": [HumanMessage(content=brd_format)],
            "iteration" : 1,
            "max_iteration": 2,
        }, 
        config=thread, 
        stream_mode="updates"):

        for key, value in output.items():
            if key == "Review and Feedback":
                try:
                    last_message = next(iter(output.values()))["messages"][-1]
                    print(last_message)
                except:
                    print("pass")

    feedback = input("Enter your review comments:")

    # Resume the graph with the human's input
    output = graph.invoke(Command(resume=feedback), config=thread)

    human_loop(feedback,graph,thread,output)
    
    print("Completed the Manual and Automated Reviews!")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)