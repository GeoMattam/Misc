import os
import uuid
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt, Command

import utils.llm_invoke as llminvoke
from prompts.brd.prompt import *

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

llm_client = llminvoke.llm_initialize("Gemini")

class State(TypedDict):
    brd_additional_content: Annotated[list, add_messages]
    brd_content: Annotated[list, add_messages]
    brd_format: Annotated[list, add_messages]
    uuid: str
    iteration: int
    max_iteration: int
    
def information_gathering(state:State):
    myuuid = uuid.uuid4()
    return {"uuid": str(myuuid),"messages": "NA"}

def update_hld(state:State):
    brd_content = state['brd_content'][-1].content
    brd_format = state['brd_format'][-1].content
    brd_additional_content = state['brd_additional_content'][-1].content
    iteration = str(state['iteration'])
    myuuid = state["uuid"]

    messages = [
        {
            "role": "system", 
            "content": brd_refine_system_message_prompt
        },
        {
            "role": "user",
            "content": brd_refine_user_message_prompt.format(brd_format=brd_format,brd_content=brd_content,brd_additional_content=brd_additional_content)
        }
    ]
    response = llm_client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    file_name = f"{ROOT_PATH}output/hld/review/{myuuid}/hld v{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    iteration = state['iteration'] + 1

    return {
        "brd_content": [response.choices[0].message.content],
        "iteration": iteration,
        "uuid": str(myuuid)
    }   

def finalize_brd(state:State):
    myuuid = state["uuid"]
    brd_content = state['brd_content'][-1].content

    file_name = f"{ROOT_PATH}brd/output/review/{myuuid}/brd_freezed.md"
    write_file.invoke({"file_path": file_name, "text": brd_content})
    
    return {
            "iteration" : state['iteration'],
            "uuid": str(myuuid),
            "brd_content": [brd_content]
        } 

def reviewer(state:State):
    myuuid = state["uuid"]
    
    brd_content = state['brd_content'][-1].content
    brd_format = state['brd_format'][-1].content
        
    messages = [
        {
            "role": "system", 
            "content": ""
        },
        {
            "role": "user",
            "content": f"{review_critique_hld_user_message_prompt.format(srs=srs_document,hld=hld,brd_format=hld_format)}"
        }
    ]

    response = llm_client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    iteration = str(state['iteration'])
    
    file_name = f"{ROOT_PATH}output/hld/review/{myuuid}/hld_feedback v{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "messages": [response.choices[0].message.content],
        "iteration" : state['iteration'],
        "uuid": str(myuuid)
    }


def is_reviewed(state:State):
    max_iteration = state['max_iteration']
    iteration = state['iteration']
    last_message = state['messages'][-1].content
   
    if "Satisfied" in last_message.lower():
        return 'reviewed'
    elif iteration > max_iteration:
        return 'reviewed'
    else:
        return 'enhance' 

def is_approved(state:State):
    last_message = state['messages'][-1].content
    print("is_approved:",last_message)
    
    if last_message.lower() not in ("approved", "approve"):
        return "enhance"
    else:
        return "approved"

def humanloop(state:State):
    myuuid = state["uuid"]  
    feedback = interrupt("Enter the feedback:")
    
    return {"messages": [HumanMessage(feedback)],
            "uuid": str(myuuid)}