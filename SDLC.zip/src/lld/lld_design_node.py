import os
import uuid
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langchain_community.agent_toolkits import FileManagementToolkit

import utils.llm_invoke as llminvoke
from prompts.lld.lld_prompts import *

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

llm_client = llminvoke.llm_initialize("Gemini")

class State(TypedDict):
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    lld: Annotated[list, add_messages]
    lld_format: Annotated[list, add_messages]
    DocumentControl: str
    ApplicationIntroduction: str
    FunctionalDesign: str
    ModuleDesign: str
    ClassObjectDesign: str
    BehaviorDesign: str
    StructuralDesign: str
    InterfaceDesign: str
    DatabaseDesign: str
    NonFunctionalDesignAspects: str
    ErrorHandlingAndRecovery: str
    AssumptionsandLimitations: str
    Appendix:str
    uuid: str

def information_gathering(state:State):
    myuuid = state["uuid"]
    return {"uuid": str(myuuid)}


# Function to combine multiple markdown files
def combine_markdown_files(input_files, output_file):
    with open(output_file, 'w') as outfile:
        for file in input_files:
            # Check if the file exists
            if os.path.exists(file):
                with open(file, 'r') as infile:
                    content = infile.read()
                    outfile.write(content + '\n\n')  # Add new line between files
            else:
                print(f"Warning: {file} not found!")

def generate_lld(state:State):
        #lld_DocumentControl = state["DocumentControl"]
        #lld_Introduction = state["ApplicationIntroduction"]
        lld_FunctionalDesign = state["FunctionalDesign"]
        lld_ModuleDesign= state["ModuleDesign"]
        lld_ClassObjectDesign = state["ClassObjectDesign"]
        lld_BehaviorDesign = state["BehaviorDesign"]
        lld_StructuralDesign = state["StructuralDesign"]
        lld_InterfaceDesign = state["InterfaceDesign"]
        lld_DatabaseDesign = state["DatabaseDesign"]
        lld_NonFunctionalDesignAspects = state["NonFunctionalDesignAspects"]
        #lld_ErrorHandlingAndRecovery = state["ErrorHandlingAndRecovery"]
        #lld_AssumptionsandLimitations = state["AssumptionsandLimitations"]
        #lld_Appendix = state["Appendix"]
        myuuid = state["uuid"]

        # List of markdown files you want to combine
        markdown_files = [
                            #lld_DocumentControl[0],
                            #lld_Introduction[0],
                            lld_FunctionalDesign[0],
                            lld_ModuleDesign[0],
                            lld_ClassObjectDesign[0],
                            lld_BehaviorDesign[0],
                            lld_StructuralDesign[0],
                            lld_InterfaceDesign[0],
                            lld_DatabaseDesign[0],
                            lld_NonFunctionalDesignAspects[0] #,
                            #lld_ErrorHandlingAndRecovery[0],
                            #lld_AssumptionsandLimitations[0],
                            #lld_Appendix[0]
                        ]

        # Output file where combined content will be stored
        output_file = f"{ROOT_PATH}lld/output/design/{myuuid}/lld.md"

        # Combine the markdown files
        combine_markdown_files(markdown_files, output_file)

        return {"uuid": str(myuuid),
                "lld": [output_file]}

def fn_documentcontrol(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": review_lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n\
                {lld_user_message_documentcontrol_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/DocumentControl.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "DocumentControl": [file_name]
    }
    

def fn_introduction(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": review_lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n\
                {lld_user_message_introduction_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/Introduction.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "ApplicationIntroduction": [file_name]
    }
    

def fn_functional_design(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n \
                {lld_user_message_functionaldesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/FunctionalDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "FunctionalDesign": [file_name]
    }

def fn_module_design(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n \
                {lld_user_message_moduledesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/ModuleDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "ModuleDesign": [file_name]
    }

def fn_class_object_design(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n \
                {lld_user_message_classobjectdesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/ClassObjectDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "ClassObjectDesign": [file_name]
    }

def fn_behavior_design(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n \
                {lld_user_message_behaviordesign_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/BehaviorDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "BehaviorDesign": [file_name]
    }

def fn_structural_design(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n \
                {lld_user_message_structuraldesign_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/StructuralDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "StructuralDesign": [file_name]
    }

def fn_interface_design(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n \
                {lld_user_message_interfacedesign_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/InterfaceDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "InterfaceDesign": [file_name]
    }
   
    
def fn_database_design(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n \
                {lld_user_message_databasedesign_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/DatabaseDesign.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "DatabaseDesign": [file_name]
    }


def fn_non_functional_design_aspects(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n \
                {lld_user_message_nonfunctionaldesignaspects_prompt}"
            }
        ]
        
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/NonFunctionalDesignAspects.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "NonFunctionalDesignAspects": [file_name]
    }

def fn_error_handling_and_recovery(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n \
                {lld_user_message_errorhandlingandrecovery_prompt}"
            }
        ]
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/ErrorHandlingAndRecovery.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "ErrorHandlingAndRecovery": [file_name]
    }


def fn_assumptions_and_limitations(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n\
                {lld_user_message_assumptionsandlimitations_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/AssumptionsandLimitations.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "AssumptionsandLimitations": [file_name]
    }

def fn_appendix(state:State):
    srs_document = state["srs"]
    hld =state["hld"]
    myuuid = state["uuid"]

    messages = [
            {
                "role": "system", 
                "content": lld_system_message_prompt
            },
            {
                "role": "user",
                "content": f"{lld_user_message_common_prompt.format(srs=srs_document,hld=hld)} \n\
                {lld_user_message_appendix_prompt}"
            }
        ]
    
    response = llminvoke.call_llm_model(llm_client,messages)
    
    file_name = f"{ROOT_PATH}lld/output/design/{myuuid}/Appendix.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "Appendix": [file_name]
    }