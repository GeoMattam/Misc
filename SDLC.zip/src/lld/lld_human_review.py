import os

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START ,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt,Command

import src.lld.lld_human_review_node as lldhumanreviewnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    workflow = StateGraph(lldhumanreviewnode.State)

    workflow.add_edge(START, "Information Gathering")

    workflow.add_node("Information Gathering", lldhumanreviewnode.information_gathering)
    workflow.add_node("Human In The Loop",lldhumanreviewnode.humanloop)
    workflow.add_node("Update lld",lldhumanreviewnode.update_lld)
    workflow.add_node("Finalize lld",lldhumanreviewnode.finalize_lld)

    workflow.add_conditional_edges(
        "Human In The Loop", 
        lldhumanreviewnode.is_approved, 
        {"approved": "Finalize lld",  "enhance": "Update lld"}
    )
    
    workflow.add_edge("Information Gathering", "Human In The Loop")
    workflow.add_edge("Human In The Loop","Update lld")
    workflow.add_edge("Finalize lld",END)

    return workflow

def human_loop(feedback,graph,thread,output):
    if feedback.lower() in ("approved", "approve"):
        pass
    else:
        feedback = input("Enter your review comments:")

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}

    srs = read_file.invoke({"file_path": f"{ROOT_PATH}lld/input/FunctionalSpecification.md"})
    hld = read_file.invoke({"file_path": f"{ROOT_PATH}lld/input/hld.md"})
    lld = read_file.invoke({"file_path": f"{ROOT_PATH}lld/output/design/intermediate/ef2ef3b3-ebd8-44df-90fc-c480ccc32c24/lld.md"})
    lld_format = read_file.invoke({"file_path": f"{ROOT_PATH}input/lld_design.md"})

    user_msg = "Generate High Level Design Document"
    
    for output in graph.invoke(
        {
            "messages": [HumanMessage(content=user_msg)],
            "srs": [HumanMessage(content=srs)],
            "hld": [HumanMessage(content=hld)],
            "lld": [HumanMessage(content=lld)],
            "lld_format": [HumanMessage(content=lld_format)],
            "iteration" : 1,
            "max_iteration": 2,
        }, 
        config=thread, 
        stream_mode="updates"):

        for key, value in output.items():
            if key == "Review and Feedback":
                try:
                    last_message = next(iter(output.values()))["messages"][-1]
                    print(last_message)
                except:
                    print("pass")

    feedback = input("Enter your review comments:")

    # Resume the graph with the human's input
    output = graph.invoke(Command(resume=feedback), config=thread)

    human_loop(feedback,graph,thread,output)
    
    print("Completed the Manual and Automated Reviews!")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)