import os
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt,Command

import src.lld.lld_document_verification_node as llddocumentverificationnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    workflow = StateGraph(llddocumentverificationnode.State)

    workflow.add_node("Seek Clarification", llddocumentverificationnode.information_gathering)
    workflow.add_node("Human Approval", llddocumentverificationnode.human_approval)
    workflow.add_node("Clarified", llddocumentverificationnode.conclude_conversation)
    
    workflow.add_edge(START, "Seek Clarification")
    workflow.add_edge("Seek Clarification", "Human Approval")
    workflow.add_edge("Human Approval", "Clarified")
    workflow.add_edge("Clarified", END)

    workflow.add_conditional_edges(
          "Human Approval", 
          llddocumentverificationnode.is_clarified, 
          {"yes": "Clarified",  "no": "Seek Clarification"}
     )

    return workflow

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}

    SRS = read_file.invoke({"file_path": f"{ROOT_PATH}input/FunctionalSpecification.md"})
    user_msg = "\n Generate High Level Design Document"
    
    output = graph.invoke(
        {
            "messages": [HumanMessage(content=user_msg)],
            "srs": [HumanMessage(content=SRS)],
            "iteration" : 1,
            "max_iteration": 2,
        },
        config=thread)
    
    print(output)

    feedback = input("Enter your review comments:")

    # Resume the graph with the human's input
    graph.invoke(Command(resume=feedback), config=thread)

    if output and "generate_lld" in output:
        print("SRS Generated!")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)