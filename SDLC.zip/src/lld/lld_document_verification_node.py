import os
import uuid
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt, Command

import utils.llm_invoke as llminvoke
from prompts.lld.lld_prompts import *

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

class State(TypedDict):
    uuid: str
    srs:str
    clarification_messages: Annotated[list, add_messages]
    user_feedback: Annotated[list, add_messages]

def is_clarified(state:State):
    messages = state['user_feedback'][-1].content
    
    if "approved" in messages:
        return "yes"
    else:
        return "no"
        
def human_approval(state: State):

    feedback = interrupt("Enter the feedback:")

    return {"user_feedback": feedback}

def information_gathering(state:State):
    myuuid = state["uuid"]
    srs_document = state["srs"]

    messages = [
                {
                    "role": "system", 
                    "content": srs_review_system_message_prompt
                },
                {
                    "role": "user",
                    "content": f"{srs_review_user_message_prompt.format(srs=srs_document)}"
                }
    ]
    
    llm_client = llminvoke.llm_initialize("Gemini")

    response = llm_client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    return {"uuid":str(myuuid),
            "clarification_messages": [response.choices[0].message.content]}
    
def conclude_conversation(state:State):
    myuuid = state["uuid"]

    clarification_messages = state['clarification_messages'][-1].content
    file_name = f"{ROOT_PATH}lld/output/verification/{myuuid}/srs_clarification_messages.md"
    
    write_file.invoke({"file_path": file_name, "text": clarification_messages})