import os
import uuid
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt, Command

import utils.llm_invoke as llminvoke
from prompts.lld.lld_prompts import *

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

llm_client = llminvoke.llm_initialize("Gemini")

class State(TypedDict):
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    lld: Annotated[list, add_messages]
    lld_format: Annotated[list, add_messages]
    uuid: str
    iteration: int
    max_iteration: int
    
def information_gathering(state:State):
    myuuid = state["uuid"]
    return {"uuid": str(myuuid),"messages": "NA"}

def update_lld(state:State):
    lld = state['lld'][-1].content
    hld = state['hld'][-1].content
    format = state['lld_format'][-1].content
    last_message = state['messages'][-1].content
    srs = state['srs'][-1].content
    iteration = state['iteration']
    myuuid = state["uuid"]

    messages = [
        {
            "role": "system", 
            "content": review_lld_system_message_prompt
        },
        {
            "role": "user",
            "content": review_lld_user_message_prompt.format(srs=srs,lld=lld,review=last_message,format=format)
        }
    ]
    response = llm_client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    file_name = f"{ROOT_PATH}lld/output/automatedreview/{myuuid}/lld v{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "lld": [response.choices[0].message.content],
        "iteration": iteration,
        "messages": "NA",
        "uuid": str(myuuid)
    }   

def finalize_lld(state:State):
    myuuid = state["uuid"]
    lld_content = state['lld'][-1].content

    file_name = f"{ROOT_PATH}lld/output/automatedreview/{myuuid}/lld_freezed.md"
    write_file.invoke({"file_path": file_name, "text": lld_content})
    
    return {
            "messages": "NA",
            "iteration" : state['iteration'],
            "uuid": str(myuuid),
            "lld": [lld_content]
        } 

def reviewer(state:State):
    myuuid = state["uuid"]
    iteration = state['iteration'] + 1

    srs_document = state['srs'][-1].content
    hld = state['hld'][-1].content
    lld = state['lld'][-1].content
    lld_format = state['lld_format'][-1].content
        
    messages = [
        {
            "role": "system", 
            "content": review_critique_lld_system_message_prompt
        },
        {
            "role": "user",
            "content": f"{review_critique_lld_user_message_prompt.format(srs=srs_document,lld=lld,lld_format=lld_format)}"
        }
    ]

    response = llm_client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)
    
    file_name = f"{ROOT_PATH}lld/output/automatedreview/{myuuid}/lld_feedback v{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})
    
    return {
        "messages": [response.choices[0].message.content],
        "iteration" : iteration,
        "uuid": str(myuuid)
    }


def is_reviewed(state:State):
    max_iteration = state['max_iteration']
    iteration = state['iteration']
    last_message = state['messages'][-1].content
   
    if "Satisfied" in last_message.lower():
        print("Satisfied reviewed")
        return 'reviewed'    
    elif iteration > max_iteration:
        return 'reviewed'
    else:
        return 'enhance'