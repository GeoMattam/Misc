import os

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START ,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit
from langgraph.types import interrupt,Command

import src.lld.lld_review_node as lldreviewnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    workflow = StateGraph(lldreviewnode.State)

    workflow.add_edge(START, "Information Gathering")

    workflow.add_node("Information Gathering", lldreviewnode.information_gathering)
    workflow.add_node("Review and Feedback",lldreviewnode.reviewer)
    workflow.add_node("Update lld",lldreviewnode.update_lld)
    workflow.add_node("Finalize lld",lldreviewnode.finalize_lld)

    workflow.add_conditional_edges(
        "Update lld", 
        lldreviewnode.is_reviewed, 
        {"reviewed": "Finalize lld",  "enhance": "Review and Feedback"}
    )
    
    workflow.add_edge("Information Gathering", "Review and Feedback")
    workflow.add_edge("Review and Feedback","Update lld",)
    workflow.add_edge("Finalize lld",END)

    return workflow

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}

    srs = read_file.invoke({"file_path": f"{ROOT_PATH}lld/input/FunctionalSpecification.md"})
    lld = read_file.invoke({"file_path": f"{ROOT_PATH}output/lld/design/intermediate/ef2ef3b3-ebd8-44df-90fc-c480ccc32c24/lld.md"})
    hld = read_file.invoke({"file_path": f"{ROOT_PATH}lld/input/hld.md"})
    lld_format = read_file.invoke({"file_path": f"{ROOT_PATH}lld/input/lld_design.md"})

    user_msg = "Generate High Level Design Document"
    
    for output in graph.invoke(
        {
            "messages": [HumanMessage(content=user_msg)],
            "srs": [HumanMessage(content=srs)],
            "hld": [HumanMessage(content=hld)],
            "lld": [HumanMessage(content=lld)],
            "lld_format": [HumanMessage(content=lld_format)],
            "iteration" : 0,
            "max_iteration": 2,
        }, 
        config=thread, 
        stream_mode="updates"):

        for key, value in output.items():
            if key == "Review and Feedback":
                try:
                    last_message = next(iter(output.values()))["messages"][-1]
                    print(last_message)
                except:
                    print("pass")

    feedback = input("Enter your review comments:")

    # Resume the graph with the human's input
    output = graph.invoke(Command(resume=feedback), config=thread)
    
    print("Completed the Manual and Automated Reviews!")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)