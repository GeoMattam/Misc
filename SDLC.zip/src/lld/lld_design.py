import os

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START ,END
from langchain_core.messages import HumanMessage
from langchain_community.agent_toolkits import FileManagementToolkit

import src.lld.lld_design_node as llddesignnode

ROOT_PATH =  os.getenv('ROOT_PATH')

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

def initialize_workflow():

    workflow = StateGraph(llddesignnode.State)

    workflow.add_edge(START, "Information Gathering")

    workflow.add_node("Information Gathering", llddesignnode.information_gathering)
    #workflow.add_node("Document Control", llddesignnode.fn_documentcontrol)
    #workflow.add_node("Introduction", llddesignnode.fn_introduction)
    workflow.add_node("Functional Design", llddesignnode.fn_functional_design)
    workflow.add_node("Module Design", llddesignnode.fn_module_design)
    workflow.add_node("Class Object Design", llddesignnode.fn_class_object_design)
    workflow.add_node("Behavior Design", llddesignnode.fn_behavior_design)
    workflow.add_node("Structural Design", llddesignnode.fn_structural_design)
    workflow.add_node("Interface Design", llddesignnode.fn_interface_design)
    workflow.add_node("Database Design", llddesignnode.fn_database_design)
    workflow.add_node("Non Functional Design Aspects", llddesignnode.fn_non_functional_design_aspects)
    #workflow.add_node("Error Handling And Recovery", llddesignnode.fn_error_handling_and_recovery)
    #workflow.add_node("Assumptions and Limitations", llddesignnode.fn_assumptions_and_limitations)
    #workflow.add_node("Appendix Details", llddesignnode.fn_appendix)
    workflow.add_node("Generate LLD",llddesignnode.generate_lld)

    #workflow.add_edge("Information Gathering", "Document Control")    
    #workflow.add_edge("Information Gathering", "Introduction")
    workflow.add_edge("Information Gathering", "Functional Design")
    workflow.add_edge("Information Gathering", "Module Design")
    workflow.add_edge("Information Gathering", "Class Object Design")
    workflow.add_edge("Information Gathering", "Behavior Design")
    workflow.add_edge("Information Gathering", "Structural Design")
    workflow.add_edge("Information Gathering", "Interface Design")
    workflow.add_edge("Information Gathering", "Database Design")
    workflow.add_edge("Information Gathering", "Non Functional Design Aspects")
    #workflow.add_edge("Information Gathering", "Error Handling And Recovery")
    #workflow.add_edge("Information Gathering", "Assumptions and Limitations")
    #workflow.add_edge("Information Gathering", "Appendix Details")

    #workflow.add_edge("Document Control","Generate LLD")
    #workflow.add_edge("Introduction","Generate LLD")
    workflow.add_edge("Functional Design","Generate LLD")
    workflow.add_edge("Module Design","Generate LLD")
    workflow.add_edge("Class Object Design","Generate LLD")
    workflow.add_edge("Behavior Design","Generate LLD")
    workflow.add_edge("Structural Design","Generate LLD")
    workflow.add_edge("Interface Design","Generate LLD")
    workflow.add_edge("Database Design","Generate LLD")
    workflow.add_edge("Non Functional Design Aspects","Generate LLD")
    #workflow.add_edge("Error Handling And Recovery","Generate LLD")
    #workflow.add_edge("Assumptions and Limitations","Generate LLD")
    #workflow.add_edge("Appendix Details","Generate LLD")
    
    workflow.add_edge("Generate LLD", END)

    return workflow

def execute_workflow(workflow):
    memory = MemorySaver()
    graph = workflow.compile(checkpointer=memory)
    
    thread = {"configurable": {"thread_id": 1}}

    SRS = read_file.invoke({"file_path": f"{ROOT_PATH}lld/input/BRD_NGB.md"})
    HLD = read_file.invoke({"file_path": f"{ROOT_PATH}lld/input/hld.md"})
    FORMAT = read_file.invoke({"file_path": f"{ROOT_PATH}lld/input/LLD Template.md"})

    user_msg = "Generate Low Level Design Document"
    output = graph.invoke(
        {
            "messages": [HumanMessage(content=user_msg)],
            "srs": [HumanMessage(content=SRS)],
            "hld": [HumanMessage(content=HLD)],
            "lld_format": [HumanMessage(content=FORMAT)],
        }, 
        config=thread,
        stream_mode="updates")
        
    print("LLD Generated!")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)