import os
from typing import List
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from pydantic import BaseModel, Field

from tempfile import TemporaryDirectory
from langchain_community.agent_toolkits import FileManagementToolkit

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START
from langgraph.graph.message import add_messages
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph import END

import src.testcases.test_cases_review_node as testcasesreviewnode

file_stores = FileManagementToolkit(
    selected_tools=["read_file", "write_file", "list_directory"], #use current folder
).get_tools()

read_file, write_file, list_file = file_stores

ROOT_PATH =  os.getenv('ROOT_PATH')

def initialize_workflow():
    workflow = StateGraph(testcasesreviewnode.State)

    workflow.add_edge(START, "Information Gathering")

    workflow.add_node("Information Gathering", testcasesreviewnode.information_gathering)
    workflow.add_node("Review and Feedback",testcasesreviewnode.reviewer)
    workflow.add_node("Human In The Loop",testcasesreviewnode.humanloop)
    workflow.add_node("Finalize Test Cases",testcasesreviewnode.finalize_rtc)
    workflow.add_node("Update Test Cases",testcasesreviewnode.update_rtc)

    workflow.add_conditional_edges(
        "Review and Feedback", 
        testcasesreviewnode.is_reviewed, 
        {"approved": "Human In The Loop",  "enhance": "Update Test Cases"}
    )

    workflow.add_conditional_edges(
        "Human In The Loop", 
        testcasesreviewnode.is_approved, 
        {"approved": "Finalize Test Cases",  "enhance": "Review and Feedback"}
    )
    
    workflow.add_edge("Information Gathering", "Review and Feedback")
    workflow.add_edge("Update Test Cases","Review and Feedback")
    workflow.add_edge("Finalize Test Cases",END)

    return workflow


def execute_workflow(workflow):
    memory = MemorySaver()
    
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}
    SRS_path = "C:/Solutions/SDLC/includes/hld/input/FunctionalSpecification.md"
    HLD_path = "C:/Solutions/SDLC/includes/hld/output/design/fe586fc3-6410-4165-a774-7a871f0ad993/hld.md"
    
    SRS = read_file.invoke({"file_path": SRS_path})
    HLD = read_file.invoke({"file_path": HLD_path})
   
    while True:
        user = input("User (q/Q to quit): ")
        if user.lower() in ["quit", "q", "Q"]:
            print("AI: Byebye")
            break
        output = None
        
        for output in graph.invoke(
            {
                "messages": [HumanMessage(content=user)],
                "srs": [HumanMessage(content=SRS)],
                "hld": [HumanMessage(content=HLD)],
                "iteration" : 1,
                "max_iteration": 3,
            }, 
            config=thread, 
            stream_mode="updates"):
            for key, value in output.items():
                print("***** Result from Agent: ",key)
                try:
                    last_message = next(iter(output.values()))["messages"][-1]
                    last_message.pretty_print()
                except:
                    print("pass")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)