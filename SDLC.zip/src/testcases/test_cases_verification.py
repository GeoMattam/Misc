import os
from typing import List
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from pydantic import BaseModel, Field

from tempfile import TemporaryDirectory
from langchain_community.agent_toolkits import FileManagementToolkit

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START
from langgraph.graph.message import add_messages
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph import END

import src.testcases.test_cases_verification_node as testcasesverificationnode

file_stores = FileManagementToolkit(
    selected_tools=["read_file", "write_file", "list_directory"], #use current folder
).get_tools()

read_file, write_file, list_file = file_stores

ROOT_PATH =  os.getenv('ROOT_PATH')

def initialize_workflow():
    workflow = StateGraph(testcasesverificationnode.State)

    workflow.add_edge(START, "information_gathering")

    workflow.add_node("information_gathering", testcasesverificationnode.information_gathering)
    workflow.add_node("Human Approval", testcasesverificationnode.human_approval)
    workflow.add_node("Clarified", testcasesverificationnode.conclude_conversation)
    
    workflow.add_edge(START, "information_gathering")
    workflow.add_edge("information_gathering", "Human Approval")
    workflow.add_edge("Human Approval", "Clarified")
    workflow.add_edge("Clarified", END)

    workflow.add_conditional_edges(
          "Human Approval", 
          testcasesverificationnode.is_clarified, 
          {"yes": "Clarified",  "no": "information_gathering"}
     )

    return workflow

def execute_workflow(workflow):
    memory = MemorySaver()
    
    graph = workflow.compile(checkpointer=memory)
    print(graph.get_graph().draw_ascii())

    thread = {"configurable": {"thread_id": 1}}
    SRS_path = "C:/Solutions/SDLC/includes/hld/input/FunctionalSpecification.md"
    HLD_path = "C:/Solutions/SDLC/includes/hld/output/design/fe586fc3-6410-4165-a774-7a871f0ad993/hld.md"
    
    SRS = read_file.invoke({"file_path": SRS_path})
    HLD = read_file.invoke({"file_path": HLD_path})
   
    while True:
        user = input("User (q/Q to quit): ")
        if user.lower() in ["quit", "q", "Q"]:
            print("AI: Byebye")
            break
        output = None
        
        for output in graph.invoke(
            {
                "messages": [HumanMessage(content=user)],
                "srs": [HumanMessage(content=SRS)],
                "hld": [HumanMessage(content=HLD)],
                "iteration" : 1,
                "max_iteration": 3,
            }, 
            config=thread, 
            stream_mode="updates"):
            for key, value in output.items():
                print("***** Result from Agent: ",key)
                try:
                    last_message = next(iter(output.values()))["messages"][-1]
                    last_message.pretty_print()
                except:
                    print("pass")

if __name__ == "__main__":
    workflow = initialize_workflow()
    execute_workflow(workflow)