import os
import uuid
from typing import List
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from pydantic import BaseModel, Field

from langchain_community.agent_toolkits import FileManagementToolkit
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langgraph.types import interrupt, Command


from prompts.testcases.testcases_prompts import *
import utils.llm_invoke as llminvoke

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

ROOT_PATH =  os.getenv('ROOT_PATH')

class State(TypedDict):
    uuid: str
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    clarification_messages: Annotated[list, add_messages]
    user_feedback: Annotated[list, add_messages]

client = llminvoke.llm_initialize("Gemini")

def is_clarified(state:State):
    messages = state['user_feedback'][-1].content
    
    if "approved" in messages:
        return "yes"
    else:
        return "no"
        
def human_approval(state: State):

    feedback = interrupt("Enter the feedback:")

    return {"user_feedback": feedback}

def information_gathering(state):
    last_message = state['messages'][-1].content
    hld = state['hld'][-1].content
    srs = state['srs'][-1].content

    messages = [
        {
            "role": "system", 
            "content": testcase_system_message_prompt
        },
        {
            "role": "user",
            "content": testcase_user_message_prompt.format(SRS=srs,HLD=hld)
        }
    ]
    
    myuuid = uuid.uuid4()
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    return {"uuid":str(myuuid),
            "clarification_messages": [response.choices[0].message.content]}

def conclude_conversation(state:State):
    myuuid = state["uuid"]

    clarification_messages = state['clarification_messages'][-1].content
    file_name = f"{ROOT_PATH}testcases/output/verification/{myuuid}/testcases_clarification_messages.md"
    
    write_file.invoke({"file_path": file_name, "text": clarification_messages})