import os
from typing import List
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from pydantic import BaseModel, Field

from langchain_community.agent_toolkits import FileManagementToolkit
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated

from prompts.testcases.testcases_prompts import *
import utils.llm_invoke as llminvoke

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

ROOT_PATH =  os.getenv('ROOT_PATH')

class State(TypedDict):
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    rtc: Annotated[list, add_messages]
    max_iteration: int
    iteration: int

client = llminvoke.llm_initialize("Gemini")

def information_gathering(state):
    hld = state['hld'][-1].content
    last_message = state['messages'][-1].content
    srs = state['srs'][-1].content

    messages = [
        {
            "role": "system", 
            "content": testcase_system_message_prompt
        },
        {
            "role": "user",
            "content": testcase_user_message_prompt.format(SRS=srs,HLD=hld)
        }
    ]
     
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    return {"messages": [response.choices[0].message.content]}


def get_prompt_messages(messages: list, state):
    messages = []
    iteration = state['iteration']
    hld = state['hld']
    srs = state['srs']
    last_message = state['messages'][-1].content
    rtc = state.get('rtc')

    if rtc:
        messages = [
            {
                "role": "system", 
                "content": tester_system_message_prompt
            },
            {
                "role": "user",
                "content": tester_user_message_prompt.format(srs=srs,hld=hld,rtc=rtc,message=last_message)
            }
        ]
    
    else:
        messages = [
            {
                "role": "system", 
                "content": initial_tester_system_message_prompt
            },
            {
                "role": "user",
                "content": initial_tester_user_message_prompt.format(srs=srs,hld=hld)
            }
        ]
    
    return messages

def generate_rtc(state):
    
    messages = get_prompt_messages(state["messages"], state)
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)
    
    iteration = str(state['iteration'])
    file_name = f"{ROOT_PATH}testcases/output/rtc v0.{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

    return {
        "messages": [response.choices[0].message.content] ,
        "rtc": [response.choices[0].message.content],        
    }


def approver(state):
    hld = state['hld']
    srs = state['srs']
    rtc = state['rtc']

    messages = [
        {
            "role": "system", 
            "content": critique_system_message_prompt
        },
        {
            "role": "user",
            "content": critique_user_message_prompt.format(srs=srs,hld=hld,rtc=rtc)
        }
    ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    iteration = str(state['iteration'])
    file_name = f"{ROOT_PATH}testcases/output/rtc critique v0.{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

    max_iteration = state['max_iteration']
    iteration = state['iteration'] + 1
    
    return {
        "messages": [response.choices[0].message.content],
        "iteration": iteration     
    }

def is_approved(state):
    max_iteration = state['max_iteration']
    iteration = state['iteration']
   
    if iteration > max_iteration:
        return 'approved'
    else:
        return 'enhance'