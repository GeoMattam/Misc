import os
import uuid
from typing import List
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from pydantic import BaseModel, Field

from langchain_community.agent_toolkits import FileManagementToolkit
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated

from prompts.testcases.testcases_prompts import *
import utils.llm_invoke as llminvoke

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

ROOT_PATH =  os.getenv('ROOT_PATH')

class State(TypedDict):
    uuid: str
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    rtc: Annotated[list, add_messages]

client = llminvoke.llm_initialize("Gemini")

def information_gathering(state:State):
    myuuid = uuid.uuid4()
    return {"uuid": str(myuuid)}

def get_prompt_messages(messages: list, state):
    hld = state['hld']
    srs = state['srs']
    
    messages = [
        {
            "role": "system", 
            "content": initial_tester_system_message_prompt
        },
        {
            "role": "user",
            "content": initial_tester_user_message_prompt.format(srs=srs,hld=hld)
        }
    ]
    
    return messages

def generate_rtc(state):
    myuuid = state["uuid"]

    messages = get_prompt_messages(state["messages"], state)
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    file_name = f"{ROOT_PATH}testcases/output/design/{myuuid}/rtc_draft.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

    return {
        "messages": [response.choices[0].message.content] ,
        "rtc": [response.choices[0].message.content],        
    }