import os
import uuid
from typing import List
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage, HumanMessage, ToolMessage,convert_to_openai_messages
from pydantic import BaseModel, Field

from langchain_community.agent_toolkits import FileManagementToolkit
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from typing import Annotated
from langgraph.types import interrupt, Command

from prompts.testcases.testcases_prompts import *
import utils.llm_invoke as llminvoke

file_stores = FileManagementToolkit(selected_tools=["read_file", "write_file", "list_directory"],).get_tools()
read_file, write_file, list_file = file_stores

ROOT_PATH =  os.getenv('ROOT_PATH')

class State(TypedDict):
    messages: Annotated[list, add_messages]
    srs: Annotated[list, add_messages]
    hld: Annotated[list, add_messages]
    rtc: Annotated[list, add_messages]
    uuid: str
    max_iteration: int
    iteration: int

client = llminvoke.llm_initialize("Gemini")

def information_gathering(state):
    myuuid = uuid.uuid4()
    return {"uuid": str(myuuid),"messages": "NA"}

def update_rtc(state):
    myuuid = state["uuid"]
    hld = state['hld']
    srs = state['srs']
    last_message = state['messages'][-1].content
    rtc = state.get('rtc')

    messages = [
            {
                "role": "system", 
                "content": tester_system_message_prompt
            },
            {
                "role": "user",
                "content": tester_user_message_prompt.format(srs=srs,hld=hld,rtc=rtc,message=last_message)
            }
        ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)
    
    iteration = str(state['iteration'])
    file_name = f"{ROOT_PATH}testcases/output/review/{myuuid}/rtc v0.{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

    return {
        "messages": [response.choices[0].message.content] ,
        "rtc": [response.choices[0].message.content],
        "iteration" : state['iteration']     
    }

def finalize_rtc(state:State):
    myuuid = state["uuid"]
    rtc_content = state['rtc'][-1].content

    file_name = f"{ROOT_PATH}testcases/output/review/{myuuid}/rtc_freezed.md"
    write_file.invoke({"file_path": file_name, "text": rtc_content})
    
    return {
            "messages": "NA",
            "iteration" : state['iteration'],
            "uuid": str(myuuid),
            "rtc": [rtc_content]
        } 

def reviewer(state):
    myuuid = state["uuid"]
    hld = state['hld']
    srs = state['srs']
    rtc = state['rtc']

    messages = [
        {
            "role": "system", 
            "content": critique_system_message_prompt
        },
        {
            "role": "user",
            "content": critique_user_message_prompt.format(srs=srs,hld=hld,rtc=rtc)
        }
    ]
    
    response = client.chat.completions.create(
        model="gemini-1.5-flash",
        messages=messages)

    iteration = str(state['iteration'])
    file_name = f"{ROOT_PATH}testcases/output/review/{myuuid}/rtc critique v0.{str(iteration)}.md"
    write_file.invoke({"file_path": file_name, "text": response.choices[0].message.content})

    iteration = state['iteration'] + 1
    
    return {
        "messages": [response.choices[0].message.content],
        "iteration": iteration     
    }

def is_reviewed(state):
    max_iteration = state['max_iteration']
    iteration = state['iteration']
   
    if iteration > max_iteration:
        return 'approved'
    else:
        return 'enhance'

def is_approved(state:State):
    last_message = state['messages'][-1].content
    print("is_approved:",last_message)
    
    if last_message.lower() not in ("approved", "approve"):
        return "enhance"
    else:
        return "approved"
    
def humanloop(state:State):
    myuuid = state["uuid"]  
    feedback = interrupt("Enter the feedback:")
    
    return {"messages": [HumanMessage(feedback)],
            "uuid": str(myuuid),
            "iteration" : state['iteration']}