import openai
from openai import OpenAI

from utils.client import PromptHubClient
client = PromptHubClient("http://localhost:9000/")

def llm_instance(model_instance):
    if model_instance == "Gemini":
        llm_client = OpenAI(
            api_key="AIzaSyAlpg24hVWAyD5lXZRTMYGbk7IseZE5CjI",
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/"
        )
    elif model_instance == "Ollama":
        llm_client = OpenAI(
            base_url = 'http://localhost:11434/v1',
            api_key='ollama', # required, but unused
        )
    return llm_client

def validate_output_against_input(lst_dict_document_details, content_template,model_instance,model_name):
    hld =  template = ""
    params = {}
    for dict_document_details in lst_dict_document_details:
        key_name = key_value = ""
        for key,value in dict_document_details.items():
            if key =="document_name":
                key_name = value
            elif key == "file_content":
                key_value = value
        params[key_name] = key_value

    print("params:",params)

    if len(lst_dict_document_details) == 0:
        content = content_template
    else:
        content = content_template.format(**params)

    messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {
                "role": "user",
                "content": content
            }
        ]
    print("messages:",messages)
    
    llm_client  = llm_instance(model_instance)
    response = llm_client.chat.completions.create(
        model=model_name,
        n=1,
        messages=messages
    )

    #str_messages = ''.join([str(d) for d in messages])
    # result = client.upload_output(application_name="IOValidator",
    #                                 logged_in_user= "Geo",
    #                                 framework=model_instance,
    #                                 llm_model_name=model_name,
    #                                 prompt=str_messages,
    #                                 output=response.choices[0].message.content,
    #                                 refs=[])
    
    return response.choices[0].message