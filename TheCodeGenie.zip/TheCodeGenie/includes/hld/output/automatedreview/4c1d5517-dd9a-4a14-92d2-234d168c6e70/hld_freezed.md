# High-Level Design (HLD) Document: School Fee Payment System using NGB Credit Cards

## 1. Document Control
- **Document Title:** High-Level Design: School Fee Payment System using NGB Credit Cards
- **Version:** 2.0
- **Author(s):** Bard
- **Reviewed by:**  [Reviewer Name]
- **Approval Date:** November 10, 2023
- **Confidentiality Level:** Internal

## 2. Introduction
### Purpose  
This document defines the high-level architecture of the School Fee Payment System, enabling school fee payments using New Gen Bank (NGB) credit cards.  It details the architecture, key components, data flow, and deployment strategy, incorporating feedback from the initial design review.

### Scope  
This system enables schools to register with NGB, allowing parents to pay fees via Online Banking, Mobile Banking, and IVR. It supports student registration, amendment, de-registration, and fee payment conversion to Easy Payment Plans (EPP). The system will initially support up to 1000 schools and 100,000 students concurrently, scaling to higher volumes as needed.  It integrates with NGB's core banking systems, including credit card processing, GL accounting, and SMS notification services.

### Definitions, Acronyms, Abbreviations  
* **NGB:** New Gen Bank
* **EPP:** Easy Payment Plan
* **GL:** General Ledger
* **IVR:** Interactive Voice Response
* **API:** Application Programming Interface
* **OTP:** One-Time Password
* **BRD:** Business Requirement Document
* **HLD:** High-Level Design
* **UI:** User Interface
* **CRM:** Customer Relationship Management
* **TPS:** Transactions Per Second
* **UAT:** User Acceptance Testing
* **CI/CD:** Continuous Integration/Continuous Deployment
* **JWT:** JSON Web Token
* **RBAC:** Role-Based Access Control
* **JSON Schema:**  A vocabulary that allows you to annotate and validate JSON documents.
* **PCI DSS:** Payment Card Industry Data Security Standard
* **GDPR:** General Data Protection Regulation
* **CCPA:** California Consumer Privacy Act
* **AES-256:** Advanced Encryption Standard with 256-bit key
* **HTTPS:** Hypertext Transfer Protocol Secure
* **TLS:** Transport Layer Security
* **WAF:** Web Application Firewall


### References  
* Business Requirement Document (BRD) – School Fee Payment Using NGB Credit Cards (provided separately)

## 3. System Overview
### System Summary  
The system facilitates secure and convenient school fee payments using NGB credit cards across multiple channels (Online Banking, Mobile Banking, IVR).

### Key Objectives & Goals  
* Expand NGB's credit card business into the school sector.
* Provide a secure and convenient payment method for school fees, supporting at least 1000 schools and 100,000 students.
* Integrate seamlessly with existing NGB systems.
* Ensure scalability and high availability to accommodate increasing transaction volumes.
* Comply with all relevant regulations and security standards (including PCI DSS, GDPR, CCPA).

### Stakeholders  
* NGB Card Operations Team
* NGB Direct Banking
* NGB Contact Centre
* Schools
* Parents/Students

## 4. Architectural Design
### Architecture Overview  
The system adopts a microservices architecture for scalability, maintainability, and independent deployment.  Each microservice is responsible for a specific business function. Communication between microservices utilizes asynchronous messaging (Apache Kafka).  A robust API Gateway manages requests, security, and rate limiting.

### Technology Stack  
* Programming Languages: Java (Spring Boot)
* Database: PostgreSQL 14 (with replication and read replicas)
* Message Queue: Apache Kafka
* API Gateway: Zuul (with rate limiting and security features, integrated with WAF)
* Cache: Redis
* Cloud Provider: AWS (with consideration for Azure and GCP)  Specific services include: EC2, RDS, EKS, ELB, S3, CloudWatch
* SMS Gateway: Twilio
* Authentication: JWT (JSON Web Tokens)
* Security:  PCI DSS compliant encryption (AES-256) for data at rest and in transit (HTTPS with TLS 1.3)
* Logging & Monitoring:  Elasticsearch, Kibana, Filebeat, Logstash, CloudWatch


### Architecture Diagram  
**(See Component Diagram below)**

### Context Diagram
```plantuml
@startuml
!include <c4/C4_Context>

System_Ext(onlineBanking, "Online Banking System", "NGB's Online Banking Platform")
System_Ext(mobileBanking, "Mobile Banking System", "NGB's Mobile Banking Platform")
System_Ext(ivrSystem, "IVR System", "NGB's Interactive Voice Response System")
System_Ext(cardsSystem, "Cards System", "NGB's Credit Card Processing System")
System_Ext(glSystem, "GL System", "NGB's General Ledger System")
System_Ext(smsGateway, "SMS Gateway", "Twilio")
System_Boundary(c1, "School Fee Payment System") {
  System(schoolFeePayment, "School Fee Payment System", "Processes school fee payments", "Java, Spring Boot, PostgreSQL, Kafka, Redis")
}

Rel(onlineBanking, schoolFeePayment, "Payment requests, student data", "REST API v1")
Rel(mobileBanking, schoolFeePayment, "Payment requests, student data", "REST API v1")
Rel(ivrSystem, schoolFeePayment, "Payment requests, student data", "REST API v1")
Rel(cardsSystem, schoolFeePayment, "Payment authorization, transaction processing", "REST API v1")
Rel(glSystem, schoolFeePayment, "GL account postings", "REST API v1")
Rel(smsGateway, schoolFeePayment, "SMS notifications", "REST API v1")

@enduml
```

## 5. Component Design
### Component List & Description  
* **School Management Service:** Manages school registration and information. Includes validation, error handling, and data persistence.
* **Student Management Service:** Handles student registration, updates, and de-registration. Includes data validation, duplicate checks, and data persistence.
* **Payment Processing Service:** Processes fee payments, interacts with the Cards System and GL System. Implements retry mechanisms with exponential backoff and detailed error handling.
* **Reporting Service:** Generates and sends daily reports to schools. Handles report formatting, email delivery, and data aggregation.
* **Notification Service:** Sends SMS notifications using a reliable queuing system. Includes retry mechanisms and robust error handling.
* **E-Form Service:** Manages E-Forms for contact center agents. Implements security measures (preventing copy-paste, input validation) to prevent unauthorized access and data manipulation.
* **Authentication Service:** Handles user authentication and authorization using JWT. Includes token generation, validation, and revocation.
* **API Gateway:** Manages all incoming requests, handles routing, authentication, authorization, rate limiting, and security.


### Component Interaction  
**(See Component Diagram below)**  Components communicate primarily via asynchronous messaging (Kafka) and REST APIs.

### Dependency Mapping  
**(See Component Diagram below)**  Dependencies are managed through clear API contracts and asynchronous message queues.

### Component Diagram
```plantuml
@startuml
!include <c4/C4_Container>
!include <c4/C4_Component>

System_Boundary(c1, "School Fee Payment System") {
    Container(apiGateway, "API Gateway", "Zuul", "Routes requests to microservices, rate limiting, security, WAF integration")
    Container(schoolManagement, "School Management Service", "Spring Boot", "Manages school registration and information")
    Container(studentManagement, "Student Management Service", "Spring Boot", "Manages student registration and information")
    Container(paymentProcessing, "Payment Processing Service", "Spring Boot", "Processes fee payments")
    Container(reporting, "Reporting Service", "Spring Boot", "Generates and sends reports")
    Container(smsNotification, "SMS Notification Service", "Spring Boot", "Sends SMS notifications")
    Container(eForm, "E-Form Service", "Spring Boot", "Manages E-Forms")
    Container(authentication, "Authentication Service", "Spring Boot", "Handles JWT authentication")
    ContainerDb(database, "Database", "PostgreSQL", "Stores school, student, and transaction data")
    Container(cache, "Cache", "Redis", "Caches frequently accessed data")


    Component(schoolReg, schoolManagement, "School Registration", "Handles school registration requests, data validation")
    Component(studentReg, studentManagement, "Student Registration", "Handles student registration requests, data validation, duplicate checks")
    Component(paymentAuth, paymentProcessing, "Payment Authorization", "Authorizes card payments via Cards System, retry mechanism, error handling")
    Component(glPosting, paymentProcessing, "GL Posting", "Posts transactions to GL System, retry mechanism, error handling")
    Component(reportGen, reporting, "Report Generation", "Generates daily reports")
    Component(smsSender, smsNotification, "SMS Sender", "Sends SMS messages via SMS Gateway, retry mechanism, error handling")
    Component(eFormHandler, eForm, "E-Form Handler", "Processes E-Forms for Contact Center, security measures")
    Component(jwtAuth, authentication, "JWT Authentication", "Issues and validates JWT tokens")


    Rel(schoolReg, database, "Read/Write School Data", "JDBC")
    Rel(studentReg, database, "Read/Write Student Data", "JDBC")
    Rel(paymentAuth, database, "Read Transaction Data, Write Transaction Data", "JDBC")
    Rel(paymentAuth, cardsSystem, "Payment Authorization", "REST")
    Rel(glPosting, database, "Write Transaction Data", "JDBC")
    Rel(glPosting, glSystem, "GL Posting", "REST")
    Rel(reportGen, database, "Read Transaction Data", "JDBC")
    Rel(smsSender, smsGateway, "Send SMS", "REST")
    Rel(eFormHandler, database, "Read/Write Student Data", "JDBC")
    Rel(apiGateway, authentication, "Authenticate requests", "JWT")
    Rel(paymentProcessing, cache, "Read/Write Transaction Data", "Cache")
    Rel(reporting, cache, "Read Transaction Data", "Cache")

    Rel(apiGateway, schoolManagement, "School Management", "REST")
    Rel(apiGateway, studentManagement, "Student Management", "REST")
    Rel(apiGateway, paymentProcessing, "Payment Processing", "REST")
    Rel(apiGateway, reporting, "Reporting", "REST")
    Rel(apiGateway, smsNotification, "SMS Notification", "REST")
    Rel(apiGateway, eForm, "E-Form", "REST")

}
@enduml
```

## 6. Data Design
### Data Model Overview  
**(See ER Diagram below)**

### Key Entities & Relationships  
* **Customer:** (customer\_id PK,  firstName, lastName, email, phone, TIN)
* **School:** (school\_id PK, school\_name, location, account\_number, contact\_person, contact\_email, fee\_types JSON)
* **Student:** (student\_id PK, student\_name, school\_id FK(School), grade, parent\_contact, customer\_id FK(Customer))
* **FeeType:** (fee\_type\_id PK, fee\_type\_name, school\_id FK(School), amount)
* **Transaction:** (transaction\_id PK, student\_id FK(Student), fee\_type\_id FK(FeeType), transaction\_date, amount, status, reference\_id, remarks, transactionTime)
* **CreditCard:** (card\_id PK, customer\_id FK(Customer), masked\_card\_number, expiry\_date, cardType)


### Data Flow Diagram  
```plantuml
@startuml
start

:School Registration Request;
:Student Registration Request;
:Fee Payment Request;

:Data Validation;
if (Valid) then (Yes)
  :Payment Authorization;
  :GL Posting;
  :SMS Notification;
  :Report Generation;
  :Update Database;
  :Update Cache;
else (No)
  :Error Handling;
  :Send Error Notification;
endif

:Data stored in Database and Cache;

stop
@enduml
```

### ER Diagram
```plantuml
@startuml
entity Customer {
  customer_id PK
  firstName
  lastName
  email
  phone
  TIN
}

entity School {
  school_id PK
  school_name
  location
  account_number
  contact_person
  contact_email
  fee_types JSON
}

entity Student {
  student_id PK
  student_name
  school_id FK(School)
  grade
  parent_contact
  customer_id FK(Customer)
}

entity FeeType {
  fee_type_id PK
  fee_type_name
  school_id FK(School)
  amount
}

entity Transaction {
  transaction_id PK
  student_id FK(Student)
  fee_type_id FK(FeeType)
  transaction_date
  amount
  status
  reference_id
  remarks
  transactionTime
}

entity CreditCard {
  card_id PK
  customer_id FK(Customer)
  masked_card_number
  expiry_date
  cardType
}

School "1" *-- "*" Student : has
Student "1" *-- "*" Transaction : has
FeeType "1" *-- "*" Transaction : has
Transaction "1" -- "1" CreditCard : uses
Customer "1" *-- "*" Student : has
Customer "1" *-- "*" CreditCard : has


@enduml
```

## 7. Interface Design
### External Interfaces  
* **Online Banking System:** REST API v1 (JSON Schema defined for requests and responses.  Includes detailed error codes (HTTP status codes and custom error objects) and versioning using URL path parameters.  Example endpoint: `/api/v1/payments/schoolFee`).
* **Mobile Banking System:** REST API v1 (Same as Online Banking System).
* **IVR System:** REST API v1 (Same as Online Banking System.  Specific considerations for IVR interaction like error handling via voice prompts).
* **Cards System:** REST API v1 (JSON Schema defined. Includes detailed error codes and versioning.  Example endpoint: `/api/v1/cards/authorize`).
* **GL System:** REST API v1 (JSON Schema defined. Includes detailed error codes and versioning. Example endpoint: `/api/v1/gl/post`).
* **SMS Gateway:** REST API (using Twilio API, error handling implemented for failed message delivery).
* **All APIs implement robust error handling with clear HTTP status codes and detailed JSON error messages.**  JSON Schema validation is implemented for all requests and responses.

### User Interfaces (if applicable)  
* **Card Operations Team (School Registration):** Web-based UI (wireframes in Appendix).
* **Customers (Online/Mobile Banking):** Responsive UI (wireframes in Appendix).
* **Contact Center Agents (E-Form):** Web-based E-Form (wireframes in Appendix). Copy-paste restrictions implemented on sensitive fields. Input validation is enforced on all fields.
* **IVR System:** Voice-based interface with menu navigation and TTS where appropriate. Error handling is implemented with clear voice prompts.

### Protocols/Formats  
All APIs utilize REST with JSON as the data format.  JSON Schema validation will be implemented. SMS communication uses standard SMS protocols.

## 8. Deployment Architecture
### Deployment Diagram  
**(See Deployment Diagram (Detailed View) below)**

### Deployment Diagram (Detailed View)
```plantuml
@startuml
!include <c4/C4_Deployment>

System_Boundary(c1, "School Fee Payment System") {
    Deployment_Node(db, "PostgreSQL Database Cluster", "PostgreSQL 14 with replication and read replicas", "Stores school, student, and transaction data; hosted on AWS RDS")
    Deployment_Node(apiGatewayServer, "API Gateway Server", "Zuul with AWS WAF", "Routes requests to microservices, rate limiting, security; hosted on AWS EC2 (Load Balanced)")
    Deployment_Node(ms1, "Microservices Cluster", "AWS EKS (Kubernetes)", "Hosts school management, student management, payment processing, reporting, and notification services")
    Deployment_Node(cardsSystem, "Cards System", "NGB Cards Platform", "Authorizes card payments")
    Deployment_Node(glSystem, "GL System", "NGB General Ledger", "Manages general ledger postings")
    Deployment_Node(smsGateway, "SMS Gateway", "Twilio", "Sends SMS notifications")
    Deployment_Node(cache, "Redis Cache Cluster", "Redis", "Caches frequently accessed data; hosted on AWS ElastiCache")
    Deployment_Node(loadBalancer, "Load Balancer", "AWS Elastic Load Balancing", "Distributes traffic across microservices")
    Deployment_Node(monitoring, "Monitoring & Logging", "Elasticsearch, Kibana, Filebeat, Logstash, CloudWatch", "Centralized monitoring and logging")


    Rel(loadBalancer, ms1, "Load Balanced Requests", "HTTP")
    Rel(apiGatewayServer, loadBalancer, "API Requests", "HTTP")
    Rel(ms1, db, "Database interactions", "JDBC")
    Rel(ms1, cardsSystem, "Payment authorization", "REST")
    Rel(ms1, glSystem, "GL postings", "REST")
    Rel(ms1, smsGateway, "Send SMS", "REST")
    Rel(ms1, cache, "Cache interactions", "Redis protocol")
    Rel(ms1, monitoring, "Logs and Metrics", "Various protocols")


}
@enduml
```

### Environment Strategy  
* **Development:** AWS EC2 instances for each microservice, local database for development and testing.
* **Testing:** Replica of production environment on AWS, using AWS services (EC2, RDS, EKS, etc.). Full integration testing, UAT.
* **Production:** Highly available and scalable environment on AWS (EC2, RDS, EKS, ELB, etc.). Automated deployment via CI/CD pipeline. Automated testing and monitoring using CloudWatch, Elasticsearch, Kibana.

### Scalability/Resilience  
* **Horizontal Scaling:** Microservices are deployed across multiple instances (Kubernetes cluster), allowing for independent scaling.
* **Database Replication:** PostgreSQL database is replicated for high availability and data redundancy. Read replicas are added to handle report generation load.
* **Message Queues:** Kafka is used for asynchronous processing to enhance resilience and decouple components.
* **Load Balancing:** AWS Elastic Load Balancing distributes traffic across multiple microservice instances.
* **Caching:** Redis is used for caching frequently accessed data to reduce database load.
* **Monitoring and Alerting:** Amazon CloudWatch and custom dashboards are used for monitoring and alerting.
* **Disaster Recovery:** A detailed disaster recovery plan is included in a separate document (see Appendix).


## 9. Use Case Design
### Use Case Diagram
```plantuml
@startuml
left to right direction

actor "Card Operations Team"
actor "Customer"
actor "Contact Center Agent"
actor "School"

rectangle "School Fee Payment System" {
    usecase "Register School"
    usecase "Manage School Profile"
    usecase "Register Student"
    usecase "Update Student Details"
    usecase "Deregister Student"
    usecase "Pay School Fee (Online/Mobile)"
    usecase "Pay School Fee (IVR)"
    usecase "Convert to EPP"
    usecase "Generate Reports"
    usecase "View Transaction History"
    usecase "Handle Payment Failure"
    usecase "View Payment Reports by School"
    usecase "Handle EPP Rejections"
}

"Card Operations Team" -- "Register School"
"Card Operations Team" -- "Manage School Profile"

"Customer" -- "Register Student"
"Customer" -- "Update Student Details"
"Customer" -- "Deregister Student"
"Customer" -- "Pay School Fee (Online/Mobile)"
"Customer" -- "View Transaction History"

"Contact Center Agent" -- "Register Student"
"Contact Center Agent" -- "Update Student Details"
"Contact Center Agent" -- "Deregister Student"
"Contact Center Agent" -- "Pay School Fee (IVR)"

"Pay School Fee (Online/Mobile)" -- "Convert to EPP"
"Pay School Fee (IVR)" -- "Convert to EPP"

"School" <.. "Generate Reports"
"School" <.. "View Payment Reports by School"
"Pay School Fee (Online/Mobile)" <.. "Handle Payment Failure"
"Pay School Fee (IVR)" <.. "Handle Payment Failure"
"Convert to EPP" <.. "Handle EPP Rejections"

@enduml
```

## 10. Behavioral & Structural Diagrams
### Sequence Diagram: Fee Payment via Online Banking
```plantuml
@startuml
actor Customer
participant OnlineBankingUI
participant API Gateway
participant PaymentProcessingService
participant CardSystem
participant GLSystem
participant NotificationService
participant Database
participant Cache

Customer -> OnlineBankingUI: Access Fee Payment
activate OnlineBankingUI
OnlineBankingUI -> API Gateway: Payment Request
activate API Gateway
API Gateway -> Authentication Service: JWT Authentication
activate Authentication Service
Authentication Service --> API Gateway: Authentication Success/Failure
deactivate Authentication Service
API Gateway -> PaymentProcessingService: Payment Request
activate PaymentProcessingService
PaymentProcessingService -> Cache: Retrieve Student and Fee Details
activate Cache
Cache --> PaymentProcessingService: Student and Fee Details or Cache Miss
deactivate Cache
if (Cache Miss) then (Yes)
    PaymentProcessingService -> Database: Retrieve Student and Fee Details
    activate Database
    Database --> PaymentProcessingService: Student and Fee Details
    deactivate Database
    PaymentProcessingService -> Cache: Store Student and Fee Details
endif
PaymentProcessingService -> CardSystem: Authorize Transaction
activate CardSystem
CardSystem --> PaymentProcessingService: Authorization Result
deactivate CardSystem
PaymentProcessingService -> GLSystem: Debit Credit Card & GL Account
activate GLSystem
GLSystem --> PaymentProcessingService: Debit Confirmation
deactivate GLSystem
PaymentProcessingService -> Database: Update Transaction Status
activate Database
Database --> PaymentProcessingService: Transaction Updated
deactivate Database
PaymentProcessingService -> Cache: Update Cache
PaymentProcessingService -> NotificationService: Send Confirmation
activate NotificationService
NotificationService -> Customer: SMS Confirmation
deactivate NotificationService
PaymentProcessingService --> API Gateway: Transaction Success
deactivate PaymentProcessingService
API Gateway --> OnlineBankingUI: Transaction Success
deactivate API Gateway
OnlineBankingUI -> Customer: Transaction Confirmation
deactivate OnlineBankingUI
@enduml
```

### Sequence Diagram: Fee Payment via IVR
```plantuml
@startuml
actor Customer
participant IVRSystem
participant API Gateway
participant PaymentProcessingService
participant CardSystem
participant GLSystem
participant NotificationService
participant Database
participant ContactCenterAgent

Customer -> IVRSystem: Initiate IVR Payment
activate IVRSystem
IVRSystem -> Customer: Authentication Prompt (IVR)
activate Customer
Customer -> IVRSystem: IVR Authentication
deactivate Customer
IVRSystem -> API Gateway: Payment Request (IVR)
activate API Gateway
API Gateway -> Authentication Service: JWT Authentication
activate Authentication Service
Authentication Service --> API Gateway: Authentication Success/Failure
deactivate Authentication Service
API Gateway -> PaymentProcessingService: Payment Request
activate PaymentProcessingService
PaymentProcessingService -> Database: Retrieve Student and Fee Details
activate Database
Database --> PaymentProcessingService: Student and Fee Details
deactivate Database
PaymentProcessingService -> CardSystem: Authorize Transaction
activate CardSystem
CardSystem --> PaymentProcessingService: Authorization Result
deactivate CardSystem
PaymentProcessingService -> GLSystem: Debit Credit Card & GL Account
activate GLSystem
GLSystem --> PaymentProcessingService: Debit Confirmation
deactivate GLSystem
PaymentProcessingService -> Database: Update Transaction Status
activate Database
Database --> PaymentProcessingService: Transaction Updated
deactivate Database
PaymentProcessingService -> NotificationService: Send Confirmation
activate NotificationService
NotificationService -> Customer: SMS Confirmation
deactivate NotificationService
PaymentProcessingService --> API Gateway: Transaction Success
deactivate PaymentProcessingService
API Gateway --> IVRSystem: Transaction Success
deactivate API Gateway
IVRSystem -> Customer: Transaction Confirmation (IVR)
deactivate IVRSystem

@enduml
```


### Activity Diagram: Student Registration
```plantuml
@startuml
start

:Select Registration Channel;

if (Online/Mobile) then (Yes)
  :Input Student Details;
  :OTP Authentication;
  if (Success) then (Yes)
    :Validate Student ID;
    if (Valid) then (Yes)
      :Register Student (Database and Cache);
      :Send SMS Confirmation;
    else (No)
      :Error: Invalid Student ID;
      :Send Error Notification;
    endif
  else (No)
    :Error: OTP Authentication Failed;
    :Send Error Notification;
  endif
else (IVR) then (Yes)
  :IVR Authentication;
  :Agent Registers Student via E-Form;
  :Validate Student ID;
  if (Valid) then (Yes)
    :Register Student (Database and Cache);
    :Send SMS Confirmation;
  else (No)
    :Error: Invalid Student ID;
    :Send Error Notification;
  endif
endif

stop
@enduml
```

### Class Diagram: Core Components (Simplified)
(A more detailed class diagram would be in the Appendix)

```plantuml
@startuml
class School {
    -schoolId: int
    -schoolName: String
    -location: String
    -accountNumber: String
    -contactPerson: String
    -contactEmail: String
    -feeTypes: JSON
}

class Student {
    -studentId: int
    -studentName: String
    -schoolId: int
    -grade: String
    -parentContact: String
    -customerId: int
}

class FeeType {
    -feeTypeId: int
    -feeTypeName: String
    -schoolId: int
    -amount: double
}

class Transaction {
    -transactionId: int
    -studentId: int
    -feeTypeId: int
    -transactionDate: Date
    -amount: double
    -status: String
    -referenceId: String
    -remarks: String
    -transactionTime: Timestamp
}

class CreditCard {
    -cardId: int
    -customerId: int
    -maskedCardNumber: String
    -expiryDate: Date
    -cardType: String
}

School "1" *-- "*" Student
Student "1" *-- "*" Transaction
FeeType "1" *-- "*" Transaction
Transaction "1" -- "1" CreditCard
class Customer {
    -customerId: int
    -firstName: String
    -lastName: String
    -email: String
    -phone: String
    -TIN: String
}
Customer "1" *-- "*" Student
Customer "1" *-- "*" CreditCard


@enduml
```

### Package Diagram: System Organization
(A detailed package diagram showing layers, components, and interactions would be in a separate document in the Appendix)


## 11. Security Design
### Authentication & Authorization  
* Customers authenticate via Online/Mobile Banking or IVR using TIN and OTP. JWT is used for session management.  Token validation is performed by the Authentication Service and the API Gateway.
* Card Operations Team, Contact Center Agents, and internal users authenticate using secure login credentials (password with multi-factor authentication). RBAC is used for granular permission management.  Session management uses JWT.

### Encryption & Data Protection  
* Data at rest will be encrypted using AES-256.  This includes database encryption and storage of sensitive data in a secure vault (AWS KMS).
* Data in transit will be secured using HTTPS with TLS 1.3.
* Sensitive data (credit card information) will be tokenized using a robust tokenization solution, and only masked card numbers are stored in the database.  PCI DSS Level 1 compliance will be maintained throughout the system.  Data is encrypted both at rest and in transit.

### Compliance Requirements  
The system will comply with relevant data privacy regulations (GDPR, CCPA) and payment card industry standards (PCI DSS Level 1). Regular security audits and penetration testing will be conducted.  A Web Application Firewall (WAF) is used to protect against common web attacks.

## 12. Performance & Scalability
### Performance Goals  
* Transaction response time: <2 seconds (99th percentile) for Online/Mobile, <5 seconds (99th percentile) for IVR.
* Report generation time: <30 minutes after end of day.
* Transaction throughput: Target 200 TPS initially, scalable to 1000 TPS.

### Scalability Strategy  
* Microservices architecture allows for independent scaling of individual components.
* Horizontal scaling of microservices using Kubernetes on AWS EKS.
* Database replication and read replicas on AWS RDS. Database sharding will be considered for future scaling.
* Load balancing to distribute traffic effectively using AWS ELB.
* Asynchronous processing for non-critical tasks using Kafka.
* Caching to reduce database load using Redis on AWS ElastiCache.
* Performance testing will be conducted using JMeter and other performance testing tools.  Database tuning will be performed as needed.


## 13. Assumptions & Constraints
### Assumptions  
* APIs for integrating with existing NGB systems are available, stable, and well-documented.
* Reliable SMS gateway service (Twilio) is available with sufficient capacity.
* Adequate network infrastructure is available for system operations.
* Sufficient resources (compute, storage, network) are available in the AWS cloud environment.

### Constraints  
* Existing NGB systems may have limitations on throughput or API capabilities.  These limitations will be assessed and accounted for in the design and performance testing.
* Regulatory compliance requirements (PCI DSS, GDPR, CCPA) might influence design choices and necessitate specific security implementations.
* Budget and project timelines may constrain certain features or require prioritization.


## 14. Risks & Mitigation
| Risk                       | Impact          | Likelihood | Mitigation Strategy                                         | Timeline     | Responsible Party |
|----------------------------|-----------------|-------------|-------------------------------------------------------------|--------------|--------------------|
| API Integration Issues     | High             | Medium       | Thorough testing, contingency plans, fallback mechanisms, robust error handling    | 2 Months     | Integration Team   |
| Security Vulnerabilities   | Critical         | Low          | Regular security audits, penetration testing, vulnerability scanning, WAF deployment | Ongoing       | Security Team     |
| Performance Bottlenecks   | High             | Medium       | Performance testing (JMeter), capacity planning, scaling strategies, database tuning, caching | 1 Month      | Performance Team   |
| SMS Gateway Outage         | Medium           | Low          | Redundant SMS gateway, fallback notification mechanisms       | 1 Month      | Operations Team   |
| Data Loss                  | Critical         | Low          | Database backups, replication, disaster recovery plan, data encryption        | Ongoing       | DBA Team          |
| Third-Party Vendor Risks   | Medium           | Low          | Due diligence on vendors, service level agreements (SLAs), contingency plans    | Ongoing       | Procurement Team |
| Data Breach                | Critical         | Low          | Robust security measures, regular security audits, incident response plan      | Ongoing       | Security Team     |



## 15. Appendix
(Supporting diagrams (detailed class diagram, package diagram, detailed wireframes), glossary, detailed disaster recovery plan, sample JSON schemas, and API specifications would be included in a separate appendix.)

