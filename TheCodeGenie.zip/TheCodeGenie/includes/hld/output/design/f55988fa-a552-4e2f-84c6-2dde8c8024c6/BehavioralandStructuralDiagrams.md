Here's the architectural outline for the School Fee Payment System using NGB Credit Cards, presented with PlantUML diagrams.

## 10. Behavioral & Structural Diagrams

### 10.1 Sequence Diagram: Fee Payment via Online/Mobile Banking

This diagram illustrates the step-by-step interaction between the customer and various system components during a fee payment transaction initiated through Online or Mobile Banking.

```plantuml
@startuml
skinparam sequenceMessageAlign center
skinparam roundCorner 5
skinparam participantPadding 20
skinparam boxPadding 10

actor "Customer" as Customer
participant "Online/Mobile Banking UI" as UI
participant "Payment Service" as PaymentService
participant "Student Management Service" as StudentService
participant "School Management Service" as SchoolService
participant "Cards System" as CardsSystem
participant "GL System" as GLSystem
participant "SMS Gateway" as SMSGateway
database "Transaction Log DB" as TransDB

box "NGB Core Systems" #LightBlue
    participant CardsSystem
    participant GLSystem
end box

Customer -> UI: Access Fee Payment
activate UI

UI -> StudentService: Request Registered Students(CardHolderId)
activate StudentService
StudentService --> UI: List of Registered Students
deactivate StudentService

UI -> SchoolService: Request Registered Schools & Fee Types
activate SchoolService
SchoolService --> UI: List of Schools & Fee Types
deactivate SchoolService

Customer -> UI: Select Student, School, Fee Type, Card, Amount (Optional Remark)
activate UI
UI -> UI: Validate inputs (e.g., amount, registered student)
activate UI
UI --> UI: Show confirmation screen
deactivate UI

Customer -> UI: Confirm Payment
activate UI
UI -> PaymentService: Process Payment Request (details)
deactivate UI
activate PaymentService

PaymentService -> StudentService: Verify Student Registration (StudentId, SchoolId)
activate StudentService
StudentService --> PaymentService: Verification Result
deactivate StudentService

PaymentService -> CardsSystem: Debit Credit Card (Card No, Amount)
activate CardsSystem
CardsSystem --> PaymentService: Debit Confirmation / Failure
deactivate CardsSystem

alt Successful Card Debit
    PaymentService -> GLSystem: Debit GL Account (Bank's Specific GL, Amount)
    activate GLSystem
    GLSystem --> PaymentService: GL Debit Confirmation
    deactivate GLSystem

    PaymentService -> GLSystem: Credit School Account (School Acc No, Amount)
    activate GLSystem
    GLSystem --> PaymentService: School Credit Confirmation
    deactivate GLSystem

    PaymentService -> PaymentService: Log Transaction (Unique Ref ID, All Details)
    activate PaymentService
    PaymentService -> TransDB: Store Transaction Record
    activate TransDB
    TransDB --> PaymentService: Confirmation
    deactivate TransDB
    deactivate PaymentService

    PaymentService -> SMSGateway: Send Payment Confirmation SMS (Customer, Transaction ID)
    activate SMSGateway
    SMSGateway --> PaymentService: SMS Sent Confirmation
    deactivate SMSGateway

    PaymentService --> UI: Payment Success Acknowledgment (Transaction ID)
    UI --> Customer: Display Payment Success / Confirmation SMS sent
else Card Debit Failed
    PaymentService --> UI: Payment Failure (Insufficient Balance/Invalid Card)
    deactivate PaymentService
    UI --> Customer: Display Payment Failed Message
end alt

deactivate UI
@enduml
```

### 10.2 Activity Diagram: Student Registration via Online/Mobile Banking

This diagram illustrates the workflow for a customer registering a student through the online or mobile banking channels, including validation and notifications.

```plantuml
@startuml
skinparam activityBorderColor #DarkBlue
skinparam activityBackgroundColor #LightSkyBlue
skinparam activityEndColor #DarkRed
skinparam activityStartColor #DarkGreen
skinparam arrowColor #DarkBlue
skinparam shadowing false

start
partition "Customer" {
  :Access Online/Mobile Banking;
  :Navigate to Student Management;
  :Select "Register Student";
}

partition "Online/Mobile Banking System" {
  :Display Student Registration Form;
  :Request Student Details (Name, Student ID (twice), School Dropdown);
}

partition "Customer" {
  :Enter Student Name;
  :Enter Student ID (first time);
  :Re-enter Student ID (second time);
  :Select School from Dropdown;
  :Submit Registration;
}

partition "Online/Mobile Banking System" {
  if (Student ID Matches?) then (Yes)
    :Generate OTP;
    :Request OTP from OTP Service;
    :Send OTP to Customer's Registered Mobile (via SMS Gateway);
    :Display OTP Entry Field;
  else (No)
    :Show Error: "Student ID mismatch";
    stop
  endif
}

partition "Customer" {
  :Receive OTP via SMS;
  :Enter OTP;
  :Submit OTP;
}

partition "Online/Mobile Banking System" {
  :Validate OTP with OTP Service;
  if (OTP Valid?) then (Yes)
    :Call Student Management Service to Register Student;
    :Log Student Registration Event;
    :Send SMS Alert Confirmation (via SMS Gateway) to Customer;
    :Display Registration Success Message;
  else (No)
    :Show Error: "Invalid OTP";
    :Allow Re-try OTP;
  endif
}

stop
@enduml
```

### 10.3 Class Diagram: Core Entities

This diagram depicts the main classes within the system, their attributes, operations, and the relationships between them, focusing on the core business entities.

```plantuml
@startuml
skinparam classAttributeIconSize 0
skinparam classFontStyle Bold
skinparam classArrowColor #DarkBlue
skinparam classBorderColor #DarkBlue
skinparam classBackgroundColor #LightYellow

class School {
  + String schoolId
  + String name
  + String location
  + String accountNumber
  + String ngbGLAccountRef
  --
  + registerSchool()
  + updateSchoolDetails()
  + getFeeTypes()
}

class FeeType {
  + String feeTypeId
  + String name
  + String description
  --
  + createFeeType()
}

class Student {
  + String studentId
  + String name
  + String schoolId
  + String cardHolderId
  + String registrationStatus
  --
  + registerStudent()
  + amendStudent()
  + deregisterStudent()
}

class CardHolder {
  + String cardHolderId
  + String customerId
  + List<CreditCard> activeCards
  --
  + getRegisteredStudents()
  + getActiveCards()
}

class CreditCard {
  + String cardNumber
  + String cardHolderId
  + String type
  + BigDecimal currentBalance
  + BigDecimal creditLimit
  --
  + debit(amount)
}

class Transaction {
  + String transactionId
  + String studentId
  + String schoolId
  + String feeTypeId
  + String cardNumber
  + BigDecimal amount
  + Date transactionDate
  + String remark
  + String status
  + boolean isEPPConversion
  + String eppStatus
  --
  + logTransaction()
  + updateStatus()
}

class GLPosting {
  + String glPostingId
  + String transactionId
  + String accountCode
  + String description
  + BigDecimal debitAmount
  + BigDecimal creditAmount
  + Date postingDate
  --
  + createDebitEntry()
  + createCreditEntry()
}

School "1" -- "*" FeeType : has >
School "1" -- "*" Student : admits >
CardHolder "1" -- "*" Student : registers >
CardHolder "1" -- "*" CreditCard : owns >
Transaction "*" -- "1" Student : for >
Transaction "*" -- "1" School : to >
Transaction "*" -- "1" FeeType : of >
Transaction "*" -- "1" CreditCard : uses >
Transaction "1" -- "*" GLPosting : generates >

@enduml
```

### 10.4 Package Diagram: System Components

This diagram organizes the system into logical packages, showing their dependencies and high-level interactions.

```plantuml
@startuml
skinparam packageStyle rectangle
skinparam componentStyle rectangle
skinparam classArrowColor #DarkBlue
skinparam arrowColor #DarkBlue

package "External Systems" {
  component "NGB Online Banking" as OB
  component "NGB Mobile Banking" as MB
  component "NGB IVR System" as IVR
  component "NGB CRM" as CRM
  component "NGB Cards System" as CardsSys
  component "NGB GL System" as GLSys
  component "ICRS System" as ICRS
  component "SMS Gateway" as SMSGW
}

package "School Fee Payment System" {

  package "Frontend Channels" {
    [Web Application (Online Banking)] as WebApp
    [Mobile Application (Mobile Banking)] as MobileApp
    [IVR Interface Module] as IVRInt
    [Contact Center E-Form UI] as EFormUI
    [Card Operations UI] as CardOpsUI
  }

  package "Core Business Services" {
    component "School Management Service" as SchoolMgmtSvc
    component "Student Management Service" as StudentMgmtSvc
    component "Fee Payment Service" as FeePaymentSvc
    component "EPP Conversion Service" as EPPConvSvc
    component "OTP Service" as OTP
    component "Transaction Log Service" as TransLogSvc
    component "Reporting Service" as ReportSvc
    component "Audit & Compliance Service" as AuditSvc
  }

  package "Data Access Layer" {
    database "Application Database" as AppDB {
      folder "School Data" as SchoolData
      folder "Student Data" as StudentData
      folder "Transaction Data" as TransData
      folder "Configuration Data" as ConfigData
    }
  }

  package "Integration Adapters" {
    component "Cards System Adapter" as CardsAdapter
    component "GL System Adapter" as GLAdapter
    component "SMS Gateway Adapter" as SMSAdapter
    component "CRM Adapter" as CRMAdapter
    component "IVR Adapter" as IVRAdapter
    component "ICRS Adapter" as ICRSAdapter
  }

  package "Security & Utilities" {
    component "Authentication/Authorization" as Auth
    component "Notification Service" as NotifySvc
  }
}

' Channel Interactions
OB --> WebApp
MB --> MobileApp
IVR --> IVRInt
CRM --> EFormUI

' UI to Core Services
WebApp --> FeePaymentSvc
MobileApp --> FeePaymentSvc
IVRInt --> FeePaymentSvc
EFormUI --> StudentMgmtSvc
EFormUI --> EPPConvSvc
CardOpsUI --> SchoolMgmtSvc

' Core Services Dependencies
FeePaymentSvc --> StudentMgmtSvc
FeePaymentSvc --> SchoolMgmtSvc
FeePaymentSvc --> EPPConvSvc
FeePaymentSvc --> TransLogSvc
FeePaymentSvc --> CardsAdapter
FeePaymentSvc --> GLAdapter
FeePaymentSvc --> SMSAdapter
FeePaymentSvc --> Auth

StudentMgmtSvc --> OTP
StudentMgmtSvc --> SMSAdapter
StudentMgmtSvc --> CRMAdapter // For agent E-Form context
StudentMgmtSvc --> TransLogSvc

EPPConvSvc --> CardsAdapter
EPPConvSvc --> SMSAdapter
EPPConvSvc --> TransLogSvc
EPPConvSvc --> EFormUI // EPP conversion triggers E-Form generation (possibly for internal team action)

ReportSvc --> TransLogSvc
ReportSvc --> SchoolMgmtSvc
AuditSvc --> TransLogSvc

' Data Access Dependencies
SchoolMgmtSvc --> AppDB
StudentMgmtSvc --> AppDB
FeePaymentSvc --> AppDB
TransLogSvc --> AppDB

' Integration Adapters to External Systems
CardsAdapter --> CardsSys
GLAdapter --> GLSys
SMSAdapter --> SMSGW
CRMAdapter --> CRM
IVRAdapter --> IVR
ICRSAdapter --> ICRS

' Security
Auth --> AppDB // For user/role data
Auth <-- WebApp
Auth <-- MobileApp
Auth <-- IVRInt
Auth <-- EFormUI
Auth <-- CardOpsUI

' Notifications
NotifySvc --> SMSAdapter // General notification, not just payment SMS
NotifySvc --> Auth // Might use Auth for user contact details

@enduml
```