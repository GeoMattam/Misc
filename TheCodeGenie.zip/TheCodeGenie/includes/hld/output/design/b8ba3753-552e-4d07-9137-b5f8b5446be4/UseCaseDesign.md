```plantuml
@startuml
left to right direction
skinparam packageStyle rectangle
skinparam actorStyle awesome

' Actors
actor "Card Operations Team" as COT
actor "Customer" as Cust
actor "Contact Center Agent" as CCA
actor "School" as School_Receiver #DDDDDD

' External Systems (represented as actors for interaction points)
actor "Cards System" as Ext_Cards
actor "NGB GL System" as Ext_GL
actor "IVR System" as Ext_IVR #lightblue

rectangle "School Fee Payment System" {
  ' Package for managing schools and students
  package "School & Student Management" {
    usecase "Register School" as UC_RegSchool
    usecase "Manage School Fee Types" as UC_ManageFeeTypes

    usecase "Manage Student Details" as UC_ManageStudentGeneral
    usecase "Manage Student Details\nvia Online/Mobile" as UC_ManageStudentOnline
    usecase "Manage Student Details\nvia Contact Center (E-Form)" as UC_ManageStudentCC
  }

  ' Package for fee payment and Easy Payment Plan (EPP) functionalities
  package "Fee Payment & EPP" {
    usecase "Make Fee Payment" as UC_PayFeeGeneral
    usecase "Make Fee Payment\nvia Online Banking" as UC_PayOnline
    usecase "Make Fee Payment\nvia Mobile Banking" as UC_PayMobile
    usecase "Make Fee Payment\nvia IVR" as UC_PayIVR

    usecase "Convert Payment to EPP" as UC_EPPGeneral
    usecase "Convert Payment to EPP\nvia Online/Mobile" as UC_EPPOnline
    usecase "Convert Payment to EPP\nvia Contact Center (E-Form)" as UC_EPPCC

    usecase "View Payment History" as UC_ViewHistory
  }

  ' Package for core system services (included functionalities)
  package "Core System Services" {
    usecase "(Perform OTP Authentication)" as UC_OTP <<include>>
    usecase "(Perform IVR TIN Authentication)" as UC_IVR_TIN <<include>>
    usecase "(Process Fee Posting)" as UC_FeePosting <<include>>
    usecase "(Generate E-Form for EPP)" as UC_GenEForm <<include>>
    usecase "(Send SMS Notification)" as UC_SendSMS <<include>>
    usecase "Generate Daily School Report" as UC_GenReport
  }
}

' Actor-Use Case Relationships (Who performs what)
COT -- UC_RegSchool
COT -- UC_ManageFeeTypes

Cust -- UC_ManageStudentOnline
Cust -- UC_PayOnline
Cust -- UC_PayMobile
Cust -- UC_PayIVR
Cust -- UC_EPPOnline
Cust -- UC_ViewHistory

CCA -- UC_ManageStudentCC
CCA -- UC_EPPCC

' Generalization Relationships (More specific use cases extend general ones)
UC_ManageStudentOnline .up.|> UC_ManageStudentGeneral
UC_ManageStudentCC .up.|> UC_ManageStudentGeneral

UC_PayOnline .up.|> UC_PayFeeGeneral
UC_PayMobile .up.|> UC_PayFeeGeneral
UC_PayIVR .up.|> UC_PayFeeGeneral

UC_EPPOnline .up.|> UC_EPPGeneral
UC_EPPCC .up.|> UC_EPPGeneral

' Include Relationships (One use case includes the functionality of another)
UC_ManageStudentOnline ..> UC_OTP
UC_PayOnline ..> UC_OTP
UC_PayMobile ..> UC_OTP
UC_EPPOnline ..> UC_OTP

UC_PayIVR ..> UC_IVR_TIN
UC_ManageStudentCC ..> UC_IVR_TIN
UC_EPPCC ..> UC_IVR_TIN

UC_PayFeeGeneral ..> UC_FeePosting : <<include>>
UC_EPPGeneral ..> UC_GenEForm : <<include>>

UC_RegSchool ..> UC_SendSMS : <<include>>
UC_ManageStudentGeneral ..> UC_SendSMS : <<include>>
UC_PayFeeGeneral ..> UC_SendSMS : <<include>>
UC_EPPGeneral ..> UC_SendSMS : <<include>>

' Use Case to External System Relationships (Interaction/Dependency with external systems)
UC_FeePosting -- Ext_Cards : Uses
UC_FeePosting -- Ext_GL : Uses

UC_PayIVR -- Ext_IVR : Interacts with
UC_IVR_TIN -- Ext_IVR : Authenticates via

UC_GenReport -- School_Receiver : Sends Report

@enduml
```