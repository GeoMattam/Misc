The architecture for the School Fee Payment system using NGB Credit Cards will be designed as a set of interconnected services, leveraging existing NGB infrastructure where appropriate. This approach promotes modularity, scalability, and maintainability, aligning with the functional and non-functional requirements.

---

### 5. Component Design

#### 5.1 Component List & Description

The system will be composed of the following key components/modules:

1.  **Admin Portal UI:**
    *   **Description:** A web-based user interface specifically for the NGB Card Operations Team. It provides functionalities for registering new schools, managing school details, and configuring fee types.
    *   **Role:** User interface for administrative functions related to school management.

2.  **School Management Service:**
    *   **Description:** A backend service responsible for managing all school-related data. This includes school registration, retrieval, and configuration of various fee types (e.g., School Fee, Bus Fee). It handles business rules like minimum student count, operational years, and annual fee collection.
    *   **Role:** Centralized repository and business logic for school entities.

3.  **Student Management Service:**
    *   **Description:** A backend service dedicated to managing student registrations, amendments, and de-registrations. It stores student details, links them to specific schools and NGB cardholders, and ensures unique student IDs.
    *   **Role:** Centralized repository and business logic for student entities.

4.  **Payment Orchestration Service:**
    *   **Description:** The core service orchestrating the fee payment process. It validates payment eligibility (registered student, active card), presents available cards and fee types, handles user remarks, initiates the debit/credit process, and manages EPP conversion requests.
    *   **Role:** Main transaction coordinator for fee payments.

5.  **Financial Posting Service:**
    *   **Description:** A critical backend service responsible for executing financial transactions. It handles the debiting of the NGB Credit Card, debiting the appropriate NGB GL Account (Visa/MasterCard), and crediting the School Account within NGB's Core Banking System. It ensures format constraints for transaction descriptions.
    *   **Role:** Ensures accurate and atomic financial ledger updates.

6.  **EPP Conversion Service:**
    *   **Description:** A specialized service that processes requests to convert fee payments into Easy Payment Plans. It validates eligibility for EPP, checks for sufficient balance at conversion time, and integrates with the E-Form Workflow System for further processing.
    *   **Role:** Manages the lifecycle and business rules for EPP conversions.

7.  **Notification Service:**
    *   **Description:** A shared utility service responsible for sending all types of SMS notifications, including registration confirmations, transaction confirmations, EPP rejections, and alerts.
    *   **Role:** Centralized outgoing communication (SMS).

8.  **Transaction & Audit Log Service:**
    *   **Description:** A dedicated service for persisting all transaction details, registration events, and key system activities. It ensures traceability, provides historical data for reporting, and maintains unique reference IDs for each transaction.
    *   **Role:** Provides immutable audit trail and historical data.

9.  **Reporting Service:**
    *   **Description:** A batch processing service responsible for generating daily Excel reports for each registered school. It fetches data from the Transaction & Audit Log Service and facilitates email delivery.
    *   **Role:** Generates and delivers compliance and operational reports.

#### 5.2 Component Interaction

Components will primarily communicate using RESTful APIs for synchronous operations and potentially message queues for asynchronous events (e.g., notifications, logging).

*   **School Registration:**
    *   `Admin Portal UI` sends school registration data to `School Management Service`.
    *   `School Management Service` stores data and potentially triggers internal GL configuration (via `Core Banking System Adapter`).

*   **Student Management (Registration/Amendment/De-registration):**
    *   `Online Banking` / `Mobile Banking` / `Contact Center E-Form` sends student data to `Student Management Service`.
    *   `Student Management Service` interacts with `Authentication Service` for OTP validation (for Online/Mobile) and `Notification Service` for SMS alerts.
    *   `Student Management Service` ensures data persistence.

*   **Fee Payment:**
    *   `Online Banking` / `Mobile Banking` / `IVR` sends payment requests to `Payment Orchestration Service`.
    *   `Payment Orchestration Service` validates student eligibility with `Student Management Service`.
    *   `Payment Orchestration Service` interacts with `Authentication Service` for OTP/TIN validation.
    *   Upon successful validation, `Payment Orchestration Service` initiates debit on `Cards System` via `Cards System Adapter`.
    *   Concurrently, `Payment Orchestration Service` instructs `Financial Posting Service` to debit GL and credit School Accounts.
    *   `Financial Posting Service` interacts with `Core Banking System Adapter` for GL and School account updates.
    *   Both `Payment Orchestration Service` and `Financial Posting Service` log detailed transaction information to `Transaction & Audit Log Service`.
    *   `Payment Orchestration Service` triggers `Notification Service` for transaction confirmation SMS.

*   **EPP Conversion:**
    *   `Payment Orchestration Service` forwards EPP conversion requests to `EPP Conversion Service`.
    *   `EPP Conversion Service` performs balance checks (potentially via `Cards System Adapter`).
    *   `EPP Conversion Service` creates/triggers an E-Form in the `E-Form Workflow System`.
    *   `EPP Conversion Service` sends rejection notifications via `Notification Service` if conditions are not met.

*   **Reporting:**
    *   `Reporting Service` periodically queries `Transaction & Audit Log Service` for relevant data.
    *   `Reporting Service` generates Excel reports and uses an `Email Gateway` to send them.

#### 5.3 Dependency Mapping

This section outlines the major internal and external dependencies for each core component.

*   **Admin Portal UI:**
    *   **Internal:** `School Management Service` (API)
    *   **External:** Web Browser

*   **School Management Service:**
    *   **Internal:** Database
    *   **External:** `Core Banking System Adapter` (for GL Account configuration - future direct integration)

*   **Student Management Service:**
    *   **Internal:** Database, `Notification Service`
    *   **External:** `Authentication Service` (for OTP)

*   **Payment Orchestration Service:**
    *   **Internal:** `Student Management Service`, `Financial Posting Service`, `EPP Conversion Service`, `Transaction & Audit Log Service`, `Notification Service`
    *   **External:** `Cards System Adapter`, `Authentication Service`

*   **Financial Posting Service:**
    *   **Internal:** `Transaction & Audit Log Service`
    *   **External:** `Cards System Adapter`, `Core Banking System Adapter`

*   **EPP Conversion Service:**
    *   **Internal:** `Notification Service`
    *   **External:** `E-Form Workflow System`, `Cards System Adapter` (for balance checks)

*   **Notification Service:**
    *   **Internal:** None (a utility consumed by others)
    *   **External:** `SMS Gateway`

*   **Transaction & Audit Log Service:**
    *   **Internal:** Database
    *   **External:** None

*   **Reporting Service:**
    *   **Internal:** `Transaction & Audit Log Service`
    *   **External:** `Email Gateway`

*   **Cards System Adapter:**
    *   **Internal:** None (an adapter for an external system)
    *   **External:** NGB `Cards System`

*   **Core Banking System Adapter:**
    *   **Internal:** None (an adapter for an external system)
    *   **External:** NGB `Core Banking System`

*   **Authentication Service (Existing NGB System):**
    *   **Internal:** None (a shared service)
    *   **External:** NGB Identity & Access Management Systems

*   **E-Form Workflow System (Existing NGB System):**
    *   **Internal:** None (a shared service)
    *   **External:** NGB `CRM`, NGB `Workflow Engine`

#### 5.4 Component Diagram

The following UML Component Diagram illustrates the structural relationships and interactions among the system's components.

```plantuml
@startuml
!theme mars

skinparam {
    component {
        backgroundColor LightGreen
        borderColor DarkGreen
        FontColor DarkGreen
        shadowing true
    }
    database {
        backgroundColor LightBlue
        borderColor DarkBlue
        FontColor DarkBlue
        shadowing true
    }
cloud {
        backgroundColor LightGray
        borderColor DarkGray
        FontColor DarkGray
        shadowing true
    }
    queue {
        backgroundColor LightYellow
        borderColor DarkOrange
        FontColor DarkOrange
        shadowing true
    }
    interface {
        borderColor DarkRed
        FontColor DarkRed
    }
    rectangle {
        borderColor Black
        FontColor Black
        backgroundColor WhiteSmoke
    }
    ArrowColor DarkSlateGray
    ArrowFontColor DarkSlateGray
    ArrowFontSize 10
}

title School Fee Payment System - Component Diagram

rectangle "NGB School Fee Payment Solution" {

    component "Admin Portal UI" as AdminUI
    component "School Management Service" as SMSvc
    component "Student Management Service" as StdSvc
    component "Payment Orchestration Service" as PayOrchSvc
    component "Financial Posting Service" as FinPostSvc
    component "EPP Conversion Service" as EPPConvSvc
    component "Notification Service" as NotifSvc
    component "Transaction & Audit Log Service" as TxnLogSvc
    component "Reporting Service" as ReportSvc

    database "Application Database" as AppDB

    AdminUI --> SMSvc : Manages Schools
    SMSvc --> AppDB : Stores School Data
    StdSvc --> AppDB : Stores Student Data

    PayOrchSvc -up-> StdSvc : Validates Student
    PayOrchSvc -down-> FinPostSvc : Initiates Postings
    PayOrchSvc -left-> EPPConvSvc : Requests EPP Conversion
    PayOrchSvc -right-> NotifSvc : Sends SMS
    PayOrchSvc -down-> TxnLogSvc : Logs Transactions

    FinPostSvc --> TxnLogSvc : Logs Financial Postings

    EPPConvSvc -right-> NotifSvc : Sends EPP Alerts
    EPPConvSvc -up-> PayOrchSvc : EPP Result

    ReportSvc --> TxnLogSvc : Fetches Data
}

rectangle "NGB Ecosystem (Existing Systems)" {
    cloud "Online Banking" as OB
    cloud "Mobile Banking" as MB
    cloud "IVR System" as IVR
    cloud "Contact Center E-Form System" as CCEForm

    cloud "Cards System" as CardSys
    cloud "Core Banking System" as CoreBankSys
    cloud "SMS Gateway" as SMSGateway
    cloud "Email Gateway" as EmailGateway
    cloud "Authentication Service" as AuthSvc
    cloud "E-Form Workflow System" as EFormWF
    cloud "CRM" as CRM
}

OB --down--> PayOrchSvc : Payment Request
MB --down--> PayOrchSvc : Payment Request
IVR --down--> PayOrchSvc : Payment Request

OB --down--> StdSvc : Student Mgmt
MB --down--> StdSvc : Student Mgmt
CCEForm --down--> StdSvc : Student Mgmt

PayOrchSvc --right--> CardSys : Debit CC
FinPostSvc --right--> CardSys : Debit GL/CC
FinPostSvc --right--> CoreBankSys : Debit GL / Credit School

NotifSvc --right--> SMSGateway : Send SMS

ReportSvc --right--> EmailGateway : Send Reports

PayOrchSvc --right--> AuthSvc : Authenticate (OTP/TIN)
StdSvc --right--> AuthSvc : Authenticate (OTP)

EPPConvSvc --right--> EFormWF : Create/Update E-Form
EFormWF -left-> CRM : Workflow Integration

note "Includes all Card Products (Visa Conventional, Islamic, MC)" as CardsNote
CardSys .. CardsNote

note "Includes GL Accounts & School Accounts" as CoreBankNote
CoreBankSys .. CoreBankNote

@enduml
```