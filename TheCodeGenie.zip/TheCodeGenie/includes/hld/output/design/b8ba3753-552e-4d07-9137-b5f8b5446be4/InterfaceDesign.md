### 7. Interface Design

#### 7.1 User Interface

The system will expose various user interfaces tailored for different user roles and channels:

*   **Card Operations UI (Web-based):**
    *   **Purpose:** Dedicated interface for the NGB Card Operations Team to manage school registrations.
    *   **Key Screens/Flows:**
        *   **School Registration Form:** Allows input of School Name, Location, and NGB Account Number.
        *   Confirmation/Error messages post-registration.

*   **Online Banking UI (Web & Mobile Application):**
    *   **Purpose:** For NGB customers to manage student registrations, make fee payments, and view history.
    *   **Key Screens/Flows:**
        *   **Student Management:**
            *   Student Registration Form: Input Student Name, Student ID (twice for confirmation), select School (dropdown).
            *   Student Amendment/De-registration: Select existing student, modify details or de-register.
            *   OTP authentication is mandatory for these actions.
        *   **Fee Payment:**
            *   Payment Initiation: Display active NGB Credit Cards for selection, dropdowns for registered students and fee types (based on selected school). Optional 20-character remark field.
            *   Payment Confirmation: Summary of transaction details.
            *   EPP Conversion Option: Checkbox or button to initiate Easy Payment Plan conversion.
        *   **Transaction History:** View payments for the last 6 months, including details like amount, date, student, and remarks.

*   **Contact Center E-Form (Agent Application):**
    *   **Purpose:** A digital form used by Contact Center Agents to assist customers with student management.
    *   **Key Screens/Flows:**
        *   **Student Management Form:** Manual input fields for Student Name, Student ID (copy-paste restricted), School, to register, amend, or de-register students based on customer's IVR authentication and verbal instructions.
        *   Integration with CRM for E-Form workflow and record keeping.

*   **IVR System (Voice-based):**
    *   **Purpose:** An interactive voice response system for NGB customers to make fee payments.
    *   **Key Features/Flows:**
        *   **Authentication:** Via IVR TIN.
        *   **Navigation:** Voice-guided menu options for selecting students, fee types, and initiating payments.
        *   **Student Name Playback:** Optional Text-To-Speech (TTS) for confirming registered student names.
        *   **Payment Confirmation:** Voice confirmation of transaction details.
        *   OTP verification and configurable daily limits apply.
        *   For EPP conversion requests originating from IVR, an E-Form is created by the agent.

#### 7.2 External Interfaces

The School Fee Payment System (SFPS) will integrate with several key internal and external systems to fulfill its functional and non-functional requirements:

*   **Online Banking System (OBS) & Mobile Banking System (MBS):** Act as primary user-facing channels, consuming services from SFPS for student management and fee payment.
*   **IVR System:** Integrates with SFPS to facilitate voice-based fee payments and agent-assisted student management.
*   **CRM System:** Used for managing customer relationships, triggering E-Form workflows for EPP conversions, and tracking agent-assisted student management activities.
*   **Cards System:** Core banking system responsible for managing credit cards, retrieving active card details, and processing debit transactions.
*   **GL Account System:** Manages the bank's General Ledger. SFPS integrates for real-time debiting of NGB GL accounts (Visa Conventional/Islamic/MasterCard) and crediting school accounts.
*   **SMS Gateway:** Used for sending mandatory SMS alerts (OTP, registration/amendment/de-registration confirmation, payment confirmation, EPP rejection).
*   **Email System:** For receiving school registration data in Excel format from the Product Team and for automatically sending daily transaction reports in Excel format to registered schools.
*   **ICRS (IVR Customer Relationship System/Reporting System):** To update and maintain transaction records specifically originating from the IVR channel.

#### 7.3 Interface Diagrams

The following diagram illustrates the high-level system context and key interfaces between the School Fee Payment System and its interacting components, users, and external systems.

```plantuml
@startuml
!theme mars

title School Fee Payment System - System Context Diagram

actor "Card Operations Team" as OpsTeam
actor "NGB Customer" as Customer
actor "Contact Center Agent" as CCAgent
actor "Product Team" as ProdTeam
boundary "School Fee Payment System\n(SFPS)" as SFPS {
    rectangle "Core Services" {
        component "School Registration\nService" as SchoolRegSvc
        component "Student Management\nService" as StudentMgmtSvc
        component "Fee Payment\nService" as FeePaymentSvc
        component "EPP Conversion\nService" as EPPConvSvc
        component "Fee Posting\nEngine" as FeePostingEngine
        component "Reporting\nService" as ReportingSvc
    }
}

rectangle "NGB Eco-system" {
  cloud "Online Banking System\n(OBS)" as OBS
  cloud "Mobile Banking System\n(MBS)" as MBS
  cloud "IVR System" as IVRS
  database "CRM System" as CRM
  database "Cards System" as CardsSys
  database "GL Account System" as GLAccSys
  queue "SMS Gateway" as SMSGw
  queue "Email System" as EmailSys
  database "ICRS" as ICRS
}

' Human-System Interactions
OpsTeam --( SchoolRegSvc : Manage Schools (UI)
ProdTeam --> SchoolRegSvc : School Data (Excel via Email)
Customer --( OBS : Access
Customer --( MBS : Access
Customer --( IVRS : Access

' Channel-SFPS Interactions
OBS <--> FeePaymentSvc : Student Mgmt & Payment APIs
MBS <--> FeePaymentSvc : Student Mgmt & Payment APIs
IVRS --> FeePaymentSvc : Payment Requests
IVRS --> StudentMgmtSvc : Student Mgmt Requests (via agent)
CCAgent --( StudentMgmtSvc : Student Mgmt (E-Form)

' SFPS-External System Interactions
FeePaymentSvc --> SMSGw : Send OTP/Alerts
StudentMgmtSvc --> SMSGw : Send Alerts
FeePaymentSvc --> CardsSys : Debit Card Auth/Capture
FeePostingEngine --> CardsSys : Debit Card Posting
FeePostingEngine --> GLAccSys : GL Debit/Credit Posting
EPPConvSvc --> CRM : EPP Workflow Initiation (E-Form)
StudentMgmtSvc --> CRM : Student Mgmt Workflow (E-Form)
ReportingSvc --> EmailSys : Send Daily Reports (Excel)
FeePaymentSvc --> ICRS : Update IVR Transactions

' Internal SFPS Flows (simplified)
FeePaymentSvc --> EPPConvSvc : EPP Request
FeePaymentSvc --> FeePostingEngine : Initiate Posting

@enduml
```

#### 7.4 Protocols/Formats

The choice of protocols and data formats will prioritize security, performance, and interoperability within the banking ecosystem.

*   **User Interface (OBS, MBS, Card Operations UI) to SFPS Backend:**
    *   **Protocol:** HTTPS
    *   **Format:** RESTful APIs with JSON payloads.
    *   **Authentication:** OAuth2.0/OpenID Connect for customers (via OBS/MBS), internal SSO/LDAP for Card Operations Team.

*   **SFPS Backend to Core Banking Systems (Cards System, GL Account System):**
    *   **Protocols:**
        *   **SOAP/XML over HTTPS:** Common for existing enterprise banking systems, ensuring robust transaction integrity and security.
        *   **REST/JSON over HTTPS:** For newer services or modernizing integrations.
        *   **Message Queues (e.g., IBM MQ, Kafka):** For asynchronous, reliable transaction processing and status updates, especially for GL postings and card debits.
    *   **Formats:** XML (for SOAP), JSON (for REST).

*   **SFPS Backend to CRM System:**
    *   **Protocols:** REST/JSON over HTTPS for E-Form initiation and workflow management.
    *   **Formats:** JSON.

*   **SFPS Backend to SMS Gateway:**
    *   **Protocols:** REST API over HTTPS.
    *   **Formats:** JSON.

*   **SFPS Backend to Email System:**
    *   **Protocols:** SMTP for sending emails.
    *   **Formats:** Excel for attached reports (daily school reports). Incoming school registration data will also be in Excel format via email.

*   **IVR System to SFPS Backend:**
    *   **Protocols:** Could be a direct API integration (SOAP/REST over HTTPS) or mediated via an Enterprise Service Bus (ESB) for routing and transformation.
    *   **Formats:** XML or JSON, depending on the IVR platform's integration capabilities.

*   **SFPS Backend to ICRS:**
    *   **Protocols:** REST/JSON over HTTPS or potentially direct database connection (for simple updates) or file transfer (SFTP) depending on ICRS capabilities.
    *   **Formats:** JSON or Flat File.

*   **General Data Formats:**
    *   **Internal Microservices:** JSON for inter-service communication.
    *   **Logging & Auditing:** Standardized structured logging (e.g., JSON logs).