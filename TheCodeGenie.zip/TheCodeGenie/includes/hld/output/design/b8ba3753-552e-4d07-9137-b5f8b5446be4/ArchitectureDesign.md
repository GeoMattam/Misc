Here's the architectural outline for the School Fee Payment System based on the provided requirements.

---

## 4. Architectural Design

### 4.1 Architectural Overview

The NGB School Fee Payment System will be designed as a **service-oriented architecture (SOA)**, potentially leveraging **microservices** for core functionalities to ensure scalability, resilience, and maintainability. It will act as an intermediary layer, connecting various NGB digital channels (Online Banking, Mobile Banking, IVR) and internal systems (Cards System, GL, CRM) with a dedicated backend for school and student management, fee processing, and easy payment plan (EPP) conversions.

The architecture will consist of:
1.  **Channel Integration Layer**: Provides standardized APIs for various NGB digital channels, ensuring secure and consistent access to the system's functionalities. An API Gateway will serve as the single entry point.
2.  **Core Business Services**:
    *   **School & Student Management Service**: Manages the registration, amendment, and de-registration of schools and students, including the internal UI for the Card Operations Team.
    *   **Fee Payment Service**: Handles the processing of fee payments, including validation, debiting credit cards, and coordinating GL postings.
    *   **EPP Management Service**: Facilitates the conversion of fee payments into Easy Payment Plans, including validation against business rules.
    *   **Reporting Service**: Responsible for generating and dispatching daily Excel reports to registered schools.
3.  **Integration Layer**: Contains adapters and connectors to interact with existing NGB core banking systems like the Cards System, GL System, CRM, and SMS Gateway. This layer will abstract the complexities of external system communication.
4.  **Data Persistence Layer**: Securely stores all operational data, including school details, student records, fee types, and transaction logs, ensuring auditability and traceability.
5.  **Cross-Cutting Concerns**: Security (OTP, access controls), Logging, Monitoring, and Error Handling will be implemented across all layers to ensure non-functional requirements are met. Asynchronous messaging will be used for critical operations like GL postings and SMS alerts to enhance performance and reliability.

This modular approach ensures high cohesion within services and loose coupling between them, supporting real-time processing, high availability, and future enhancements.

### 4.2 Technology Stack

The system will primarily leverage the Java ecosystem, combined with robust enterprise-grade technologies to meet performance, security, and scalability requirements.

*   **Backend Language & Framework**:
    *   **Java**: Latest LTS version (e.g., Java 17/21).
    *   **Spring Boot**: For building RESTful APIs and microservices, providing rapid development and robust features.
    *   **Spring Cloud**: For microservices patterns (e.g., Service Discovery, Load Balancing, Circuit Breakers).
*   **Build Tool**:
    *   **Maven** or **Gradle**: For dependency management and project building.
*   **Database**:
    *   **PostgreSQL** or **Oracle Database**: Robust relational database for transactional data (Schools, Students, Fee Types, Transactions, EPP details).
    *   **JPA/Hibernate**: For Object-Relational Mapping (ORM).
*   **API Management**:
    *   **Spring Cloud Gateway** or **Netflix Zuul**: As an API Gateway for routing, security, and rate limiting.
*   **Messaging/Asynchronous Processing**:
    *   **Apache Kafka** or **RabbitMQ**: For asynchronous communication between services, real-time GL postings, and reliable SMS notifications.
*   **Security**:
    *   **Spring Security**: For authentication and authorization (integrating with NGB's IAM system).
    *   **JWT (JSON Web Tokens)** or **OAuth2**: For secure API access.
    *   **Internal NGB OTP Service**: Integration for multi-factor authentication.
*   **Reporting**:
    *   **Apache POI**: Java API for Microsoft Office documents, specifically for generating Excel reports.
*   **Containerization & Orchestration**:
    *   **Docker**: For containerizing applications.
    *   **Kubernetes**: For orchestrating, deploying, and scaling containerized applications.
*   **Monitoring & Logging**:
    *   **Prometheus & Grafana**: For metrics collection and visualization.
    *   **ELK Stack (Elasticsearch, Logstash, Kibana)**: For centralized logging and analysis.
*   **CI/CD**:
    *   **Jenkins**, **GitLab CI/CD**, or **Azure DevOps**: For automated build, test, and deployment pipelines.
*   **Version Control**:
    *   **Git** (e.g., GitHub Enterprise, GitLab).

### 4.3 Architecture Diagram

```plantuml
@startuml
!theme mars

skinparam {
  shadowing true
  ParticipantPadding 20
  BoxPadding 10
  RectanglePadding 10
  BorderColor #5E81AC
  BackgroundColor #ECEFF4
  FontColor #2E3440
  ArrowColor #88C0D0
  ArrowThickness 2
  RoundCorner 5
  Padding 10
}

skinparam component {
  BorderColor #81A1C1
  BackgroundColor #D8DEE9
  FontColor #3B4252
}

skinparam database {
  BorderColor #A3BE8C
  BackgroundColor #ECEFF4
  FontColor #3B4252
}

skinparam cloud {
  BorderColor #BF616A
  BackgroundColor #ECEFF4
  FontColor #3B4252
}

skinparam rectangle {
  BorderColor #B48EAD
  BackgroundColor #ECEFF4
  FontColor #3B4252
}

skinparam actor {
  BorderColor #BF616A
  FontColor #BF616A
}

title NGB School Fee Payment System - Component Architecture

rectangle "External NGB Channels" {
  component "Online Banking App" as OB
  component "Mobile Banking App" as MB
  component "IVR System" as IVR_SYS
  component "Contact Center E-Form" as EFORM
}

cloud "API Gateway" as APIGW

rectangle "NGB School Fee Payment Platform" {

  rectangle "Application Services" as AppServices {
    component "School & Student\nManagement Service" as SSMS
    component "Fee Payment Service" as FPS
    component "EPP Management Service" as EPPS
    component "Reporting Service" as RS
  }

  rectangle "Core Data" {
    database "Application Database\n(PostgreSQL/Oracle)" as DB {
      folder "School Data"
      folder "Student Data"
      folder "Fee Types"
      folder "Transaction Logs"
      folder "EPP Plans"
    }
  }

  rectangle "Integration Adapters" as Integration {
    component "Cards System Adapter" as CSA
    component "GL System Adapter" as GLSA
    component "SMS Gateway Adapter" as SMSA
    component "CRM System Adapter" as CRMA
    component "NGB OTP Service Adapter" as OTPA
  }
}

rectangle "NGB Core Systems" {
  component "Cards System" as CS_EXT
  component "NGB GL System" as GL_EXT
  component "NGB CRM System" as CRM_EXT
}

rectangle "External Entities" {
  component "SMS Gateway" as SMS_EXT
  rectangle "Registered Schools" as SCHOOLS_EXT
}

' Channel Interactions'
OB --> APIGW : Fee Payment / Student Mgt Request
MB --> APIGW : Fee Payment / Student Mgt Request
IVR_SYS --> APIGW : IVR Payment / Student Mgt Request
EFORM --> APIGW : Student Mgt / EPP Request

' API Gateway to Services'
APIGW --> SSMS : Manage Schools/Students
APIGW --> FPS : Process Fee Payments
APIGW --> EPPS : Manage EPP Conversions

' Internal Service Interactions'
SSMS --> DB : CRUD School/Student Data
FPS --> DB : Store Transactions / Retrieve Student Data
EPPS --> DB : Store EPP Plans / Retrieve Transactions
RS --> DB : Retrieve Transaction/School Data

FPS --> CSA : Debit Card Request
CSA --> CS_EXT : Debit Request / Card Info

FPS --> GLSA : GL Posting Request (Debit/Credit)
GLSA --> GL_EXT : GL Posting

SSMS --> OTPA : OTP Generation/Validation
FPS --> OTPA : OTP Generation/Validation
OTPA --> SMS_EXT : Send OTP

SMSA --> SMS_EXT : Send SMS Notification
FPS --> SMSA : Transaction Confirmation
SSMS --> SMSA : Registration/Amendment Confirmation
EPPS --> SMSA : EPP Status Notification

EFORM --> CRMA : Agent Data Entry / CRM Context
CRMA --> CRM_EXT : Customer/Student Lookup

RS --> SCHOOLS_EXT : Email Excel Reports

@enduml
```

### 4.4 Context Diagram

```plantuml
@startuml
!theme mars

skinparam {
  shadowing true
  ParticipantPadding 20
  BoxPadding 10
  RectanglePadding 10
  BorderColor #5E81AC
  BackgroundColor #ECEFF4
  FontColor #2E3440
  ArrowColor #88C0D0
  ArrowThickness 2
  RoundCorner 5
  Padding 10
}

skinparam system {
  BorderColor #81A1C1
  BackgroundColor #D8DEE9
  FontColor #3B4252
}

skinparam actor {
  BorderColor #BF616A
  FontColor #BF616A
}

skinparam system_ext {
  BorderColor #A3BE8C
  BackgroundColor #ECEFF4
  FontColor #3B4252
}

title NGB School Fee Payment System - Context Diagram

actor "NGB Cardholder" as Cardholder
actor "Card Operations Team" as CardOps
actor "Contact Center Agent" as CCAgent

system "NGB School Fee Payment Platform" as System {
  ' The central system is represented as a single block
}

system_ext "NGB Online Banking System" as OB_Sys
system_ext "NGB Mobile Banking System" as MB_Sys
system_ext "NGB IVR System" as IVR_Sys
system_ext "NGB Cards System" as Cards_Sys
system_ext "NGB General Ledger (GL) System" as GL_Sys
system_ext "NGB CRM System" as CRM_Sys
system_ext "SMS Gateway" as SMS_Gateway
system_ext "SMTP Server (for Reporting)" as SMTP_Server

rectangle "Registered Schools" as Schools

Cardholder --down--> OB_Sys : Access Payment Options
Cardholder --down--> MB_Sys : Access Payment Options
Cardholder --down--> IVR_Sys : Voice-based Transactions

CardOps --> System : School Registration Data (via UI)

CCAgent --> System : Student Management/EPP (via E-Form/IVR)
CCAgent --> CRM_Sys : Customer Authentication/Context

OB_Sys --right--> System : Student Mgt / Fee Payment Request
MB_Sys --right--> System : Student Mgt / Fee Payment Request
IVR_Sys --right--> System : Student Mgt / Fee Payment Request

System --right--> Cards_Sys : Credit Card Debit Request
Cards_Sys --left--> System : Debit Confirmation

System --right--> GL_Sys : GL Posting Request (Debit/Credit)
GL_Sys --left--> System : Posting Confirmation

System --down--> SMS_Gateway : Transaction/Notification SMS
SMS_Gateway --up--> System : SMS Delivery Status

System --right--> CRM_Sys : Student Registration Sync (Optional)
CRM_Sys --left--> System : Customer Info (for E-Form)

System --down--> SMTP_Server : Daily Excel Reports
SMTP_Server --right--> Schools : Email Excel Reports

@enduml
```