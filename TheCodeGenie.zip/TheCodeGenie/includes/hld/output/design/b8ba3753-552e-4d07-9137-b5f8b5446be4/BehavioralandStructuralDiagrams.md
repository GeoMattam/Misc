## 10. Behavioral & Structural Diagrams

### 10.1 Sequence Diagram: Fee Payment via Online/Mobile Banking

This sequence diagram illustrates the typical flow for a customer making a school fee payment using Online or Mobile Banking, including the required validations and integrations.

```plantuml
@startuml
skinparam handwritten false
skinparam participant {
    BorderColor RoyalBlue
    BackgroundColor AliceBlue
    ArrowColor DarkSlateGrey
}
skinparam actor {
    BorderColor DarkGreen
    BackgroundColor LightGreen
}
skinparam box {
    BorderColor MidnightBlue
    BackgroundColor LightSteelBlue
}

actor Customer
participant "Online/Mobile Banking App" as UI
participant "NGB School Fee Payment System" as NGBSystem
participant "NGB Cards System" as CardsSystem
participant "NGB GL System" as GLSystem
participant "SMS Gateway" as SMSGateway

box "NGB Bank Internal Systems"
    NGBSystem -[hidden]-> CardsSystem
    CardsSystem -[hidden]-> GLSystem
end box

Customer -> UI: Access Fee Payment
activate UI
UI -> NGBSystem: Request Registered Students/Schools (for Customer)
activate NGBSystem
NGBSystem --> UI: List of Students, Schools, Fee Types, Active Cards
deactivate NGBSystem

Customer -> UI: Select Student, School, Fee Type, Amount, Card, (Optional) Remark
activate UI
UI -> UI: Display Payment Summary
Customer -> UI: Confirm Payment

UI -> NGBSystem: Initiate Payment Request (with OTP)
activate NGBSystem
NGBSystem -> NGBSystem: Validate Input Data
NGBSystem -> NGBSystem: Perform OTP Authentication
alt OTP Validated
    NGBSystem -> CardsSystem: Verify Card Status & Balance
    activate CardsSystem
    CardsSystem --> NGBSystem: Card Status & Available Balance
    deactivate CardsSystem

    alt Sufficient Balance & Valid Card
        NGBSystem -> CardsSystem: Debit Credit Card (Amount, Desc: max 40 chars)
        activate CardsSystem
        CardsSystem --> NGBSystem: Debit Confirmation (Txn Ref ID)
        deactivate CardsSystem

        NGBSystem -> GLSystem: Post Debit GL Account (Visa/MC)
        activate GLSystem
        GLSystem --> NGBSystem: GL Debit Confirmation
        deactivate GLSystem

        NGBSystem -> GLSystem: Post Credit School Account
        activate GLSystem
        GLSystem --> NGBSystem: School Credit Confirmation
        deactivate GLSystem

        NGBSystem -> NGBSystem: Log Transaction (Unique Ref ID, All Details)
        NGBSystem -> SMSGateway: Send Payment Confirmation SMS
        activate SMSGateway
        SMSGateway --> NGBSystem: SMS Sent Ack
        deactivate SMSGateway
        NGBSystem --> UI: Payment Success Acknowledgment
        deactivate NGBSystem
        UI --> Customer: Display Success Message & Txn Ref ID
        deactivate UI
    else Insufficient Balance or Invalid Card
        CardsSystem --> NGBSystem: Payment Rejection
        deactivate CardsSystem
        NGBSystem --> UI: Payment Failure (Insufficient Balance/Invalid Card)
        deactivate NGBSystem
        UI --> Customer: Display Error Message
        deactivate UI
    end alt
else OTP Invalid
    NGBSystem --> UI: OTP Validation Failed
    deactivate NGBSystem
    UI --> Customer: Display OTP Error
    deactivate UI
end alt

@enduml
```

### 10.2 Activity Diagram: Student Registration/Amendment/De-registration

This activity diagram illustrates the workflow for managing student registrations, amendments, and de-registrations, covering both online/mobile banking and contact center channels.

```plantuml
@startuml
skinparam activity {
    BorderColor DarkBlue
    BackgroundColor LightBlue
    ArrowColor Black
}
skinparam note {
    BorderColor DarkGreen
    BackgroundColor LightGreen
}

start
:Customer/Agent initiates Student Management;

if (Channel is Online/Mobile Banking) then (Online/Mobile)
    :Customer logs in;
    :Authenticate User (OTP Mandatory);
    note right: SMS for registration/amendment/de-registration
    if (Authentication Successful) then (Authenticated)
        :Customer inputs Student Name, Student ID (twice), Select School (Dropdown);
        note right: Student ID must be entered twice and match
        if (Student IDs Match) then (IDs Match)
            :Submit request to NGB System;
            :NGB System processes Student Registration / Amendment / De-registration;
            :Send SMS Alert for confirmation;
        else (IDs Mismatch)
            :Display Error: Student IDs do not match;
            stop
        endif
    else (Authentication Failed)
        :Display Error: OTP Invalid;
        stop
    endif
else (Contact Center - E-Form)
    :Customer calls Contact Center;
    :Authenticate via IVR TIN;
    if (Authentication Successful) then (Authenticated)
        :Agent accesses E-Form;
        :Agent manually inputs Student Name, Student ID, Select School;
        note right: Restrict copy-paste on Student ID
        :NGB System processes Student Registration / Amendment / De-registration;
        :Send SMS Alert post-processing;
    else (Authentication Failed)
        :Agent informs Customer: IVR TIN Authentication Failed;
        stop
    endif
endif

:Log Student Management Activity;
end
@enduml
```

### 10.3 Class Diagram: Core Domain Model

This class diagram illustrates the main entities within the NGB School Fee Payment System, their attributes, and relationships.

```plantuml
@startuml
skinparam class {
    BorderColor DarkSlateGrey
    BackgroundColor LightYellow
    ArrowColor DarkSlateGrey
}
hide empty members

class School {
    - schoolId: String
    - name: String
    - location: String
    - ngbAccountNumber: String
    - ngbGlAccount: String
    - minEnrolledStudents: int
    - operationalYears: int
    - minAnnualFeeCollection: double
    --
    + registerSchool()
    + updateSchoolDetails()
}

class FeeType {
    - feeTypeId: String
    - name: String
    - description: String
    --
    + createFeeType()
}

class Customer {
    - customerId: String
    - name: String
    - isActiveCreditCardHolder: boolean
    --
    + authenticate()
}

class CreditCard {
    - cardNumber: String
    - customerId: String
    - expiryDate: Date
    - balance: double
    - status: String // Active, Inactive, Blocked
    --
    + debitCard(amount: double)
    + checkBalance(): double
}

class Student {
    - studentId: String
    - name: String
    - registeredByCustomerId: String
    - schoolId: String
    - status: String // Registered, De-registered
    --
    + registerStudent()
    + amendStudentDetails()
    + deRegisterStudent()
}

class Transaction {
    - transactionId: String
    - referenceId: String // Unique for each txn
    - customerId: String
    - studentId: String
    - schoolId: String
    - feeTypeId: String
    - cardNumber: String
    - amount: double
    - transactionDate: Date
    - remark: String (max 20 chars)
    - status: String // Success, Failed, Pending
    - isEPPConverted: boolean
    --
    + initiatePayment()
    + postTransaction()
    + logTransaction()
}

class EPPRequest {
    - eppRequestId: String
    - transactionId: String
    - originalAmount: double
    - conversionDate: Date
    - status: String // Pending, Approved, Rejected
    - rejectionReason: String
    --
    + convertToEPP()
}

class SMSNotification {
    - notificationId: String
    - recipientPhoneNumber: String
    - message: String
    - timestamp: Date
    - type: String // Confirmation, Alert, Error
    --
    + sendSMS()
}

class Report {
    - reportId: String
    - schoolId: String
    - generationDate: Date
    - type: String // Daily School Report
    - filePath: String
    --
    + generateReport()
    + emailReport()
}

School "1" -- "1..*" FeeType : has >
Customer "1" -- "0..*" Student : registers >
Customer "1" -- "1..*" CreditCard : owns >
Student "1" -- "1" School : belongs to >
Transaction "1" -- "1" Customer : initiated by >
Transaction "1" -- "1" Student : for >
Transaction "1" -- "1" School : to >
Transaction "1" -- "1" FeeType : type >
Transaction "1" -- "1" CreditCard : uses >
Transaction "1" -- "0..1" EPPRequest : can convert to >
SMSNotification "0..*" -- "1" Transaction : related to >
SMSNotification "0..*" -- "1" Student : related to >
Report "0..*" -- "1" School : for >

@enduml
```

### 10.4 Package Diagram: System Architecture Overview

This package diagram provides a high-level overview of the system's structure, grouping related components and illustrating dependencies between them and external systems.

```plantuml
@startuml
skinparam package {
    BorderColor DarkBlue
    BackgroundColor LightCyan
    ArrowColor Black
}
skinparam component {
    BorderColor Teal
    BackgroundColor LightYellow
    ArrowColor DarkGreen
}
skinparam rectangle {
    BorderColor DarkRed
    BackgroundColor LightCoral
}

' High-level packages representing logical modules
package "User Channels" as Channels {
    component "Online Banking UI" as OnlineBanking
    component "Mobile Banking UI" as MobileBanking
    component "Contact Center E-Form" as EForm
    component "IVR System Interface" as IVR
}

package "Core Business Logic" as CoreServices {
    component "School Management Service" as SchoolSvc
    component "Student Management Service" as StudentSvc
    component "Fee Payment Service" as PaymentSvc
    component "EPP Conversion Service" as EPPSvc
    component "Reporting Service" as ReportingSvc
    component "Notification Service" as NotificationSvc
    component "Audit & Logging Service" as AuditSvc
}

package "Integration Adapters" as Adapters {
    component "Cards System Adapter" as CardsAdapter
    component "GL System Adapter" as GLAdapter
    component "CRM Adapter" as CRMAdapter
    component "SMS Gateway Adapter" as SMSAdapter
    component "IVR System Adapter" as IVRAdapter
    component "ICRS System Adapter" as ICRSAdapter
}

' External Systems
rectangle "External Systems" {
    component "NGB Cards System" as CardsSystemExternal
    component "NGB GL System" as GLSystemExternal
    component "NGB CRM" as CRMExternal
    component "SMS Gateway" as SMSGatewayExternal
    component "Existing IVR Platform" as IVRPlatformExternal
    component "ICRS (Card Transaction Records)" as ICRSExternal
}

' Dependencies
Channels --> CoreServices : Uses
Channels --> Adapters : Direct IVR/E-Form via Adapters

CoreServices --> Adapters : Orchestrates external interactions

Adapters --> CardsSystemExternal : Interacts with
Adapters --> GLSystemExternal : Interacts with
Adapters --> CRMExternal : Interacts with
Adapters --> SMSGatewayExternal : Interacts with
Adapters --> IVRPlatformExternal : Interacts with
Adapters --> ICRSExternal : Interacts with

SchoolSvc .down.> AuditSvc : Logs events
StudentSvc .down.> AuditSvc : Logs events
PaymentSvc .down.> AuditSvc : Logs events
EPPSvc .down.> AuditSvc : Logs events

PaymentSvc --> NotificationSvc : Triggers SMS
StudentSvc --> NotificationSvc : Triggers SMS

ReportingSvc --> AuditSvc : For data
ReportingSvc --> PaymentSvc : For transaction data

@enduml
```