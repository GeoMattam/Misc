```plantuml
@startuml
!theme plain
skinparam handwritten false
skinparam class {
    BorderColor #A3B8B9
    BackgroundColor #EDF2F4
    ArrowColor #A3B8B9
}
skinparam relationship {
    LineColor #A3B8B9
    FontColor #A3B8B9
    ArrowColor #A3B8B9
}

title "School Fee Payment System - Entity-Relationship Diagram"

entity "School" as School {
    **school_id** (PK)
    --
    school_name
    location
    ngb_account_number
    ngb_gl_account_config
    registration_date
    is_active
}

entity "FeeType" as FeeType {
    **fee_type_id** (PK)
    --
    fee_type_name
    description
    **school_id** (FK)
}

entity "Customer" as Customer {
    **customer_id** (PK)
    --
    customer_name
    contact_info
    status
}

entity "CreditCard" as CreditCard {
    **card_number** (PK)
    --
    **customer_id** (FK)
    card_type
    expiry_date
    balance
    status
}

entity "Student" as Student {
    **student_id** (PK)
    **school_id** (PK, FK)
    --
    student_name
    **registered_by_customer_id** (FK)
    registration_date
    status
}

entity "Transaction" as Transaction {
    **transaction_id** (PK)
    --
    transaction_date_time
    amount
    remark (20 char)
    status
    posting_description (40 char)
    is_epp_converted
    gl_posting_status
    **card_number** (FK)
    **student_id** (FK)
    **school_id** (FK)
    **fee_type_id** (FK)
}

entity "EPP_Request" as EPPRequest {
    **epp_request_id** (PK)
    **transaction_id** (PK, FK)
    --
    request_date_time
    status
    rejection_reason
}

entity "AuditLog" as AuditLog {
    **log_id** (PK)
    --
    activity_type
    entity_id_affected
    entity_type
    timestamp
    performed_by_user_or_system
    details
}

' Relationships
School ||--o{ FeeType : "offers"
School ||--o{ Student : "enrolls"
Customer ||--o{ CreditCard : "owns"
Customer ||--o{ Student : "registers"
CreditCard ||--o{ Transaction : "used in"
Student ||--o{ Transaction : "involved in"
FeeType ||--o{ Transaction : "selected for"

Transaction ||--o| EPPRequest : "can convert to"

' AuditLog relationships are more conceptual due to generic FKs
' AuditLog o-- Transaction
' AuditLog o-- Student
' AuditLog o-- School
' AuditLog o-- EPPRequest

@enduml
```

## 6. Data Design

### 6.1 Data Model: Describe the data model, including major entities and relationships.

The data model for the School Fee Payment system is designed around several core entities that represent the key participants and activities within the system.

*   **School:** This entity represents an educational institution registered with New Gen Bank (NGB) for fee collection. It holds fundamental information about the school and acts as a central point for managing associated fee types and student enrollments.
*   **FeeType:** This entity defines the various categories of fees that a particular school offers (e.g., "School Fee," "Bus Fee"). Each `FeeType` is directly associated with a `School`.
*   **Customer:** Represents an NGB credit cardholder. This entity is crucial for authenticating users who can register students and initiate fee payments. It's expected to be synchronized or referenced from the bank's core Customer Relationship Management (CRM) system.
*   **CreditCard:** This entity holds details of an NGB credit card owned by a `Customer`. It's the primary instrument for making payments and is likely synchronized from the bank's Cards System.
*   **Student:** Represents an individual student enrolled at a registered `School`. Students must be registered by an active `Customer` before any fee payments can be made on their behalf. The unique identification of a student is combined with the school they attend.
*   **Transaction:** This is the central transactional entity, recording every fee payment processed through the system. It captures details such as the amount, date, the `CreditCard` used, the `Student` for whom the payment was made, the `School` receiving the payment, and the specific `FeeType`. It also tracks the transaction's status and any relevant remarks.
*   **EPP_Request:** This entity captures requests from `Customer`s to convert a completed `Transaction` into an Easy Payment Plan (EPP). It maintains a one-to-one or one-to-zero-or-one relationship with a `Transaction`, indicating whether a payment is subject to an EPP.
*   **AuditLog:** This is a comprehensive logging entity designed for traceability and compliance. It records significant system activities, including registrations, amendments, de-registrations, payments, and EPP processing, detailing who performed the action, when, and on which entity.

**Relationships:**

*   A `School` **offers** multiple `FeeType`s (One-to-Many).
*   A `School` **enrolls** multiple `Student`s (One-to-Many).
*   A `Customer` **owns** multiple `CreditCard`s (One-to-Many).
*   A `Customer` **registers** multiple `Student`s (One-to-Many).
*   A `CreditCard` **is used in** multiple `Transaction`s (One-to-Many).
*   A `Student` **is involved in** multiple `Transaction`s (One-to-Many).
*   A `FeeType` **is selected for** each `Transaction` (One-to-Many).
*   A `Transaction` **can convert to** one `EPP_Request` (One-to-Zero-or-One).
*   `AuditLog` entries provide traceability for actions across various entities (`School`, `Student`, `Transaction`, `EPP_Request`), linked conceptually through `entity_id_affected` and `entity_type` fields.

### 6.2 Database Schema: Provide an overview of the database schema.

The database schema will comprise several tables, each corresponding to an entity described above, with defined primary keys (PKs) and foreign keys (FKs) to enforce referential integrity.

*   **`SCHOOL` Table:**
    *   `school_id` (PK, VARCHAR/INT) - Unique identifier for the school.
    *   `school_name` (VARCHAR) - Full name of the school.
    *   `location` (VARCHAR) - Geographical location.
    *   `ngb_account_number` (VARCHAR) - School's NGB account for crediting fees.
    *   `ngb_gl_account_config` (VARCHAR) - Internal GL account identifier or mapping.
    *   `registration_date` (DATE/TIMESTAMP) - Date the school was registered.
    *   `is_active` (BOOLEAN) - Status of the school registration.

*   **`FEE_TYPE` Table:**
    *   `fee_type_id` (PK, INT) - Unique identifier for the fee type.
    *   `school_id` (FK, INT) - References `SCHOOL.school_id`.
    *   `fee_type_name` (VARCHAR) - Name of the fee type (e.g., "School Fee").
    *   `description` (VARCHAR, NULLABLE) - Optional description.

*   **`CUSTOMER` Table:** (Likely a replicated or integrated table from core banking systems)
    *   `customer_id` (PK, VARCHAR/INT) - Unique identifier for the customer (cardholder).
    *   `customer_name` (VARCHAR) - Name of the customer.
    *   `contact_info` (VARCHAR) - Email or phone number.
    *   `status` (VARCHAR) - E.g., 'ACTIVE', 'INACTIVE'.

*   **`CREDIT_CARD` Table:** (Likely a replicated or integrated table from the Cards System)
    *   `card_number` (PK, VARCHAR) - Unique credit card number (masked/encrypted).
    *   `customer_id` (FK, VARCHAR/INT) - References `CUSTOMER.customer_id`.
    *   `card_type` (VARCHAR) - E.g., 'VISA_CONVENTIONAL', 'MASTERCARD'.
    *   `expiry_date` (DATE) - Card expiry date.
    *   `balance` (DECIMAL) - Current card balance (may be dynamic/real-time retrieved).
    *   `status` (VARCHAR) - E.g., 'ACTIVE', 'INACTIVE', 'BLOCKED'.

*   **`STUDENT` Table:**
    *   `student_id` (PK, VARCHAR/INT) - Unique identifier for the student within a school.
    *   `school_id` (PK, FK, INT) - References `SCHOOL.school_id`. (Forms a composite primary key with `student_id`).
    *   `student_name` (VARCHAR) - Full name of the student.
    *   `registered_by_customer_id` (FK, VARCHAR/INT) - References `CUSTOMER.customer_id`.
    *   `registration_date` (DATE/TIMESTAMP) - Date the student was registered.
    *   `status` (VARCHAR) - E.g., 'ACTIVE', 'DE-REGISTERED'.

*   **`TRANSACTION` Table:**
    *   `transaction_id` (PK, VARCHAR/UUID) - Unique reference ID for each payment.
    *   `transaction_date_time` (TIMESTAMP) - Timestamp of the transaction.
    *   `amount` (DECIMAL) - Payment amount.
    *   `card_number` (FK, VARCHAR) - References `CREDIT_CARD.card_number`.
    *   `student_id` (FK, VARCHAR/INT) - References `STUDENT.student_id`.
    *   `school_id` (FK, INT) - References `SCHOOL.school_id`.
    *   `fee_type_id` (FK, INT) - References `FEE_TYPE.fee_type_id`.
    *   `remark` (VARCHAR(20), NULLABLE) - Optional user-input remark.
    *   `status` (VARCHAR) - E.g., 'SUCCESS', 'FAILED', 'PENDING_EPP', 'CANCELLED'.
    *   `posting_description` (VARCHAR(40)) - Formatted description for GL posting.
    *   `is_epp_converted` (BOOLEAN) - Flag indicating if converted to EPP (default FALSE).
    *   `gl_posting_status` (VARCHAR) - Status of the GL posting (e.g., 'PENDING', 'POSTED', 'FAILED').

*   **`EPP_REQUEST` Table:**
    *   `epp_request_id` (PK, VARCHAR/UUID) - Unique identifier for the EPP request.
    *   `transaction_id` (PK, FK, VARCHAR/UUID) - References `TRANSACTION.transaction_id`. (Forms a composite primary key with `epp_request_id` and ensures 1:1 relationship).
    *   `request_date_time` (TIMESTAMP) - Timestamp of the EPP request.
    *   `status` (VARCHAR) - E.g., 'PENDING', 'APPROVED', 'REJECTED'.
    *   `rejection_reason` (VARCHAR, NULLABLE) - Reason if request is rejected.
    *   *(Further fields for installment details would be added here if required, e.g., `num_installments`, `installment_amount`)*

*   **`AUDIT_LOG` Table:**
    *   `log_id` (PK, BIGINT/UUID) - Unique log entry identifier.
    *   `activity_type` (VARCHAR) - E.g., 'STUDENT_REGISTRATION_SUCCESS', 'PAYMENT_FAILED'.
    *   `entity_id_affected` (VARCHAR) - ID of the primary entity involved (e.g., student_id, transaction_id).
    *   `entity_type` (VARCHAR) - Type of entity affected (e.g., 'STUDENT', 'TRANSACTION').
    *   `timestamp` (TIMESTAMP) - When the activity occurred.
    *   `performed_by_user_or_system` (VARCHAR) - Identifier of the user or system component.
    *   `details` (TEXT/JSONB) - Additional context or message (e.g., SMS content, error message).

### 6.3 Data Flow: Describe how data is created, read, updated, and deleted within the system.

Data flows through the system across various functional modules and interacts with internal and external systems.

**Data Creation (C - Create):**
*   **School Registration:**
    *   `SCHOOL` and associated `FEE_TYPE` records are *created* via a UI for the Card Operations Team or through an automated process for Excel uploads from the Product Team.
    *   An `AUDIT_LOG` entry is *created* for each successful school registration.
*   **Student Registration:**
    *   `STUDENT` records are *created* by customers through Online/Mobile Banking channels or by Contact Center agents using an E-Form after IVR authentication.
    *   `AUDIT_LOG` entries are *created* to record these new student registrations.
*   **Fee Payment:**
    *   Upon a successful payment transaction, a `TRANSACTION` record is *created*, capturing all relevant payment details.
    *   An `AUDIT_LOG` entry is *created* for payment confirmation.
*   **EPP Conversion Request:**
    *   When a customer opts to convert a payment to EPP, an `EPP_REQUEST` record is *created*, linked to the `TRANSACTION`.
    *   An `AUDIT_LOG` entry is *created* for the EPP request initiation.

**Data Reading (R - Read):**
*   **User Interface Displays:**
    *   Online/Mobile Banking interfaces *read* `SCHOOL` names for dropdown selection.
    *   They *read* the customer's registered `STUDENT`s and available `CREDIT_CARD`s for selection.
    *   `FEE_TYPE`s are *read* based on the selected `SCHOOL`.
    *   Transaction history views *read* `TRANSACTION` records (last 6 months) for display.
*   **System Validations:**
    *   Before processing payments, the system *reads* `CUSTOMER`, `CREDIT_CARD` (for status and balance), `SCHOOL`, and `STUDENT` data to perform various validations (e.g., active card, registered student, sufficient balance).
*   **Reporting:**
    *   The reporting module *reads* `SCHOOL`, `STUDENT`, and `TRANSACTION` data to generate daily Excel reports.
*   **External System Interactions:**
    *   The system *reads* real-time card balance information from the `Cards System` via API calls.

**Data Updates (U - Update):**
*   **Student Amendment:**
    *   Customers (Online/Mobile Banking) or Contact Center agents (E-Form) *update* existing `STUDENT` details.
    *   `AUDIT_LOG` entries are *created* for all amendments.
*   **Fee Posting:**
    *   The `TRANSACTION` record's `gl_posting_status` is *updated* after integration with the NGB General Ledger (GL) system (e.g., from 'PENDING' to 'POSTED' or 'FAILED').
    *   The `CREDIT_CARD` balance in the `Cards System` is *updated* by debiting the transaction amount.
*   **EPP Request Status:**
    *   The `EPP_REQUEST` record's `status` is *updated* (e.g., to 'APPROVED' or 'REJECTED') by the Cards Management team, potentially via an E-Form workflow.
    *   The corresponding `TRANSACTION` record's `is_epp_converted` flag is *updated*.
    *   `AUDIT_LOG` entries are *created* for EPP status changes.

**Data Deletion (D - Delete):**
*   **Student De-registration:**
    *   Student de-registration is handled as a "soft delete" by *updating* the `STUDENT.status` field to 'DE-REGISTERED'. This preserves historical data for audit purposes.
    *   An `AUDIT_LOG` entry is *created* for de-registration.
*   *(Note: Direct hard deletion of core transactional or registration data is generally avoided in financial systems due to audit, compliance, and historical reporting requirements.)*

**External Data Flow and Interactions:**
*   **Online/Mobile Banking:** User interfaces send and receive data for student management and fee payment.
*   **IVR:** Provides input and receives authentication from the system; directs agents for E-Form creation.
*   **CRM:** Provides customer master data and potentially receives updates on customer activities.
*   **Cards System:** Involved in real-time card validation, debiting, and potentially card balance inquiries.
*   **NGB Core Banking (GL):** Receives real-time fee posting instructions (debit credit card GL, credit school account).
*   **E-Form Workflow:** Facilitates data exchange and state management between Contact Center, Cards team, and system for student management and EPP processing.
*   **SMS Gateway:** Receives messages from the system for transactional alerts and confirmations.
*   **Email Service:** Used to send daily Excel reports to registered schools.
*   **ICRS (Internal Credit Risk System):** Receives `TRANSACTION` records specifically for IVR payments, as per requirements.

### 6.4 ER Diagram : Entity-Relationship diagram showing logical data structure.

The following PlantUML diagram illustrates the major entities and their relationships within the School Fee Payment System. Primary keys are marked with `**` and foreign keys are indicated with `(FK)`. Relationships are depicted using standard crow's foot notation.

```plantuml
@startuml
!theme plain
skinparam handwritten false
skinparam class {
    BorderColor #A3B8B9
    BackgroundColor #EDF2F4
    ArrowColor #A3B8B9
}
skinparam relationship {
    LineColor #A3B8B9
    FontColor #A3B8B9
    ArrowColor #A3B8B9
}

title "School Fee Payment System - Entity-Relationship Diagram"

entity "School" as School {
    **school_id** (PK)
    --
    school_name
    location
    ngb_account_number
    ngb_gl_account_config
    registration_date
    is_active
}

entity "FeeType" as FeeType {
    **fee_type_id** (PK)
    --
    fee_type_name
    description
    **school_id** (FK)
}

entity "Customer" as Customer {
    **customer_id** (PK)
    --
    customer_name
    contact_info
    status
}

entity "CreditCard" as CreditCard {
    **card_number** (PK)
    --
    **customer_id** (FK)
    card_type
    expiry_date
    balance
    status
}

entity "Student" as Student {
    **student_id** (PK)
    **school_id** (PK, FK)
    --
    student_name
    **registered_by_customer_id** (FK)
    registration_date
    status
}

entity "Transaction" as Transaction {
    **transaction_id** (PK)
    --
    transaction_date_time
    amount
    remark (20 char)
    status
    posting_description (40 char)
    is_epp_converted
    gl_posting_status
    **card_number** (FK)
    **student_id** (FK)
    **school_id** (FK)
    **fee_type_id** (FK)
}

entity "EPP_Request" as EPPRequest {
    **epp_request_id** (PK)
    **transaction_id** (PK, FK)
    --
    request_date_time
    status
    rejection_reason
}

entity "AuditLog" as AuditLog {
    **log_id** (PK)
    --
    activity_type
    entity_id_affected
    entity_type
    timestamp
    performed_by_user_or_system
    details
}

' Relationships
School ||--o{ FeeType : "offers"
School ||--o{ Student : "enrolls"
Customer ||--o{ CreditCard : "owns"
Customer ||--o{ Student : "registers"
CreditCard ||--o{ Transaction : "used in"
Student ||--o{ Transaction : "involved in"
FeeType ||--o{ Transaction : "selected for"

Transaction ||--o| EPPRequest : "can convert to"

' AuditLog relationships are more conceptual due to generic FKs
' AuditLog o-- Transaction
' AuditLog o-- Student
' AuditLog o-- School
' AuditLog o-- EPPRequest

@enduml
```