## 8. Deployment Architecture

### 8.1 Deployment Diagram (High-Level)

This diagram illustrates the macro-level physical deployment of the School Fee Payment System (SFPS) within the New Gen Bank (NGB) infrastructure, showing how it interacts with existing bank systems and external users.

```plantuml
@startuml
skinparam handwritten false
skinparam titleFontSize 20
skinparam actor {
  FontColor #333333
  BorderColor #555555
  ArrowColor #555555
}
skinparam node {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #DDEEFF
}
skinparam database {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #CCEEFF
}
skinparam cloud {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #FFEEEE
}
skinparam rectangle {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #FFEECC
}
skinparam component {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #DDDDDD
}
skinparam package {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #F0F8FF
}

title 8.1 Deployment Diagram (High-Level)

actor "NGB Customer" as Customer
actor "Card Operations Team" as CardOps
actor "Product Team" as ProductTeam

cloud "External Networks" as Network {
  node "Mobile Device" as MobileApp
  node "Web Browser" as OnlineBanking
}

node "NGB Data Center" as NGB_DC {
  rectangle "School Fee Payment System (SFPS)" as SFPS_Rect {
    component "SFPS Core Application" as SFPS_Core
  }

  node "Existing NGB Systems" as Existing_Systems {
    component "Online Banking Core" as OB_Core
    component "Mobile Banking Core" as MB_Core
    component "IVR System" as IVR_Sys
    component "CRM System" as CRM
    component "Cards System" as CardsSys
    component "NGB GL Account / Core Banking" as GL_Core
  }
  node "Email Server" as EmailSrv
}

Customer -- Network
Network -- OnlineBanking : Accesses
Network -- MobileApp : Accesses

OnlineBanking -- OB_Core : Integrates
MobileApp -- MB_Core : Integrates
Customer -- IVR_Sys : Calls

CardOps -- OnlineBanking : Uses UI for School Reg.
ProductTeam --> EmailSrv : Sends School Data (Excel)

OB_Core -- SFPS_Core : Invokes SFPS Services
MB_Core -- SFPS_Core : Invokes SFPS Services
IVR_Sys -- SFPS_Core : Invokes SFPS Services

SFPS_Core -- CardsSys : Card Validation & Debit
SFPS_Core -- GL_Core : GL Debit & School Account Credit
SFPS_Core -- CRM : E-Form Generation, Customer Data
SFPS_Core --> EmailSrv : Sends Daily Reports & Alerts
SFPS_Core --> IVR_Sys : (for voice prompts, if applicable)

@enduml
```

### 8.2 Deployment Diagram (Detailed View)

This diagram provides a more granular view of the School Fee Payment System's internal components, showcasing how they are deployed across various infrastructure nodes and interact with each other and existing NGB systems.

```plantuml
@startuml
skinparam handwritten false
skinparam titleFontSize 20
skinparam actor {
  FontColor #333333
  BorderColor #555555
  ArrowColor #555555
}
skinparam node {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #DDEEFF
}
skinparam database {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #CCEEFF
}
skinparam cloud {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #FFEEEE
}
skinparam rectangle {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #FFEECC
}
skinparam component {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #DDDDDD
}
skinparam package {
  FontColor #333333
  BorderColor #444444
  BackgroundColor #F0F8FF
}

title 8.2 Deployment Diagram (Detailed View)

node "Customer Access Tier" {
  component "Online Banking Front-End (Web)" as OB_FE
  component "Mobile Banking App" as MB_APP
  component "IVR System" as IVR_SYS
}

node "NGB Data Center" as NGB_DC {

  node "Integration Gateway Layer" as IntegrationGateway {
    component "API Gateway / ESB" as APIGateway
  }

  node "SFPS Application Cluster" as SFPS_Cluster {
    rectangle "Load Balancer" as LB
    node "Application Server (SFPS-Node 1)" as AS1 {
      component "School Registration Service" as RegSvc
      component "Student Management Service" as StudentSvc
      component "Fee Payment Orchestrator" as PaymentSvc
      component "EPP Conversion Service" as EPP_Svc
      component "Reporting Service" as ReportSvc
      component "Alerts & Notification Service" as AlertSvc
    }
    node "Application Server (SFPS-Node 2)" as AS2 {
      RegSvc .. AS2
      StudentSvc .. AS2
      PaymentSvc .. AS2
      EPP_Svc .. AS2
      ReportSvc .. AS2
      AlertSvc .. AS2
    }
    LB --> AS1 : Distributes Traffic
    LB --> AS2 : Distributes Traffic
  }

  node "SFPS Database Cluster" as DB_Cluster {
    database "SFPS Database (Primary)" as DB_Primary
    database "SFPS Database (Replica)" as DB_Replica
    DB_Primary -left- DB_Replica : Async Data Replication
  }

  node "Messaging Infrastructure" as MessagingInfra {
    component "Message Queue (e.g., Kafka/RabbitMQ)" as MQ
  }

  node "Existing NGB Core Systems" as Existing_Systems {
    component "Cards System API" as Cards_API
    component "Core Banking (GL) API" as GL_API
    component "CRM API (E-Form / Customer)" as CRM_API
    component "SMS Gateway" as SMS_GW
    component "Email Server" as Email_Server
    component "Online Banking Core" as OB_Core
    component "Mobile Banking Core" as MB_Core
    component "IVR Integration Service" as IVR_Integration
  }

  OB_FE --> OB_Core : Customer Interactions
  MB_APP --> MB_Core : Customer Interactions
  IVR_SYS --> IVR_Integration : Voice/DTMF Commands

  OB_Core -- APIGateway : SFPS Service Calls
  MB_Core -- APIGateway : SFPS Service Calls
  IVR_Integration -- APIGateway : SFPS Service Calls

  APIGateway --> LB : SFPS API Requests

  AS1 -- MQ : Publish Events/Messages
  AS2 -- MQ

  MQ --> Cards_API : Async Card Debit Request
  MQ --> GL_API : Async GL Posting Request
  MQ --> CRM_API : Async E-Form Creation / CRM Update
  MQ --> SMS_GW : Async SMS Notification Request
  MQ --> Email_Server : Async Report Dispatch Trigger

  AS1 -- DB_Primary : Read/Write SFPS Data
  AS2 -- DB_Primary : Read/Write SFPS Data

  ReportSvc --> DB_Primary : Query for Reports
  ReportSvc --> Email_Server : Send Generated Reports

  RegSvc -- APIGateway : (For Card Ops UI within OB_FE)

}
@enduml
```

### 8.3 Environment Strategy

To ensure robust development, testing, and deployment, the following environment strategy will be adopted:

1.  **Development (DEV) Environment:**
    *   **Purpose:** Local development, unit testing, and initial integration testing.
    *   **Setup:** Individual developer workstations will have local development environments. A shared integrated DEV environment will be used for early-stage component integration and testing of core SFPS services. External NGB systems will typically be mocked or accessed via dedicated DEV instances.
    *   **Deployment:** Continuous integration (CI) pipeline deploys code changes automatically or on-demand to the shared DEV environment.

2.  **System Integration Testing (SIT) Environment:**
    *   **Purpose:** End-to-end integration testing of the SFPS with all interconnected NGB core systems (Online Banking, Mobile Banking, IVR, CRM, Cards System, GL Account).
    *   **Setup:** A dedicated environment that closely mirrors the production architecture, using test data. All integrated NGB systems will have their SIT instances connected.
    *   **Deployment:** Automated deployment via CI/CD pipeline from successful DEV builds. Rigorous automated and manual integration test cases are executed here.

3.  **User Acceptance Testing (UAT) Environment:**
    *   **Purpose:** Business users validate the system's functionality against the specified requirements and business rules. Performance and usability are also assessed.
    *   **Setup:** An environment that is a near-replica of the production setup, populated with realistic (anonymized/synthesized) test data. It provides the business teams with a stable platform for comprehensive testing.
    *   **Deployment:** Deployment of builds that have successfully passed SIT. Business users conduct acceptance tests, and sign-off is required before promotion to production.

4.  **Production (PROD) Environment:**
    *   **Purpose:** The live operational environment serving NGB customers and internal teams.
    *   **Setup:** Highly available, secure, and performant infrastructure, configured for maximum uptime and resilience. Strict access controls, robust monitoring, and comprehensive logging are in place.
    *   **Deployment:** Controlled deployment of UAT-approved builds, typically during scheduled maintenance windows, with comprehensive rollback plans. Post-deployment smoke tests are mandatory.

5.  **Disaster Recovery (DR) Environment:**
    *   **Purpose:** To ensure business continuity and minimize downtime in the event of a catastrophic failure in the primary PROD environment.
    *   **Setup:** A geographically separate site with infrastructure and data replication from the primary PROD environment.
    *   **Deployment:** Data is replicated in near real-time. Regular DR drills are conducted to validate recovery procedures and meet defined RTO (Recovery Time Objective) and RPO (Recovery Point Objective).

**Deployment Flow:**
Code changes will follow a structured promotion path:
`Developer Local -> Shared DEV -> SIT -> UAT -> PROD`
A CI/CD pipeline will automate builds, testing, and deployments across these environments, ensuring consistency, speed, and quality.

### 8.4 Scalability and Resilience

The architecture is designed with inherent scalability and resilience to meet the non-functional requirements of performance, reliability, and support for multiple schools, students, and transactions.

**Scalability:**

*   **Horizontal Scaling of Application Servers:** The "SFPS Application Cluster" utilizes a Load Balancer distributing requests across multiple application server instances (AS1, AS2, etc.). New instances can be added or removed dynamically based on demand, allowing the system to handle increasing transaction volumes and user concurrency without significant code changes.
*   **Database Scaling:**
    *   **Read Replicas:** The "SFPS Database Cluster" includes a primary database and one or more read replicas. This offloads read-heavy operations (e.g., viewing transaction history, generating reports) from the primary write database, improving overall database performance and throughput.
    *   **Connection Pooling:** Efficient database connection pooling in the application layer will minimize overhead and maximize resource utilization.
*   **Asynchronous Processing with Message Queues:** The use of a Message Queue (MQ) for tasks like GL postings, SMS notifications, and EPP processing decouples the core transaction flow from downstream system dependencies. This prevents bottlenecks and allows each service (e.g., Cards System API, GL API) to process messages at its own pace, independently scaling its processing capacity.
*   **Stateless Application Design:** Application servers are designed to be largely stateless, meaning session-specific data is not stored directly on the server. This facilitates easier horizontal scaling and load balancing, as any server can handle any request.
*   **API Gateway:** The API Gateway acts as a central entry point, capable of rate limiting, caching, and routing, which can help manage and scale access to the backend services.

**Resilience (Reliability and High Availability):**

*   **Redundancy at All Layers:**
    *   **Load Balancer:** Provides redundancy for the application cluster. If an application server fails, the load balancer automatically redirects traffic to healthy instances.
    *   **Application Cluster:** Multiple identical application server instances ensure that the failure of one server does not lead to system downtime.
    *   **Database Replication:** The Primary-Replica database setup provides data redundancy and enables quick failover to a replica in case of a primary database failure, minimizing data loss and downtime.
    *   **Clustered Message Queue:** The MQ itself will be deployed in a clustered, highly available configuration to ensure message persistence and reliable delivery even if individual MQ nodes fail.
*   **Asynchronous Processing for Reliability:** By queuing critical operations (like fee postings and SMS alerts), the system ensures that these actions are eventually performed, even if the target systems are temporarily unavailable. Messages are persisted in the queue and retried until successful.
*   **Transaction Logging and Traceability:** Every transaction is logged with a unique reference ID, ensuring traceability and aiding in reconciliation and audit processes, fulfilling reliability and audit requirements.
*   **SMS Confirmation:** Mandatory SMS alerts for key activities (registration, payment, EPP status) provide immediate confirmation to users, enhancing confidence and perceived reliability.
*   **Disaster Recovery (DR):** A geographically separate DR site with ongoing data replication will be maintained. In the event of a major regional outage, the system can be brought online at the DR site, ensuring business continuity with minimal data loss (defined by RPO) and downtime (defined by RTO).
*   **Monitoring, Alerting, and Self-Healing:** Comprehensive monitoring tools will continuously track system health, performance metrics, and potential issues. Automated alerts will notify operations teams of anomalies, and where possible, automated self-healing mechanisms will be implemented (e.g., restarting failed services).
*   **Graceful Degradation:** Services will be designed to handle failures of non-critical components gracefully. For example, if CRM E-Form generation is temporarily down, the core fee payment process should still complete, with the E-Form generation retried later or handled manually.