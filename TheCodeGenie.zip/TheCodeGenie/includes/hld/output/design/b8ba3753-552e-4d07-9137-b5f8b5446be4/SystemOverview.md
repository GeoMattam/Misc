## 3. System Overview

### 3.1 System Description

The School Fee Payment System is a strategic initiative by New Gen Bank (NGB) to expand its card business into the education sector. Its primary purpose is to enable NGB Credit Card holders to conveniently pay school fees for registered students at partner schools. The system facilitates end-to-end processing from school and student registration to multi-channel fee payment, optional conversion to Easy Payment Plans (EPP), and real-time fee posting to relevant accounts. It integrates with various NGB digital channels like Online Banking, Mobile Banking, and IVR, ensuring a secure, scalable, and auditable transaction process.

### 3.2 System Context

The System Context diagram illustrates the School Fee Payment System's position within the broader NGB ecosystem, showing its interactions with external users and other NGB systems.

```plantuml
@startuml
!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Container.puml

title System Context Diagram for School Fee Payment System

Person(cardOperationsTeam, "NGB Card Operations Team", "Registers schools via dedicated UI.")
Person(productTeam, "NGB Product Team", "Provides school registration data (e.g., via email/Excel).")
Person(customer, "NGB Customer (Cardholder)", "Manages students and pays fees via NGB digital channels.")
Person(contactCenterAgent, "NGB Contact Center Agent", "Assists customers with student management and IVR payments via E-Form.")
System_Ext(schools, "Schools", "Recipients of fee payments; receive daily transaction reports.")

System(schoolFeePaymentSystem, "School Fee Payment System", "Enables school fee payments using NGB Credit Cards.")

System_Ext(onlineBanking, "NGB Online Banking", "Customer-facing web channel for banking services.")
System_Ext(mobileBanking, "NGB Mobile Banking", "Customer-facing mobile application for banking services.")
System_Ext(ivrSystem, "NGB IVR System", "NGB's Interactive Voice Response system for automated services.")
System_Ext(cardsSystem, "NGB Cards System", "Manages credit card accounts, processes debits and balance checks.")
System_Ext(glSystem, "NGB GL System", "Handles General Ledger postings for all financial transactions.")
System_Ext(crmSystem, "NGB CRM System", "Manages customer data; integrates with E-Form workflows.")
System_Ext(icrsSystem, "NGB ICRS", "Stores IVR transaction records for auditing.")
System_Ext(smsGateway, "SMS Gateway", "Sends automated SMS alerts and confirmations.")
System_Ext(emailSystem, "Email System", "Used for receiving data from product team and sending reports to schools.")


Rel(cardOperationsTeam, schoolFeePaymentSystem, "Registers Schools", "UI interaction")
Rel(productTeam, emailSystem, "Sends School Data", "Excel format")
Rel(emailSystem, schoolFeePaymentSystem, "Imports School Data", "Batch process / Manual processing")

Rel(customer, onlineBanking, "Accesses", "Web UI")
Rel(customer, mobileBanking, "Accesses", "Mobile App UI")
Rel(customer, ivrSystem, "Interacts with", "Voice/Menu navigation")

Rel(onlineBanking, schoolFeePaymentSystem, "Initiates Student Management & Payments", "API calls")
Rel(mobileBanking, schoolFeePaymentSystem, "Initiates Student Management & Payments", "API calls")
Rel(ivrSystem, schoolFeePaymentSystem, "Initiates Payments & Authentication", "API calls")

Rel(contactCenterAgent, crmSystem, "Uses E-Form", "Data entry & workflow")
Rel(crmSystem, schoolFeePaymentSystem, "Manages Student Data / Triggers EPP Requests", "API calls")
Rel(contactCenterAgent, ivrSystem, "Assists Customer", "System control")

Rel(schoolFeePaymentSystem, cardsSystem, "Debits Credit Cards / Checks Balance", "API calls")
Rel(schoolFeePaymentSystem, glSystem, "Posts Debits/Credits to GL Accounts", "Real-time API calls")
Rel(schoolFeePaymentSystem, smsGateway, "Sends Alerts & Confirmations", "API calls")
Rel(schoolFeePaymentSystem, icrsSystem, "Logs IVR Transaction Records", "API calls")
Rel(schoolFeePaymentSystem, emailSystem, "Sends Daily Reports to Schools", "Automated Excel Reports")

Rel(schoolFeePaymentSystem, schools, "Credits School Bank Account", "Automated Bank Transfer")

@enduml
```

### 3.3 Key Objectives & Goals

The primary objectives and goals of the School Fee Payment System are:
*   **Business Expansion:** To expand New Gen Bank's cards business by penetrating the school sector, starting with a pilot at Europe School.
*   **Customer Convenience:** To provide NGB Credit Card holders with convenient, multi-channel options (Online Banking, Mobile Banking, IVR) for paying school fees.
*   **Operational Efficiency:** To streamline the processes for school registration, student management (registration, amendment, de-registration), and fee collection.
*   **Financial Flexibility:** To offer cardholders the option to convert fee payments into Easy Payment Plans (EPP), enhancing their financial management.
*   **Transaction Integrity:** To ensure secure, real-time, and accurate debiting of credit cards and posting to General Ledger and school accounts.
*   **Auditability & Compliance:** To maintain comprehensive, traceable transaction logs and generate necessary reports for audit and compliance purposes.
*   **Scalability:** To support a growing number of schools and students, accommodating multiple transactions efficiently.

### 3.4 Stakeholders

The key stakeholders involved in the School Fee Payment System initiative include:

**Business Stakeholders:**
*   **NGB Cards Management:** Overall owner and driver of the initiative, focused on expanding card business.
*   **NGB Direct Banking (Online & Mobile):** Responsible for the digital channels used for payment.
*   **NGB Contact Centre:** Involved in student management via E-Forms and assisting IVR payments.
*   **NGB Card Operations Team:** Responsible for registering schools in the system.
*   **NGB Product Team:** Provides initial school data for registration.
*   **Schools (e.g., Europe School):** The beneficiaries receiving fee payments, and recipients of transaction reports.
*   **NGB Customers (Cardholders):** The end-users making fee payments.

**Technical Stakeholders:**
*   **NGB IT Department:** Responsible for system development, maintenance, and infrastructure.
*   **Teams managing Online Banking System:** Ensure integration and proper functionality.
*   **Teams managing Mobile Banking System:** Ensure integration and proper functionality.
*   **Teams managing IVR System:** Ensure integration and proper functionality.
*   **Teams managing Cards System:** Responsible for card-related transactions and data.
*   **Teams managing GL System:** Responsible for financial postings.
*   **Teams managing CRM System:** Involved in E-Form integration and customer data.
*   **Teams managing ICRS:** Responsible for IVR transaction logging.
*   **NGB Security & Compliance Teams:** Ensure adherence to security standards and regulatory requirements.