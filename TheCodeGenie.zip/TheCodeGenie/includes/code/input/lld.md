## 3. Functional Design

### 3.1 Functional Overview

The NGB School Fee Payment System is designed to provide a comprehensive solution for managing school and student registrations, facilitating multi-channel fee payments, and offering flexible Easy Payment Plan (EPP) conversions. It integrates seamlessly with NGB's existing digital channels and core banking systems to ensure a secure, efficient, and auditable transaction process.

**Key Functional Modules:**

1.  **School Registration:**
    *   **Purpose:** Enables the onboarding of new schools into the NGB fee payment program.
    *   **Process:** NGB Card Operations Team uses a dedicated Admin Portal UI to input school details such as School Name, Location, and NGB Account Number. The Product Team can also provide initial registration data via Excel. The system internally configures the NGB GL account mapping for the school. It supports registration of multiple fee types per school (e.g., School Fee, Bus Fee).
    *   **Business Rules Applied:** Enforces school qualification criteria (min. 1,000 enrolled students, min. 3 years operational, min. €500,000 annual fee collection) and requires the school to have an NGB account.

2.  **Student Registration / Amendment / De-registration:**
    *   **Purpose:** Allows NGB cardholders to manage student profiles linked to their fee payments.
    *   **Channels & Process:**
        *   **Online/Mobile Banking:** Customers with active credit cards can register multiple students by providing Student Name, Student ID (entered twice for confirmation), and selecting the School from a dropdown. OTP authentication is mandatory. SMS alerts are sent for all registration/amendment/de-registration actions.
        *   **Contact Center (E-Form):** Contact Center Agents can perform student management (register, amend, de-register) using an E-Form after authenticating the customer via IVR TIN. Manual input fields are used, with restrictions on copy-paste for the Student ID. SMS alerts are sent post-processing.
    *   **Business Rules Applied:** Only active credit cardholders can register students. Student ID must be entered twice and match.

3.  **Fee Payment:**
    *   **Purpose:** Facilitates credit card payments for school fees for registered students.
    *   **Channels & Process:** Available across Online Banking, Mobile Banking, and IVR.
        *   **Common:** Only registered students are eligible. All active cards for the customer are displayed for selection. An option to convert the payment to an EPP is available. Each transaction is logged with a unique reference ID, and a confirmation SMS is sent.
        *   **Online/Mobile Banking:** Displays fee types based on the registered school, with dropdowns for student and fee type selection. An optional 20-character remark field is available. Customers can view their payment history for the last 6 months. EPP conversion requests trigger an E-Form generation for further processing.
        *   **IVR:** Authenticates using IVR TIN. Uses voice/menu navigation. Optional TTS for student names. OTP and daily limits are configurable. E-Forms are created by agents for EPP requests. Transaction records are updated in ICRS.
    *   **Business Rules Applied:** Payments only allowed for registered students. Payment fails if card balance is insufficient. Daily limits apply to IVR payments.

4.  **Conversion of Fee Payment to Easy Payment Plan (EPP):**
    *   **Purpose:** Provides cardholders with flexibility to convert lump-sum fee payments into installment plans.
    *   **Process:** Initiated from the Fee Payment flow (Online/Mobile Banking) or by a Contact Center Agent (IVR E-Form). The system validates eligibility, checks for sufficient balance at conversion time, and generates an E-Form for the NGB Cards team's approval workflow.
    *   **Business Rules Applied:** No loyalty points are awarded if payment is converted to EPP. EPP request is rejected if balance is insufficient at conversion time, with an SMS notification.

5.  **Fee Posting:**
    *   **Purpose:** Ensures accurate and real-time financial settlement of fee payments.
    *   **Process:** Each successful transaction triggers individual postings: Debit the Credit Card (on the Cards System), Debit the NGB GL Account (based on card type - Visa Conventional/Islamic/MasterCard), and Credit the School Account (within NGB's Core Banking System). Description format constraints (max 40 characters) are applied.
    *   **Non-Functional Requirements:** Real-time GL postings and near-instant transaction acknowledgment are critical.

### 3.2 Use Cases

#### 3.2.1 Use Case: Register School

*   **Use Case ID:** UC-SCHOOL-001
*   **Use Case Name:** Register School
*   **Actors:** NGB Card Operations Team
*   **Description:** Allows the NGB Card Operations Team to register a new school in the system, enabling it to receive fee payments via NGB Credit Cards.
*   **Preconditions:**
    *   User is authenticated as NGB Card Operations Team member with appropriate permissions.
    *   The school has an NGB bank account.
    *   The school meets NGB's business qualification rules (min. 1,000 enrolled students, operational for at least 3 years, generates min. €500,000 annual fee collection).
*   **Postconditions:**
    *   A new School record is created in the system.
    *   Default fee types (if any) are configured for the school.
    *   An audit log entry is created for the registration.
    *   NGB GL account is internally configured/mapped for the school.

*   **Main Flow (Happy Path):**
    1.  Card Operations Team (COT) accesses the Admin Portal UI.
    2.  COT selects "Register New School" option.
    3.  System displays School Registration Form.
    4.  COT inputs:
        *   School Name
        *   Location
        *   NGB Account Number (of the school)
    5.  COT submits the form.
    6.  System validates the input data and applies business rules (e.g., checks NGB Account Number validity, verifies school qualification criteria against internal records/data).
    7.  System creates a new `School` record in the database.
    8.  System automatically configures/maps the NGB GL account internally for the school.
    9.  System records an `AuditLog` entry for the successful registration.
    10. System displays a success message to COT: "School [School Name] registered successfully."

*   **Alternative Flows:**
    *   **AF1: Product Team Initiated Registration (Batch Upload):**
        1.  Product Team sends school registration data in Excel format via email to the NGB system.
        2.  System's batch processing component receives and parses the Excel file.
        3.  For each valid school record in the Excel, system performs steps 6-10 of the Main Flow.
        4.  System generates a summary report of successful/failed registrations from the batch, and sends it to the Product Team.

*   **Exception Flows:**
    *   **EF1: Invalid Input Data:**
        *   (Steps 1-5 of Main Flow)
        *   6a. System detects invalid input (e.g., missing mandatory fields, invalid NGB Account Number format).
        *   7a. System displays specific error messages indicating invalid fields.
        *   8a. Flow restarts from step 3 or COT corrects input.
    *   **EF2: Business Rule Violation:**
        *   (Steps 1-5 of Main Flow)
        *   6b. System detects that the school does not meet qualification criteria (e.g., "School does not meet minimum student enrollment requirement").
        *   7b. System displays an error message indicating the specific business rule violation.
        *   8b. Flow ends, COT informs relevant teams for further action if business rules are to be reconsidered.
    *   **EF3: Duplicate School Registration:**
        *   (Steps 1-5 of Main Flow)
        *   6c. System identifies that a school with the same unique identifier (e.g., name + location, or account number) already exists.
        *   7c. System displays an error message: "School already registered."
        *   8c. Flow ends.

*   **Business Rules Applied:**
    *   A school must have a minimum of 1,000 enrolled students to qualify for registration.
    *   School must be operational for at least 3 years.
    *   The school must generate a minimum annual fee collection of €500,000.
    *   Schools must have an NGB account to register.

#### 3.2.2 Use Case: Register/Amend/De-register Student (Online/Mobile Banking)

*   **Use Case ID:** UC-STUDENT-001
*   **Use Case Name:** Manage Student Details via Online/Mobile Banking
*   **Actors:** NGB Customer (Cardholder)
*   **Description:** Allows an NGB customer to register new students, amend existing student details, or de-register students linked to their account via NGB Online or Mobile Banking.
*   **Preconditions:**
    *   Customer has an active NGB credit card.
    *   Customer is logged into their Online/Mobile Banking account.
*   **Postconditions:**
    *   `Student` record is created, updated, or its status changed to 'DE-REGISTERED'.
    *   An SMS alert is sent to the customer for confirmation.
    *   An `AuditLog` entry is created.

*   **Main Flow (Happy Path - Registration):**
    1.  Customer navigates to "School Fee Payment" section in Online/Mobile Banking.
    2.  Customer selects "Manage Students" and then "Register New Student".
    3.  System displays Student Registration Form.
    4.  Customer inputs:
        *   Student Name
        *   Student ID (first entry)
        *   Student ID (second entry, confirmation)
        *   Select School (from dropdown of registered schools)
    5.  Customer submits the form.
    6.  System validates that Student ID entries match.
    7.  System requests OTP authentication.
    8.  Customer receives OTP via SMS and enters it.
    9.  System authenticates OTP.
    10. System validates input data and business rules (e.g., student ID format, customer has active credit card, school exists).
    11. System creates a new `Student` record linked to the customer and school.
    12. System sends an SMS alert to the customer confirming student registration.
    13. System records an `AuditLog` entry.
    14. System displays a success message: "Student [Student Name] registered successfully."

*   **Main Flow (Happy Path - Amendment):**
    1.  (Steps 1-2 of Registration Flow, then selects "Amend Student Details")
    2.  Customer selects the student to amend from a list of their registered students.
    3.  System displays pre-filled student details.
    4.  Customer modifies Student Name or selects a different School.
    5.  Customer submits the changes.
    6.  System requests OTP authentication.
    7.  Customer receives OTP via SMS and enters it.
    8.  System authenticates OTP.
    9.  System validates changes.
    10. System updates the existing `Student` record.
    11. System sends an SMS alert to the customer confirming student amendment.
    12. System records an `AuditLog` entry.
    13. System displays a success message: "Student [Student Name] details updated successfully."

*   **Main Flow (Happy Path - De-registration):**
    1.  (Steps 1-2 of Registration Flow, then selects "De-register Student")
    2.  Customer selects the student to de-register from a list of their registered students.
    3.  System displays student details and a confirmation prompt.
    4.  Customer confirms de-registration.
    5.  System requests OTP authentication.
    6.  Customer receives OTP via SMS and enters it.
    7.  System authenticates OTP.
    8.  System updates the `Student` record status to 'DE-REGISTERED' (soft delete).
    9.  System sends an SMS alert to the customer confirming student de-registration.
    10. System records an `AuditLog` entry.
    11. System displays a success message: "Student [Student Name] de-registered successfully."

*   **Exception Flows:**
    *   **EF1: Student ID Mismatch:**
        *   (Steps 1-5 of Registration Flow)
        *   6a. System detects that Student ID entries do not match.
        *   7a. System displays an error: "Student IDs do not match. Please re-enter."
        *   8a. Flow restarts from step 4.
    *   **EF2: OTP Validation Failed:**
        *   (Steps 1-9 of any Main Flow)
        *   9a. OTP is incorrect or expired.
        *   10a. System displays an error: "OTP validation failed. Please try again."
        *   11a. Customer can retry OTP or cancel.
    *   **EF3: Customer Not Active Credit Card Holder:**
        *   (Initial check upon accessing Student Management)
        *   System prevents access and displays error: "Only active NGB Credit Cardholders can manage students."
        *   Flow ends.

*   **Business Rules Applied:**
    *   Available to customers with active credit cards.
    *   Student ID must be entered twice and must match.
    *   OTP authentication mandatory for all student management actions.
    *   Mandatory SMS notifications for registration/amendment/de-registration.

#### 3.2.3 Use Case: Make Fee Payment (Online/Mobile Banking)

*   **Use Case ID:** UC-PAY-001
*   **Use Case Name:** Make Fee Payment via Online/Mobile Banking
*   **Actors:** NGB Customer (Cardholder)
*   **Description:** Allows an NGB customer to pay school fees for a registered student using their NGB Credit Card via Online or Mobile Banking.
*   **Preconditions:**
    *   Customer has an active NGB credit card.
    *   Customer is logged into their Online/Mobile Banking account.
    *   The student for whom payment is being made is already registered and active.
*   **Postconditions:**
    *   Credit Card is debited.
    *   NGB GL accounts are debited, and School account is credited.
    *   A `Transaction` record is created.
    *   A payment confirmation SMS is sent.
    *   An `AuditLog` entry is created.

*   **Main Flow (Happy Path):**
    1.  Customer navigates to "School Fee Payment" section.
    2.  System displays list of active NGB Credit Cards, registered students, and fee types (based on selected school).
    3.  Customer selects:
        *   An active Credit Card.
        *   A registered Student.
        *   A Fee Type.
        *   Enters Amount.
        *   (Optional) Enters 20-character remark.
    4.  System displays payment summary.
    5.  Customer reviews and confirms payment.
    6.  System requests OTP authentication.
    7.  Customer receives OTP via SMS and enters it.
    8.  System authenticates OTP.
    9.  System validates payment (registered student, active card, sufficient balance, daily limits).
    10. System initiates debit on `Cards System` for the Credit Card.
    11. `Cards System` confirms debit and provides a unique transaction reference ID.
    12. System initiates GL postings: Debit NGB GL Account (Visa/MC), Credit School NGB Account.
    13. `GL System` confirms postings.
    14. System creates a `Transaction` record with the unique reference ID and all payment details.
    15. System sends a payment confirmation SMS to the customer.
    16. System records an `AuditLog` entry.
    17. System displays a success message and transaction reference ID to the customer.

*   **Alternative Flows:**
    *   **AF1: View History:**
        1.  Customer navigates to "School Fee Payment" section.
        2.  Customer selects "View History".
        3.  System displays transaction history for the last 6 months (Amount, Date, Student, Remarks).

*   **Exception Flows:**
    *   **EF1: OTP Validation Failed:**
        *   (Steps 1-8 of Main Flow)
        *   8a. OTP is incorrect or expired.
        *   9a. System displays an error: "OTP validation failed. Please try again."
        *   10a. Customer can retry OTP or cancel.
    *   **EF2: Insufficient Card Balance:**
        *   (Steps 1-9 of Main Flow)
        *   10a. `Cards System` returns insufficient balance error.
        *   11a. System displays error: "Payment failed: Insufficient card balance."
        *   12a. System logs the failed transaction.
        *   Flow ends.
    *   **EF3: Invalid Card / Card Status:**
        *   (Steps 1-9 of Main Flow)
        *   10b. `Cards System` returns invalid card or inactive status error.
        *   11b. System displays error: "Payment failed: Invalid or inactive card."
        *   12b. System logs the failed transaction.
        *   Flow ends.
    *   **EF4: Student Not Registered:**
        *   (Initial check at Step 9)
        *   System detects selected student is not active or registered.
        *   System displays error: "Payment only allowed for registered students."
        *   Flow ends.
    *   **EF5: GL Posting Failure:**
        *   (Steps 1-12 of Main Flow)
        *   13a. `GL System` fails to post, or posting confirmation is not received within timeout.
        *   14a. System rolls back card debit (if atomic transaction not supported, a separate reversal is initiated).
        *   15a. System logs critical error for reconciliation and manual intervention.
        *   16a. System displays error: "Payment failed due to internal system error. Please contact customer service."
        *   Flow ends.

*   **Business Rules Applied:**
    *   Only registered students eligible for payment.
    *   Show all active cards for selection.
    *   Option to convert to EPP.
    *   Transaction logged with unique reference ID.
    *   Confirmation SMS sent.
    *   Payment fails if card balance is insufficient.
    *   Optional 20-character remark field.
    *   View history for last 6 months.

#### 3.2.4 Use Case: Convert Payment to EPP (Online/Mobile Banking)

*   **Use Case ID:** UC-EPP-001
*   **Use Case Name:** Convert Fee Payment to Easy Payment Plan (EPP)
*   **Actors:** NGB Customer (Cardholder), NGB Contact Center Agent, Cards Management Team
*   **Description:** Allows a customer to request conversion of a recent fee payment into an Easy Payment Plan (EPP).
*   **Preconditions:**
    *   A fee payment transaction has been successfully completed.
    *   The customer has sufficient balance for EPP conversion (if applicable at conversion time).
*   **Postconditions:**
    *   An `EPP_Request` record is created/updated.
    *   An E-Form is generated for Cards Management Team review.
    *   Customer receives an SMS notification about EPP request status.
    *   An `AuditLog` entry is created.

*   **Main Flow (Happy Path - Online/Mobile):**
    1.  Customer completes a `Fee Payment` transaction (as per UC-PAY-001).
    2.  On the payment confirmation screen, Customer selects the "Convert to EPP" option.
    3.  System displays EPP terms and conditions.
    4.  Customer reviews and confirms EPP conversion request.
    5.  System validates EPP eligibility (e.g., transaction type, customer standing, sufficient balance at conversion time).
    6.  System creates an `EPP_Request` record linked to the `Transaction` and sets its status to 'PENDING'.
    7.  System generates an E-Form in the `E-Form Workflow System` for the Cards Management Team's review and approval.
    8.  System sends an SMS alert to the customer confirming the EPP request submission.
    9.  System records an `AuditLog` entry.
    10. Cards Management Team reviews the E-Form and approves/rejects the EPP.
    11. `E-Form Workflow System` updates the `EPP_Request` status (e.g., 'APPROVED').
    12. System sends an SMS alert to the customer confirming EPP approval.
    13. System updates the original `Transaction` record, setting `is_epp_converted` to TRUE.

*   **Main Flow (Happy Path - Contact Center Assisted):**
    1.  Customer calls Contact Center regarding EPP conversion.
    2.  Agent authenticates customer via IVR TIN.
    3.  Agent accesses `CRM System` and opens an E-Form for EPP conversion.
    4.  Agent manually enters required transaction details for EPP conversion based on customer's request.
    5.  Agent submits the E-Form.
    6.  System (via CRM integration) receives EPP request.
    7.  System validates EPP eligibility (e.g., sufficient balance).
    8.  System creates an `EPP_Request` record linked to the `Transaction` and sets its status to 'PENDING'.
    9.  System updates the E-Form workflow for the Cards Management Team's review and approval.
    10. System sends an SMS alert to the customer confirming the EPP request submission.
    11. System records an `AuditLog` entry.
    12. Cards Management Team reviews the E-Form and approves/rejects the EPP.
    13. `E-Form Workflow System` updates the `EPP_Request` status (e.g., 'APPROVED').
    14. System sends an SMS alert to the customer confirming EPP approval.
    15. System updates the original `Transaction` record, setting `is_epp_converted` to TRUE.

*   **Exception Flows:**
    *   **EF1: Insufficient Balance at Conversion Time:**
        *   (Steps 1-5 of Main Flow - Online/Mobile, or Steps 1-7 of Main Flow - Contact Center)
        *   5a/7a. System detects insufficient balance for EPP conversion (if a separate balance check is performed at conversion).
        *   6a/8a. System rejects the EPP request.
        *   7a/9a. System sends an SMS notification to the customer stating EPP rejection due to insufficient balance.
        *   8a/10a. System records an `AuditLog` entry for the rejection.
        *   Flow ends.
    *   **EF2: EPP Request Rejected by Cards Management:**
        *   (Steps 1-10 of Main Flow)
        *   11a. Cards Management Team rejects the EPP request (e.g., due to internal policy, fraud suspicion).
        *   12a. `E-Form Workflow System` updates `EPP_Request` status to 'REJECTED' with reason.
        *   13a. System sends an SMS alert to the customer confirming EPP rejection and reason.
        *   14a. System records an `AuditLog` entry.
        *   Flow ends.

*   **Business Rules Applied:**
    *   EPP conversion triggers E-Form generation (for Online/Mobile).
    *   E-Form created by agent (for IVR).
    *   EPP request rejected if balance is insufficient at conversion time.
    *   No loyalty points if payment converted to EPP.
    *   SMS notification for EPP rejection due to insufficient balance.

### 3.3 Flowcharts / Pseudocode

#### 3.3.1 Activity Diagram: Make Fee Payment (Online/Mobile Banking)

This diagram visualizes the detailed steps and decision points involved in a customer making a school fee payment via Online or Mobile Banking.

```plantuml
@startuml
skinparam activity {
    BorderColor DarkBlue
    BackgroundColor LightBlue
    ArrowColor Black
}
skinparam note {
    BorderColor DarkGreen
    BackgroundColor LightGreen
}

start
:Customer accesses Fee Payment module;

:System displays active cards, registered students, schools, fee types;

:Customer selects Payment Details (Card, Student, School, Fee Type, Amount, Remark);

:System displays Payment Summary;

:Customer confirms payment;

:System sends OTP to customer;

:Customer enters OTP;

if (OTP Valid and Matched?) then (Yes)
  :System validates Payment Eligibility (Registered Student, Active Card, Daily Limits);
  if (Eligible?) then (Yes)
    :System checks Card System for Available Balance;
    if (Sufficient Balance?) then (Yes)
      :System sends Debit Request to Cards System;
      :Cards System processes Debit and returns Confirmation/Txn Ref ID;
      :System prepares GL Posting Request (Debit GL, Credit School Account);
      :System sends GL Posting Request to GL System;
      :GL System processes Postings and returns Confirmation;
      :System logs Transaction (with unique Ref ID) to Transaction & Audit Log Service;
      :System sends Payment Confirmation SMS to Customer;
      :System acknowledges Payment Success to UI;
      :UI displays Success Message and Txn Ref ID;
    else (No)
      :System sends Payment Failure Message (Insufficient Balance) to UI;
      :UI displays Error Message;
      :Log Failed Transaction (Insufficient Balance);
    endif
  else (No)
    :System sends Payment Failure Message (Not Eligible) to UI;
    :UI displays Error Message;
    :Log Failed Transaction (Eligibility Issue);
  endif
else (No)
  :System sends OTP Validation Failed Message to UI;
  :UI displays OTP Error Message;
  :Log OTP Failure;
endif

stop
@enduml
```

#### 3.3.2 Pseudocode: Fee Posting Logic (Simplified)

This pseudocode outlines the core logic within the `FinancialPostingService` for processing a single fee payment transaction.

```
FUNCTION ProcessFeePosting(transactionDetails: Map<String, Any>): Boolean
    // Input: Map containing transaction details (amount, card number, GL accounts, school account, posting description, etc.)

    DECLARE transactionId = transactionDetails.get("transactionId")
    DECLARE amount = transactionDetails.get("amount")
    DECLARE cardNumber = transactionDetails.get("cardNumber")
    DECLARE glDebitAccount = transactionDetails.get("glDebitAccount") // Based on card type (Visa/MC GL)
    DECLARE schoolCreditAccount = transactionDetails.get("schoolCreditAccount") // School's NGB Account
    DECLARE postingDescription = transactionDetails.get("postingDescription") // Max 40 chars

    LOG_INFO("Initiating fee posting for transaction ID: " + transactionId)

    TRY
        // Step 1: Debit the Credit Card
        // This step is often orchestrated by Payment Orchestration Service
        // For Financial Posting Service, assume card debit is confirmed or
        // it directly integrates with Cards System for financial settlement after initial auth.
        // If this is a two-phase commit, the debit confirmation would precede this.
        // Here, we assume a confirmed debit event triggered this posting.
        // CALL CardsSystemAdapter.performCardDebit(cardNumber, amount, postingDescription)
        // IF debitResponse.isSuccess() == FALSE THEN
        //     LOG_ERROR("Card debit failed for transaction ID: " + transactionId + " Reason: " + debitResponse.getMessage())
        //     UPDATE Transaction.gl_posting_status to 'CARD_DEBIT_FAILED' for transactionId
        //     RETURN FALSE
        // END IF

        // Step 2: Post Debit to NGB GL Account (e.g., Visa/MasterCard GL)
        DECLARE glDebitResponse = CALL GLSystemAdapter.postTransaction(
            transactionType: "DEBIT",
            accountNumber: glDebitAccount,
            amount: amount,
            description: postingDescription
        )

        IF glDebitResponse.isSuccess() == FALSE THEN
            LOG_ERROR("GL Debit posting failed for transaction ID: " + transactionId + " Reason: " + glDebitResponse.getMessage())
            // Implement compensation for card debit if needed, or flag for manual reconciliation
            // Example: CALL CardsSystemAdapter.reverseCardDebit(cardNumber, amount, transactionId)
            UPDATE Transaction.gl_posting_status to 'GL_DEBIT_FAILED' for transactionId
            LOG_TRANSACTION_STATUS("Transaction ID: " + transactionId + " GL Debit Failed")
            RETURN FALSE
        END IF

        // Step 3: Post Credit to School NGB Account
        DECLARE schoolCreditResponse = CALL GLSystemAdapter.postTransaction(
            transactionType: "CREDIT",
            accountNumber: schoolCreditAccount,
            amount: amount,
            description: postingDescription
        )

        IF schoolCreditResponse.isSuccess() == FALSE THEN
            LOG_ERROR("School Credit posting failed for transaction ID: " + transactionId + " Reason: " + schoolCreditResponse.getMessage())
            // Critical failure: Debit was successful but credit failed. Requires robust reconciliation.
            // Possible actions: Manual intervention, automatic reversal of GL debit.
            UPDATE Transaction.gl_posting_status to 'SCHOOL_CREDIT_FAILED' for transactionId
            LOG_TRANSACTION_STATUS("Transaction ID: " + transactionId + " School Credit Failed")
            RETURN FALSE
        END IF

        // Step 4: Update Transaction Status (if not already done by Payment Orchestration)
        UPDATE Transaction.gl_posting_status to 'POSTED' for transactionId
        LOG_INFO("Fee posting successful for transaction ID: " + transactionId)
        LOG_TRANSACTION_STATUS("Transaction ID: " + transactionId + " GL Posting Completed")
        RETURN TRUE

    CATCH Exception as e
        LOG_ERROR("Unexpected error during fee posting for transaction ID: " + transactionId + " Error: " + e.getMessage())
        UPDATE Transaction.gl_posting_status to 'EXCEPTION_OCCURRED' for transactionId
        LOG_TRANSACTION_STATUS("Transaction ID: " + transactionId + " GL Posting Exception: " + e.getMessage())
        RETURN FALSE

END FUNCTION
```

## 4. Module Design

### 4.1 Module Overview

The School Fee Payment System is logically segmented into several distinct modules, each encapsulating specific functionalities and responsibilities. This modular approach enhances maintainability, scalability, and clarity of the system's architecture.

1.  **School Management Module**
    *   **Purpose:** Manages the lifecycle of school entities within the system.
    *   **Functional Responsibilities:**
        *   Registration of new schools, including their name, location, NGB account number, and internal GL account configuration.
        *   Enforcement of business rules for school qualification (e.g., minimum enrolled students, operational years, annual fee collection).
        *   Configuration and management of multiple fee types per registered school.
        *   Providing data for school dropdowns in user interfaces.

2.  **Student Management Module**
    *   **Purpose:** Handles the registration, amendment, and de-registration of students linked to NGB cardholders and registered schools.
    *   **Functional Responsibilities:**
        *   Processing student registration requests from Online/Mobile Banking channels and Contact Center E-Forms.
        *   Validating student details, including ensuring Student ID matches upon double entry.
        *   Authenticating requests via OTP (for online/mobile) or IVR TIN (for Contact Center).
        *   Managing student record updates (amendments) and de-activation (de-registration via soft delete).
        *   Notifying customers via SMS for all student management actions.

3.  **Payment Orchestration Module**
    *   **Purpose:** Coordinates the entire fee payment transaction flow, from initiation to confirmation.
    *   **Functional Responsibilities:**
        *   Receiving payment requests from Online Banking, Mobile Banking, and IVR channels.
        *   Validating payment eligibility (active card, registered student).
        *   Presenting active cards, registered students, and school-specific fee types to the customer.
        *   Handling optional user remarks for transactions.
        *   Initiating card debit requests to the NGB Cards System.
        *   Triggering financial postings to the GL System and School Accounts.
        *   Coordinating with the EPP Conversion Module for installment requests.
        *   Ensuring unique transaction reference IDs are generated and logged.
        *   Sending payment confirmation SMS messages.

4.  **Financial Posting Module**
    *   **Purpose:** Executes the actual financial ledger updates based on successful fee payments.
    *   **Functional Responsibilities:**
        *   Debiting the customer's NGB Credit Card.
        *   Debiting the appropriate NGB GL Account (e.g., Visa Conventional, MasterCard).
        *   Crediting the registered School's NGB Account.
        *   Ensuring transaction description adheres to specified format and length constraints.
        *   Recording the status of GL postings (real-time).
        *   Ensuring individual postings for each student/fee.

5.  **EPP Conversion Module**
    *   **Purpose:** Manages the conversion of eligible fee payments into Easy Payment Plans (EPP).
    *   **Functional Responsibilities:**
        *   Receiving EPP conversion requests from the Payment Orchestration Module.
        *   Validating EPP eligibility, including balance sufficiency at conversion time.
        *   Integrating with the E-Form Workflow System for EPP request processing by the Cards team.
        *   Sending SMS notifications for EPP request rejections.
        *   Ensuring loyalty points are not awarded for EPP-converted payments.

6.  **Notification Module**
    *   **Purpose:** Provides a centralized mechanism for sending automated SMS alerts and confirmations across the system.
    *   **Functional Responsibilities:**
        *   Sending OTPs for authentication.
        *   Delivering SMS alerts for student registration, amendment, and de-registration.
        *   Sending SMS confirmations for successful fee payments.
        *   Notifying customers about EPP request rejections.

7.  **Transaction & Audit Logging Module**
    *   **Purpose:** Maintains a comprehensive, traceable, and immutable record of all significant system activities and financial transactions.
    *   **Functional Responsibilities:**
        *   Logging all transaction details with unique reference IDs.
        *   Recording student management activities (registration, amendment, de-registration).
        *   Logging EPP requests and their status changes.
        *   Providing historical data for reporting and audit purposes.
        *   Storing IVR transaction records (to update ICRS).

8.  **Reporting Module**
    *   **Purpose:** Generates and dispatches required reports to relevant stakeholders.
    *   **Functional Responsibilities:**
        *   Generating daily Excel reports for each registered school, including student ID, name, amount, transaction date, and remarks.
        *   Automating the email delivery of these reports to schools.
        *   Fetching necessary data from the Transaction & Audit Logging Module.

### 4.2 Internal Workflows

Detailed processing logic within key modules:

#### 4.2.1 Fee Payment Processing Workflow (within Payment Orchestration Module)

**Trigger:** Customer initiates a fee payment via Online Banking, Mobile Banking, or IVR.

**Steps:**
1.  **Receive Payment Request:** The `Payment Orchestration Module` receives a request containing customer ID, selected student, school, fee type, amount, chosen NGB credit card (masked), and optional remarks.
2.  **Initial Validation:**
    *   Validate that the customer is an active NGB credit card holder.
    *   Validate that the selected student is registered and active for the chosen school.
    *   Validate that the selected fee type is configured for the chosen school.
    *   Validate the requested amount (e.g., positive, within reasonable limits).
3.  **Authentication (Online/Mobile):**
    *   If the channel is Online/Mobile Banking, the module requests an OTP from the `Authentication Service`.
    *   The customer inputs the OTP, which is then validated. If OTP validation fails, the transaction is rejected.
4.  **Card Verification & Balance Check:**
    *   The module calls the `Cards System Adapter` to verify the active status of the selected credit card and to retrieve the current available balance.
    *   If the card is inactive, blocked, or the balance is insufficient, the payment is rejected.
5.  **Transaction Processing (Atomic):**
    *   If all validations pass and sufficient balance is confirmed:
        *   **Debit Credit Card:** The `Payment Orchestration Module` calls the `Cards System Adapter` to initiate the debit on the customer's credit card.
        *   **Initiate Financial Posting:** The module then asynchronously sends a message to the `Financial Posting Module` with details for GL and school account updates. This asynchronous call ensures non-blocking behavior and resilience for financial updates.
        *   **Log Transaction:** The module generates a unique `transaction_id` and immediately logs the transaction details (including initial status, e.g., 'PENDING_POSTING') to the `Transaction & Audit Logging Module`.
    *   If any of the above steps fail (e.g., card debit rejection), the transaction is marked as 'FAILED', and corresponding logs are recorded.
6.  **Confirmation & Notification:**
    *   Upon successful initiation of the debit and financial posting:
        *   The `Payment Orchestration Module` acknowledges success to the originating UI/IVR channel, providing the unique transaction reference ID.
        *   It then triggers the `Notification Module` to send a payment confirmation SMS to the customer.
7.  **EPP Conversion Option:**
    *   If the customer opted for EPP conversion, the `Payment Orchestration Module` sends a request to the `EPP Conversion Module` with the transaction ID and relevant payment details.

**Outputs:**
*   Real-time transaction acknowledgment (success/failure) to the customer.
*   SMS confirmation to the customer.
*   Updated records in `TRANSACTION` and `AUDIT_LOG` tables.
*   Asynchronous financial posting requests.

#### 4.2.2 Student Management Workflow (within Student Management Module)

**Trigger:** Customer (Online/Mobile Banking) or Contact Center Agent (E-Form) initiates student registration, amendment, or de-registration.

**Steps:**
1.  **Receive Request:** The `Student Management Module` receives a request from Online Banking, Mobile Banking, or the Contact Center E-Form, specifying the action (Register, Amend, De-register) and student details.
2.  **Channel-Specific Authentication & Validation:**
    *   **Online/Mobile Banking:**
        *   The module integrates with the `Authentication Service` to perform OTP validation for the customer.
        *   For registration, it validates that the `Student ID` entered twice matches.
    *   **Contact Center E-Form:**
        *   Assumes the `IVR TIN` authentication has been performed by the IVR System and confirmed by the agent.
        *   Enforces restrictions on copy-paste for the `Student ID` field within the E-Form (UI-level control).
3.  **Business Rule Validation:**
    *   For registration, it verifies if the student (by name/ID combination) is not already registered under the same school by the same cardholder.
    *   Ensures the requesting customer is an active cardholder.
4.  **Process Action:**
    *   **Registration:** A new record is created in the `STUDENT` table.
    *   **Amendment:** The existing `STUDENT` record is updated with new details.
    *   **De-registration:** The `status` field of the `STUDENT` record is updated to 'DE-REGISTERED' (soft delete to preserve audit trail).
5.  **Logging & Notification:**
    *   For every action (registration, amendment, de-registration), the module logs a detailed activity entry in the `Transaction & Audit Logging Module`.
    *   The `Notification Module` is triggered to send an SMS alert to the customer confirming the student management action.

**Outputs:**
*   Updated `STUDENT` records in the database.
*   Entries in the `AUDIT_LOG` table.
*   SMS alerts to the customer.

### 4.3 Data Dictionary

This section describes the major data elements used across the School Fee Payment System.

#### `SCHOOL` Table

| Field Name                  | Data Type      | Description                                                          | Source/Target                 | Constraints                                                    |
| :-------------------------- | :------------- | :------------------------------------------------------------------- | :---------------------------- | :------------------------------------------------------------- |
| `school_id`                 | VARCHAR(50)    | Unique identifier for the school.                                    | System Generated              | PK, NOT NULL, Unique                                           |
| `school_name`               | VARCHAR(255)   | Full legal name of the school.                                       | Admin Portal UI / Product Team| NOT NULL, Unique                                               |
| `location`                  | VARCHAR(255)   | Geographical location of the school (e.g., address, city, country).  | Admin Portal UI / Product Team| NOT NULL                                                       |
| `ngb_account_number`        | VARCHAR(50)    | School's dedicated NGB bank account number for fee crediting.        | Admin Portal UI / Product Team| NOT NULL, Unique, Valid NGB Account Format, Numeric            |
| `ngb_gl_account_config`     | VARCHAR(100)   | Internal GL account identifier or mapping for the school.            | Internal Configuration        | NOT NULL, Valid GL Account                                     |
| `registration_date`         | TIMESTAMP      | Date and time the school was registered in the system.               | System Generated              | NOT NULL, Default to current timestamp                         |
| `is_active`                 | BOOLEAN        | Status indicating if the school is active for fee payments.          | Admin Portal UI / System      | NOT NULL, Default TRUE                                         |
| `min_enrolled_students`     | INT            | Business rule: Minimum students required for school qualification.   | Configuration                 | NOT NULL, >= 1000                                              |
| `operational_years`         | INT            | Business rule: Minimum years school must be operational.             | Configuration                 | NOT NULL, >= 3                                                 |
| `min_annual_fee_collection` | DECIMAL(18,2)  | Business rule: Minimum annual fee collection required (in EUR).      | Configuration                 | NOT NULL, >= 500000.00                                         |

#### `FEE_TYPE` Table

| Field Name    | Data Type      | Description                                                  | Source/Target           | Constraints                                                |
| :------------ | :------------- | :----------------------------------------------------------- | :---------------------- | :--------------------------------------------------------- |
| `fee_type_id` | INT            | Unique identifier for the fee type.                          | System Generated        | PK, NOT NULL, Unique                                       |
| `school_id`   | VARCHAR(50)    | Foreign key referencing `SCHOOL.school_id`.                  | School Management Module| FK to `SCHOOL.school_id`, NOT NULL                         |
| `fee_type_name` | VARCHAR(100)   | Name of the fee type (e.g., "School Fee", "Bus Fee").        | Admin Portal UI         | NOT NULL, Unique per school (`school_id`, `fee_type_name`) |
| `description` | VARCHAR(255)   | Optional detailed description of the fee type.               | Admin Portal UI         | NULLABLE                                                   |

#### `CUSTOMER` Table (Assumed replicated/integrated from core banking)

| Field Name      | Data Type      | Description                                                  | Source/Target      | Constraints                                                |
| :-------------- | :------------- | :----------------------------------------------------------- | :----------------- | :--------------------------------------------------------- |
| `customer_id`   | VARCHAR(50)    | Unique identifier for the NGB customer (cardholder).         | CRM System         | PK, NOT NULL, Unique                                       |
| `customer_name` | VARCHAR(255)   | Full name of the customer.                                   | CRM System         | NOT NULL                                                   |
| `contact_info`  | VARCHAR(255)   | Customer's primary contact (e.g., masked phone number/email).| CRM System         | NOT NULL (for SMS notifications)                           |
| `status`        | VARCHAR(20)    | Current status of the customer (e.g., 'ACTIVE', 'INACTIVE'). | CRM System         | NOT NULL, ENUM ('ACTIVE', 'INACTIVE', 'BLOCKED')           |

#### `CREDIT_CARD` Table (Assumed replicated/integrated from Cards System)

| Field Name    | Data Type      | Description                                                  | Source/Target      | Constraints                                                |
| :------------ | :------------- | :----------------------------------------------------------- | :----------------- | :--------------------------------------------------------- |
| `card_number` | VARCHAR(20)    | Unique credit card number (masked and encrypted in storage). | Cards System       | PK, NOT NULL, Unique, Encrypted/Masked                   |
| `customer_id` | VARCHAR(50)    | Foreign key referencing `CUSTOMER.customer_id`.              | Cards System       | FK to `CUSTOMER.customer_id`, NOT NULL                     |
| `card_type`   | VARCHAR(50)    | Type of credit card (e.g., 'VISA_CONVENTIONAL', 'MASTERCARD').| Cards System       | NOT NULL, ENUM ('VISA_CONVENTIONAL', 'VISA_ISLAMIC', 'MASTERCARD') |
| `expiry_date` | DATE           | Expiry date of the credit card.                              | Cards System       | NOT NULL                                                   |
| `balance`     | DECIMAL(18,2)  | Current available balance on the credit card.                | Cards System       | NOT NULL, >= 0 (real-time check)                           |
| `status`      | VARCHAR(20)    | Status of the credit card (e.g., 'ACTIVE', 'INACTIVE', 'BLOCKED').| Cards System       | NOT NULL, ENUM ('ACTIVE', 'INACTIVE', 'BLOCKED')           |

#### `STUDENT` Table

| Field Name                | Data Type      | Description                                                          | Source/Target                 | Constraints                                                    |
| :------------------------ | :------------- | :------------------------------------------------------------------- | :---------------------------- | :------------------------------------------------------------- |
| `student_id`              | VARCHAR(50)    | Unique identifier for the student within a specific school.          | Online/Mobile UI / E-Form     | PK (part of composite key), NOT NULL                         |
| `school_id`               | VARCHAR(50)    | Foreign key referencing `SCHOOL.school_id`.                          | Online/Mobile UI / E-Form     | PK (part of composite key), FK to `SCHOOL.school_id`, NOT NULL |
| `student_name`            | VARCHAR(255)   | Full name of the student.                                            | Online/Mobile UI / E-Form     | NOT NULL                                                       |
| `registered_by_customer_id`| VARCHAR(50)    | Foreign key referencing `CUSTOMER.customer_id` (the cardholder who registered this student).| System Derived                | FK to `CUSTOMER.customer_id`, NOT NULL                         |
| `registration_date`       | TIMESTAMP      | Date and time the student was initially registered.                  | System Generated              | NOT NULL, Default to current timestamp                         |
| `status`                  | VARCHAR(20)    | Current status of the student (e.g., 'ACTIVE', 'DE-REGISTERED').     | Student Management Module     | NOT NULL, ENUM ('ACTIVE', 'DE-REGISTERED')                     |

#### `TRANSACTION` Table

| Field Name            | Data Type      | Description                                                          | Source/Target                 | Constraints                                                    |
| :-------------------- | :------------- | :------------------------------------------------------------------- | :---------------------------- | :------------------------------------------------------------- |
| `transaction_id`      | VARCHAR(50)    | Unique identifier for each fee payment transaction.                  | System Generated              | PK, NOT NULL, Unique, (Matches "unique reference ID")          |
| `transaction_date_time`| TIMESTAMP      | Date and time when the payment transaction occurred.                 | System Generated              | NOT NULL, Default to current timestamp                         |
| `amount`              | DECIMAL(18,2)  | The amount of the fee payment.                                       | Online/Mobile UI / IVR        | NOT NULL, > 0                                                  |
| `card_number`         | VARCHAR(20)    | Foreign key referencing `CREDIT_CARD.card_number` used for payment.  | Online/Mobile UI / IVR        | FK to `CREDIT_CARD.card_number`, NOT NULL                      |
| `student_id`          | VARCHAR(50)    | Foreign key referencing `STUDENT.student_id` for whom payment is made.| Online/Mobile UI / IVR        | FK to `STUDENT.student_id`, NOT NULL                           |
| `school_id`           | VARCHAR(50)    | Foreign key referencing `SCHOOL.school_id` to which payment is made. | Online/Mobile UI / IVR        | FK to `SCHOOL.school_id`, NOT NULL                             |
| `fee_type_id`         | INT            | Foreign key referencing `FEE_TYPE.fee_type_id`.                      | Online/Mobile UI / IVR        | FK to `FEE_TYPE.fee_type_id`, NOT NULL                         |
| `remark`              | VARCHAR(20)    | Optional remark provided by the user (max 20 characters).            | Online/Mobile UI              | NULLABLE, Max length 20 characters                             |
| `status`              | VARCHAR(20)    | Current status of the transaction (e.g., 'SUCCESS', 'FAILED', 'PENDING_EPP').| Payment Orchestration Module  | NOT NULL, ENUM ('SUCCESS', 'FAILED', 'PENDING_EPP', 'REJECTED')|
| `posting_description` | VARCHAR(40)    | Formatted description used for GL postings.                          | Financial Posting Module      | NOT NULL, Max length 40 characters                             |
| `is_epp_converted`    | BOOLEAN        | Flag indicating if this payment has been converted to an EPP.        | EPP Conversion Module         | NOT NULL, Default FALSE                                        |
| `gl_posting_status`   | VARCHAR(20)    | Status of the GL posting for this transaction.                       | Financial Posting Module      | NOT NULL, ENUM ('PENDING', 'POSTED', 'FAILED')                 |
| `is_loyalty_eligible` | BOOLEAN        | Flag indicating if the payment is eligible for loyalty points.       | EPP Conversion Module         | NOT NULL, Default TRUE, Set to FALSE if `is_epp_converted` is TRUE |

#### `EPP_REQUEST` Table

| Field Name        | Data Type      | Description                                                          | Source/Target                 | Constraints                                                    |
| :---------------- | :------------- | :------------------------------------------------------------------- | :---------------------------- | :------------------------------------------------------------- |
| `epp_request_id`  | VARCHAR(50)    | Unique identifier for the EPP request.                               | System Generated              | PK, NOT NULL, Unique                                           |
| `transaction_id`  | VARCHAR(50)    | Foreign key referencing `TRANSACTION.transaction_id`.                | Payment Orchestration Module  | PK (part of composite key), FK to `TRANSACTION.transaction_id`, NOT NULL, Unique (1:1 relationship with TRANSACTION) |
| `request_date_time`| TIMESTAMP      | Date and time when the EPP conversion was requested.                 | System Generated              | NOT NULL, Default to current timestamp                         |
| `status`          | VARCHAR(20)    | Current status of the EPP request (e.g., 'PENDING', 'APPROVED', 'REJECTED').| EPP Conversion Module         | NOT NULL, ENUM ('PENDING', 'APPROVED', 'REJECTED')             |
| `rejection_reason`| VARCHAR(255)   | Reason for EPP request rejection, if applicable.                     | EPP Conversion Module         | NULLABLE                                                       |

#### `AUDIT_LOG` Table

| Field Name                | Data Type      | Description                                                          | Source/Target                 | Constraints                                                    |
| :------------------------ | :------------- | :------------------------------------------------------------------- | :---------------------------- | :------------------------------------------------------------- |
| `log_id`                  | BIGINT         | Unique identifier for each audit log entry.                          | System Generated              | PK, NOT NULL, Unique, Auto-increment                           |
| `activity_type`           | VARCHAR(100)   | Type of activity logged (e.g., 'STUDENT_REGISTRATION_SUCCESS', 'PAYMENT_FAILED').| Various Modules (e.g., Student, Payment, EPP, School) | NOT NULL                                                       |
| `entity_id_affected`      | VARCHAR(50)    | Identifier of the primary entity affected by the activity.           | Various Modules               | NOT NULL (e.g., `student_id`, `transaction_id`, `school_id`)   |
| `entity_type`             | VARCHAR(50)    | Type of entity affected (e.g., 'STUDENT', 'TRANSACTION', 'SCHOOL').  | Various Modules               | NOT NULL, ENUM ('SCHOOL', 'STUDENT', 'TRANSACTION', 'EPP_REQUEST') |
| `timestamp`               | TIMESTAMP      | Date and time when the activity occurred.                            | System Generated              | NOT NULL, Default to current timestamp                         |
| `performed_by_user_or_system`| VARCHAR(100)   | Identifier of the user or system component that performed the action.| Various Modules               | NOT NULL (e.g., `customer_id`, 'System', 'ContactCenterAgent') |
| `details`                 | TEXT           | Additional context or message, e.g., SMS content, error message.     | Various Modules               | NULLABLE, JSONB for structured details                         |

## 5. Class & Object Design

### 5.1 Class Diagram

The detailed class diagram below illustrates the core domain entities of the NGB School Fee Payment System, their attributes, methods, and relationships. It also includes the key service classes responsible for implementing the business logic and interacting with both the domain entities and external systems via adapters.

The diagram adheres to standard UML notation, using associations (`---`) to denote relationships between classes, with multiplicities (e.g., "1" for one, "0..*" for zero to many). Dependencies (`..>`) indicate that one class uses or depends on another (e.g., a service depends on a domain entity or an adapter). Methods are listed with their return types and parameters, and attributes with their types.

```plantuml
@startuml
skinparam handwritten false
skinparam class {
    BorderColor DarkSlateGrey
    BackgroundColor LightYellow
    ArrowColor DarkSlateGrey
    AttributeFontColor DarkSlateGrey
    MethodFontColor DarkSlateGrey
}
skinparam interface {
    BorderColor RoyalBlue
    BackgroundColor AliceBlue
    ArrowColor DarkSlateGrey
}
hide empty members

title NGB School Fee Payment System - Detailed Class Diagram

' Domain Entities
class School {
    - schoolId: String
    - name: String
    - location: String
    - ngbAccountNumber: String
    - ngbGlAccountConfig: String
    - registrationDate: Date
    - isActive: boolean
    - minEnrolledStudents: int
    - operationalYears: int
    - minAnnualFeeCollection: double
    + applyBusinessRules(): boolean
}

class FeeType {
    - feeTypeId: String
    - name: String
    - description: String
}

class Customer {
    - customerId: String
    - name: String
    - contactInfo: String
    - status: String // ACTIVE, INACTIVE
    + isActiveCardholder(): boolean
}

class CreditCard {
    - cardNumber: String
    - customerId: String
    - cardType: String // VISA_CONVENTIONAL, MASTERCARD etc.
    - expiryDate: Date
    - balance: double // Current balance (may be dynamic/real-time)
    - status: String // ACTIVE, INACTIVE, BLOCKED
    + isCardActive(): boolean
    + hasSufficientBalance(amount: double): boolean
}

class Student {
    - studentId: String
    - name: String
    - registeredByCustomerId: String
    - schoolId: String
    - registrationDate: Date
    - status: String // REGISTERED, DE_REGISTERED
    + isRegistered(): boolean
}

class Transaction {
    - transactionId: String // Unique reference ID
    - transactionDateTime: Date
    - amount: double
    - remark: String (max 20 chars)
    - status: String // SUCCESS, FAILED, PENDING_EPP, CANCELLED
    - postingDescription: String (max 40 chars)
    - isEPPConverted: boolean
    - glPostingStatus: String // PENDING, POSTED, FAILED
    + updateStatus(newStatus: String)
}

class EPPRequest {
    - eppRequestId: String
    - requestDateTime: Date
    - status: String // PENDING, APPROVED, REJECTED
    - rejectionReason: String
    + updateStatus(newStatus: String, reason: String)
}

class AuditLog {
    - logId: String
    - activityType: String
    - entityIdAffected: String
    - entityType: String
    - timestamp: Date
    - performedByUserOrSystem: String
    - details: String // JSONB/TEXT for additional context
}

' Service Classes - encapsulate business logic and orchestrate operations
class SchoolManagementService {
    + registerSchool(schoolData: Map<String, String>): School
    + updateSchoolDetails(schoolId: String, updateData: Map<String, String>): School
    + getSchoolById(schoolId: String): School
    + getFeeTypesBySchool(schoolId: String): List<FeeType>
    + validateSchoolEligibility(schoolData: Map<String, String>): boolean
}

class StudentManagementService {
    + registerStudent(studentData: Map<String, String>, customerId: String): Student
    + amendStudent(studentId: String, schoolId: String, updateData: Map<String, String>): Student
    + deRegisterStudent(studentId: String, schoolId: String): boolean
    + getStudentsByCustomerId(customerId: String): List<Student>
    + isStudentRegistered(studentId: String, schoolId: String): boolean
}

class PaymentOrchestrationService {
    + processFeePayment(paymentDetails: Map<String, String>, customerId: String): Transaction
    + viewPaymentHistory(customerId: String, months: int): List<Transaction>
    + initiateEPPConversion(transactionId: String, customerId: String): EPPRequest
}

class FinancialPostingService {
    + debitCreditCard(cardNumber: String, amount: double, description: String): boolean
    + postGLTransactions(transaction: Transaction): boolean
    + creditSchoolAccount(schoolAccountNumber: String, amount: double, description: String): boolean
}

class EPPConversionService {
    + evaluateAndProcessEPP(eppRequest: EPPRequest, transaction: Transaction): EPPRequest
    + rejectEPP(eppRequest: EPPRequest, reason: String): EPPRequest
}

class NotificationService {
    + sendSMS(phoneNumber: String, message: String): boolean
    + sendEmail(recipient: String, subject: String, body: String, attachment: byte[]): boolean
}

class TransactionAndAuditLogService {
    + saveTransaction(transaction: Transaction): Transaction
    + logAuditEntry(auditLog: AuditLog): AuditLog
    + getTransactionLogs(criteria: Map<String, String>): List<Transaction>
}

class ReportingService {
    + generateDailySchoolReport(schoolId: String, date: Date): byte[]
    + dispatchDailyReport(schoolId: String, date: Date): boolean
}

' Adapters - provide interfaces to external systems
class CardsSystemAdapter {
    + retrieveCardDetails(cardNumber: String, customerId: String): CreditCard
    + performCardDebit(cardNumber: String, amount: double): boolean
}

class GLSystemAdapter {
    + postDebitEntry(glAccount: String, amount: double, description: String): boolean
    + postCreditEntry(glAccount: String, amount: double, description: String): boolean
}

class SMSGatewayAdapter {
    + sendMessage(phoneNumber: String, message: String): boolean
}

class CRMAdapter {
    + createEForm(formData: Map<String, String>): boolean
    + getCustomerDetails(customerId: String): Customer
}

class AuthenticationAdapter {
    + validateOTP(otp: String, identifier: String): boolean
    + validateIVRTIN(tin: String, identifier: String): boolean
}

' Relationships: Domain Entities (Associations)
School "1" --- "0..*" FeeType : configures
School "1" --- "0..*" Student : enrolls
Customer "1" --- "0..*" CreditCard : owns
Customer "1" --- "0..*" Student : registers

CreditCard "1" --- "0..*" Transaction : used in
Student "1" --- "0..*" Transaction : for
FeeType "1" --- "0..*" Transaction : type
School "1" --- "0..*" Transaction : receives

Transaction "1" --- "0..1" EPPRequest : converts to

' Relationships: Services to Domain Entities (Dependencies / Uses)
SchoolManagementService ..> School : manages
SchoolManagementService ..> FeeType : manages

StudentManagementService ..> Student : manages
StudentManagementService ..> Customer : accesses

PaymentOrchestrationService ..> Transaction : orchestrates
PaymentOrchestrationService ..> Student : validates
PaymentOrchestrationService ..> CreditCard : validates

FinancialPostingService ..> Transaction : affects
FinancialPostingService ..> CreditCard : interacts

EPPConversionService ..> EPPRequest : processes
EPPConversionService ..> Transaction : relates to

NotificationService ..> SMSGatewayAdapter : sends messages via

TransactionAndAuditLogService ..> Transaction : persists
TransactionAndAuditLogService ..> AuditLog : persists

ReportingService ..> Transaction : queries
ReportingService ..> School : queries

' Relationships: Service-to-Service / Service-to-Adapter Dependencies
PaymentOrchestrationService ..> StudentManagementService
PaymentOrchestrationService ..> CardsSystemAdapter
PaymentOrchestrationService ..> FinancialPostingService
PaymentOrchestrationService ..> EPPConversionService
PaymentOrchestrationService ..> NotificationService
PaymentOrchestrationService ..> TransactionAndAuditLogService
PaymentOrchestrationService ..> AuthenticationAdapter

StudentManagementService ..> NotificationService
StudentManagementService ..> AuthenticationAdapter
StudentManagementService ..> TransactionAndAuditLogService

SchoolManagementService ..> TransactionAndAuditLogService

FinancialPostingService ..> CardsSystemAdapter
FinancialPostingService ..> GLSystemAdapter

EPPConversionService ..> CardsSystemAdapter
EPPConversionService ..> CRMAdapter
EPPConversionService ..> NotificationService
EPPConversionService ..> TransactionAndAuditLogService

ReportingService ..> TransactionAndAuditLogService
ReportingService ..> NotificationService 

@enduml
```

### 5.2 Object Diagram

This object diagram illustrates a specific instance of a typical scenario: a customer making a successful school fee payment for a student, followed by an EPP conversion request. It shows how concrete objects of various classes relate to each other at a particular point in time, along with their attribute values.

```plantuml
@startuml
skinparam object {
    BorderColor RoyalBlue
    BackgroundColor AliceBlue
    FontColor DarkSlateGrey
    ArrowColor DarkSlateGrey
}
hide empty members

title NGB School Fee Payment System - Object Diagram (Scenario: Fee Payment with EPP Option)

object "schoolA: School" as SchoolA {
    schoolId = "EUR-001"
    name = "Europe School"
    ngbAccountNumber = "1234567890"
    isActive = true
}

object "schoolFee: FeeType" as FeeTypeSF {
    feeTypeId = "FT-SF"
    name = "School Fee"
    description = "Standard school tuition"
}

object "customer1: Customer" as Customer1 {
    customerId = "CUST-001"
    name = "Alice Wonderland"
    status = "ACTIVE"
}

object "cardX: CreditCard" as CardX {
    cardNumber = "************1234"
    customerId = "CUST-001"
    cardType = "VISA_CONVENTIONAL"
    balance = 1000.00
    status = "ACTIVE"
}

object "student1: Student" as Student1 {
    studentId = "STU-1001"
    name = "Bob Wonderland"
    registeredByCustomerId = "CUST-001"
    schoolId = "EUR-001"
    status = "REGISTERED"
}

object "transaction1: Transaction" as Txn1 {
    transactionId = "TXN-20240315-0001"
    transactionDateTime = 2024-03-15 10:30:00
    amount = 500.00
    remark = "March Tuition"
    status = "SUCCESS"
    isEPPConverted = true
    glPostingStatus = "POSTED"
}

object "eppRequest1: EPPRequest" as EPP1 {
    eppRequestId = "EPP-20240315-0001"
    requestDateTime = 2024-03-15 10:32:00
    status = "APPROVED"
    rejectionReason = "N/A"
}

object "auditLogPayment: AuditLog" as Audit1 {
    logId = "AUD-TXN-001"
    activityType = "FEE_PAYMENT_SUCCESS"
    entityIdAffected = "TXN-20240315-0001"
    entityType = "TRANSACTION"
    timestamp = 2024-03-15 10:30:15
    performedByUserOrSystem = "Online Banking System"
    details = "{'amount': 500.0, 'cardLast4': '1234'}"
}

object "auditLogEPP: AuditLog" as Audit2 {
    logId = "AUD-EPP-001"
    activityType = "EPP_CONVERSION_APPROVED"
    entityIdAffected = "EPP-20240315-0001"
    entityType = "EPP_REQUEST"
    timestamp = 2024-03-15 10:35:00
    performedByUserOrSystem = "EPPConversionService"
    details = "{'transactionId': 'TXN-20240315-0001', 'status': 'APPROVED'}"
}

' Links between objects, reflecting class relationships
SchoolA "registers" -- Student1
SchoolA "offers" -- FeeTypeSF

Customer1 "owns" -- CardX
Customer1 "registers" -- Student1

Txn1 "used by" -- CardX
Txn1 "for" -- Student1
Txn1 "type" -- FeeTypeSF
Txn1 "receives payment" -- SchoolA

Txn1 "converts to" -- EPP1

Audit1 "logs activity of" -- Txn1
Audit2 "logs activity of" -- EPP1

@enduml
```

## 6. Behavior Design

### 6.1 Sequence Diagram: Fee Payment via Online/Mobile Banking

This sequence diagram illustrates the typical flow for a customer making a school fee payment using Online or Mobile Banking, including the required validations and integrations.

```plantuml
@startuml
skinparam handwritten false
skinparam participant {
    BorderColor RoyalBlue
    BackgroundColor AliceBlue
    ArrowColor DarkSlateGrey
}
skinparam actor {
    BorderColor DarkGreen
    BackgroundColor LightGreen
}
skinparam box {
    BorderColor MidnightBlue
    BackgroundColor LightSteelBlue
}

actor Customer
participant "Online/Mobile Banking App" as UI
participant "NGB School Fee Payment System" as NGBSystem
participant "NGB Cards System" as CardsSystem
participant "NGB GL System" as GLSystem
participant "SMS Gateway" as SMSGateway

box "NGB Bank Internal Systems"
    NGBSystem -[hidden]-> CardsSystem
    CardsSystem -[hidden]-> GLSystem
end box

Customer -> UI: Access Fee Payment
activate UI
UI -> NGBSystem: Request Registered Students/Schools (for Customer)
activate NGBSystem
NGBSystem --> UI: List of Students, Schools, Fee Types, Active Cards
deactivate NGBSystem

Customer -> UI: Select Student, School, Fee Type, Amount, Card, (Optional) Remark
activate UI
UI -> UI: Display Payment Summary
Customer -> UI: Confirm Payment

UI -> NGBSystem: Initiate Payment Request (with OTP)
activate NGBSystem
NGBSystem -> NGBSystem: Validate Input Data
NGBSystem -> NGBSystem: Perform OTP Authentication
alt OTP Validated
    NGBSystem -> CardsSystem: Verify Card Status & Balance
    activate CardsSystem
    CardsSystem --> NGBSystem: Card Status & Available Balance
    deactivate CardsSystem

    alt Sufficient Balance & Valid Card
        NGBSystem -> CardsSystem: Debit Credit Card (Amount, Desc: max 40 chars)
        activate CardsSystem
        CardsSystem --> NGBSystem: Debit Confirmation (Txn Ref ID)
        deactivate CardsSystem

        NGBSystem -> GLSystem: Post Debit GL Account (Visa/MC)
        activate GLSystem
        GLSystem --> NGBSystem: GL Debit Confirmation
        deactivate GLSystem

        NGBSystem -> GLSystem: Post Credit School Account
        activate GLSystem
        GLSystem --> NGBSystem: School Credit Confirmation
        deactivate GLSystem

        NGBSystem -> NGBSystem: Log Transaction (Unique Ref ID, All Details)
        NGBSystem -> SMSGateway: Send Payment Confirmation SMS
        activate SMSGateway
        SMSGateway --> NGBSystem: SMS Sent Ack
        deactivate SMSGateway
        NGBSystem --> UI: Payment Success Acknowledgment
        deactivate NGBSystem
        UI --> Customer: Display Success Message & Txn Ref ID
        deactivate UI
    else Insufficient Balance or Invalid Card
        CardsSystem --> NGBSystem: Payment Rejection
        deactivate CardsSystem
        NGBSystem --> UI: Payment Failure (Insufficient Balance/Invalid Card)\n(System logs failure)
        deactivate NGBSystem
        UI --> Customer: Display Error Message
        deactivate UI
    end alt
else OTP Invalid
    NGBSystem --> UI: OTP Validation Failed
    deactivate NGBSystem
    UI --> Customer: Display OTP Error
    deactivate UI
end alt

@enduml
```

### 6.2 Communication Diagram: Fee Payment Flow

This communication diagram emphasizes the message flow and relationships between objects during a fee payment transaction.

```plantuml
@startuml
skinparam handwritten false
skinparam actor {
    BorderColor DarkGreen
    BackgroundColor LightGreen
}
skinparam participant {
    BorderColor RoyalBlue
    BackgroundColor AliceBlue
}
skinparam cloud {
    BorderColor MidnightBlue
    BackgroundColor LightSteelBlue
}

title Communication Diagram: Fee Payment Flow

actor Customer
participant "Online/Mobile Banking App" as UI
cloud "NGB School Fee Payment System" as NGBSystem
participant "NGB Cards System" as CardsSystem
participant "NGB GL System" as GLSystem
participant "SMS Gateway" as SMSGateway

Customer -- UI : 1: Access Payment
UI -- NGBSystem : 2: Request Student/School Data
NGBSystem -- UI : 3: Return Student/School Data
Customer -- UI : 4: Select Details & Confirm
UI -- NGBSystem : 5: Initiate Payment (with OTP)
NGBSystem -- CardsSystem : 6: Verify Card Status/Balance
CardsSystem -- NGBSystem : 7: Card Status/Balance Info
NGBSystem -- CardsSystem : 8: Debit Card
CardsSystem -- NGBSystem : 9: Debit Confirmation
NGBSystem -- GLSystem : 10: Post GL Debit (Credit Card GL)
GLSystem -- NGBSystem : 11: GL Debit Confirmation
NGBSystem -- GLSystem : 12: Post GL Credit (School Account)
GLSystem -- NGBSystem : 13: GL Credit Confirmation
NGBSystem -- UI : 14: Payment Success/Failure
UI -- Customer : 15: Display Result
NGBSystem -- SMSGateway : 16: Send Confirmation SMS
SMSGateway -- NGBSystem : 17: SMS Sent Ack

@enduml
```

### 6.3 State Diagram: Fee Payment Transaction

This state diagram illustrates the lifecycle and possible status transitions of a fee payment transaction within the system.

```plantuml
@startuml
skinparam state {
    BorderColor RoyalBlue
    BackgroundColor AliceBlue
    ArrowColor DarkSlateGrey
    FontColor DarkSlateGrey
}
skinparam note {
    BorderColor DarkGreen
    BackgroundColor LightGreen
    FontColor DarkGreen
}

title State Diagram for Fee Payment Transaction

[*] --> PaymentInitiated : Customer initiates payment

state PaymentInitiated {
  PaymentInitiated --> PaymentValidationPending : Data submitted
  PaymentValidationPending --> CardVerificationPending : Input Validated, OTP Passed
  CardVerificationPending --> CardDebited : Card Valid & Balance OK
  CardVerificationPending --> PaymentDeclined : Card Invalid / Insufficient Balance
  PaymentValidationPending --> PaymentDeclined : Input Validation Failed / OTP Failed
}

CardDebited --> GLPostingPending : Card Debit Confirmed

GLPostingPending --> TransactionComplete : GL Postings Successful
GLPostingPending --> GLPostingFailed : GL Postings Failed

TransactionComplete --> EPPRequested : Customer opts for EPP conversion
EPPRequested --> EPPApproved : EPP Request Processed Successfully
EPPRequested --> EPPRejected : EPP Request Rejected (e.g., Insufficient Balance)

PaymentDeclined --> [*] : Notify Customer
GLPostingFailed --> [*] : Notify Customer & Operations (for reconciliation)
EPPApproved --> [*] : Notify Customer
EPPRejected --> [*] : Notify Customer

state PaymentDeclined #red
state GLPostingFailed #red
state EPPRejected #orange
state TransactionComplete #green

@enduml
```

### 6.4 Activity Diagram: Student Registration/Amendment/De-registration

This activity diagram illustrates the workflow for managing student registrations, amendments, and de-registrations, covering both online/mobile banking and contact center channels.

```plantuml
@startuml
skinparam activity {
    BorderColor DarkBlue
    BackgroundColor LightBlue
    ArrowColor Black
}
skinparam note {
    BorderColor DarkGreen
    BackgroundColor LightGreen
}

start
:Customer/Agent initiates Student Management;\r
\r
if (Channel is Online/Mobile Banking) then (Online/Mobile)\r
    :Customer logs in;\r
    :Authenticate User (OTP Mandatory);\r
    note right: SMS for registration/amendment/de-registration\r
    if (Authentication Successful) then (Authenticated)\r
        :Customer inputs Student Name, Student ID (twice), Select School (Dropdown);\r
        note right: Student ID must be entered twice and match\r
        if (Student IDs Match) then (IDs Match)\r
            :Submit request to NGB System;\r
            :NGB System processes Student Registration / Amendment / De-registration;\r
            :Send SMS Alert for confirmation;\r
        else (IDs Mismatch)\r
            :Display Error: Student IDs do not match;\r
            stop\r
        endif\r
    else (Authentication Failed)\r
        :Display Error: OTP Invalid;\r
        stop\r
    endif\r
else (Contact Center - E-Form)\r
    :Customer calls Contact Center;\r
    :Authenticate via IVR TIN;\r
    if (Authentication Successful) then (Authenticated)\r
        :Agent accesses E-Form;\r
        :Agent manually inputs Student Name, Student ID, Select School;\r
        note right: Restrict copy-paste on Student ID\r
        :NGB System processes Student Registration / Amendment / De-registration;\r
        :Send SMS Alert post-processing;\r
    else (Authentication Failed)\r
        :Agent informs Customer: IVR TIN Authentication Failed;\r
        stop\r
    endif\r
endif\r
\r
:Log Student Management Activity;\r
end
@enduml
```

## 7. Structural Design

### 7.1 Package Diagram: Depicts grouping of related classes/modules and dependencies.

The following package diagram illustrates the high-level logical structure of the School Fee Payment System, showing the primary packages (logical modules) and their dependencies on each other and external systems. This view emphasizes how different sets of functionalities are grouped and how they interact.

```plantuml
@startuml
skinparam package {
    BorderColor DarkBlue
    BackgroundColor LightCyan
    ArrowColor Black
}
skinparam component {
    BorderColor Teal
    BackgroundColor LightYellow
    ArrowColor DarkGreen
}
skinparam rectangle {
    BorderColor DarkRed
    BackgroundColor LightCoral
}

' High-level packages representing logical modules
package "User Channels" as Channels {
    component "Online Banking UI" as OnlineBanking
    component "Mobile Banking UI" as MobileBanking
    component "Contact Center E-Form" as EForm
    component "IVR System Interface" as IVR
}

package "Core Business Logic" as CoreServices {
    component "School Management Service" as SchoolSvc
    component "Student Management Service" as StudentSvc
    component "Fee Payment Service" as PaymentSvc
    component "EPP Conversion Service" as EPPSvc
    component "Reporting Service" as ReportingSvc
    component "Notification Service" as NotificationSvc
    component "Audit & Logging Service" as AuditSvc
}

package "Integration Adapters" as Adapters {
    component "Cards System Adapter" as CardsAdapter
    component "GL System Adapter" as GLAdapter
    component "CRM Adapter" as CRMAdapter
    component "SMS Gateway Adapter" as SMSAdapter
    component "IVR System Adapter" as IVRAdapter
    component "ICRS System Adapter" as ICRSAdapter
}

' External Systems
rectangle "External Systems" {
    component "NGB Cards System" as CardsSystemExternal
    component "NGB GL System" as GLSystemExternal
    component "NGB CRM" as CRMExternal
    component "SMS Gateway" as SMSGatewayExternal
    component "Existing IVR Platform" as IVRPlatformExternal
    component "ICRS (Card Transaction Records)" as ICRSExternal
}

' Dependencies
Channels --> CoreServices : Uses\n(APIs)
Channels --> Adapters : Direct IVR/E-Form\nvia Adapters

CoreServices --> Adapters : Orchestrates external interactions

Adapters --> CardsSystemExternal : Interacts with
Adapters --> GLSystemExternal : Interacts with
Adapters --> CRMExternal : Interacts with
Adapters --> SMSGatewayExternal : Interacts with
Adapters --> IVRPlatformExternal : Interacts with
Adapters --> ICRSExternal : Interacts with

SchoolSvc .down.> AuditSvc : Logs events
StudentSvc .down.> AuditSvc : Logs events
PaymentSvc .down.> AuditSvc : Logs events
EPPSvc .down.> AuditSvc : Logs events

PaymentSvc --> NotificationSvc : Triggers SMS
StudentSvc --> NotificationSvc : Triggers SMS

ReportingSvc --> AuditSvc : For data
ReportingSvc --> PaymentSvc : For transaction data
@enduml
```

## 8. Interface Design

### 8.1 API Definitions

The School Fee Payment System (SFPS) will expose internal RESTful APIs for its core business services and integrate with external NGB systems via their respective APIs/protocols.

#### 8.1.1 Internal SFPS Backend APIs

These are the RESTful APIs exposed by the SFPS microservices, consumed by internal NGB channels (Online Banking, Mobile Banking, Contact Center E-Form, IVR System Integration).

**A. School Management Service API**

*   **Endpoint Prefix:** `/api/schools`

| Method | HTTP Verb | Path | Description | Request Body Parameters | Response Body Parameters | Notes |
| :----- | :-------- | :--- | :---------- | :---------------------- | :----------------------- | :---- |
| `registerSchool` | `POST` | `/` | Registers a new school in the system. | `schoolName` (String), `location` (String), `accountNumber` (String), `feeTypes` (List<FeeTypeRequest>) | `schoolId` (String), `status` (String: "REGISTERED", "FAILED") | Requires authentication for Card Operations Team. |
| `getSchoolDetails` | `GET` | `/{schoolId}` | Retrieves details for a specific school. | None | `schoolId` (String), `schoolName` (String), `location` (String), `accountNumber` (String), `glAccountConfig` (String), `isActive` (boolean), `feeTypes` (List<FeeTypeResponse>) | |
| `updateSchoolDetails` | `PUT` | `/{schoolId}` | Updates details of an existing school. | `schoolName` (String, optional), `location` (String, optional), `accountNumber` (String, optional), `isActive` (boolean, optional) | `schoolId` (String), `status` (String: "UPDATED", "FAILED") | |
| `getFeeTypesBySchool` | `GET` | `/{schoolId}/fee-types` | Retrieves configured fee types for a given school. | None | List of `FeeTypeResponse` (`feeTypeId` (String), `name` (String), `description` (String)) | |

**B. Student Management Service API**

*   **Endpoint Prefix:** `/api/students`

| Method | HTTP Verb | Path | Description | Request Body Parameters | Response Body Parameters | Notes |
| :----- | :-------- | :--- | :---------- | :---------------------- | :----------------------- | :---- |
| `registerStudent` | `POST` | `/` | Registers a new student for a customer at a specific school. | `customerId` (String), `studentName` (String), `studentId` (String), `studentIdConfirm` (String), `schoolId` (String), `otp` (String, for online/mobile) | `studentSystemId` (String), `status` (String: "REGISTERED", "FAILED") | Student ID must match `studentIdConfirm`. OTP required for online/mobile. SMS alert triggered. |
| `amendStudent` | `PUT` | `/{studentSystemId}` | Amends details of an existing student. | `studentName` (String, optional), `schoolId` (String, optional), `otp` (String, for online/mobile) | `studentSystemId` (String), `status` (String: "UPDATED", "FAILED") | SMS alert triggered. |
| `deRegisterStudent` | `DELETE` | `/{studentSystemId}` | De-registers a student (soft delete). | `customerId` (String), `otp` (String, for online/mobile) | `studentSystemId` (String), `status` (String: "DE-REGISTERED", "FAILED") | Updates student status to 'DE-REGISTERED'. SMS alert triggered. |
| `getStudentsByCustomer` | `GET` | `/customer/{customerId}` | Retrieves all registered students for a given customer. | None | List of `StudentResponse` (`studentSystemId` (String), `studentName` (String), `studentId` (String), `schoolId` (String), `schoolName` (String), `status` (String)) | |
| `validateStudent` | `GET` | `/{studentSystemId}/validate` | Internal method to validate if a student is active and registered. | None | `isValid` (boolean) | Used by Payment Orchestration Service. |

**C. Payment Orchestration Service API**

*   **Endpoint Prefix:** `/api/payments`

| Method | HTTP Verb | Path | Description | Request Body Parameters | Response Body Parameters | Notes |
| :----- | :-------- | :--- | :---------- | :---------------------- | :----------------------- | :---- |
| `initiateFeePayment` | `POST` | `/` | Initiates a school fee payment for a registered student. | `customerId` (String), `studentSystemId` (String), `schoolId` (String), `feeTypeId` (String), `cardNumber` (String), `amount` (double), `remark` (String, max 20 chars), `otp` (String, for online/mobile), `ivrTin` (String, for IVR) | `transactionId` (String), `status` (String: "SUCCESS", "FAILED", "PENDING_EPP"), `referenceId` (String) | Performs various validations (student eligibility, active card, balance). Triggers card debit, GL posting, and SMS confirmation. |
| `viewPaymentHistory` | `GET` | `/history` | Retrieves transaction history for the last 6 months for a customer. | `customerId` (String), `startDate` (Date), `endDate` (Date), `page` (int), `size` (int) | List of `TransactionHistoryResponse` (`transactionId` (String), `date` (Timestamp), `amount` (double), `studentName` (String), `schoolName` (String), `feeTypeName` (String), `remark` (String), `status` (String)) | |

**D. EPP Conversion Service API**

*   **Endpoint Prefix:** `/api/epp-conversions`

| Method | HTTP Verb | Path | Description | Request Body Parameters | Response Body Parameters | Notes |
| :----- | :-------- | :--- | :---------- | :---------------------- | :----------------------- | :---- |
| `requestEPPConversion` | `POST` | `/` | Submits a request to convert a payment to EPP. | `transactionId` (String), `customerId` (String) | `eppRequestId` (String), `status` (String: "PENDING", "REJECTED") | Triggers E-Form generation if approved. Checks for insufficient balance. No loyalty points if EPP. |
| `getEPPRequestStatus` | `GET` | `/{eppRequestId}` | Retrieves the status of an EPP conversion request. | None | `eppRequestId` (String), `transactionId` (String), `status` (String), `rejectionReason` (String) | |

**E. Financial Posting Service API**

*   **Endpoint Prefix:** `/api/financial-postings`

| Method | HTTP Verb | Path | Description | Request Body Parameters | Response Body Parameters | Notes |
| :----- | :-------- | :--- | :---------- | :----------------------- | :----------------------- | :---- |
| `postTransactionGL` | `POST` | `/` | Posts debit/credit entries to the General Ledger and school accounts. | `transactionId` (String), `cardType` (String), `amount` (double), `description` (String, max 40 chars), `schoolAccountNumber` (String) | `postingId` (String), `status` (String: "POSTED", "FAILED") | Internal, typically asynchronous. |

**F. Notification Service API**

*   **Endpoint Prefix:** `/api/notifications`

| Method | HTTP Verb | Path | Description | Request Body Parameters | Response Body Parameters | Notes |
| :----- | :-------- | :--- | :---------- | :---------------------- | :----------------------- | :---- |
| `sendSMS` | `POST` | `/sms` | Sends an SMS notification to a recipient. | `phoneNumber` (String), `message` (String), `type` (String: "OTP", "CONFIRMATION", "ALERT", "REJECTION") | `notificationId` (String), `status` (String: "SENT", "FAILED") | Generic SMS utility, used by other services. |

**G. Transaction & Audit Log Service API**

*   **Endpoint Prefix:** `/api/logs`

| Method | HTTP Verb | Path | Description | Request Body Parameters | Response Body Parameters | Notes |
| :----- | :-------- | :--- | :---------- | :---------------------- | :----------------------- | :---- |
| `logActivity` | `POST` | `/audit` | Logs an audit-worthy activity in the system. | `activityType` (String), `entityIdAffected` (String), `entityType` (String), `performedBy` (String), `details` (JSON/String) | `logId` (String), `status` (String: "LOGGED", "FAILED") | Internal. Used for all CRUD operations on core entities and transactions. |
| `getTransactionsForReport` | `GET` | `/transactions/reporting` | Retrieves transaction data for report generation. | `schoolId` (String), `startDate` (Date), `endDate` (Date) | List of `TransactionLogResponse` | Internal. Used by Reporting Service. |

**H. Reporting Service API**

*   **Endpoint Prefix:** `/api/reports`

| Method | HTTP Verb | Path | Description | Request Body Parameters | Response Body Parameters | Notes |
| :----- | :-------- | :--- | :---------- | :---------------------- | :----------------------- | :---- |
| `generateDailySchoolReport` | `POST` | `/daily/schools/{schoolId}` | Triggers generation and email of a daily Excel report for a specific school. | `reportDate` (Date) | `reportId` (String), `status` (String: "INITIATED", "FAILED") | Typically invoked by a scheduled job. |

#### 8.1.2 External System API Calls (APIs consumed by SFPS)

These describe the interactions SFPS initiates with external NGB systems.

**A. NGB Cards System API**

*   **Purpose:** Credit card validation, balance inquiry, and debiting.
*   **Protocol/Format:** Likely SOAP/XML or REST/JSON over HTTPS, potentially MQ.

| API Call | Description | Parameters | Expected Response |
| :------- | :---------- | :--------- | :---------------- |
| `verifyCardStatusAndBalance` | Checks card activity status and available balance. | `cardNumber` (String), `customerId` (String), `amount` (double) | `isValid` (boolean), `availableBalance` (double), `status` (String) |
| `debitCreditCard` | Debits the specified credit card. | `cardNumber` (String), `amount` (double), `transactionReference` (String), `description` (String) | `success` (boolean), `errorCode` (String), `errorMessage` (String) |

**B. NGB GL System API**

*   **Purpose:** Real-time General Ledger postings for debits and credits.
*   **Protocol/Format:** Likely SOAP/XML or REST/JSON over HTTPS, or Message Queue for guaranteed delivery.

| API Call | Description | Parameters | Expected Response |
| :------- | :---------- | :--------- | :---------------- |
| `postGLTransaction` | Posts a single GL transaction (debit or credit). | `glAccountId` (String), `amount` (double), `transactionType` (String: "DEBIT", "CREDIT"), `description` (String, max 40 chars), `transactionReference` (String) | `success` (boolean), `postingId` (String), `errorMessage` (String) |

**C. NGB SMS Gateway API**

*   **Purpose:** Sending automated SMS alerts and confirmations.
*   **Protocol/Format:** REST/JSON over HTTPS.

| API Call | Description | Parameters | Expected Response |
| :------- | :---------- | :--------- | :---------------- |
| `sendSMS` | Sends an SMS message to a mobile number. | `toPhoneNumber` (String), `messageContent` (String) | `messageId` (String), `status` (String: "QUEUED", "FAILED") |

**D. NGB CRM System API / E-Form Workflow System**

*   **Purpose:** Initiating E-Forms for student management (Contact Center) and EPP conversions.
*   **Protocol/Format:** REST/JSON over HTTPS.

| API Call | Description | Parameters | Expected Response |
| :------- | :---------- | :--------- | :---------------- |
| `createEForm` | Creates a new E-Form instance for a specific workflow. | `workflowType` (String: "STUDENT_MGMT", "EPP_CONVERSION"), `customerDetails` (JSON), `transactionDetails` (JSON, for EPP) | `eFormId` (String), `status` (String: "CREATED", "FAILED") |
| `getIVRTINAuthentication` | Authenticates a customer via IVR TIN. | `phoneNumber` (String), `ivrTin` (String) | `isValid` (boolean), `customerId` (String) |

**E. NGB OTP Service API**

*   **Purpose:** Generating and validating One-Time Passwords.
*   **Protocol/Format:** REST/JSON over HTTPS.

| API Call | Description | Parameters | Expected Response |
| :------- | :---------- | :--------- | :---------------- |
| `generateOTP` | Requests a new OTP for a given user. | `customerId` (String), `transactionType` (String: "PAYMENT", "STUDENT_REGISTRATION") | `otpReferenceId` (String), `status` (String: "SENT", "FAILED") |
| `validateOTP` | Validates an OTP provided by the user. | `otpReferenceId` (String), `otpCode` (String) | `isValid` (boolean), `errorMessage` (String) |

**F. Email System (SMTP)**

*   **Purpose:** Sending daily Excel reports to schools.
*   **Protocol/Format:** SMTP for sending, incoming Excel via email (manual/batch processing).

| API Call | Description | Parameters | Expected Response |
| :------- | :---------- | :--------- | :---------------- |
| `sendEmailWithAttachment` | Sends an email with an attached report. | `toEmailAddress` (String), `subject` (String), `body` (String), `attachmentFileName` (String), `attachmentData` (Base64 encoded String) | `success` (boolean), `messageId` (String) |

**G. NGB ICRS (IVR Customer Relationship System/Reporting System) API**

*   **Purpose:** Logging IVR transaction records.
*   **Protocol/Format:** REST/JSON over HTTPS or file transfer.

| API Call | Description | Parameters | Expected Response |
| :------- | :---------- | :--------- | :---------------- |
| `logIVRTransaction` | Logs a specific IVR-originated transaction. | `transactionId` (String), `ivrSessionId` (String), `customerPhoneNumber` (String), `details` (JSON/String) | `success` (boolean), `logEntryId` (String) |

## 9. Database Design

### 9.1 Schema Definitions: Detailed table structures including primary/foreign keys, constraints.

The database schema will be based on a relational model, primarily using PostgreSQL or Oracle, ensuring data integrity, traceability, and adherence to business rules. All sensitive data like credit card numbers will be stored securely (e.g., encrypted or tokenized) and not as plain text.

#### 1. `SCHOOL` Table

Represents registered schools within the system.

| Column Name            | Data Type          | Constraints / Notes                                                                   |
| :--------------------- | :----------------- | :------------------------------------------------------------------------------------ |
| `school_id`            | VARCHAR(50)        | **Primary Key (PK)**, Unique identifier for the school.                               |
| `school_name`          | VARCHAR(255)       | NOT NULL, Unique.                                                                     |
| `location`             | VARCHAR(255)       | NOT NULL.                                                                             |
| `ngb_account_number`   | VARCHAR(50)        | NOT NULL, Unique. School's NGB bank account for receiving fee credits.                |
| `ngb_gl_account_config`| VARCHAR(100)       | NOT NULL. Internal GL account or mapping configured for the school.                   |
| `registration_date`    | TIMESTAMP          | NOT NULL, Default: current timestamp. Date of registration.                           |
| `operational_since`    | DATE               | NOT NULL. Date the school started operations (for 3-year rule).                       |
| `is_active`            | BOOLEAN            | NOT NULL, Default: TRUE. Indicates if the school is active for payments.              |
| `min_students`         | INT                | NOT NULL, Default: 1000. Business rule: minimum enrolled students.                    |
| `min_annual_fee_coll`  | DECIMAL(18, 2)     | NOT NULL, Default: 500000. Business rule: minimum annual fee collection (€).          |

#### 2. `FEE_TYPE` Table

Defines different fee categories offered by a school.

| Column Name            | Data Type          | Constraints / Notes                                                                   |
| :--------------------- | :----------------- | :------------------------------------------------------------------------------------ |
| `fee_type_id`          | VARCHAR(50)        | **Primary Key (PK)**, Unique identifier for the fee type.                             |
| `school_id`            | VARCHAR(50)        | **Foreign Key (FK)** references `SCHOOL.school_id`. NOT NULL.                         |
| `fee_type_name`        | VARCHAR(100)       | NOT NULL. E.g., 'School Fee', 'Bus Fee'.                                              |
| `description`          | VARCHAR(255)       | NULLABLE.                                                                             |
| `is_active`            | BOOLEAN            | NOT NULL, Default: TRUE.                                                              |

#### 3. `CUSTOMER` Table (Replicated/Synchronized from NGB Core CRM)

Contains NGB customer (cardholder) details relevant to the system.

| Column Name            | Data Type          | Constraints / Notes                                                                   |
| :--------------------- | :----------------- | :------------------------------------------------------------------------------------ |
| `customer_id`          | VARCHAR(50)        | **Primary Key (PK)**, Unique NGB customer ID.                                         |
| `customer_name`        | VARCHAR(255)       | NOT NULL.                                                                             |
| `contact_email`        | VARCHAR(255)       | NULLABLE.                                                                             |
| `contact_phone`        | VARCHAR(50)        | NOT NULL. For SMS alerts.                                                             |
| `is_active_cardholder` | BOOLEAN            | NOT NULL, Default: TRUE. Indicates active credit card status.                         |

#### 4. `CREDIT_CARD` Table (Replicated/Synchronized from NGB Cards System)

Contains NGB Credit Card details.

| Column Name            | Data Type          | Constraints / Notes                                                                   |
| :--------------------- | :----------------- | :------------------------------------------------------------------------------------ |
| `card_token`           | VARCHAR(255)       | **Primary Key (PK)**, Unique token/ID for the card (not raw card number).             |
| `customer_id`          | VARCHAR(50)        | **Foreign Key (FK)** references `CUSTOMER.customer_id`. NOT NULL.                     |
| `card_last_4_digits`   | VARCHAR(4)         | NOT NULL. For display purposes (e.g., 'XXXX-XXXX-XXXX-1234').                         |
| `card_type`            | VARCHAR(50)        | NOT NULL. E.g., 'VISA_CONVENTIONAL', 'MASTERCARD', 'VISA_ISLAMIC'.                    |
| `expiry_date`          | DATE               | NOT NULL.                                                                             |
| `status`               | VARCHAR(50)        | NOT NULL. E.g., 'ACTIVE', 'INACTIVE', 'BLOCKED'.                                      |

#### 5. `STUDENT` Table

Manages student registrations by customers for specific schools.

| Column Name            | Data Type          | Constraints / Notes                                                                   |
| :--------------------- | :----------------- | :------------------------------------------------------------------------------------ |
| `student_id`           | VARCHAR(50)        | **Part of Composite Primary Key**. Unique ID provided by the customer/school.         |
| `school_id`            | VARCHAR(50)        | **Part of Composite Primary Key**, **Foreign Key (FK)** references `SCHOOL.school_id`.|
| `student_name`         | VARCHAR(255)       | NOT NULL.                                                                             |
| `registered_by_customer_id` | VARCHAR(50)    | **Foreign Key (FK)** references `CUSTOMER.customer_id`. NOT NULL.                     |
| `registration_date`    | TIMESTAMP          | NOT NULL, Default: current timestamp.                                                 |
| `status`               | VARCHAR(50)        | NOT NULL, Default: 'REGISTERED'. 'DE-REGISTERED' for soft delete.                     |
| `last_updated_date`    | TIMESTAMP          | NOT NULL, Default: current timestamp. Updated on amendment/de-registration.           |

#### 6. `TRANSACTION` Table

Records every fee payment transaction.

| Column Name            | Data Type          | Constraints / Notes                                                                   |
| :--------------------- | :----------------- | :------------------------------------------------------------------------------------ |
| `transaction_id`       | VARCHAR(50)        | **Primary Key (PK)**, Unique reference ID for each transaction.                       |
| `transaction_date_time`| TIMESTAMP          | NOT NULL, Default: current timestamp.                                                 |
| `amount`               | DECIMAL(18, 2)     | NOT NULL. Payment amount.                                                             |
| `card_token`           | VARCHAR(255)       | **Foreign Key (FK)** references `CREDIT_CARD.card_token`. NOT NULL.                   |
| `student_id`           | VARCHAR(50)        | **Foreign Key (FK)** references `STUDENT.student_id`. NOT NULL.                       |
| `school_id`            | VARCHAR(50)        | **Foreign Key (FK)** references `SCHOOL.school_id` (also implicit FK via STUDENT). NOT NULL.|
| `fee_type_id`          | VARCHAR(50)        | **Foreign Key (FK)** references `FEE_TYPE.fee_type_id`. NOT NULL.                     |
| `remark`               | VARCHAR(20)        | NULLABLE. Optional user-input remark (max 20 characters).                             |
| `status`               | VARCHAR(50)        | NOT NULL, Default: 'PENDING'. E.g., 'SUCCESS', 'FAILED', 'CANCELLED', 'PENDING_EPP'.|
| `posting_description`  | VARCHAR(40)        | NOT NULL. Formatted description for GL posting (max 40 characters).                   |
| `is_epp_converted`     | BOOLEAN            | NOT NULL, Default: FALSE. Flag indicating if converted to EPP.                        |
| `gl_posting_status`    | VARCHAR(50)        | NOT NULL, Default: 'PENDING'. E.g., 'POSTED', 'FAILED_GL'.                            |
| `ivr_tin_used`         | BOOLEAN            | NOT NULL, Default: FALSE. Indicates if IVR TIN was used for authentication.           |
| `channel_used`         | VARCHAR(50)        | NOT NULL. E.g., 'ONLINE_BANKING', 'MOBILE_BANKING', 'IVR'.                            |

#### 7. `EPP_REQUEST` Table

Records requests to convert a payment to an Easy Payment Plan.

| Column Name            | Data Type          | Constraints / Notes                                                                   |
| :--------------------- | :----------------- | :------------------------------------------------------------------------------------ |
| `epp_request_id`       | VARCHAR(50)        | **Primary Key (PK)**, Unique identifier for the EPP request.                          |
| `transaction_id`       | VARCHAR(50)        | **Foreign Key (FK)** references `TRANSACTION.transaction_id`. NOT NULL, Unique. Enforces 1:1 relationship.|
| `request_date_time`    | TIMESTAMP          | NOT NULL, Default: current timestamp.                                                 |
| `status`               | VARCHAR(50)        | NOT NULL, Default: 'PENDING'. E.g., 'APPROVED', 'REJECTED'.                           |
| `rejection_reason`     | VARCHAR(255)       | NULLABLE. Reason if the EPP request is rejected.                                      |
| `approval_date_time`   | TIMESTAMP          | NULLABLE. Timestamp when EPP was approved/rejected.                                   |
| `no_loyalty_points_flag`| BOOLEAN            | NOT NULL, Default: TRUE. Business rule: No loyalty points if EPP.                     |

#### 8. `AUDIT_LOG` Table

Comprehensive log for all significant system activities, ensuring traceability and compliance.

| Column Name            | Data Type          | Constraints / Notes                                                                   |
| :--------------------- | :----------------- | :------------------------------------------------------------------------------------ |
| `log_id`               | BIGINT / UUID      | **Primary Key (PK)**, Auto-generated unique identifier.                               |
| `activity_type`        | VARCHAR(100)       | NOT NULL. E.g., 'SCHOOL_REGISTERED', 'STUDENT_AMENDED', 'PAYMENT_SUCCESS'.            |
| `entity_id_affected`   | VARCHAR(50)        | NULLABLE. ID of the primary entity involved (e.g., school_id, student_id, transaction_id).|
| `entity_type`          | VARCHAR(50)        | NULLABLE. Type of entity affected (e.g., 'SCHOOL', 'STUDENT', 'TRANSACTION').         |
| `timestamp`            | TIMESTAMP          | NOT NULL, Default: current timestamp. When the activity occurred.                     |
| `performed_by_user_id` | VARCHAR(50)        | NULLABLE. Identifier of the user (customer_id, agent_id) or system (e.g., 'SYSTEM').|
| `channel`              | VARCHAR(50)        | NULLABLE. Channel through which action was performed (e.g., 'ONLINE_BANKING', 'CONTACT_CENTER').|
| `details`              | TEXT               | NULLABLE. Additional context, old/new values, SMS content, error messages (JSON/text).|
| `success_status`       | BOOLEAN            | NOT NULL. TRUE for success, FALSE for failure.                                        |

### 9.2 Data Mappings: Mapping between logical data entities and physical tables/columns.

The logical data entities described in Section 6.1 of the HLD are directly mapped to the physical tables defined above. The relationships between these entities are enforced using primary and foreign keys, ensuring referential integrity and data consistency.

#### Logical to Physical Mapping:

*   **School (Logical Entity) -> `SCHOOL` (Physical Table):**
    *   `school_id` (Logical PK) -> `school_id` (Physical PK)
    *   Attributes like `school_name`, `location`, `ngb_account_number` are directly mapped.
    *   Business rules: `min_enrolled_students` and `min_annual_fee_collection` are stored as `min_students` and `min_annual_fee_coll` columns, respectively. `Operational for at Least 3 Years` is tracked via `operational_since`.

*   **FeeType (Logical Entity) -> `FEE_TYPE` (Physical Table):**
    *   `fee_type_id` (Logical PK) -> `fee_type_id` (Physical PK)
    *   `school_id` (Logical FK) -> `school_id` (Physical FK to `SCHOOL.school_id`)
    *   `fee_type_name`, `description` map directly.

*   **Customer (Logical Entity) -> `CUSTOMER` (Physical Table):**
    *   `customer_id` (Logical PK) -> `customer_id` (Physical PK)
    *   This table is expected to be a synchronized subset of NGB's core CRM or customer master. `is_active_cardholder` directly supports the business rule `Only customers with active credit cards can register students`.

*   **CreditCard (Logical Entity) -> `CREDIT_CARD` (Physical Table):**
    *   `card_number` (Logical PK) -> `card_token` (Physical PK, securely representing the card number). `card_last_4_digits` is for display.
    *   `customer_id` (Logical FK) -> `customer_id` (Physical FK to `CUSTOMER.customer_id`).
    *   `status` and `balance` are critical attributes, likely synchronized or real-time retrieved from the `Cards System` but represented here for a comprehensive view.

*   **Student (Logical Entity) -> `STUDENT` (Physical Table):**
    *   The logical composite key `(Student ID, School ID)` is mapped to the physical composite primary key `(student_id, school_id)`.
    *   `registered_by_customer_id` (Logical FK) -> `registered_by_customer_id` (Physical FK to `CUSTOMER.customer_id`).
    *   `student_name` maps directly.
    *   `status` column (e.g., 'REGISTERED', 'DE-REGISTERED') implements the 'soft delete' requirement for de-registration.

*   **Transaction (Logical Entity) -> `TRANSACTION` (Physical Table):**
    *   `transaction_id` (Logical PK, unique reference ID) -> `transaction_id` (Physical PK).
    *   Foreign keys connect it to `CREDIT_CARD`, `STUDENT`, `SCHOOL`, and `FEE_TYPE`.
    *   `remark` (user-input, 20 chars) maps to `remark` column with a VARCHAR(20) constraint.
    *   `posting_description` (for GL, 40 chars) maps to `posting_description` with VARCHAR(40) constraint.
    *   `is_epp_converted` tracks EPP status, and `gl_posting_status` tracks GL integration status, supporting "Real-time GL postings" and "Near-instant transaction acknowledgment".

*   **EPP_Request (Logical Entity) -> `EPP_REQUEST` (Physical Table):**
    *   `epp_request_id` (Logical PK) -> `epp_request_id` (Physical PK).
    *   `transaction_id` (Logical FK to Transaction) -> `transaction_id` (Physical FK to `TRANSACTION.transaction_id`). The unique constraint on `transaction_id` in this table ensures the one-to-one relationship (a transaction can only have one EPP request).
    *   `rejection_reason` provides details for "EPP request rejected if balance is insufficient".
    *   `no_loyalty_points_flag` explicitly enforces the "No loyalty points if payment converted to EPP" business rule.

*   **AuditLog (Logical Entity) -> `AUDIT_LOG` (Physical Table):**
    *   `log_id` (Logical PK) -> `log_id` (Physical PK).
    *   `activity_type`, `entity_id_affected`, `entity_type`, `timestamp`, `performed_by_user_or_system`, `details` map directly to support "Maintain traceable transaction records" and "SMS alerts post-processing".

#### Relationship Enforcement through Foreign Keys:

*   **`SCHOOL` and `FEE_TYPE` (One-to-Many):** `FEE_TYPE.school_id` is a foreign key referencing `SCHOOL.school_id`.
*   **`SCHOOL` and `STUDENT` (One-to-Many):** `STUDENT.school_id` is a foreign key referencing `SCHOOL.school_id` and is part of `STUDENT`'s composite primary key. This ensures a student is always linked to a specific school.
*   **`CUSTOMER` and `CREDIT_CARD` (One-to-Many):** `CREDIT_CARD.customer_id` is a foreign key referencing `CUSTOMER.customer_id`.
*   **`CUSTOMER` and `STUDENT` (One-to-Many):** `STUDENT.registered_by_customer_id` is a foreign key referencing `CUSTOMER.customer_id`.
*   **`CREDIT_CARD` and `TRANSACTION` (One-to-Many):** `TRANSACTION.card_token` is a foreign key referencing `CREDIT_CARD.card_token`.
*   **`STUDENT` and `TRANSACTION` (One-to-Many):** `TRANSACTION.student_id` and `TRANSACTION.school_id` implicitly reference the `STUDENT` composite primary key.
*   **`FEE_TYPE` and `TRANSACTION` (One-to-Many):** `TRANSACTION.fee_type_id` is a foreign key referencing `FEE_TYPE.fee_type_id`.
*   **`TRANSACTION` and `EPP_REQUEST` (One-to-Zero-or-One):** `EPP_REQUEST.transaction_id` is a foreign key referencing `TRANSACTION.transaction_id` and has a unique constraint to ensure only one EPP request per transaction.
*   **`AUDIT_LOG`:** While not enforcing direct foreign key constraints to all entities (due to its generic nature), `entity_id_affected` and `entity_type` columns conceptually link log entries to the relevant primary entities, allowing for historical lookup and auditing.

This schema design provides a robust foundation for the School Fee Payment System, explicitly supporting the functional requirements and business rules related to data storage, integrity, and relationships.

## 10. Non-Functional Design Aspects

The non-functional requirements (NFRs) are critical for ensuring the system performs as expected, remains secure, is scalable for future growth, and is easily maintainable.

### 10.1 Performance Requirements

The system is designed to meet stringent performance criteria, especially concerning real-time financial operations and user interactions.

*   **Real-time GL Postings:** Financial postings (debiting Credit Card GL, crediting School Account) are designed to be near real-time. This will be achieved by:
    *   **Asynchronous Messaging:** Utilizing message queues (e.g., Apache Kafka) for GL posting requests. The `Financial Posting Service` will publish messages to a dedicated topic, and the `GL System Adapter` will consume these messages for immediate processing by the NGB GL System. This decouples the payment transaction from the GL posting, preventing bottlenecks and ensuring high throughput for payments.
    *   **Direct API Integration:** Where supported by the NGB GL System, direct, optimized API calls (e.g., highly performant SOAP/REST endpoints) will be used to ensure low latency.
*   **Near-instant Transaction Acknowledgment:** Customers will receive immediate feedback on their payment transactions.
    *   **Synchronous Debit:** The debiting of the Credit Card will be a synchronous call from the `Payment Orchestration Service` to the `Cards System Adapter` to ensure immediate balance reflection and transaction success/failure.
    *   **Lightweight Response:** The UI will receive a quick acknowledgment from the `Payment Orchestration Service` containing a unique transaction reference ID, allowing the user to proceed without waiting for all downstream processes (like SMS sending or full GL reconciliation).
*   **Optimized Database Access:** The data model is normalized, and indexes will be appropriately applied to ensure fast retrieval of student details, school information, and transaction history (especially for the last 6 months view). Caching mechanisms can be introduced if specific data reads become bottlenecks.

### 10.2 Scalability Requirements

The system architecture is explicitly designed for high scalability to accommodate a growing number of schools, students, and transaction volumes, as well as multiple transactions in one session.

*   **Horizontal Scaling of Application Services:**
    *   The core business services (`School & Student Management Service`, `Fee Payment Service`, `EPP Management Service`, `Reporting Service`, `Notification Service`, `Transaction & Audit Log Service`) are developed as stateless microservices using Spring Boot.
    *   These services will be deployed in a containerized environment (Docker/Kubernetes) behind a Load Balancer (e.g., Kubernetes Ingress Controller or Spring Cloud Gateway). This allows for dynamic scaling by adding or removing instances based on CPU, memory, or request load.
*   **Database Scalability:**
    *   A relational database (PostgreSQL/Oracle) will be deployed in a clustered configuration with read replicas. This offloads read-heavy operations (e.g., transaction history, report generation) from the primary write database, enhancing overall performance and allowing for independent scaling of read capacity.
    *   Connection pooling will be utilized within the application services to efficiently manage database connections.
*   **Asynchronous Processing:** Critical, potentially long-running, or retryable operations (e.g., GL postings, SMS notifications, EPP workflow initiation, daily report generation triggers) are handled asynchronously via message queues (e.g., Apache Kafka). This decouples services, preventing backpressure and enabling independent scaling of producers and consumers.
*   **API Gateway:** The API Gateway (e.g., Spring Cloud Gateway) provides a unified entry point, capable of handling high concurrency, rate limiting, and intelligent routing to manage and scale access to backend services.
*   **Stateless Design:** Services are designed to be stateless, minimizing resource consumption per request and simplifying horizontal scaling, as any instance can serve any request without session affinity.

### 10.3 Security Measures

Security is paramount for a banking application. The system will implement robust measures across all layers.

*   **Authentication & Authorization:**
    *   **Customer Authentication:** For Online/Mobile Banking, OTP (One-Time Password) verification is mandatory for sensitive actions like student registration/amendment/de-registration and fee payments. This will integrate with an existing NGB OTP Service.
    *   **Contact Center Agent Authentication:** Agents authenticate via IVR TIN. Access to the E-Form and system functionalities will be governed by their existing NGB identity and access management (IAM) roles and permissions, integrating with NGB's SSO/LDAP.
    *   **Card Operations Team Authentication:** Access to the Admin Portal UI for school registration will be secured via NGB's internal SSO/LDAP and role-based access control (RBAC).
    *   **API Security:** All external and internal API communication will use HTTPS with strong TLS/SSL encryption. Authentication tokens (JWT or OAuth2) will be used for API access, ensuring only authorized clients and users can invoke services.
*   **Data Protection:**
    *   **Sensitive Data Handling:** Student ID input fields on the E-Form will restrict copy-paste functionality to prevent accidental exposure or malware injection. While the SRS mentions this restriction on the E-Form, it's a good practice to apply it to any sensitive input fields across all UIs if feasible.
    *   **Encryption:** Data at rest (in the database) will be encrypted using industry-standard encryption algorithms. Data in transit (over networks) is secured with HTTPS/TLS.
    *   **Card Details:** Full credit card numbers will not be stored in the SFPS database; only masked/tokenized representations will be maintained, with the actual card processing handled by the NGB Cards System.
*   **Input Validation & Sanitization:** All user inputs (e.g., student name, remarks) will undergo strict validation and sanitization to prevent injection attacks (SQL Injection, XSS) and ensure data integrity (e.g., 20-character limit for remarks, 40-character limit for GL description).
*   **Least Privilege Principle:** Components and users will only be granted the minimum necessary permissions to perform their functions.
*   **Audit Trails:** Comprehensive `AuditLog` records will capture all key activities (registrations, payments, EPP requests, amendments, de-registrations, user actions) including timestamps, user/system identifiers, and details of the action. This ensures traceability and accountability.

### 10.4 Logging & Monitoring

Robust logging and monitoring are crucial for system health, performance, security, and audit compliance.

*   **Centralized Logging:** All application services will generate structured logs (e.g., JSON format) and push them to a centralized logging system (e.g., ELK Stack - Elasticsearch, Logstash, Kibana). This allows for easy aggregation, search, and analysis of logs across the distributed system.
    *   **Key Logged Events:**
        *   All transaction lifecycle events (initiation, success, failure, EPP conversion status).
        *   Student management events (registration, amendment, de-registration).
        *   School registration events.
        *   Authentication attempts (success/failure, including OTP failures).
        *   Inter-service communication events and errors.
        *   External system integration requests and responses (anonymized sensitive data).
        *   System errors and exceptions with stack traces.
*   **Performance Monitoring:**
    *   **Metrics Collection:** Prometheus will be used to collect application and infrastructure metrics (CPU, memory, network I/O, disk I/O, response times, throughput, error rates, queue lengths). Spring Boot Actuator endpoints will expose application-specific metrics.
    *   **Dashboards & Alerts:** Grafana will visualize these metrics through intuitive dashboards, providing real-time insights into system performance. Automated alerts will be configured in Prometheus/Grafana to notify operations teams of anomalies (e.g., high error rates, slow response times, resource exhaustion).
*   **Business Monitoring:** Custom business metrics (e.g., number of payments per hour, EPP conversion rate, daily school report generation status) will be collected and monitored to track business performance and identify potential issues impacting revenue or customer satisfaction.
*   **Traceability:** Unique correlation IDs will be propagated across all microservices and external system calls for a given transaction or request, enabling end-to-end tracing and debugging.
*   **Reporting:** The `Reporting Service` will generate daily Excel reports for each registered school, pulling data directly from the `Transaction & Audit Log Service` (or the `TRANSACTION` table). This fulfills audit and compliance requirements for schools.

### 10.5 Maintainability & Extensibility

The chosen architectural style (Service-Oriented Architecture/Microservices) and technology stack are selected to maximize maintainability and extensibility.

*   **Modular Architecture (Microservices):**
    *   **Loose Coupling, High Cohesion:** Each service is responsible for a specific business capability, minimizing dependencies between services. This means changes within one service are less likely to impact others, facilitating independent development and deployment.
    *   **Independent Deployment:** Services can be deployed independently, reducing the risk and complexity of releases. New features or bug fixes can be deployed for a specific service without requiring a full system redeployment.
    *   **Clear Boundaries:** Well-defined API contracts between services ensure clear communication and reduce integration complexities.
*   **Java & Spring Boot Ecosystem:**
    *   **Enterprise-Grade & Mature:** Java and Spring Boot are widely adopted in enterprise environments, offering a rich ecosystem of libraries, frameworks, and community support. This leads to readily available expertise and stable development practices.
    *   **Rapid Development:** Spring Boot's opinionated approach and auto-configuration features accelerate development and reduce boilerplate code, making it easier to implement and extend functionalities.
    *   **Convention over Configuration:** Simplifies development and reduces the learning curve for new team members.
*   **Containerization (Docker) & Orchestration (Kubernetes):**
    *   **Consistent Environments:** Docker containers ensure that applications run consistently across different environments (DEV, SIT, UAT, PROD), reducing "it works on my machine" issues.
    *   **Automated Operations:** Kubernetes automates deployment, scaling, and management of containerized applications, reducing operational overhead and standardizing deployment practices.
*   **Automated CI/CD Pipeline:** A robust CI/CD pipeline (Jenkins/GitLab CI/CD) automates the build, test, and deployment processes. This ensures code quality, reduces manual errors, and allows for frequent and reliable releases, enabling faster delivery of new features and bug fixes.
*   **API-First Design:** Designing services with well-documented RESTful APIs ensures that new channels or external systems can easily integrate with the SFPS in the future.
*   **Standardized Practices:** Adherence to NGB's internal coding standards, security guidelines, and architectural patterns will ensure consistency across the system and facilitate easier maintenance by different teams.

