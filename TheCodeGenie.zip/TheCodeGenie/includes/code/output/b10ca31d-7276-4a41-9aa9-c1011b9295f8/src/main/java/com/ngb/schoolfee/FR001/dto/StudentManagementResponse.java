```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

@Data
public class StudentManagementResponse {
    private String studentSystemId;
    private String status; // REGISTERED, UPDATED, DE-REGISTERED, FAILED
    private String message;
}
```