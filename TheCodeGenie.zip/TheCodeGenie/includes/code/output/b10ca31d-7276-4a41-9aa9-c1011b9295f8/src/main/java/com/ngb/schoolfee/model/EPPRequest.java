package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "epp_request")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false, unique = true)
    private Transaction transaction;

    @Column(nullable = false)
    private LocalDateTime requestDateTime = LocalDateTime.now();

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status = EPPStatus.PENDING;

    @Column(nullable = true)
    private String rejectionReason;

    @Column(nullable = false)
    private Boolean noLoyaltyPointsFlag = true;

    @Column(nullable = true)
    private LocalDateTime approvalDateTime;


    public enum EPPStatus {
        PENDING, APPROVED, REJECTED
    }
}