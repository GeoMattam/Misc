```java
package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.EppConversionRequest;
import com.ngb.schoolfee.FR001.dto.EppConversionResponse;
import com.ngb.schoolfee.FR001.exception.EppConversionException;
import com.ngb.schoolfee.FR001.model.EPPRequest;
import com.ngb.schoolfee.FR001.model.Transaction;
import com.ngb.schoolfee.FR001.repository.EppRequestRepository;
import com.ngb.schoolfee.FR001.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class EppConversionService {

    private final EppRequestRepository eppRequestRepository;
    private final TransactionRepository transactionRepository;
    private final NotificationService notificationService;
    private final TransactionAndAuditLogService transactionAndAuditLogService;
    private final CardsSystemAdapter cardsSystemAdapter;
    private final CRMAdapter crmAdapter;

    @Autowired
    public EppConversionService(EppRequestRepository eppRequestRepository, TransactionRepository transactionRepository,
                                 NotificationService notificationService, TransactionAndAuditLogService transactionAndAuditLogService,
                                 CardsSystemAdapter cardsSystemAdapter, CRMAdapter crmAdapter) {
        this.eppRequestRepository = eppRequestRepository;
        this.transactionRepository = transactionRepository;
        this.notificationService = notificationService;
        this.transactionAndAuditLogService = transactionAndAuditLogService;
        this.cardsSystemAdapter = cardsSystemAdapter;
        this.crmAdapter = crmAdapter;
    }

    @Transactional
    public EppConversionResponse requestEPPConversion(EppConversionRequest request) {
        Transaction transaction = transactionRepository.findById(UUID.fromString(request.getTransactionId()))
                .orElseThrow(() -> new EppConversionException("Transaction not found."));

        EPPRequest eppRequest = EPPRequest.builder()
                .transaction(transaction)
                .status("PENDING")
                .noLoyaltyPointsFlag