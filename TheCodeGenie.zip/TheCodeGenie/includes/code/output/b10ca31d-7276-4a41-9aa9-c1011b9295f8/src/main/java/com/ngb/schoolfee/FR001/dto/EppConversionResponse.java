```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

@Data
public class EppConversionResponse {
    private String eppRequestId;
    private String status; // PENDING, APPROVED, REJECTED
    private String message;
}
```