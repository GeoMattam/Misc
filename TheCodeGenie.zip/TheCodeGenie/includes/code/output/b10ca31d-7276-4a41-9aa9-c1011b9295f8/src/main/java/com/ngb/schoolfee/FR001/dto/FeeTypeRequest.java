```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class FeeTypeRequest {
    @NotBlank
    private String name;
    private String description;
}
```