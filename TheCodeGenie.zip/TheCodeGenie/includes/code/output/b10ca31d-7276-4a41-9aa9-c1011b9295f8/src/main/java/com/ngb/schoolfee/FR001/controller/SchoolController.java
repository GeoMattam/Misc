```java
package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.FR001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.FR001.service.SchoolManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/schools")
public class SchoolController {

    private final SchoolManagementService schoolManagementService;

    @Autowired
    public SchoolController(SchoolManagementService schoolManagementService) {
        this.schoolManagementService = schoolManagementService;
    }

    @PostMapping
    public ResponseEntity<SchoolRegistrationResponse> registerSchool(
            @Valid @RequestBody SchoolRegistrationRequest request) {
        SchoolRegistrationResponse response = schoolManagementService.registerSchool(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }


    // Add other endpoints for School Management as needed (GET, PUT, DELETE)
}
```