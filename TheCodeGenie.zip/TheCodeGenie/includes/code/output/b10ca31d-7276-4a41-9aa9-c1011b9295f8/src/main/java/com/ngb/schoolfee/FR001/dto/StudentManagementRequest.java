```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class StudentManagementRequest {
    private String action; // REGISTER, AMEND, DE_REGISTER
    @NotBlank
    private String studentName;
    @NotBlank
    private String studentId;
    private String studentIdConfirm;
    @NotNull
    private String schoolId;
    private String otp; //For Online/Mobile
    private String ivrTin; //For Contact Center

}

```