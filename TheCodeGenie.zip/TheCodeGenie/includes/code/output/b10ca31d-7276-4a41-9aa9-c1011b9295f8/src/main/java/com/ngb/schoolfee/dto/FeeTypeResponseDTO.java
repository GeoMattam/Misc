package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeTypeResponseDTO {
    private Long feeTypeId;
    private String feeTypeName;
    private String description;
    private Boolean isActive;
}