```java
package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.EppConversionRequest;
import com.ngb.schoolfee.FR001.dto.EppConversionResponse;
import com.ngb.schoolfee.FR001.service.EppConversionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/epp-conversions")
public class EppController {

    private final EppConversionService eppConversionService;

    @Autowired
    public EppController(EppConversionService eppConversionService) {
        this.eppConversionService = eppConversionService;
    }

    @PostMapping
    public ResponseEntity<EppConversionResponse> requestEPPConversion(
            @Valid @RequestBody EppConversionRequest request) {
        EppConversionResponse response = eppConversionService.requestEPPConversion(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/{eppRequestId}")
    public ResponseEntity<Object> getEPPRequestStatus(@PathVariable String eppRequestId) {
        return ResponseEntity.ok(eppConversionService.getEPPRequestStatus(eppRequestId));
    }
}
```