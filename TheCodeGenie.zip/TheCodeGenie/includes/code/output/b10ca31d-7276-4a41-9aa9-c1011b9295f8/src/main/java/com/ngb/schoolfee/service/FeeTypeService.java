package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.FeeTypeRequestDTO;
import com.ngb.schoolfee.dto.FeeTypeResponseDTO;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.FeeType;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FeeTypeService {

    private final FeeTypeRepository feeTypeRepository;
    private final SchoolRepository schoolRepository;

    @Autowired
    public FeeTypeService(FeeTypeRepository feeTypeRepository, SchoolRepository schoolRepository) {
        this.feeTypeRepository = feeTypeRepository;
        this.schoolRepository = schoolRepository;
    }


    public List<Long> createFeeTypes(Long schoolId, List<FeeTypeRequestDTO> feeTypeRequestDTOS) {
        Optional<School> school = schoolRepository.findById(schoolId);
        if (school.isEmpty()) {
            throw new SchoolRegistrationException("School not found for fee type creation.");
        }
        return feeTypeRequestDTOS.stream()
                .map(dto -> createFeeType(school.get(), dto))
                .map(FeeType::getFeeTypeId)
                .collect(Collectors.toList());

    }

    private FeeType createFeeType(School school, FeeTypeRequestDTO feeTypeRequestDTO) {
        return feeTypeRepository.save(FeeType.builder()
                .school(school)
                .feeTypeName(feeTypeRequestDTO.getFeeTypeName())
                .description(feeTypeRequestDTO.getDescription())
                .build());
    }

    public List<FeeType> getFeeTypesBySchoolId(Long schoolId) {
        return feeTypeRepository.findBySchool_SchoolId(schoolId);
    }

    public FeeTypeResponseDTO mapToResponse(FeeType feeType) {
        return FeeTypeResponseDTO.builder()
                .feeTypeId(feeType.getFeeTypeId())
                .feeTypeName(feeType.getFeeTypeName())
                .description(feeType.getDescription())
                .isActive(feeType.getIsActive())
                .build();
    }
}