package com.ngb.schoolfee.exception;

public class SchoolRegistrationException extends RuntimeException {
    public SchoolRegistrationException(String message) {
        super(message);
    }
}