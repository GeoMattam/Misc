```java
package com.ngb.schoolfee.FR001.model;

import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "epp_requests")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EPPRequest {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "epp_request_id", updatable = false, nullable = false)
    private UUID eppRequestId;

    @OneToOne
    @JoinColumn(name = "transaction_id", unique = true, nullable = false)
    private Transaction transaction;

    @CreationTimestamp
    private LocalDateTime requestDateTime;

    private String status; // PENDING, APPROVED, REJECTED

    private String rejectionReason;

    private LocalDateTime approvalDateTime;

    private boolean noLoyaltyPointsFlag;
}
```