### FilePath: src/main/java/com/ngb/schoolfee/model/School.java

```java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "school")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class School {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long schoolId;

    @Column(nullable = false, unique = true)
    private String schoolName;

    @Column(nullable = false)
    private String location;

    @Column(nullable = false, unique = true)
    private String ngbAccountNumber;

    @Column(nullable = false)
    private String ngbGlAccountConfig;

    @Column(nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();

    @Column(nullable = false)
    private Boolean isActive = true;

    @Column(nullable = false)
    private Integer minEnrolledStudents = 1000;

    @Column(nullable = false)
    private Integer operationalYears = 3;

    @Column(nullable = false, precision = 18, scale = 2)
    private Double minAnnualFeeCollection = 500000.00;

    @Column(nullable = false)
    private LocalDate operationalSince;

}
```

### FilePath: src/main/java/com/ngb/schoolfee/model/FeeType.java
```java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "fee_type")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feeTypeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(nullable = false)
    private String feeTypeName;

    @Column(nullable = true)
    private String description;

    @Column(nullable = false)
    private Boolean isActive = true;

}
```

### FilePath: src/main/java/com/ngb/schoolfee/model/Customer.java

```java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "customer")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    @Column(nullable = false, unique = true)
    private String customerId;

    @Column(nullable = false)
    private String customerName;

    @Column(nullable = false)
    private String contactInfo;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CustomerStatus status = CustomerStatus.ACTIVE;


    public enum CustomerStatus {
        ACTIVE, INACTIVE, BLOCKED
    }
}

```

### FilePath: src/main/java/com/ngb/schoolfee/model/CreditCard.java

```java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "credit_card")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditCard {

    @Id
    @Column(nullable = false, unique = true)
    private String cardToken;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @Column(nullable = false)
    private String cardLast4Digits;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CardType cardType;

    @Column(nullable = false)
    private LocalDate expiryDate;

    @Column(nullable = false, precision = 18, scale = 2)
    private Double balance;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CardStatus status = CardStatus.ACTIVE;

    public enum CardType {
        VISA_CONVENTIONAL, VISA_ISLAMIC, MASTERCARD
    }

    public enum CardStatus {
        ACTIVE, INACTIVE, BLOCKED
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/model/Student.java

```java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "student")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @Column(nullable = false)
    private String studentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(nullable = false)
    private String studentName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "registered_by_customer_id", nullable = false)
    private Customer registeredByCustomer;

    @Column(nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private StudentStatus status = StudentStatus.REGISTERED;

    @Column(nullable = false)
    private LocalDateTime lastUpdatedDate = LocalDateTime.now();

    public enum StudentStatus {
        REGISTERED, DE_REGISTERED
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/model/Transaction.java

```java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "transaction")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column(nullable = false)
    private LocalDateTime transactionDateTime = LocalDateTime.now();

    @Column(nullable = false, precision = 18, scale = 2)
    private Double amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_token", nullable = false)
    private CreditCard creditCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @Column(nullable = true, length = 20)
    private String remark;


    @Column(nullable = false, length = 40)
    private String postingDescription;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status = TransactionStatus.PENDING;

    @Column(nullable = false)
    private Boolean isEppConverted = false;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private GLPostingStatus glPostingStatus = GLPostingStatus.PENDING;

    @Column(nullable = false)
    private Boolean isLoyaltyEligible = true;

    @Column(nullable = false)
    private Boolean ivrTinUsed = false;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private PaymentChannel channelUsed;



    public enum TransactionStatus {
        PENDING, SUCCESS, FAILED, CANCELLED, PENDING_EPP, REJECTED
    }

    public enum GLPostingStatus {
        PENDING, POSTED, FAILED_GL, CARD_DEBIT_FAILED, SCHOOL_CREDIT_FAILED, EXCEPTION_OCCURRED
    }

    public enum PaymentChannel {
        ONLINE_BANKING, MOBILE_BANKING, IVR
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/model/EPPRequest.java

```java
package com.ngb.schoolfee.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "epp_request")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false, unique = true)
    private Transaction transaction;

    @Column(nullable = false)
    private LocalDateTime requestDateTime = LocalDateTime.now();

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status = EPPStatus.PENDING;

    @Column(nullable = true)
    private String rejectionReason;

    @Column(nullable = false)
    private Boolean noLoyaltyPointsFlag = true;

    @Column(nullable = true)
    private LocalDateTime approvalDateTime;


    public enum EPPStatus {
        PENDING, APPROVED, REJECTED
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/model/AuditLog.java
```java
package com.ngb.schoolfee.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "audit_log")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logId;

    @Column(nullable = false)
    private String activityType;

    @Column(nullable = true)
    private String entityIdAffected;

    @Column(nullable = true)
    private String entityType;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime timestamp;

    @Column(nullable = false)
    private String performedByUserId;

    @Column(nullable = true)
    private String channel;


    @Column(nullable = false)
    private String details;

    @Column(nullable = false)
    private Boolean successStatus;
}
```

### FilePath: src/main/java/com/ngb/schoolfee/repository/SchoolRepository.java

```java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SchoolRepository extends JpaRepository<School, Long> {
}
```

### FilePath: src/main/java/com/ngb/schoolfee/repository/FeeTypeRepository.java

```java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.FeeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeeTypeRepository extends JpaRepository<FeeType, Long> {
}
```

### FilePath: src/main/java/com/ngb/schoolfee/repository/CustomerRepository.java

```java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {
}
```

### FilePath: src/main/java/com/ngb/schoolfee/repository/CreditCardRepository.java

```java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.CreditCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CreditCardRepository extends JpaRepository<CreditCard, String> {
}
```

### FilePath: src/main/java/com/ngb/schoolfee/repository/StudentRepository.java

```java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {
}
```

### FilePath: src/main/java/com/ngb/schoolfee/repository/TransactionRepository.java

```java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
}
```

### FilePath: src/main/java/com/ngb/schoolfee/repository/EPPRequestRepository.java

```java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.EPPRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EPPRequestRepository extends JpaRepository<EPPRequest, Long> {
}
```

### FilePath: src/main/java/com/ngb/schoolfee/repository/AuditLogRepository.java

```java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.model.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
}
```

### FilePath: src/main/java/com/ngb/schoolfee/dto/SchoolRequestDTO.java

```java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SchoolRequestDTO {
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private List<FeeTypeRequestDTO> feeTypes;
    private LocalDate operationalSince;

}
```

### FilePath: src/main/java/com/ngb/schoolfee/dto/FeeTypeRequestDTO.java
```java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeTypeRequestDTO {
    private String feeTypeName;
    private String description;
}
```

### FilePath: src/main/java/com/ngb/schoolfee/dto/SchoolResponseDTO.java

```java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SchoolResponseDTO {
    private Long schoolId;
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private String ngbGlAccountConfig;
    private LocalDateTime registrationDate;
    private Boolean isActive;
    private List<FeeTypeResponseDTO> feeTypes;
}
```

### FilePath: src/main/java/com/ngb/schoolfee/dto/FeeTypeResponseDTO.java
```java
package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeTypeResponseDTO {
    private Long feeTypeId;
    private String feeTypeName;
    private String description;
    private Boolean isActive;
}
```


### FilePath: src/main/java/com/ngb/schoolfee/service/SchoolService.java

```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.SchoolRequestDTO;
import com.ngb.schoolfee.dto.SchoolResponseDTO;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SchoolService {

    private final SchoolRepository schoolRepository;
    private final FeeTypeService feeTypeService;

    @Autowired
    public SchoolService(SchoolRepository schoolRepository, FeeTypeService feeTypeService) {
        this.schoolRepository = schoolRepository;
        this.feeTypeService = feeTypeService;
    }

    public SchoolResponseDTO registerSchool(SchoolRequestDTO schoolRequestDTO) {
        //Validate data and Business Rules
        Optional<School> existingSchool = schoolRepository.findBySchoolNameAndLocation(schoolRequestDTO.getSchoolName(), schoolRequestDTO.getLocation());
        if (existingSchool.isPresent()) {
            throw new SchoolRegistrationException("School already registered: " + schoolRequestDTO.getSchoolName());
        }

        School school = School.builder()
                .schoolName(schoolRequestDTO.getSchoolName())
                .location(schoolRequestDTO.getLocation())
                .ngbAccountNumber(schoolRequestDTO.getNgbAccountNumber())
                .operationalSince(schoolRequestDTO.getOperationalSince())
                .build();

        School savedSchool = schoolRepository.save(school);
        if (schoolRequestDTO.getFeeTypes() != null) {
            List<Long> feeTypeIds = feeTypeService.createFeeTypes(savedSchool.getSchoolId(), schoolRequestDTO.getFeeTypes());
        }

        return mapToResponse(savedSchool);
    }

    public SchoolResponseDTO getSchoolDetails(Long schoolId) {
        Optional<School> school = schoolRepository.findById(schoolId);
        if (school.isEmpty()) {
            throw new SchoolRegistrationException("School not found");
        }
        return mapToResponse(school.get());
    }


    private SchoolResponseDTO mapToResponse(School school) {
        return SchoolResponseDTO.builder()
                .schoolId(school.getSchoolId())
                .schoolName(school.getSchoolName())
                .location(school.getLocation())
                .ngbAccountNumber(school.getNgbAccountNumber())
                .ngbGlAccountConfig(school.getNgbGlAccountConfig())
                .registrationDate(school.getRegistrationDate())
                .isActive(school.getIsActive())
                .feeTypes(feeTypeService.getFeeTypesBySchoolId(school.getSchoolId()).stream().map(feeTypeService::mapToResponse).collect(Collectors.toList()))
                .build();
    }
}

```

### FilePath: src/main/java/com/ngb/schoolfee/service/FeeTypeService.java

```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.FeeTypeRequestDTO;
import com.ngb.schoolfee.dto.FeeTypeResponseDTO;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.FeeType;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FeeTypeService {

    private final FeeTypeRepository feeTypeRepository;
    private final SchoolRepository schoolRepository;

    @Autowired
    public FeeTypeService(FeeTypeRepository feeTypeRepository, SchoolRepository schoolRepository) {
        this.feeTypeRepository = feeTypeRepository;
        this.schoolRepository = schoolRepository;
    }


    public List<Long> createFeeTypes(Long schoolId, List<FeeTypeRequestDTO> feeTypeRequestDTOS) {
        Optional<School> school = schoolRepository.findById(schoolId);
        if (school.isEmpty()) {
            throw new SchoolRegistrationException("School not found for fee type creation.");
        }
        return feeTypeRequestDTOS.stream()
                .map(dto -> createFeeType(school.get(), dto))
                .map(FeeType::getFeeTypeId)
                .collect(Collectors.toList());

    }

    private FeeType createFeeType(School school, FeeTypeRequestDTO feeTypeRequestDTO) {
        return feeTypeRepository.save(FeeType.builder()
                .school(school)
                .feeTypeName(feeTypeRequestDTO.getFeeTypeName())
                .description(feeTypeRequestDTO.getDescription())
                .build());
    }

    public List<FeeType> getFeeTypesBySchoolId(Long schoolId) {
        return feeTypeRepository.findBySchool_SchoolId(schoolId);
    }

    public FeeTypeResponseDTO mapToResponse(FeeType feeType) {
        return FeeTypeResponseDTO.builder()
                .feeTypeId(feeType.getFeeTypeId())
                .feeTypeName(feeType.getFeeTypeName())
                .description(feeType.getDescription())
                .isActive(feeType.getIsActive())
                .build();
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/controller/SchoolController.java

```java
package com.ngb.schoolfee.controller;

import com.ngb.schoolfee.dto.SchoolRequestDTO;
import com.ngb.schoolfee.dto.SchoolResponseDTO;
import com.ngb.schoolfee.service.SchoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/schools")
public class SchoolController {

    private final SchoolService schoolService;

    @Autowired
    public SchoolController(SchoolService schoolService) {
        this.schoolService = schoolService;
    }

    @PostMapping
    public ResponseEntity<SchoolResponseDTO> registerSchool(@RequestBody SchoolRequestDTO schoolRequestDTO) {
        SchoolResponseDTO schoolResponseDTO = schoolService.registerSchool(schoolRequestDTO);
        return new ResponseEntity<>(schoolResponseDTO, HttpStatus.CREATED);
    }

    @GetMapping("/{schoolId}")
    public ResponseEntity<SchoolResponseDTO> getSchoolDetails(@PathVariable Long schoolId) {
        SchoolResponseDTO schoolResponseDTO = schoolService.getSchoolDetails(schoolId);
        return new ResponseEntity<>(schoolResponseDTO, HttpStatus.OK);
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/exception/SchoolRegistrationException.java

```java
package com.ngb.schoolfee.exception;

public class SchoolRegistrationException extends RuntimeException {
    public SchoolRegistrationException(String message) {
        super(message);
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/exception/GlobalExceptionHandler.java

```java
package com.ngb.schoolfee.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(SchoolRegistrationException.class)
    public ResponseEntity<ErrorResponse> handleSchoolRegistrationException(SchoolRegistrationException ex) {
        return buildErrorResponse(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    private ResponseEntity<ErrorResponse> buildErrorResponse(String message, HttpStatus status) {
        ErrorResponse errorResponse = new ErrorResponse(status.value(), message);
        return new ResponseEntity<>(errorResponse, status);
    }

    public static class ErrorResponse {
        private final int code;
        private final String message;

        public ErrorResponse(int code, String message) {
            this.code = code;
            this.message = message;
        }

        //Getters...
    }

}
```

### FilePath: src/test/java/com/ngb/schoolfee/service/SchoolServiceTest.java

```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.FeeTypeRequestDTO;
import com.ngb.schoolfee.dto.SchoolRequestDTO;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SchoolServiceTest {

    @Mock
    private SchoolRepository schoolRepository;

    @Mock
    private FeeTypeService feeTypeService;

    @InjectMocks
    private SchoolService schoolService;

    @Test
    void registerSchool_success() {
        SchoolRequestDTO request = SchoolRequestDTO.builder()
                .schoolName("Test School")
                .location("Test Location")
                .ngbAccountNumber("1234567890")
                .operationalSince(LocalDate.now().minusYears(4))
                .feeTypes(List.of(FeeTypeRequestDTO.builder().feeTypeName("Tuition").build()))
                .build();

        when(schoolRepository.findBySchoolNameAndLocation(anyString(), anyString())).thenReturn(Optional.empty());
        when(schoolRepository.save(any(School.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(feeTypeService.createFeeTypes(anyLong(), anyList())).thenReturn(List.of(1L));


        SchoolResponseDTO response = schoolService.registerSchool(request);
        assertNotNull(response);
        assertEquals(request.getSchoolName(), response.getSchoolName());
        verify(schoolRepository, times(1)).save(any(School.class));
        verify(feeTypeService, times(1)).createFeeTypes(anyLong(), anyList());
    }


    @Test
    void registerSchool_existingSchool() {
        SchoolRequestDTO request = SchoolRequestDTO.builder()
                .schoolName("Test School")
                .location("Test Location")
                .ngbAccountNumber("1234567890")
                .build();

        School existingSchool = School.builder().schoolId(1L).build();
        when(schoolRepository.findBySchoolNameAndLocation(anyString(), anyString())).thenReturn(Optional.of(existingSchool));

        assertThrows(SchoolRegistrationException.class, () -> schoolService.registerSchool(request));
        verify(schoolRepository, never()).save(any(School.class));
        verify(feeTypeService, never()).createFeeTypes(anyLong(), anyList());
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/config/AppConfig.java

```java
package com.ngb.schoolfee.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

//Add other necessary configurations as needed (e.g., security, messaging)
@Configuration
@EnableJpaRepositories(basePackages = "com.ngb.schoolfee.repository")
public class AppConfig {

    //Add beans for other services/components as needed (e.g., SMS gateway adapter, financial posting adapter, etc.)
}
```

### FilePath: src/main/java/com/ngb/schoolfee/SchoolFeeApplication.java

```java
package com.ngb.schoolfee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolFeeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SchoolFeeApplication.class, args);
    }

}
```

### FilePath: src/main/resources/application.yaml

```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/school_fee_db
    username: your_db_username
    password: your_db_password
    driver-class-name: org.postgresql.Driver
  jpa:
    hibernate:
      ddl-auto: update # update, validate, create, create-drop, none
    show-sql: true
    generate-ddl: true
    properties:
      hibernate:
        dialect: org.hibernate.dialect.PostgreSQLDialect
```

### FilePath: src/main/resources/pom.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.ngb</groupId>
    <artifactId>school-fee</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <spring-boot.version>3.1.0</spring-boot.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
            <version>${spring-boot.version}</version>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
            <version>${spring-boot.version}</version>
        </dependency>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <version>42.6.0</version>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <version>1.18.26</version>
            <scope>provided</scope>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
            <version>${spring-boot.version}</version>
        </dependency>


        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <version>${spring-boot.version}</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.mockito</groupId>
            <artifactId>mockito-core</artifactId>
            <version>5.1.1</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>com.fasterxml.jackson.datatype</groupId>
            <artifactId>jackson-datatype-jsr310</artifactId>
            <version>2.15.2</version>
        </dependency>
    </dependencies>


    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <version>${spring-boot.version}</version>
                <configuration>
                    <excludes>
                        <exclude>
                            <groupId>org.projectlombok</groupId>
                            <artifactId>lombok</artifactId>
                        </exclude>
                    </excludes>
                </configuration>
            </plugin>
        </plugins>
    </build>

</project>

```

### FilePath: src/main/resources/README.md

To build and run the application:

1.  **Prerequisites:** Make sure you have Java 17+ and Maven installed.  Also, ensure PostgreSQL is running and you have created the database `school_fee_db` with appropriate user credentials (update `application.yaml` accordingly).
2.  **Build:** Navigate to the project root directory and run `mvn clean install`.
3.  **Run:** Execute `mvn spring-boot:run`.

The application will start on port 8080 (by default). You can then test the REST APIs using tools like Postman or curl.


