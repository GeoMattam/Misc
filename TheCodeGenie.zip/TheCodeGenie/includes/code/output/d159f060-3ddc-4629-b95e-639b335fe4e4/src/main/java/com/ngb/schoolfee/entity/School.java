package com.ngb.schoolfee.entity;

import lombok.*;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "schools")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class School {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 255)
    private String schoolName;
    @Column(length = 255)
    private String location;
    @Column(nullable = false, unique = true, length = 50)
    private String ngbAccountNumber;
    @Column(nullable = false, length = 50)
    private String glAccountNumber;
    @ElementCollection
    @CollectionTable(name = "school_fee_types", joinColumns = @JoinColumn(name = "school_id"))
    @Column(name = "fee_type")
    private List<String> feeTypes;
}
```

```java