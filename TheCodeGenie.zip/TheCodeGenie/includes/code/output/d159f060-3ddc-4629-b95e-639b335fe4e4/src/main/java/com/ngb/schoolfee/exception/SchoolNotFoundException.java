package com.ngb.schoolfee.exception;

public class SchoolNotFoundException extends RuntimeException{
    public SchoolNotFoundException(String message){
        super(message);
    }
}
```

```java