package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.SchoolDto;
import com.ngb.schoolfee.entity.School;
import com.ngb.schoolfee.mapper.SchoolMapper;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SchoolServiceImpl implements SchoolService{

    private final SchoolRepository schoolRepository;
    private final SchoolMapper schoolMapper;

    @Autowired
    public SchoolServiceImpl(SchoolRepository schoolRepository, SchoolMapper schoolMapper){
        this.schoolRepository = schoolRepository;
        this.schoolMapper = schoolMapper;
    }

    @Override
    @Transactional
    public SchoolDto registerSchool(SchoolDto schoolDto) {
        School school = schoolMapper.toEntity(schoolDto);
        School savedSchool = schoolRepository.save(school);
        return schoolMapper.toDto(savedSchool);
    }

    @Override
    public List<SchoolDto> getAllSchools() {
        List<School> schools = schoolRepository.findAll();
        return schools.stream()
                .map(schoolMapper::toDto)
                .collect(Collectors.toList());
    }
}
```

```java