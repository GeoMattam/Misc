package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SchoolRequestDTO {
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private List<FeeTypeRequestDTO> feeTypes;
}
```

```java