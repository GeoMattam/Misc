package com.ngb.schoolfee.enums;

public enum PaymentChannel {
    ONLINE_BANKING,
    MOBILE_BANKING,
    IVR
}
```

```java