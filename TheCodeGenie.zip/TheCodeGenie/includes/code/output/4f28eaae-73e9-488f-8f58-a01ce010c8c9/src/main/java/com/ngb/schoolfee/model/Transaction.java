package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "TRANSACTION")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column(nullable = false, unique = true)
    private String referenceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_token", nullable = false)
    private CreditCard creditCard;

    @Column(nullable = false)
    private double amount;

    @Column(nullable = false)
    private LocalDateTime transactionDateTime = LocalDateTime.now();

    @Column
    private String remark;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status = TransactionStatus.PENDING;

    @Column(nullable = false)
    private String postingDescription;

    @Column(nullable = false)
    private Boolean isEppConverted = false;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private GLPostingStatus glPostingStatus = GLPostingStatus.PENDING;

    @Column(nullable = false)
    private Boolean ivrTinUsed = false;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private PaymentChannel channelUsed;

    @Column(nullable = false)
    private Boolean isLoyaltyEligible = true;


    public void updateStatus(TransactionStatus newStatus){
        this.status = newStatus;
    }
}
```

```java