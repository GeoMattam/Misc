package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.StudentStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentResponseDTO {
    private String studentSystemId;
    private String studentName;
    private String studentId;
    private String schoolId;
    private String schoolName;
    private StudentStatus status;
    private LocalDateTime registrationDate;

}
```

```java