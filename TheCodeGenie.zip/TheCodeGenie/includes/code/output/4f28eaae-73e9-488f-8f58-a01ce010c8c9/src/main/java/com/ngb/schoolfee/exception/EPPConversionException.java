package com.ngb.schoolfee.exception;

public class EPPConversionException extends RuntimeException{
    public EPPConversionException(String message) {
        super(message);
    }
}
```

```java