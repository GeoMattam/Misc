```java
###FilePath:src/main/java/com/ngb/schoolfee/domain/School.java

package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "SCHOOL")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class School {

    @Id
    @Column(name = "school_id", length = 50, nullable = false, unique = true)
    private String schoolId;

    @Column(name = "school_name", length = 255, nullable = false, unique = true)
    private String schoolName;

    @Column(name = "location", length = 255, nullable = false)
    private String location;

    @Column(name = "ngb_account_number", length = 50, nullable = false, unique = true)
    private String ngbAccountNumber;

    @Column(name = "ngb_gl_account_config", length = 100, nullable = false)
    private String ngbGlAccountConfig;

    @Column(name = "registration_date", nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();

    @Column(name = "operational_since", nullable = false)
    private LocalDate operationalSince;

    @Column(name = "is_active", nullable = false)
    private boolean isActive = true;

    @Column(name = "min_students", nullable = false)
    private int minEnrolledStudents = 1000;

    @Column(name = "min_annual_fee_coll", nullable = false, precision = 18, scale = 2)
    private BigDecimal minAnnualFeeCollection = BigDecimal.valueOf(500000.00);

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;

    public boolean applyBusinessRules() {
        return operationalSince != null && operationalSince.isBefore(LocalDate.now().minusYears(3)) &&
               minEnrolledStudents >= 1000 && minAnnualFeeCollection.compareTo(BigDecimal.valueOf(500000.00)) >= 0;
    }
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/domain/FeeType.java
package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "FEE_TYPE")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "fee_type_id", nullable = false, unique = true)
    private Long feeTypeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(name = "fee_type_name", length = 100, nullable = false)
    private String feeTypeName;

    @Column(name = "description", length = 255)
    private String description;

    @Column(name = "is_active", nullable = false)
    private boolean isActive = true;


}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/domain/Customer.java

package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CUSTOMER")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    @Column(name = "customer_id", length = 50, nullable = false, unique = true)
    private String customerId;

    @Column(name = "customer_name", length = 255, nullable = false)
    private String customerName;

    @Column(name = "contact_info", length = 255, nullable = false)
    private String contactInfo;

    @Column(name = "status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private CustomerStatus status = CustomerStatus.ACTIVE;


    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CreditCard> creditCards;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Student> students;

    public boolean isActiveCardholder() {
        return this.creditCards != null && !this.creditCards.isEmpty() && this.status == CustomerStatus.ACTIVE;
    }
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/domain/CreditCard.java

package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "CREDIT_CARD")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditCard {

    @Id
    @Column(name = "card_token", length = 255, nullable = false, unique = true)
    private String cardToken;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @Column(name = "card_last_4_digits", length = 4, nullable = false)
    private String cardLast4Digits;

    @Column(name = "card_type", length = 50, nullable = false)
    @Enumerated(EnumType.STRING)
    private CardType cardType;

    @Column(name = "expiry_date", nullable = false)
    private LocalDate expiryDate;

    @Column(name = "balance", nullable = false, precision = 18, scale = 2)
    private BigDecimal balance;

    @Column(name = "status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private CardStatus status = CardStatus.ACTIVE;


    @OneToMany(mappedBy = "creditCard", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Transaction> transactions;

    public boolean isCardActive() {
        return this.status == CardStatus.ACTIVE;
    }

    public boolean hasSufficientBalance(BigDecimal amount) {
        return this.balance.compareTo(amount) >= 0;
    }

}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/domain/Student.java

package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "STUDENT")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @Column(name = "student_id", length = 50, nullable = false)
    private String studentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Column(name = "student_name", length = 255, nullable = false)
    private String studentName;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "registered_by_customer_id", nullable = false)
    private Customer customer;

    @Column(name = "registration_date", nullable = false, updatable = false)
    private LocalDateTime registrationDate = LocalDateTime.now();

    @Column(name = "status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private StudentStatus status = StudentStatus.REGISTERED;

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Transaction> transactions;

    @Column(name = "last_updated_date", nullable = false)
    private LocalDateTime lastUpdatedDate = LocalDateTime.now();

    public boolean isRegistered(){
        return this.status == StudentStatus.REGISTERED;
    }
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/domain/Transaction.java

package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "TRANSACTION")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @Column(name = "transaction_id", length = 50, nullable = false, unique = true)
    private String transactionId;

    @Column(name = "transaction_date_time", nullable = false, updatable = false)
    private LocalDateTime transactionDateTime = LocalDateTime.now();

    @Column(name = "amount", nullable = false, precision = 18, scale = 2)
    private BigDecimal amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_token", nullable = false)
    private CreditCard creditCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @Column(name = "remark", length = 20)
    private String remark;

    @Column(name = "status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status = TransactionStatus.PENDING;

    @Column(name = "posting_description", length = 40, nullable = false)
    private String postingDescription;

    @Column(name = "is_epp_converted", nullable = false)
    private boolean isEPPConverted = false;

    @Column(name = "gl_posting_status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private GLPostingStatus glPostingStatus = GLPostingStatus.PENDING;


    @Column(name = "is_loyalty_eligible", nullable = false)
    private boolean isLoyaltyEligible = true;

    @Column(name = "ivr_tin_used", nullable = false)
    private boolean ivrTinUsed = false;

    @Column(name = "channel_used", length = 50, nullable = false)
    private String channelUsed;


    @OneToMany(mappedBy = "transaction", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<EPPRequest> eppRequests;

    @OneToMany(mappedBy = "transaction", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AuditLog> auditLogs;


    public void updateStatus(TransactionStatus newStatus) {
        this.status = newStatus;
    }
}

```

```java
###FilePath:src/main/java/com/ngb/schoolfee/domain/EPPRequest.java

package com.ngb.schoolfee.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "EPP_REQUEST")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EPPRequest {

    @Id
    @Column(name = "epp_request_id", length = 50, nullable = false, unique = true)
    private String eppRequestId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false, unique = true) //Ensures 1:1 with Transaction
    private Transaction transaction;

    @Column(name = "request_date_time", nullable = false, updatable = false)
    private LocalDateTime requestDateTime = LocalDateTime.now();

    @Column(name = "status", length = 20, nullable = false)
    @Enumerated(EnumType.STRING)
    private EPPStatus status = EPPStatus.PENDING;

    @Column(name = "rejection_reason", length = 255)
    private String rejectionReason;


    @Column(name = "approval_date_time")
    private LocalDateTime approvalDateTime;

    @Column(name = "no_loyalty_points_flag", nullable = false)
    private boolean noLoyaltyPointsFlag = true;

    @OneToMany(mappedBy = "eppRequest", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AuditLog> auditLogs;

    public void updateStatus(EPPStatus newStatus, String reason) {
        this.status = newStatus;
        this.rejectionReason = reason;
    }
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/domain/AuditLog.java

package com.ngb.schoolfee.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "AUDIT_LOG")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "log_id", nullable = false, unique = true)
    private Long logId;

    @Column(name = "activity_type", length = 100, nullable = false)
    private String activityType;

    @Column(name = "entity_id_affected", length = 50)
    private String entityIdAffected;

    @Column(name = "entity_type", length = 50)
    private String entityType;

    @Column(name = "timestamp", nullable = false, updatable = false)
    private LocalDateTime timestamp = LocalDateTime.now();

    @Column(name = "performed_by_user_id", length = 100)
    private String performedByUserId;

    @Column(name = "channel", length = 50)
    private String channel;

    @Column(name = "details")
    private String details;

    @Column(name = "success_status", nullable = false)
    private boolean successStatus;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id")
    @JsonIgnore
    private Transaction transaction;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "epp_request_id")
    @JsonIgnore
    private EPPRequest eppRequest;
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/enums/CardType.java

package com.ngb.schoolfee.enums;

public enum CardType {
    VISA_CONVENTIONAL,
    VISA_ISLAMIC,
    MASTERCARD
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/enums/CardStatus.java

package com.ngb.schoolfee.enums;

public enum CardStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/enums/CustomerStatus.java

package com.ngb.schoolfee.enums;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/enums/EPPStatus.java
package com.ngb.schoolfee.enums;

public enum EPPStatus {
    PENDING,
    APPROVED,
    REJECTED
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/enums/GLPostingStatus.java

package com.ngb.schoolfee.enums;

public enum GLPostingStatus {
    PENDING,
    POSTED,
    FAILED
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/enums/StudentStatus.java

package com.ngb.schoolfee.enums;

public enum StudentStatus {
    REGISTERED,
    DE_REGISTERED
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/enums/TransactionStatus.java

package com.ngb.schoolfee.enums;

public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILED,
    PENDING_EPP,
    CANCELLED
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/repository/SchoolRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SchoolRepository extends JpaRepository<School, String> {
    Optional<School> findBySchoolName(String schoolName);
    Optional<School> findByNgbAccountNumber(String accountNumber);
    boolean existsBySchoolName(String schoolName);
    boolean existsByNgbAccountNumber(String accountNumber);
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/repository/FeeTypeRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.FeeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeeTypeRepository extends JpaRepository<FeeType, Long> {

}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/repository/CustomerRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {
    Optional<Customer> findByCustomerId(String customerId);
    boolean existsByCustomerId(String customerId);
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/repository/CreditCardRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.CreditCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CreditCardRepository extends JpaRepository<CreditCard, String> {
    Optional<CreditCard> findByCardToken(String cardToken);
    boolean existsByCardToken(String cardToken);
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/repository/StudentRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {

    List<Student> findByCustomerId(String customerId);
    Optional<Student> findByStudentIdAndSchoolSchoolId(String studentId, String schoolId);
    boolean existsByStudentIdAndSchoolSchoolId(String studentId, String schoolId);

}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/repository/TransactionRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.Transaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, String> {
    Page<Transaction> findByCustomerId(String customerId, Pageable pageable);
    List<Transaction> findByCustomerId(String customerId);
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/repository/EPPRequestRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.EPPRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EPPRequestRepository extends JpaRepository<EPPRequest, String> {
    Optional<EPPRequest> findByTransactionTransactionId(String transactionId);
    boolean existsByTransactionTransactionId(String transactionId);
}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/repository/AuditLogRepository.java

package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/service/SchoolManagementService.java

package com.ngb.schoolfee.service;


import com.ngb.schoolfee.domain.School;
import com.ngb.schoolfee.dto.FeeTypeRequest;
import com.ngb.schoolfee.dto.SchoolRequest;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SchoolManagementService {

    private final SchoolRepository schoolRepository;
    private final FeeTypeRepository feeTypeRepository;


    @Transactional
    public School registerSchool(SchoolRequest schoolRequest) {
        if (schoolRepository.existsBySchoolName(schoolRequest.getSchoolName()) ||
            schoolRepository.existsByNgbAccountNumber(schoolRequest.getNgbAccountNumber())) {
            throw new SchoolRegistrationException("School with this name or account number already exists.");
        }

        School school = School.builder()
                .schoolId(generateSchoolId())
                .schoolName(schoolRequest.getSchoolName())
                .location(schoolRequest.getLocation())
                .ngbAccountNumber(schoolRequest.getNgbAccountNumber())
                .ngbGlAccountConfig(schoolRequest.getNgbGlAccountConfig())
                .operationalSince(schoolRequest.getOperationalSince())
                .build();


        if(!school.applyBusinessRules()){
            throw new SchoolRegistrationException("School does not meet registration criteria.");
        }

        List<com.ngb.schoolfee.domain.FeeType> feeTypes = schoolRequest.getFeeTypes().stream()
                .map(feeTypeRequest -> com.ngb.schoolfee.domain.FeeType.builder()
                        .feeTypeName(feeTypeRequest.getFeeTypeName())
                        .description(feeTypeRequest.getDescription())
                        .school(school)
                        .build())
                .collect(Collectors.toList());

        school.setFeeTypes(feeTypes);
        return schoolRepository.save(school);
    }


    private String generateSchoolId() {
        //Implement your school ID generation logic here.  This is a placeholder.
        return "SCHOOL-" + System.currentTimeMillis();
    }

}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/service/StudentManagementService.java

package com.ngb.schoolfee.service;

import com.ngb.schoolfee.domain.Student;
import com.ngb.schoolfee.dto.StudentRequest;
import com.ngb.schoolfee.enums.StudentStatus;
import com.ngb.schoolfee.exception.StudentManagementException;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class StudentManagementService {

    private final StudentRepository studentRepository;
    private final SchoolRepository schoolRepository;
    private final NotificationService notificationService;


    @Transactional
    public Student registerStudent(StudentRequest studentRequest, String customerId) {
        //1. Verify Customer
        CustomerService customerService = new CustomerService(null, null); // Replace with actual dependency injection
        if(!customerService.isCustomerActiveCardholder(customerId)){
            throw new StudentManagementException("Only active credit card holders can register students.");
        }


        //2. Verify School
        if(!schoolRepository.existsById(studentRequest.getSchoolId())){
            throw new StudentManagementException("School does not exist.");
        }

        //3. Verify Student ID Match & Uniqueness
        if(!studentRequest.getStudentId().equals(studentRequest.getStudentIdConfirm())){
            throw new StudentManagementException("Student IDs do not match.");
        }
        if(studentRepository.existsByStudentIdAndSchoolSchoolId(studentRequest.getStudentId(), studentRequest.getSchoolId())){
            throw new StudentManagementException("Student is already registered with this school.");
        }

        //4.Create Student
        Student student = Student.builder()
                .studentId(studentRequest.getStudentId())
                .studentName(studentRequest.getStudentName())
                .school(schoolRepository.findById(studentRequest.getSchoolId()).get())
                .customer(customerService.findCustomerById(customerId).get())
                .build();


        Student savedStudent = studentRepository.save(student);
        notificationService.sendSMS(student.getCustomer().getContactInfo(),
                "Student " + student.getStudentName() + " registered successfully. Student ID: " + student.getStudentId());

        return savedStudent;
    }

    @Transactional
    public Student amendStudent(String studentId, String schoolId, StudentRequest studentRequest, String customerId) {
        Optional<Student> studentOptional = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId);

        if (studentOptional.isEmpty()) {
            throw new StudentManagementException("Student not found.");
        }

        Student student = studentOptional.get();
        if (!student.getCustomer().getCustomerId().equals(customerId)) {
            throw new StudentManagementException("Unauthorized access: You cannot amend other customers' students.");
        }


        student.setStudentName(studentRequest.getStudentName());
        student.setSchool(schoolRepository.findById(studentRequest.getSchoolId()).get());
        student.setLastUpdatedDate(LocalDateTime.now());

        Student updatedStudent = studentRepository.save(student);

        notificationService.sendSMS(updatedStudent.getCustomer().getContactInfo(),
                "Student " + updatedStudent.getStudentName() + " details updated successfully. Student ID: " + updatedStudent.getStudentId());
        return updatedStudent;
    }


    @Transactional
    public boolean deRegisterStudent(String studentId, String schoolId, String customerId) {
        Optional<Student> studentOptional = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId);

        if (studentOptional.isEmpty()) {
            throw new StudentManagementException("Student not found.");
        }

        Student student = studentOptional.get();
        if (!student.getCustomer().getCustomerId().equals(customerId)) {
            throw new StudentManagementException("Unauthorized access: You cannot deregister other customers' students.");
        }

        student.setStatus(StudentStatus.DE_REGISTERED);
        student.setLastUpdatedDate(LocalDateTime.now());
        studentRepository.save(student);
        notificationService.sendSMS(student.getCustomer().getContactInfo(),
                "Student " + student.getStudentName() + " deregistered successfully. Student ID: " + student.getStudentId());
        return true;
    }

    public List<Student> getStudentsByCustomerId(String customerId) {
        return studentRepository.findByCustomerId(customerId);
    }

    public boolean isStudentRegistered(String studentId, String schoolId) {
        return studentRepository.existsByStudentIdAndSchoolSchoolId(studentId, schoolId);
    }


}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/service/PaymentOrchestrationService.java

package com.ngb.schoolfee.service;

import com.ngb.schoolfee.domain.CreditCard;
import com.ngb.schoolfee.domain.Student;
import com.ngb.schoolfee.domain.Transaction;
import com.ngb.schoolfee.dto.PaymentRequest;
import com.ngb.schoolfee.dto.TransactionHistoryResponse;
import com.ngb.schoolfee.enums.TransactionStatus;
import com.ngb.schoolfee.exception.PaymentException;
import com.ngb.schoolfee.repository.CreditCardRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import com.ngb.schoolfee.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaymentOrchestrationService {

    private final StudentRepository studentRepository;
    private final CreditCardRepository creditCardRepository;
    private final TransactionRepository transactionRepository;
    private final FinancialPostingService financialPostingService;
    private final NotificationService notificationService;
    private final TransactionAndAuditLogService auditLogService;
    private final AuthenticationService authenticationService;


    @Transactional
    public Transaction initiateFeePayment(PaymentRequest paymentRequest, String customerId) {

        //1. Authentication
        if(!authenticationService.validateOTP(paymentRequest.getOtp(), customerId)){
            throw new PaymentException("Invalid OTP.");
        }

        //2. Validate Student
        Student student = studentRepository.findById(paymentRequest.getStudentSystemId())
                .orElseThrow(() -> new PaymentException("Student not found."));

        if (!student.isRegistered()){
            throw new PaymentException("Student is not registered.");
        }

        //3. Validate Card
        CreditCard creditCard = creditCardRepository.findById(paymentRequest.getCardNumber())
                .orElseThrow(() -> new PaymentException("Credit Card not found."));
        if (!creditCard.isCardActive() || !creditCard.hasSufficientBalance(paymentRequest.getAmount())) {
            throw new PaymentException("Card is inactive or insufficient balance.");
        }

        //4. Initiate Transaction & Debit
        String transactionId = UUID.randomUUID().toString();
        Transaction transaction = Transaction.builder()
                .transactionId(transactionId)
                .amount(paymentRequest.getAmount())
                .remark(paymentRequest.getRemark())
                .creditCard(creditCard)
                .student(student)
                .school(student.getSchool())
                .feeType(student.getSchool().getFeeTypes().stream()
                        .filter(feeType -> feeType.getFeeTypeName().equals(paymentRequest.getFeeType()))
                        .findFirst().orElseThrow(()-> new PaymentException("Fee type not found.")))
                .postingDescription(generatePostingDescription(student, paymentRequest.getFeeType(), paymentRequest.getAmount()))
                .channelUsed(paymentRequest.getChannelUsed())
                .build();


        if (!financialPostingService.debitCreditCard(creditCard.getCardToken(), paymentRequest.getAmount(), transaction.getPostingDescription())) {
            transaction.setStatus(TransactionStatus.FAILED);
            transaction.setGlPostingStatus(GLPostingStatus.FAILED);
            throw new PaymentException("Failed to debit credit card.");
        }
        transaction.setStatus(TransactionStatus.PENDING_POSTING);

        transactionRepository.save(transaction);

        // 5. Asynchronously Post to GL
        financialPostingService.postTransaction(transaction);


        notificationService.sendSMS(student.getCustomer().getContactInfo(),
                "Your fee payment of " + paymentRequest.getAmount() + " is processing. Transaction ID: " + transactionId);

        auditLogService.logActivity("FEE_PAYMENT_INITIATED", transactionId, "TRANSACTION", customerId, null, true);

        return transaction;
    }


    private String generatePostingDescription(Student student, String feeType, BigDecimal amount) {
        //Implement your description generation logic here. This is a placeholder.
        return student.getStudentName() + " - " + feeType + " - " + amount;
    }


    public List<TransactionHistoryResponse> viewPaymentHistory(String customerId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Transaction> transactions = transactionRepository.findByCustomerId(customerId, pageable);

        return transactions.getContent().stream()
                .map(transaction -> TransactionHistoryResponse.builder()
                        .transactionId(transaction.getTransactionId())
                        .date(transaction.getTransactionDateTime())
                        .amount(transaction.getAmount())
                        .studentName(transaction.getStudent().getStudentName())
                        .schoolName(transaction.getSchool().getSchoolName())
                        .feeTypeName(transaction.getFeeType().getFeeTypeName())
                        .remark(transaction.getRemark())
                        .status(transaction.getStatus().toString())
                        .build())
                .collect(Collectors.toList());
    }

}
```

```java
###FilePath:src/main/java/com/ngb/schoolfee/service/FinancialPostingService.java

package com.ngb.schoolfee.service;

import com.ng