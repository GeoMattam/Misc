```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.FeeTypeDto;
import com.ngb.schoolfee.model.FeeType;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FeeTypeService {

    @Autowired
    private FeeTypeRepository feeTypeRepository;

    @Transactional
    public List<FeeType> createFeeTypes(List<FeeTypeDto> feeTypeDtos, String schoolName) {

        return feeTypeDtos.stream()
                .map(dto -> FeeType.builder()
                        .feeTypeName(dto.getFeeTypeName())
                        .description(dto.getDescription())
                        .isActive(dto.isActive())
                        .build())
                .collect(Collectors.toList());
    }
}
```