```java
package com.ngb.schoolfee.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
public class StudentDto {
    private String studentId;
    @NotBlank(message = "Student name cannot be blank")
    private String studentName;

    @NotNull(message = "School ID cannot be null")
    private Long schoolId;

    private String status; // REGISTERED, DE_REGISTERED

    private Long registeredByCustomerId;
}

```