package com.ngb.schoolfee.service;

import com.ngb.schoolfee.domain.Student;
import com.ngb.schoolfee.dto.StudentRequest;
import com.ngb.schoolfee.enums.StudentStatus;
import com.ngb.schoolfee.exception.StudentManagementException;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class StudentManagementService {

    private final StudentRepository studentRepository;
    private final SchoolRepository schoolRepository;
    private final NotificationService notificationService;


    @Transactional
    public Student registerStudent(StudentRequest studentRequest, String customerId) {
        //1. Verify Customer
        CustomerService customerService = new CustomerService(null, null); // Replace with actual dependency injection
        if(!customerService.isCustomerActiveCardholder(customerId)){
            throw new StudentManagementException("Only active credit card holders can register students.");
        }


        //2. Verify School
        if(!schoolRepository.existsById(studentRequest.getSchoolId())){
            throw new StudentManagementException("School does not exist.");
        }

        //3. Verify Student ID Match & Uniqueness
        if(!studentRequest.getStudentId().equals(studentRequest.getStudentIdConfirm())){
            throw new StudentManagementException("Student IDs do not match.");
        }
        if(studentRepository.existsByStudentIdAndSchoolSchoolId(studentRequest.getStudentId(), studentRequest.getSchoolId())){
            throw new StudentManagementException("Student is already registered with this school.");
        }

        //4.Create Student
        Student student = Student.builder()
                .studentId(studentRequest.getStudentId())
                .studentName(studentRequest.getStudentName())
                .school(schoolRepository.findById(studentRequest.getSchoolId()).get())
                .customer(customerService.findCustomerById(customerId).get())
                .build();


        Student savedStudent = studentRepository.save(student);
        notificationService.sendSMS(student.getCustomer().getContactInfo(),
                "Student " + student.getStudentName() + " registered successfully. Student ID: " + student.getStudentId());

        return savedStudent;
    }

    @Transactional
    public Student amendStudent(String studentId, String schoolId, StudentRequest studentRequest, String customerId) {
        Optional<Student> studentOptional = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId);

        if (studentOptional.isEmpty()) {
            throw new StudentManagementException("Student not found.");
        }

        Student student = studentOptional.get();
        if (!student.getCustomer().getCustomerId().equals(customerId)) {
            throw new StudentManagementException("Unauthorized access: You cannot amend other customers' students.");
        }


        student.setStudentName(studentRequest.getStudentName());
        student.setSchool(schoolRepository.findById(studentRequest.getSchoolId()).get());
        student.setLastUpdatedDate(LocalDateTime.now());

        Student updatedStudent = studentRepository.save(student);

        notificationService.sendSMS(updatedStudent.getCustomer().getContactInfo(),
                "Student " + updatedStudent.getStudentName() + " details updated successfully. Student ID: " + updatedStudent.getStudentId());
        return updatedStudent;
    }


    @Transactional
    public boolean deRegisterStudent(String studentId, String schoolId, String customerId) {
        Optional<Student> studentOptional = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId);

        if (studentOptional.isEmpty()) {
            throw new StudentManagementException("Student not found.");
        }

        Student student = studentOptional.get();
        if (!student.getCustomer().getCustomerId().equals(customerId)) {
            throw new StudentManagementException("Unauthorized access: You cannot deregister other customers' students.");
        }

        student.setStatus(StudentStatus.DE_REGISTERED);
        student.setLastUpdatedDate(LocalDateTime.now());
        studentRepository.save(student);
        notificationService.sendSMS(student.getCustomer().getContactInfo(),
                "Student " + student.getStudentName() + " deregistered successfully. Student ID: " + student.getStudentId());
        return true;
    }

    public List<Student> getStudentsByCustomerId(String customerId) {
        return studentRepository.findByCustomerId(customerId);
    }

    public boolean isStudentRegistered(String studentId, String schoolId) {
        return studentRepository.existsByStudentIdAndSchoolSchoolId(studentId, schoolId);
    }


}
```

```java