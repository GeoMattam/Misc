```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.SchoolDto;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SchoolService {

    @Autowired
    private SchoolRepository schoolRepository;

    @Autowired
    private FeeTypeService feeTypeService;


    @Transactional
    public School registerSchool(SchoolDto schoolDto) {
        if(schoolRepository.existsByNgbAccountNumber(schoolDto.getNgbAccountNumber())) {
            throw new SchoolRegistrationException("School with this account number already exists");
        }
        School school = School.builder()
                .schoolName(schoolDto.getSchoolName())
                .location(schoolDto.getLocation())
                .ngbAccountNumber(schoolDto.getNgbAccountNumber())
                .isActive(schoolDto.isActive())
                .feeTypes(feeTypeService.createFeeTypes(schoolDto.getFeeTypes(), schoolDto.getSchoolName()))
                .build();


        if (!school.applyBusinessRules()) {
            throw new SchoolRegistrationException("School registration failed: Business rules not met");
        }

        return schoolRepository.save(school);
    }


    public List<SchoolDto> getAllSchools() {
        return schoolRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());

    }

    public SchoolDto getSchoolDetails(Long schoolId) {
        Optional<School> optionalSchool = schoolRepository.findById(schoolId);
        return optionalSchool.map(this::mapToDto).orElse(null);

    }

    public SchoolDto mapToDto(School school) {
        SchoolDto schoolDto = new SchoolDto();
        schoolDto.setSchoolId(school.getSchoolId());
        schoolDto.setSchoolName(school.getSchoolName());
        schoolDto.setLocation(school.getLocation());
        schoolDto.setNgbAccountNumber(school.getNgbAccountNumber());
        schoolDto.setIsActive(school.isActive());
        return schoolDto;
    }



}
```