package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column(unique = true)
    private String referenceId; // Unique for each transaction

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_number", nullable = false)
    private CreditCard creditCard;

    @Column(nullable = false, precision = 18, scale = 2)
    private double amount;

    @Column(nullable = false, updatable = false)
    private LocalDateTime transactionDate = LocalDateTime.now();


    private String remark; // Max 20 chars

    @Column(nullable = false)
    private String status; // SUCCESS, FAILED, PENDING_EPP, CANCELLED

    @Column(nullable = false)
    private String postingDescription; // Max 40 chars

    @Column(nullable = false)
    private Boolean isEPPConverted = false;

    @Column(nullable = false)
    private String glPostingStatus; // PENDING, POSTED, FAILED

    @OneToMany(mappedBy = "transaction")
    private List<AuditLog> auditLogs;

    @OneToOne(mappedBy = "transaction", cascade = CascadeType.ALL, orphanRemoval = true)
    private EPPRequest eppRequest;

    public void updateStatus(String newStatus){
        this.status = newStatus;
    }

}
```

```java