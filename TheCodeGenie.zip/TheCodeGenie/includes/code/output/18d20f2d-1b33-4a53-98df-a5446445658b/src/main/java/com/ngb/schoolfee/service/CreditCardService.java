```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.exception.CreditCardException;
import com.ngb.schoolfee.model.CreditCard;
import com.ngb.schoolfee.repository.CreditCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CreditCardService {

    @Autowired
    private CreditCardRepository creditCardRepository;

    public CreditCard getCreditCard(String cardNumber) {
        Optional<CreditCard> creditCardOptional = creditCardRepository.findByCardNumber(cardNumber);
        return creditCardOptional.orElseThrow(() ->