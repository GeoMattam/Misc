package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class AuditLogRequest {
    private String activityType;
    private String entityIdAffected;
    private String entityType;
    private String performedBy;
    private String details;
}
```

```java