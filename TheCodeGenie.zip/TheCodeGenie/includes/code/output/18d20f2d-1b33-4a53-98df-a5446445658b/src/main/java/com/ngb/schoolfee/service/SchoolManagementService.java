package com.ngb.schoolfee.service;


import com.ngb.schoolfee.domain.School;
import com.ngb.schoolfee.dto.FeeTypeRequest;
import com.ngb.schoolfee.dto.SchoolRequest;
import com.ngb.schoolfee.exception.SchoolRegistrationException;
import com.ngb.schoolfee.repository.FeeTypeRepository;
import com.ngb.schoolfee.repository.SchoolRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SchoolManagementService {

    private final SchoolRepository schoolRepository;
    private final FeeTypeRepository feeTypeRepository;


    @Transactional
    public School registerSchool(SchoolRequest schoolRequest) {
        if (schoolRepository.existsBySchoolName(schoolRequest.getSchoolName()) ||
            schoolRepository.existsByNgbAccountNumber(schoolRequest.getNgbAccountNumber())) {
            throw new SchoolRegistrationException("School with this name or account number already exists.");
        }

        School school = School.builder()
                .schoolId(generateSchoolId())
                .schoolName(schoolRequest.getSchoolName())
                .location(schoolRequest.getLocation())
                .ngbAccountNumber(schoolRequest.getNgbAccountNumber())
                .ngbGlAccountConfig(schoolRequest.getNgbGlAccountConfig())
                .operationalSince(schoolRequest.getOperationalSince())
                .build();


        if(!school.applyBusinessRules()){
            throw new SchoolRegistrationException("School does not meet registration criteria.");
        }

        List<com.ngb.schoolfee.domain.FeeType> feeTypes = schoolRequest.getFeeTypes().stream()
                .map(feeTypeRequest -> com.ngb.schoolfee.domain.FeeType.builder()
                        .feeTypeName(feeTypeRequest.getFeeTypeName())
                        .description(feeTypeRequest.getDescription())
                        .school(school)
                        .build())
                .collect(Collectors.toList());

        school.setFeeTypes(feeTypes);
        return schoolRepository.save(school);
    }


    private String generateSchoolId() {
        //Implement your school ID generation logic here.  This is a placeholder.
        return "SCHOOL-" + System.currentTimeMillis();
    }

}
```

```java