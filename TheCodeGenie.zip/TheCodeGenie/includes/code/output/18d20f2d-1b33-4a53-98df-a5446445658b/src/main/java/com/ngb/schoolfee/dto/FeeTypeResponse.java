package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class FeeTypeResponse {
    private Long feeTypeId;
    private String name;
    private String description;
}
```

```java