package com.ngb.schoolfee.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "AUDIT_LOG")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "log_id", nullable = false, unique = true)
    private Long logId;

    @Column(name = "activity_type", length = 100, nullable = false)
    private String activityType;

    @Column(name = "entity_id_affected", length = 50)
    private String entityIdAffected;

    @Column(name = "entity_type", length = 50)
    private String entityType;

    @Column(name = "timestamp", nullable = false, updatable = false)
    private LocalDateTime timestamp = LocalDateTime.now();

    @Column(name = "performed_by_user_id", length = 100)
    private String performedByUserId;

    @Column(name = "channel", length = 50)
    private String channel;

    @Column(name = "details")
    private String details;

    @Column(name = "success_status", nullable = false)
    private boolean successStatus;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id")
    @JsonIgnore
    private Transaction transaction;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "epp_request_id")
    @JsonIgnore
    private EPPRequest eppRequest;
}
```

```java