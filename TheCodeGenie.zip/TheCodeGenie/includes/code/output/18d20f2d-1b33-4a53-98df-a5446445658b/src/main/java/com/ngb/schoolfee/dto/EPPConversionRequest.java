package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class EPPConversionRequest {
    private String transactionId;
    private String customerId;
}
```

```java