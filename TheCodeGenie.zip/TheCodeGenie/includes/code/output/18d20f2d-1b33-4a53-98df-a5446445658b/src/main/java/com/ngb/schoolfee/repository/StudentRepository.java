package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.domain.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {

    List<Student> findByCustomerId(String customerId);
    Optional<Student> findByStudentIdAndSchoolSchoolId(String studentId, String schoolId);
    boolean existsByStudentIdAndSchoolSchoolId(String studentId, String schoolId);

}
```

```java