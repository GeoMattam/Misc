```java
package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AuditLogDto {
    private Long logId;
    private String activityType;
    private String entityIdAffected;
    private String entityType;
    private LocalDateTime timestamp;
    private String performedByUserOrSystem;
    private String details;
    private boolean successStatus;
}
```