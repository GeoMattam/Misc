package com.ngb.schoolfee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;


@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logId;

    @Column(nullable = false)
    private String activityType;

    private String entityIdAffected;

    private String entityType;


    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime timestamp;


    private String performedByUserOrSystem;

    private String details;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id")
    private Transaction transaction;


    private Boolean successStatus = true;
}
```

```java