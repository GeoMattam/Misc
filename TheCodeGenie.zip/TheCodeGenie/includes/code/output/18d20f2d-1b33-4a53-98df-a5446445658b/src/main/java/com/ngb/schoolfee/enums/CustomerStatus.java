package com.ngb.schoolfee.enums;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}
```

```java