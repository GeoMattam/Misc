```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.StudentDto;
import com.ngb.schoolfee.enums.StudentStatus;
import com.ngb.schoolfee.exception.StudentRegistrationException;
import com.ngb.schoolfee.model.Customer;
import com.ngb.schoolfee.model.School;
import com.ngb.schoolfee.model.Student;
import com.ngb.schoolfee.repository.SchoolRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private SchoolRepository schoolRepository;
    @Autowired
    private CustomerService customerService;

    @Transactional
    public Student registerStudent(StudentDto studentDto, String customerId) {
        Optional<School> schoolOptional = schoolRepository.findById(studentDto.getSchoolId());
        if (schoolOptional.isEmpty()) {
            throw new StudentRegistrationException("School not found");
        }
        School school = schoolOptional.get();
        Customer customer = customerService.getCustomer(customerId);

        if (!customer.isActiveCardholder()) {
            throw new StudentRegistrationException("Only active NGB Credit Cardholders can manage students.");
        }

        Student student = Student.builder()
                .studentId(studentDto.getStudentId())
                .school(school)
                .name(studentDto.getStudentName())
                .registeredByCustomer(customer)
                .status(StudentStatus.REGISTERED.name())
                .build();

        return studentRepository.save(student);
    }



    public List<StudentDto> getStudentsByCustomerId(String customerId) {
        return studentRepository.findAll().stream()
                .filter(s -> customerId.equals(s.getRegisteredByCustomer().getCustomerId()))
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }


    public StudentDto mapToDto(Student student) {
        StudentDto studentDto = new StudentDto();
        studentDto.setStudentId(student.getStudentId());
        studentDto.setStudentName(student.getName());
        studentDto.setSchoolId(student.getSchool().getSchoolId());
        studentDto.setStatus(student.getStatus());
        return studentDto;
    }

    @Transactional
    public boolean deRegisterStudent(String studentId, Long schoolId) {
        Optional<Student> studentOptional = studentRepository.findByStudentIdAndSchoolSchoolId(studentId, schoolId);
        if (studentOptional.isEmpty()) {
            return false; //Or throw exception
        }
        Student student = studentOptional.get();
        student.setStatus(StudentStatus.DE_REGISTERED.name());
        studentRepository.save(student);
        return true;
    }
}
```