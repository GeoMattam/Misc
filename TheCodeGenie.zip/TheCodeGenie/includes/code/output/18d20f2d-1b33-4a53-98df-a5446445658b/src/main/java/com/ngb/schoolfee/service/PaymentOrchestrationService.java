package com.ngb.schoolfee.service;

import com.ngb.schoolfee.domain.CreditCard;
import com.ngb.schoolfee.domain.Student;
import com.ngb.schoolfee.domain.Transaction;
import com.ngb.schoolfee.dto.PaymentRequest;
import com.ngb.schoolfee.dto.TransactionHistoryResponse;
import com.ngb.schoolfee.enums.TransactionStatus;
import com.ngb.schoolfee.exception.PaymentException;
import com.ngb.schoolfee.repository.CreditCardRepository;
import com.ngb.schoolfee.repository.StudentRepository;
import com.ngb.schoolfee.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaymentOrchestrationService {

    private final StudentRepository studentRepository;
    private final CreditCardRepository creditCardRepository;
    private final TransactionRepository transactionRepository;
    private final FinancialPostingService financialPostingService;
    private final NotificationService notificationService;
    private final TransactionAndAuditLogService auditLogService;
    private final AuthenticationService authenticationService;


    @Transactional
    public Transaction initiateFeePayment(PaymentRequest paymentRequest, String customerId) {

        //1. Authentication
        if(!authenticationService.validateOTP(paymentRequest.getOtp(), customerId)){
            throw new PaymentException("Invalid OTP.");
        }

        //2. Validate Student
        Student student = studentRepository.findById(paymentRequest.getStudentSystemId())
                .orElseThrow(() -> new PaymentException("Student not found."));

        if (!student.isRegistered()){
            throw new PaymentException("Student is not registered.");
        }

        //3. Validate Card
        CreditCard creditCard = creditCardRepository.findById(paymentRequest.getCardNumber())
                .orElseThrow(() -> new PaymentException("Credit Card not found."));
        if (!creditCard.isCardActive() || !creditCard.hasSufficientBalance(paymentRequest.getAmount())) {
            throw new PaymentException("Card is inactive or insufficient balance.");
        }

        //4. Initiate Transaction & Debit
        String transactionId = UUID.randomUUID().toString();
        Transaction transaction = Transaction.builder()
                .transactionId(transactionId)
                .amount(paymentRequest.getAmount())
                .remark(paymentRequest.getRemark())
                .creditCard(creditCard)
                .student(student)
                .school(student.getSchool())
                .feeType(student.getSchool().getFeeTypes().stream()
                        .filter(feeType -> feeType.getFeeTypeName().equals(paymentRequest.getFeeType()))
                        .findFirst().orElseThrow(()-> new PaymentException("Fee type not found.")))
                .postingDescription(generatePostingDescription(student, paymentRequest.getFeeType(), paymentRequest.getAmount()))
                .channelUsed(paymentRequest.getChannelUsed())
                .build();


        if (!financialPostingService.debitCreditCard(creditCard.getCardToken(), paymentRequest.getAmount(), transaction.getPostingDescription())) {
            transaction.setStatus(TransactionStatus.FAILED);
            transaction.setGlPostingStatus(GLPostingStatus.FAILED);
            throw new PaymentException("Failed to debit credit card.");
        }
        transaction.setStatus(TransactionStatus.PENDING_POSTING);

        transactionRepository.save(transaction);

        // 5. Asynchronously Post to GL
        financialPostingService.postTransaction(transaction);


        notificationService.sendSMS(student.getCustomer().getContactInfo(),
                "Your fee payment of " + paymentRequest.getAmount() + " is processing. Transaction ID: " + transactionId);

        auditLogService.logActivity("FEE_PAYMENT_INITIATED", transactionId, "TRANSACTION", customerId, null, true);

        return transaction;
    }


    private String generatePostingDescription(Student student, String feeType, BigDecimal amount) {
        //Implement your description generation logic here. This is a placeholder.
        return student.getStudentName() + " - " + feeType + " - " + amount;
    }


    public List<TransactionHistoryResponse> viewPaymentHistory(String customerId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Transaction> transactions = transactionRepository.findByCustomerId(customerId, pageable);

        return transactions.getContent().stream()
                .map(transaction -> TransactionHistoryResponse.builder()
                        .transactionId(transaction.getTransactionId())
                        .date(transaction.getTransactionDateTime())
                        .amount(transaction.getAmount())
                        .studentName(transaction.getStudent().getStudentName())
                        .schoolName(transaction.getSchool().getSchoolName())
                        .feeTypeName(transaction.getFeeType().getFeeTypeName())
                        .remark(transaction.getRemark())
                        .status(transaction.getStatus().toString())
                        .build())
                .collect(Collectors.toList());
    }

}
```

```java