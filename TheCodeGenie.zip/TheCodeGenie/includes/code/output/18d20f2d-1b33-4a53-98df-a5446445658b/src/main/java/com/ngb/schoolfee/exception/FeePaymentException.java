package com.ngb.schoolfee.exception;

public class FeePaymentException extends RuntimeException {
    public FeePaymentException(String message) {
        super(message);
    }
}
```

```java