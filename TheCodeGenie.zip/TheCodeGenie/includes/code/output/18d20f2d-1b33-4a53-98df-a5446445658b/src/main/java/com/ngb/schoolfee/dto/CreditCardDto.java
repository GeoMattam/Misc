```java
package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class CreditCardDto {
    private String cardNumber;
    private String cardType;
    private String expiryDate;
    private double balance;
    private String status;
    private Long customerId;
}
```