package com.ngb.schoolfee.fr001.controller;

import com.ngb.schoolfee.fr001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.fr001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.fr001.service.SchoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/schools")
public class SchoolController {

    private final SchoolService schoolService;

    @Autowired
    public SchoolController(SchoolService schoolService) {
        this.schoolService = schoolService;
    }

    @PostMapping
    public ResponseEntity<SchoolRegistrationResponse> registerSchool(@Valid @RequestBody SchoolRegistrationRequest request) {
        SchoolRegistrationResponse response = schoolService.registerSchool(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    //Add other endpoints as needed (GET, PUT, DELETE) based on requirements.
}