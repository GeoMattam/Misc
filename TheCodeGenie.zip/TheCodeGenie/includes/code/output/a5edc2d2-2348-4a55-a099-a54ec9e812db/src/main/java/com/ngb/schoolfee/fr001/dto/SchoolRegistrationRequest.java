package com.ngb.schoolfee.fr001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Data
public class SchoolRegistrationRequest {

    @NotBlank(message = "School name cannot be blank")
    @Size(max = 255, message = "School name must be less than 255 characters")
    private String name;

    @NotBlank(message = "Location cannot be blank")
    @Size(max = 255, message = "Location must be less than 255 characters")
    private String location;

    @NotBlank(message = "Account number cannot be blank")
    @Size(max = 50, message = "Account number must be less than 50 characters")
    private String accountNumber;

    @NotNull(message = "Minimum enrolled students cannot be null")
    @Positive(message = "Minimum enrolled students must be a positive number")
    private Integer minEnrolledStudents;

    @NotNull(message = "Operational years cannot be null")
    @Positive(message = "Operational years must be a positive number")
    private Integer operationalYears;

    @NotNull(message = "Minimum annual fee collection cannot be null")
    @Positive(message = "Minimum annual fee collection must be a positive number")
    private Double minAnnualFeeCollection;
    //Add other fields as needed.

}