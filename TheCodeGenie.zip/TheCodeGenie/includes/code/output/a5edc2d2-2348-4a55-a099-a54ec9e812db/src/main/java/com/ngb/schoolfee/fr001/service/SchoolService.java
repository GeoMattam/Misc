package com.ngb.schoolfee.fr001.service;

import com.ngb.schoolfee.fr001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.fr001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.fr001.exception.SchoolRegistrationException;
import com.ngb.schoolfee.fr001.model.School;
import com.ngb.schoolfee.fr001.repository.SchoolRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class SchoolService {

    private static final Logger logger = LoggerFactory.getLogger(SchoolService.class);

    private final SchoolRepository schoolRepository;

    @Autowired
    public SchoolService(SchoolRepository schoolRepository) {
        this.schoolRepository = schoolRepository;
    }


    @Transactional
    public SchoolRegistrationResponse registerSchool(SchoolRegistrationRequest request) {
        //Validate Request
        Optional<School> existingSchool = schoolRepository.findByNameAndLocation(request.getName(), request.getLocation());
        if (existingSchool.isPresent()) {
            throw new SchoolRegistrationException("School already registered with this name and location.");
        }

        // Apply Business Rules (from BRD)
        if (request.getMinEnrolledStudents() < 1000 || request.getOperationalYears() < 3 || request.getMinAnnualFeeCollection() < 500000) {
            throw new SchoolRegistrationException("School does not meet the minimum requirements for registration.");
        }

        School school = new School();
        school.setName(request.getName());
        school.setLocation(request.getLocation());
        school.setNgbAccountNumber(request.getAccountNumber());
        school.setRegistrationDate(LocalDateTime.now());
        school.setIsActive(true);
        school.setMinEnrolledStudents(request.getMinEnrolledStudents());
        school.setOperationalYears(request.getOperationalYears());
        school.setMinAnnualFeeCollection(request.getMinAnnualFeeCollection());
        // ... other fields ...

        School savedSchool = schoolRepository.save(school);

        logger.info("School registered successfully: {}", savedSchool);

        SchoolRegistrationResponse response = new SchoolRegistrationResponse();
        response.setSchoolId(savedSchool.getId());
        response.setStatus("REGISTERED");

        return response;
    }
    //Add other service methods as needed based on requirements.
}