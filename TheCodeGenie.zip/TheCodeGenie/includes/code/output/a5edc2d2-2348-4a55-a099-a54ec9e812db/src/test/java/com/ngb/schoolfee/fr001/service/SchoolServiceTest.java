package com.ngb.schoolfee.fr001.service;

import com.ngb.schoolfee.fr001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.fr001.exception.SchoolRegistrationException;
import com.ngb.schoolfee.fr001.model.School;
import com.ngb.schoolfee.fr001.repository.SchoolRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SchoolServiceTest {

    @Mock
    private SchoolRepository schoolRepository;

    @InjectMocks
    private SchoolService schoolService;

    @Test
    void registerSchool_validRequest_success() {
        SchoolRegistrationRequest request = new SchoolRegistrationRequest();
        request.setName("Test School");
        request.setLocation("Test Location");
        request.setAccountNumber("1234567890");
        request.setMinEnrolledStudents(1500);
        request.setOperationalYears(5);
        request.setMinAnnualFeeCollection(700000.0);


        when(schoolRepository.findByNameAndLocation(anyString(), anyString())).thenReturn(Optional.empty());
        when(schoolRepository.save(any(School.class))).thenReturn(new School());


        SchoolRegistrationResponse response = schoolService.registerSchool(request);

        assertNotNull(response);
        assertEquals("REGISTERED", response.getStatus());
        verify(schoolRepository, times(1)).save(any(School.class));

    }

    @Test
    void registerSchool_schoolAlreadyExists_throwsException() {
        SchoolRegistrationRequest request = new SchoolRegistrationRequest();
        request.setName("Test School");
        request.setLocation("Test Location");
        request.setAccountNumber("1234567890");
        request.setMinEnrolledStudents(1500);
        request.setOperationalYears(5);
        request.setMinAnnualFeeCollection(700000.0);


        when(schoolRepository.findByNameAndLocation(anyString(), anyString())).thenReturn(Optional.of(new School()));

        assertThrows(SchoolRegistrationException.class, () -> schoolService.registerSchool(request));
    }

    @Test
    void registerSchool_invalidRequest_throwsException() {
        SchoolRegistrationRequest request = new SchoolRegistrationRequest();
        request.setName("Test School");
        request.setLocation("Test Location");
        request.setAccountNumber("1234567890");
        request.setMinEnrolledStudents(500); // Invalid: below minimum
        request.setOperationalYears(1);     // Invalid: below minimum
        request.setMinAnnualFeeCollection(200000.0);  //Invalid: below minimum

        when(schoolRepository.findByNameAndLocation(anyString(), anyString())).thenReturn(Optional.empty());

        assertThrows(SchoolRegistrationException.class, () -> schoolService.registerSchool(request));
    }

}