package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.StudentManagementRequest;
import com.ngb.schoolfee.FR001.dto.StudentManagementResponse;
import com.ngb.schoolfee.FR001.model.Student;
import com.ngb.schoolfee.FR001.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StudentService {

    private final StudentRepository studentRepository;
    private final SchoolService schoolService;
    private final CustomerService customerService;
    private final NotificationService notificationService;


    public StudentService(StudentRepository studentRepository, SchoolService schoolService,
                          CustomerService customerService, NotificationService notificationService) {
        this.studentRepository = studentRepository;
        this.schoolService = schoolService;
        this.customerService = customerService;
        this.notificationService = notificationService;
    }

    @Transactional
    public StudentManagementResponse manageStudent(StudentManagementRequest request) {
        String action = request.getAction();
        Student student = null;
        StudentManagementResponse response = new StudentManagementResponse();

        //Check if customer is active cardholder for registration/amendment/de-registration
        if(!customerService.isActiveCardholder(request.getCustomerId())){
            response.setStatus("FAILED");
            response.setMessage("Only active NGB credit cardholders can manage students.");
            return response;
        }

        switch (action) {
            case "REGISTER":
                if (!request.getStudentId().equals(request.getStudentIdConfirm())) {
                    response.setStatus("FAILED");
                    response.setMessage("Student IDs do not match.");
                    return response;
                }
                student = Student.builder()
                        .studentName(request.getStudentName())
                        .studentId(request.getStudentId())
                        .school(schoolService.getSchoolById(Long.parseLong(request.getSchoolId())))
                        .registeredByCustomer(customerService.getCustomerById(request.getCustomerId()))
                        .status("REGISTERED")
                        .build();
                break;
            case "AMEND":
                student = studentRepository.findById(Long.parseLong(request.getStudentSystemId())).orElse(null);
                if (student == null) {
                    response.setStatus("FAILED");
                    response.setMessage("Student not found.");
                    return response;
                }
                //Implement logic to update student details based on request
                break;
            case "DEREGISTER":
                student = studentRepository.findById(Long.parseLong(request.getStudentSystemId())).orElse(null);
                if (student == null) {
                    response.setStatus("FAILED");
                    response.setMessage("Student not found.");
                    return response;
                }
                student.setStatus("DE-REGISTERED");
                break;
            default:
                response.setStatus("FAILED");
                response.setMessage("Invalid action type.");
                return response;
        }
        student = studentRepository.save(student);
        response.setStudentSystemId(String.valueOf(student.getStudentSystemId()));
        response.setStatus(action);
        notificationService.sendSMS(student.getRegisteredByCustomer().getContactInfo(), action + " confirmation for " + student.getStudentName());

        return response;
    }
}