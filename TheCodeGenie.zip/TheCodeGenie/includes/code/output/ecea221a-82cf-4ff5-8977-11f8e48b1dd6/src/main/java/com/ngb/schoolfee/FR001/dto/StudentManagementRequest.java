package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
public class StudentManagementRequest {
    private String action; // REGISTER, AMEND, DEREGISTER

    @NotBlank
    @Size(max = 255)
    private String studentName;

    @NotBlank
    @Size(max = 50)
    private String studentId;

    @NotBlank
    @Size(max = 50)
    private String studentIdConfirm;

    @NotNull
    private String schoolId;

    private String otp; // For Online/Mobile
    private String ivrTin; // For Contact Center

}