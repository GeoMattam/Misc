package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.StudentManagementRequest;
import com.ngb.schoolfee.FR001.dto.StudentManagementResponse;
import com.ngb.schoolfee.FR001.service.StudentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @PostMapping
    public ResponseEntity<StudentManagementResponse> manageStudent(
            @RequestBody @Valid StudentManagementRequest studentManagementRequest) {
        StudentManagementResponse response = studentService.manageStudent(studentManagementRequest);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // Add other endpoints as needed (e.g., GET, PUT, DELETE)

}