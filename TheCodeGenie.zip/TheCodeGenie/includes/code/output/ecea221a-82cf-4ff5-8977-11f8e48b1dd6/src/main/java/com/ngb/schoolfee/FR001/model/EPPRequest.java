package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name = "epp_requests")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EPPRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", unique = true, nullable = false)
    private Transaction transaction;

    @Column(nullable = false, columnDefinition = "TIMESTAMP")
    private LocalDateTime requestDateTime = LocalDateTime.now();

    @NotBlank
    private String status; // PENDING, APPROVED, REJECTED

    private String rejectionReason;

    private LocalDateTime approvalDateTime;

    private Boolean noLoyaltyPointsFlag = true; // Default to true (no points for EPP)

}