package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Entity
@Table(name = "students")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long studentSystemId;

    @NotBlank
    @Size(max = 255)
    private String studentName;

    @NotBlank
    @Size(max = 50)
    private String studentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "registered_by_customer_id", nullable = false)
    private Customer registeredByCustomer;

    @Column(nullable = false, columnDefinition = "TIMESTAMP")
    private LocalDateTime registrationDate = LocalDateTime.now();

    private String status; // REGISTERED, DE-REGISTERED

    // Add other fields as needed (e.g., dateOfBirth, contactInfo)
}