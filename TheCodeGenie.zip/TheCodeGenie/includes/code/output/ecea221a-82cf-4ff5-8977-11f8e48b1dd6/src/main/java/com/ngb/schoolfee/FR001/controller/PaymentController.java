package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.PaymentRequest;
import com.ngb.schoolfee.FR001.dto.PaymentResponse;
import com.ngb.schoolfee.FR001.service.PaymentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping
    public ResponseEntity<PaymentResponse> initiatePayment(@RequestBody @Valid PaymentRequest paymentRequest) {
        PaymentResponse response = paymentService.initiatePayment(paymentRequest);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/history")
    public ResponseEntity<?> getPaymentHistory(
            @RequestParam String customerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return paymentService.getPaymentHistory(customerId, page, size);
    }
    // Add other endpoints as needed
}