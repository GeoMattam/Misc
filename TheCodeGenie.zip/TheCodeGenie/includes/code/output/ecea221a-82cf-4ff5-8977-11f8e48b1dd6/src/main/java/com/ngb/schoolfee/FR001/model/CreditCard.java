package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "credit_cards")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreditCard {
    @Id
    private String cardNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @NotBlank
    private String cardType; // VISA_CONVENTIONAL, MASTERCARD, VISA_ISLAMIC

    @NotNull
    private LocalDate expiryDate;

    @NotNull
    private Double balance; // current balance

    @NotBlank
    private String status; // ACTIVE, INACTIVE, BLOCKED


}