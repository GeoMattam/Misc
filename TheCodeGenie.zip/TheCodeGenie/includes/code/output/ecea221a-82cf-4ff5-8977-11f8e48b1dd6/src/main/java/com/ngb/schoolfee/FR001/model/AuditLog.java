package com.ngb.schoolfee.FR001.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logId;

    @NotBlank
    private String activityType;

    private String entityIdAffected;

    private String entityType;

    @Column(nullable = false, columnDefinition = "TIMESTAMP")
    private LocalDateTime timestamp = LocalDateTime.now();

    private String performedByUserOrSystem;

    private String channel;

    private String details;

    private boolean successStatus;
}