package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class SchoolRegistrationRequest {
    @NotBlank
    @Size(max = 255)
    private String schoolName;

    @NotBlank
    @Size(max = 255)
    private String location;

    @NotBlank
    @Size(max = 50)
    private String accountNumber;

    @NotNull
    private List<FeeTypeRequest> feeTypes;
}