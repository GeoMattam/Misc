package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "schools")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class School {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long schoolId;

    @NotBlank
    @Size(max = 255)
    private String schoolName;

    @NotBlank
    @Size(max = 255)
    private String location;

    @NotBlank
    @Size(max = 50)
    private String ngbAccountNumber;

    @NotBlank
    @Size(max = 100)
    private String ngbGlAccountConfig;

    @NotNull
    private LocalDateTime registrationDate = LocalDateTime.now();

    @NotNull
    private Boolean isActive = true;

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;


    //Add other fields as per requirements
}