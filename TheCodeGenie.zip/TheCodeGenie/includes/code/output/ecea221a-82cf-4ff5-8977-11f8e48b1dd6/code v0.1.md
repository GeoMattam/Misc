### FilePath: src/main/java/com/ngb/schoolfee/FR001/controller/SchoolController.java

```java
package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.FR001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.FR001.service.SchoolService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/schools")
public class SchoolController {

    private final SchoolService schoolService;

    public SchoolController(SchoolService schoolService) {
        this.schoolService = schoolService;
    }

    @PostMapping
    public ResponseEntity<SchoolRegistrationResponse> registerSchool(
            @RequestBody @Valid SchoolRegistrationRequest schoolRegistrationRequest) {
        SchoolRegistrationResponse response = schoolService.registerSchool(schoolRegistrationRequest);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }


    // Add other endpoints for school management as needed (e.g., GET, PUT, DELETE)
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/controller/StudentController.java

```java
package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.StudentManagementRequest;
import com.ngb.schoolfee.FR001.dto.StudentManagementResponse;
import com.ngb.schoolfee.FR001.service.StudentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @PostMapping
    public ResponseEntity<StudentManagementResponse> manageStudent(
            @RequestBody @Valid StudentManagementRequest studentManagementRequest) {
        StudentManagementResponse response = studentService.manageStudent(studentManagementRequest);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // Add other endpoints as needed (e.g., GET, PUT, DELETE)

}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/controller/PaymentController.java

```java
package com.ngb.schoolfee.FR001.controller;

import com.ngb.schoolfee.FR001.dto.PaymentRequest;
import com.ngb.schoolfee.FR001.dto.PaymentResponse;
import com.ngb.schoolfee.FR001.service.PaymentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping
    public ResponseEntity<PaymentResponse> initiatePayment(@RequestBody @Valid PaymentRequest paymentRequest) {
        PaymentResponse response = paymentService.initiatePayment(paymentRequest);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/history")
    public ResponseEntity<?> getPaymentHistory(
            @RequestParam String customerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return paymentService.getPaymentHistory(customerId, page, size);
    }
    // Add other endpoints as needed
}

```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/dto/SchoolRegistrationRequest.java

```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class SchoolRegistrationRequest {
    @NotBlank
    @Size(max = 255)
    private String schoolName;

    @NotBlank
    @Size(max = 255)
    private String location;

    @NotBlank
    @Size(max = 50)
    private String accountNumber;

    @NotNull
    private List<FeeTypeRequest> feeTypes;
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/dto/SchoolRegistrationResponse.java
```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

@Data
public class SchoolRegistrationResponse {
    private String schoolId;
    private String status; // REGISTERED, FAILED
    private String message;
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/dto/FeeTypeRequest.java

```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
public class FeeTypeRequest {
    @NotBlank
    @Size(max = 100)
    private String feeTypeName;
    @Size(max = 255)
    private String description;
}
```


### FilePath: src/main/java/com/ngb/schoolfee/FR001/dto/StudentManagementRequest.java

```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
public class StudentManagementRequest {
    private String action; // REGISTER, AMEND, DEREGISTER

    @NotBlank
    @Size(max = 255)
    private String studentName;

    @NotBlank
    @Size(max = 50)
    private String studentId;

    @NotBlank
    @Size(max = 50)
    private String studentIdConfirm;

    @NotNull
    private String schoolId;

    private String otp; // For Online/Mobile
    private String ivrTin; // For Contact Center

}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/dto/StudentManagementResponse.java

```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

@Data
public class StudentManagementResponse {
    private String studentSystemId;
    private String status; // REGISTERED, UPDATED, DE-REGISTERED, FAILED
    private String message;
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/dto/PaymentRequest.java

```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Data
public class PaymentRequest {
    @NotBlank
    private String customerId;

    @NotBlank
    private String studentSystemId;

    @NotBlank
    private String schoolId;

    @NotBlank
    private String feeTypeId;

    @NotBlank
    private String cardNumber;

    @NotNull
    @Positive
    private Double amount;

    @Size(max = 20)
    private String remark;

    private String otp; // For Online/Mobile
    private String ivrTin; // For IVR

}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/dto/PaymentResponse.java

```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

@Data
public class PaymentResponse {
    private String transactionId;
    private String status; // SUCCESS, FAILED, PENDING_EPP
    private String message;
    private String referenceId;
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/exception/SchoolRegistrationException.java

```java
package com.ngb.schoolfee.FR001.exception;

public class SchoolRegistrationException extends RuntimeException {
    public SchoolRegistrationException(String message) {
        super(message);
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/exception/GlobalExceptionHandler.java

```java
package com.ngb.schoolfee.FR001.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(SchoolRegistrationException.class)
    public ResponseEntity<Map<String, String>> handleSchoolRegistrationException(
            SchoolRegistrationException ex) {
        Map<String, String> responseBody = new HashMap<>();
        responseBody.put("error", ex.getMessage());
        return new ResponseEntity<>(responseBody, HttpStatus.BAD_REQUEST);
    }


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(
            MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage()));
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    // Add other exception handlers as needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/model/School.java

```java
package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "schools")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class School {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long schoolId;

    @NotBlank
    @Size(max = 255)
    private String schoolName;

    @NotBlank
    @Size(max = 255)
    private String location;

    @NotBlank
    @Size(max = 50)
    private String ngbAccountNumber;

    @NotBlank
    @Size(max = 100)
    private String ngbGlAccountConfig;

    @NotNull
    private LocalDateTime registrationDate = LocalDateTime.now();

    @NotNull
    private Boolean isActive = true;

    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;


    //Add other fields as per requirements
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/model/FeeType.java

```java
package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "fee_types")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FeeType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feeTypeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @NotBlank
    @Size(max = 100)
    private String feeTypeName;

    @Size(max = 255)
    private String description;

    //Add other fields as per requirements
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/model/Student.java

```java
package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Entity
@Table(name = "students")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long studentSystemId;

    @NotBlank
    @Size(max = 255)
    private String studentName;

    @NotBlank
    @Size(max = 50)
    private String studentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "registered_by_customer_id", nullable = false)
    private Customer registeredByCustomer;

    @Column(nullable = false, columnDefinition = "TIMESTAMP")
    private LocalDateTime registrationDate = LocalDateTime.now();

    private String status; // REGISTERED, DE-REGISTERED

    // Add other fields as needed (e.g., dateOfBirth, contactInfo)
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/model/Customer.java

```java
package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "customers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Customer {
    @Id
    private String customerId;

    @NotBlank
    @Size(max = 255)
    private String name;

    @NotBlank
    @Size(max = 255)
    private String contactInfo;

    private boolean isActiveCreditCardHolder;

    // Add other fields as per requirements (e.g., address, etc.)
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/model/CreditCard.java

```java
package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "credit_cards")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreditCard {
    @Id
    private String cardNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @NotBlank
    private String cardType; // VISA_CONVENTIONAL, MASTERCARD, VISA_ISLAMIC

    @NotNull
    private LocalDate expiryDate;

    @NotNull
    private Double balance; // current balance

    @NotBlank
    private String status; // ACTIVE, INACTIVE, BLOCKED


}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/model/Transaction.java

```java
package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @NotNull
    private LocalDateTime transactionDateTime = LocalDateTime.now();

    @NotNull
    private Double amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_number", nullable = false)
    private CreditCard creditCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_system_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fee_type_id", nullable = false)
    private FeeType feeType;

    @Size(max = 20)
    private String remark;

    @NotBlank
    private String status; // SUCCESS, FAILED, PENDING_EPP, CANCELLED

    @NotBlank
    @Size(max = 40)
    private String postingDescription;

    private Boolean isEPPConverted = false;

    @NotBlank
    private String glPostingStatus; // PENDING, POSTED, FAILED

    private Boolean isLoyaltyEligible = true; //Default: eligible. No loyalty points if converted to EPP

    // Add other fields as per requirements (e.g., unique reference ID, etc.)

}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/model/EPPRequest.java

```java
package com.ngb.schoolfee.FR001.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name = "epp_requests")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EPPRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eppRequestId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", unique = true, nullable = false)
    private Transaction transaction;

    @Column(nullable = false, columnDefinition = "TIMESTAMP")
    private LocalDateTime requestDateTime = LocalDateTime.now();

    @NotBlank
    private String status; // PENDING, APPROVED, REJECTED

    private String rejectionReason;

    private LocalDateTime approvalDateTime;

    private Boolean noLoyaltyPointsFlag = true; // Default to true (no points for EPP)

}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/model/AuditLog.java

```java
package com.ngb.schoolfee.FR001.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logId;

    @NotBlank
    private String activityType;

    private String entityIdAffected;

    private String entityType;

    @Column(nullable = false, columnDefinition = "TIMESTAMP")
    private LocalDateTime timestamp = LocalDateTime.now();

    private String performedByUserOrSystem;

    private String channel;

    private String details;

    private boolean successStatus;
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/repository/SchoolRepository.java

```java
package com.ngb.schoolfee.FR001.repository;

import com.ngb.schoolfee.FR001.model.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SchoolRepository extends JpaRepository<School, Long> {
    // Add custom query methods if needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/repository/StudentRepository.java

```java
package com.ngb.schoolfee.FR001.repository;


import com.ngb.schoolfee.FR001.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    // Add custom query methods if needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/repository/CustomerRepository.java

```java
package com.ngb.schoolfee.FR001.repository;

import com.ngb.schoolfee.FR001.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {
    // Add custom query methods if needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/repository/CreditCardRepository.java

```java
package com.ngb.schoolfee.FR001.repository;

import com.ngb.schoolfee.FR001.model.CreditCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CreditCardRepository extends JpaRepository<CreditCard, String> {
    // Add custom query methods if needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/repository/TransactionRepository.java

```java
package com.ngb.schoolfee.FR001.repository;

import com.ngb.schoolfee.FR001.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    // Add custom query methods if needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/repository/EPPRequestRepository.java

```java
package com.ngb.schoolfee.FR001.repository;

import com.ngb.schoolfee.FR001.model.EPPRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EPPRequestRepository extends JpaRepository<EPPRequest, Long> {
    // Add custom query methods if needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/repository/AuditLogRepository.java

```java
package com.ngb.schoolfee.FR001.repository;

import com.ngb.schoolfee.FR001.model.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    // Add custom query methods if needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/service/SchoolService.java

```java
package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.FR001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.FR001.exception.SchoolRegistrationException;
import com.ngb.schoolfee.FR001.model.School;
import com.ngb.schoolfee.FR001.repository.SchoolRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SchoolService {

    private final SchoolRepository schoolRepository;
    private final FeeTypeService feeTypeService;


    public SchoolService(SchoolRepository schoolRepository, FeeTypeService feeTypeService) {
        this.schoolRepository = schoolRepository;
        this.feeTypeService = feeTypeService;
    }

    @Transactional
    public SchoolRegistrationResponse registerSchool(SchoolRegistrationRequest request) {
        School school = School.builder()
                .schoolName(request.getSchoolName())
                .location(request.getLocation())
                .ngbAccountNumber(request.getAccountNumber())
                .build();

        // Apply business rules
        if (!school.applyBusinessRules()) {
            throw new SchoolRegistrationException("School registration failed. Does not meet business rules.");
        }
        School savedSchool = schoolRepository.save(school);

        //Save fee types
        feeTypeService.createFeeTypes(savedSchool, request.getFeeTypes());

        SchoolRegistrationResponse response = new SchoolRegistrationResponse();
        response.setSchoolId(String.valueOf(savedSchool.getSchoolId()));
        response.setStatus("REGISTERED");
        return response;
    }


    // Add other service methods as needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/service/StudentService.java

```java
package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.StudentManagementRequest;
import com.ngb.schoolfee.FR001.dto.StudentManagementResponse;
import com.ngb.schoolfee.FR001.model.Student;
import com.ngb.schoolfee.FR001.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StudentService {

    private final StudentRepository studentRepository;
    private final SchoolService schoolService;
    private final CustomerService customerService;
    private final NotificationService notificationService;


    public StudentService(StudentRepository studentRepository, SchoolService schoolService,
                          CustomerService customerService, NotificationService notificationService) {
        this.studentRepository = studentRepository;
        this.schoolService = schoolService;
        this.customerService = customerService;
        this.notificationService = notificationService;
    }

    @Transactional
    public StudentManagementResponse manageStudent(StudentManagementRequest request) {
        String action = request.getAction();
        Student student = null;
        StudentManagementResponse response = new StudentManagementResponse();

        //Check if customer is active cardholder for registration/amendment/de-registration
        if(!customerService.isActiveCardholder(request.getCustomerId())){
            response.setStatus("FAILED");
            response.setMessage("Only active NGB credit cardholders can manage students.");
            return response;
        }

        switch (action) {
            case "REGISTER":
                if (!request.getStudentId().equals(request.getStudentIdConfirm())) {
                    response.setStatus("FAILED");
                    response.setMessage("Student IDs do not match.");
                    return response;
                }
                student = Student.builder()
                        .studentName(request.getStudentName())
                        .studentId(request.getStudentId())
                        .school(schoolService.getSchoolById(Long.parseLong(request.getSchoolId())))
                        .registeredByCustomer(customerService.getCustomerById(request.getCustomerId()))
                        .status("REGISTERED")
                        .build();
                break;
            case "AMEND":
                student = studentRepository.findById(Long.parseLong(request.getStudentSystemId())).orElse(null);
                if (student == null) {
                    response.setStatus("FAILED");
                    response.setMessage("Student not found.");
                    return response;
                }
                //Implement logic to update student details based on request
                break;
            case "DEREGISTER":
                student = studentRepository.findById(Long.parseLong(request.getStudentSystemId())).orElse(null);
                if (student == null) {
                    response.setStatus("FAILED");
                    response.setMessage("Student not found.");
                    return response;
                }
                student.setStatus("DE-REGISTERED");
                break;
            default:
                response.setStatus("FAILED");
                response.setMessage("Invalid action type.");
                return response;
        }
        student = studentRepository.save(student);
        response.setStudentSystemId(String.valueOf(student.getStudentSystemId()));
        response.setStatus(action);
        notificationService.sendSMS(student.getRegisteredByCustomer().getContactInfo(), action + " confirmation for " + student.getStudentName());

        return response;
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/service/PaymentService.java

```java
package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.PaymentRequest;
import com.ngb.schoolfee.FR001.dto.PaymentResponse;
import com.ngb.schoolfee.FR001.model.Transaction;
import com.ngb.schoolfee.FR001.repository.TransactionRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PaymentService {

    private final TransactionRepository transactionRepository;
    private final StudentService studentService;
    private final CreditCardService creditCardService;
    private final FinancialPostingService financialPostingService;
    private final NotificationService notificationService;

    public PaymentService(TransactionRepository transactionRepository, StudentService studentService,
                          CreditCardService creditCardService, FinancialPostingService financialPostingService,
                          NotificationService notificationService) {
        this.transactionRepository = transactionRepository;
        this.studentService = studentService;
        this.creditCardService = creditCardService;
        this.financialPostingService = financialPostingService;
        this.notificationService = notificationService;
    }

    @Transactional
    public PaymentResponse initiatePayment(PaymentRequest request) {
        //Implement Payment initiation logic here
        //Validate input data
        //Check student registration status
        //Check card details
        //Check balance
        //Process Payment
        //Send SMS
        //Update transaction status
        //Log audit entry

        PaymentResponse response = new PaymentResponse();
        Transaction transaction = Transaction.builder()
                .amount(request.getAmount())
                .creditCard(creditCardService.findByCardNumber(request.getCardNumber()))
                .student(studentService.getStudentById(Long.parseLong(request.getStudentSystemId())))
                .school(studentService.getStudentById(Long.parseLong(request.getStudentSystemId())).getSchool())
                .feeType(studentService.getStudentById(Long.parseLong(request.getStudentSystemId())).getSchool().getFeeTypes().stream().filter(f -> f.getFeeTypeName().equals(request.getFeeTypeId())).findFirst().orElse(null))
                .remark(request.getRemark())
                .status("PENDING")
                .glPostingStatus("PENDING")
                .postingDescription("Fee payment for " + studentService.getStudentById(Long.parseLong(request.getStudentSystemId())).getStudentName() + " at " + studentService.getStudentById(Long.parseLong(request.getStudentSystemId())).getSchool().getSchoolName())
                .build();
        transaction = transactionRepository.save(transaction);
        financialPostingService.postTransactionGL(transaction);
        response.setTransactionId(String.valueOf(transaction.getTransactionId()));
        response.setStatus("SUCCESS");
        notificationService.sendSMS(transaction.getCreditCard().getCustomer().getContactInfo(), "Payment confirmation for " + transaction.getAmount());
        return response;
    }

    public ResponseEntity<?> getPaymentHistory(String customerId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Transaction> transactions = transactionRepository.findAll(pageable);
        return ResponseEntity.ok(transactions);
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/service/FeeTypeService.java

```java
package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.dto.FeeTypeRequest;
import com.ngb.schoolfee.FR001.model.FeeType;
import com.ngb.schoolfee.FR001.model.School;
import com.ngb.schoolfee.FR001.repository.FeeTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FeeTypeService {

    private final FeeTypeRepository feeTypeRepository;

    public FeeTypeService(FeeTypeRepository feeTypeRepository) {
        this.feeTypeRepository = feeTypeRepository;
    }

    @Transactional
    public void createFeeTypes(School school, List<FeeTypeRequest> feeTypeRequests){
        List<FeeType> feeTypes = feeTypeRequests.stream()
                .map(req -> FeeType.builder()
                        .feeTypeName(req.getFeeTypeName())
                        .description(req.getDescription())
                        .school(school)
                        .build())
                .collect(Collectors.toList());
        feeTypeRepository.saveAll(feeTypes);
    }

    // Add other service methods as needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/service/CreditCardService.java

```java
package com.ngb.schoolfee.FR001.service;

import com.ngb.schoolfee.FR001.model.CreditCard;
import com.ngb.schoolfee.FR001.repository.CreditCardRepository;
import org.springframework.stereotype.Service;

@Service
public class CreditCardService {

    private final CreditCardRepository creditCardRepository;

    public CreditCardService(CreditCardRepository creditCardRepository) {
        this.creditCardRepository = creditCardRepository;
    }

    public CreditCard findByCardNumber(String cardNumber){
        return creditCardRepository.findById(cardNumber).orElse(null);
    }

    //Add other methods as needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/FR001/service/NotificationService.java
```java
package com.ngb.schoolfee.FR001.service;