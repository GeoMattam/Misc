```java
package com.ngb.schoolfee.FR001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolFeePaymentApplicationTests {

    @Test
    void contextLoads() {
    }

}
```