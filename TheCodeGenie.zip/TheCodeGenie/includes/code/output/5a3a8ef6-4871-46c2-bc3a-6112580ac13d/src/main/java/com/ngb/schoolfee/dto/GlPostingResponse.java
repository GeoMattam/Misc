package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class GlPostingResponse {
    private Long postingId;
    private String status;
}
```

```java