package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TransactionLogResponse {
    private Long transactionId;
    private LocalDateTime transactionDateTime;
    private double amount;
    private String studentName;
    private String schoolName;
    private String feeTypeName;
    private String remark;
    private String status;
    private String postingDescription;

}
```

```java