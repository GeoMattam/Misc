package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class PaymentResponse {
    private Long transactionId;
    private String status;
    private String referenceId;
}
```

```java