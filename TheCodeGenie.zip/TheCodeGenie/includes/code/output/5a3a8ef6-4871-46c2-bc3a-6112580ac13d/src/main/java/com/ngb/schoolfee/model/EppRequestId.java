package com.ngb.schoolfee.model;

import java.io.Serializable;

public class EppRequestId implements Serializable {
    private Long eppRequestId;
    private Long transactionId;

    public EppRequestId(){}

    public EppRequestId(Long eppRequestId, Long transactionId){
        this.eppRequestId = eppRequestId;
        this.transactionId = transactionId;
    }
}
```

```java