package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.model.Student;
import lombok.Data;

@Data
public class StudentResponse {
    private String studentSystemId;
    private String studentName;
    private String studentId;
    private Long schoolId;
    private String schoolName;
    private String status;


    public StudentResponse(Student student, String schoolName){
        this.studentSystemId = student.getStudentId();
        this.studentName = student.getStudentName();
        this.studentId = student.getStudentId();
        this.schoolId = student.getSchool().getSchoolId();
        this.schoolName = schoolName;
        this.status = student.getStatus().toString();
    }
}

```

```java