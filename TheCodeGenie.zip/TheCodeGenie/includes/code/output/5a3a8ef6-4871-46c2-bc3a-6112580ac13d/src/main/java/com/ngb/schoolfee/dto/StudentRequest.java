package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class StudentRequest {
    private String studentName;
    private String studentId;
    private String studentIdConfirm;
    private Long schoolId;
    private String otp; //for online/mobile
}
```

```java