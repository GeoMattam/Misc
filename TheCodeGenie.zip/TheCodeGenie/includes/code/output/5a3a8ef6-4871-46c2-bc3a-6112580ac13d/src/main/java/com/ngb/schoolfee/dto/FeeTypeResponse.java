package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class FeeTypeResponse {
    private Long feeTypeId;
    private String feeTypeName;
    private String description;
    private boolean isActive;
}
```

```java