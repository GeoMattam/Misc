package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class SmsRequest {
    private String phoneNumber;
    private String message;
    private String type;
}
```

```java