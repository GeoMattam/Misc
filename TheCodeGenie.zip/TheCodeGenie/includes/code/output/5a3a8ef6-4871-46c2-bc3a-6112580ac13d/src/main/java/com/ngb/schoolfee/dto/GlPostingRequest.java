package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class GlPostingRequest {
    private Long transactionId;
    private String cardType;
    private double amount;
    private String description;
    private String schoolAccountNumber;
}
```

```java