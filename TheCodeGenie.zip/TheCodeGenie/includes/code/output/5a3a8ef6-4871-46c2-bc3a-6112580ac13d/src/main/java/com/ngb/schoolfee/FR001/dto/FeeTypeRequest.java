```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
public class FeeTypeRequest {
    @NotBlank(message = "Fee type name is required")
    @Size(max = 100, message = "Fee type name must be less than 100 characters")
    private String name;

    @Size(max = 255, message = "Description must be less than 255 characters")
    private String description;
}
```