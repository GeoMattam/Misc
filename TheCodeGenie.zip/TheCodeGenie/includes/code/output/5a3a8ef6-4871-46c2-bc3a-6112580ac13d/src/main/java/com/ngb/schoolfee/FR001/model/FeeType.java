```java
package com.ngb.schoolfee.FR001.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "fee_types")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feeTypeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @NotBlank(message = "Fee type name is required")
    @Size(max = 100, message = "Fee type name must be less than 100 characters")
    private String feeTypeName;

    @Size(max = 255, message = "Description must be less than 255 characters")
    private String description;

    private boolean isActive = true;
}
```