```java
package com.ngb.schoolfee.FR001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class SchoolRegistrationRequest {
    @NotBlank(message = "School name is required")
    @Size(max = 255, message = "School name must be less than 255 characters")
    private String schoolName;

    @NotBlank(message = "Location is required")
    @Size(max = 255, message = "Location must be less than 255 characters")
    private String location;

    @NotBlank(message = "NGB account number is required")
    @Size(max = 50, message = "NGB account number must be less than 50 characters")
    private String ngbAccountNumber;

    @NotEmpty(message = "At least one fee type is required")
    private List<FeeTypeRequest> feeTypes;
}
```