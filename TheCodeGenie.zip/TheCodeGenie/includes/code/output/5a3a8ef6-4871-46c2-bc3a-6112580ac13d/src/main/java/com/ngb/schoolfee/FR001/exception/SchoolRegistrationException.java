```java
package com.ngb.schoolfee.FR001.exception;

public class SchoolRegistrationException extends RuntimeException {
    public SchoolRegistrationException(String message) {
        super(message);
    }
}
```