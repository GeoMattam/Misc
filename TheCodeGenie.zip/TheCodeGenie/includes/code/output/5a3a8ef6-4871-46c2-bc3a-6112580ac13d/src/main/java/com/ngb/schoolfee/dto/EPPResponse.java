package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class EPPResponse {
    private Long eppRequestId;
    private String status;
}
```

```java