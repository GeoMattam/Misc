```java
package com.ngb.schoolfee.repository;

import com.ngb.schoolfee.entity.FeeType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeeTypeRepository extends JpaRepository<FeeType, Long> {
}
```