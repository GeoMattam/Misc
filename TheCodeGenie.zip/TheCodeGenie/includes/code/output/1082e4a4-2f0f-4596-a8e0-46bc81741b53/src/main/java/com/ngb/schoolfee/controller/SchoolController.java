```java
package com.ngb.schoolfee.controller;

import com.ngb.schoolfee.dto.SchoolDto;
import com.ngb.schoolfee.service.SchoolService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/schools")
public class SchoolController {

    private final SchoolService schoolService;

    public SchoolController(SchoolService schoolService) {
        this.schoolService = schoolService;
    }

    @PostMapping
    public ResponseEntity<String> registerSchool(@Valid @RequestBody SchoolDto schoolDto) {
        schoolService.registerSchool(schoolDto);
        return new ResponseEntity<>("School registered successfully", HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<SchoolDto>> getAllSchools() {
        return ResponseEntity.ok(schoolService.getAllSchools());
    }

    // Add other endpoints for retrieving school details, fee types, etc. as needed.
}
```