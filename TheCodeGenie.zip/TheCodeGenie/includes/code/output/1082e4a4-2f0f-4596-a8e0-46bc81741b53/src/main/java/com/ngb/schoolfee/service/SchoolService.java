```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.SchoolDto;
import com.ngb.schoolfee.entity.School;
import com.ngb.schoolfee.repository.SchoolRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SchoolService {

    private final SchoolRepository schoolRepository;

    public SchoolService(SchoolRepository schoolRepository) {
        this.schoolRepository = schoolRepository;
    }

    @Transactional
    public void registerSchool(SchoolDto schoolDto) {
        School school = new School();
        school.setSchoolName(schoolDto.getSchoolName());
        school.setLocation(schoolDto.getLocation());
        school.setNgbAccountNumber(schoolDto.getNgbAccountNumber());
        school.setGlAccountNumber(schoolDto.getGlAccountNumber());
        // ... map feeTypes ...
        schoolRepository.save(school);
    }

    public List<SchoolDto> getAllSchools() {
        return schoolRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    // Add other service methods to retrieve details, update etc.

    private SchoolDto mapToDto(School school) {
        SchoolDto schoolDto = new SchoolDto();
        schoolDto.setSchoolName(school.getSchoolName());
        // ... map other fields ...
        return schoolDto;
    }
}
```