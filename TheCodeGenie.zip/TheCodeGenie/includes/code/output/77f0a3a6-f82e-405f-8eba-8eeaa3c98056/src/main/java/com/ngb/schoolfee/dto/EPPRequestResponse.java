package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.EPPStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EPPRequestResponse {
    private Long eppRequestId;
    private Long transactionId;
    private EPPStatus status;
    private String rejectionReason;
}
```

```java