package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentResponse {
    private Long transactionId;
    private String referenceId;
    private TransactionStatus status;
}
```

```java