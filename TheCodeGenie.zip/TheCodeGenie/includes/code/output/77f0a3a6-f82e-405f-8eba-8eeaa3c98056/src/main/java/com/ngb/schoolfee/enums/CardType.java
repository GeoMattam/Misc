package com.ngb.schoolfee.enums;

public enum CardType {
    VISA_CONVENTIONAL, VISA_ISLAMIC, MASTERCARD
}
```

```java