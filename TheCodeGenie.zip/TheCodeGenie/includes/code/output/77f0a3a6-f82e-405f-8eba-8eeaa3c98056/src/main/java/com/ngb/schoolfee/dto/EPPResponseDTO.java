```java
package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class EPPResponseDTO {
    private Long eppRequestId;
    private String status;
}
```