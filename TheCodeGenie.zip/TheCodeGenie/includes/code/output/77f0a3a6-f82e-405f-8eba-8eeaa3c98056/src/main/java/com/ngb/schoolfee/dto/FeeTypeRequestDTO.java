```java
package com.ngb.schoolfee.dto;

import lombok.Data;

@Data
public class FeeTypeRequestDTO {
    private String feeTypeName;
    private String description;
}
```