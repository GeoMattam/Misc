```java
package com.ngb.schoolfee.service;

import com.ngb.schoolfee.dto.EPPRequestDTO;
import com.ngb.schoolfee.dto.EPPResponseDTO;
import com.ngb.schoolfee.exception.EPPConversionException;
import com.ngb.schoolfee.model.AuditLog;
import com.ngb.schoolfee.model.EPPRequest;
import com.ngb.schoolfee.model.Transaction;
import com.ngb.schoolfee.repository.AuditLogRepository;
import com.ngb.schoolfee.repository.EPPRequestRepository;
import com.ngb.schoolfee.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class EPPConversionService {

    @Autowired
    private EPPRequestRepository eppRequestRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AuditLogRepository auditLogRepository;

    public EPPResponseDTO requestEPPConversion(EPPRequestDTO eppRequestDTO, String customerId) {
        Transaction transaction = transactionRepository.findById(eppRequestDTO.getTransactionId())
                .orElseThrow(() -> new EPPConversionException("Transaction not