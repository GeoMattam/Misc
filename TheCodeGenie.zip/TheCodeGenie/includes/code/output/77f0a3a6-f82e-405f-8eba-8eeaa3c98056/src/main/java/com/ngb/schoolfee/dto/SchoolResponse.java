package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.model.FeeType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SchoolResponse {
    private Long schoolId;
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private String ngbGlAccountConfig;
    private boolean isActive;
    private LocalDateTime registrationDate;
    private List<FeeType> feeTypes;
}
```

```java