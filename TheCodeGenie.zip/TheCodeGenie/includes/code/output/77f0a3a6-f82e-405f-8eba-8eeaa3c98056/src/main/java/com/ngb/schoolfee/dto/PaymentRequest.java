package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequest {
    private String customerId;
    private String studentSystemId;
    private Long schoolId;
    private Long feeTypeId;
    private String cardNumber;
    private double amount;
    private String remark;
    private String otp; //For online/mobile
    private String ivrTin; //For IVR
}
```

```java