package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SchoolRequest {
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private List<FeeTypeRequest> feeTypes;
}
```

```java