package com.ngb.schoolfee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionLogResponse {
    private Long transactionId;
    private String referenceId;
    private String studentName;
    private String schoolName;
    private String feeTypeName;
    private double amount;
    private LocalDateTime transactionDateTime;
    private String remark;

}
```

```java