```java
package com.ngb.schoolfee.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class SchoolResponseDTO {
    private Long schoolId;
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private String ngbGlAccountConfig;
    private LocalDateTime registrationDate;
    private Boolean isActive;
    private List<FeeTypeResponseDTO> feeTypes;
}
```