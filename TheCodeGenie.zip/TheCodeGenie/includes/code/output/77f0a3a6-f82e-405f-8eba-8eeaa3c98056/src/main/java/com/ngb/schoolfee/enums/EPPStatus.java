package com.ngb.schoolfee.enums;

public enum EPPStatus {
    PENDING, APPROVED, REJECTED
}
```

```java