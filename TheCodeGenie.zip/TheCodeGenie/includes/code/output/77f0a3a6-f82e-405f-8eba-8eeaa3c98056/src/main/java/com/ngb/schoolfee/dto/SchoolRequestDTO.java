```java
package com.ngb.schoolfee.dto;

import lombok.Data;

import java.util.List;

@Data
public class SchoolRequestDTO {
    private String schoolName;
    private String location;
    private String ngbAccountNumber;
    private List<FeeTypeRequestDTO> feeTypes;
}
```