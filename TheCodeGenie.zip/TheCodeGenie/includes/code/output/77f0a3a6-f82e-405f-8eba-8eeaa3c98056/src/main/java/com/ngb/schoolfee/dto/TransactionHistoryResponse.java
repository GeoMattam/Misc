package com.ngb.schoolfee.dto;

import com.ngb.schoolfee.enums.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionHistoryResponse {
    private Long transactionId;
    private LocalDateTime date;
    private double amount;
    private String studentName;
    private String schoolName;
    private String feeTypeName;
    private String remark;
    private TransactionStatus status;

}
```

```java