package com.ngb.schoolfee.fr001.exception;

public class SchoolRegistrationException extends RuntimeException {
    public SchoolRegistrationException(String message) {
        super(message);
    }
}