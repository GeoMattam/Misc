package com.ngb.schoolfee.fr001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class SchoolRegistrationRequest {

    @NotBlank(message = "School name cannot be blank")
    @Size(max = 255, message = "School name must be less than 255 characters")
    private String schoolName;

    @NotBlank(message = "Location cannot be blank")
    @Size(max = 255, message = "Location must be less than 255 characters")
    private String location;

    @NotBlank(message = "Account number cannot be blank")
    @Size(min = 10, max = 50, message = "Account number must be between 10 and 50 characters")
    private String accountNumber;

    @NotNull(message = "Fee types cannot be null")
    private List<FeeTypeRequest> feeTypes;

    //Add other fields as required

}