package com.ngb.schoolfee.fr001.repository;

import com.ngb.schoolfee.fr001.model.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SchoolRepository extends JpaRepository<School, String> {
    Optional<School> findByName(String name);
    boolean existsByAccountnumber(String accountNumber);
    //Add other query methods as needed
}