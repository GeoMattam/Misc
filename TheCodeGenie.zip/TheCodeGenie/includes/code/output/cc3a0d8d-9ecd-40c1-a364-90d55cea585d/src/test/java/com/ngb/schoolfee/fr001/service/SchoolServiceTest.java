package com.ngb.schoolfee.fr001.service;

import com.ngb.schoolfee.fr001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.fr001.model.School;
import com.ngb.schoolfee.fr001.repository.SchoolRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SchoolServiceTest {

    @Mock
    private SchoolRepository schoolRepository;

    @InjectMocks
    private SchoolService schoolService;

    @Test
    void registerSchool_validRequest_success() {
        //Arrange
        SchoolRegistrationRequest request = new SchoolRegistrationRequest();
        request.setSchoolName("Test School");
        request.setLocation("Test Location");
        request.setAccountNumber("1234567890");
        List<SchoolRegistrationRequest.FeeTypeRequest> feeTypes = new ArrayList<>();
        SchoolRegistrationRequest.FeeTypeRequest feeType1 = new SchoolRegistrationRequest.FeeTypeRequest();
        feeType1.setFeeTypeName("Tuition");
        feeTypes.add(feeType1);
        request.setFeeTypes(feeTypes);

        School school = School.builder()
                .schoolName("Test School")
                .location("Test Location")
                .accountNumber("1234567890")
                .glAccountConfig("GL-AUTO-CONFIG-1234567890")
                .registrationDate(LocalDateTime.now())
                .build();

        when(schoolRepository.existsBySchoolNameAndLocation(request.getSchoolName(), request.getLocation())).thenReturn(false);
        when(schoolRepository.existsByAccountNumber(request.getAccountNumber())).thenReturn(false);
        when(schoolRepository.save(school)).thenReturn(school);

        //Act
        var result = schoolService.registerSchool(request);

        //Assert
        assertEquals("REGISTERED", result.getStatus());
        assertNotNull(result.getSchoolId());
        assertEquals("School registered successfully!", result.getMessage());
    }

}