package com.ngb.schoolfee.fr001;


import com.ngb.schoolfee.fr001.dto.FeeTypeRequest;
import com.ngb.schoolfee.fr001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.fr001.model.School;
import com.ngb.schoolfee.fr001.repository.SchoolRepository;
import com.ngb.schoolfee.fr001.service.FeeTypeService;
import com.ngb.schoolfee.fr001.service.SchoolService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class SchoolServiceTest {

    @Mock
    private SchoolRepository schoolRepository;
    @Mock
    private FeeTypeService feeTypeService;
    @InjectMocks
    private SchoolService schoolService;

    @Test
    void testRegisterSchoolSuccess() {
        SchoolRegistrationRequest request = new SchoolRegistrationRequest();
        request.setSchoolName("Test School");
        request.setLocation("Test Location");
        request.setAccountnumber("1234567890");
        request.setFeeTypes(List.of(new FeeTypeRequest()));

        School mockSchool = new School();
        mockSchool.setSchoolId("testSchoolId");
        // ... other fields ...


        when(schoolRepository.save(org.mockito.ArgumentMatchers.any(School.class))).thenReturn(mockSchool);
        when(feeTypeService.createFeeType(org.mockito.ArgumentMatchers.any(FeeTypeRequest.class), org.mockito.ArgumentMatchers.anyString())).thenReturn(new FeeType()); // Mock FeeType creation
        when(schoolService.validateSchoolEligibility(org.mockito.ArgumentMatchers.any(SchoolRegistrationRequest.class))).thenReturn(true); // Mock eligibility check

        var result = schoolService.registerSchool(request);
        assertEquals("REGISTERED", result.getStatus());
        assertEquals("testSchoolId", result.getSchoolId());
        assertEquals("School registered successfully.", result.getMessage());
    }



}