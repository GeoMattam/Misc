# School Fee Payment System

This project implements the backend for a school fee payment system using NGB credit cards.

## Requirements

- Java 17+
- Maven 

## Build and Run

1. Clone the repository.
2. Navigate to the project directory.
3. Run `mvn clean install` to build the project.
4. Create a PostgreSQL database named `school_fee_db` (or modify `application.yaml` to use a different database).
5. Configure database credentials in `application.yaml`.
6. Run `mvn spring-boot:run` to start the application.


## API Endpoints

- `/api/schools`:  For school registration and management.  See Swagger documentation for details after running the app.

## Testing

Run `mvn test` to execute JUnit tests.