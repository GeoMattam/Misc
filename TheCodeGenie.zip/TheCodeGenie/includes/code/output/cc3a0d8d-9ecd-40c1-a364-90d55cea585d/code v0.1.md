### FilePath: src/main/java/com/ngb/schoolfee/fr001/controller/SchoolController.java

```java
package com.ngb.schoolfee.fr001.controller;

import com.ngb.schoolfee.fr001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.fr001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.fr001.service.SchoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/schools")
public class SchoolController {

    private final SchoolService schoolService;

    @Autowired
    public SchoolController(SchoolService schoolService) {
        this.schoolService = schoolService;
    }


    @PostMapping
    public ResponseEntity<SchoolRegistrationResponse> registerSchool(@Valid @RequestBody SchoolRegistrationRequest request) {
        SchoolRegistrationResponse response = schoolService.registerSchool(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Add other endpoints for school management as needed (GET, PUT, DELETE)

}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/dto/SchoolRegistrationRequest.java

```java
package com.ngb.schoolfee.fr001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class SchoolRegistrationRequest {

    @NotBlank(message = "School name cannot be blank")
    @Size(max = 255, message = "School name must be less than 255 characters")
    private String schoolName;

    @NotBlank(message = "Location cannot be blank")
    @Size(max = 255, message = "Location must be less than 255 characters")
    private String location;

    @NotBlank(message = "Account number cannot be blank")
    @Size(min = 10, max = 50, message = "Account number must be between 10 and 50 characters")
    private String accountNumber;

    @NotNull(message = "Fee types cannot be null")
    private List<FeeTypeRequest> feeTypes;

    //Add other fields as required

}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/dto/FeeTypeRequest.java
```java
package com.ngb.schoolfee.fr001.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
public class FeeTypeRequest {
    @NotBlank(message = "Fee type name cannot be blank")
    @Size(max = 100, message = "Fee type name must be less than 100 characters")
    private String name;

    @Size(max = 255, message = "Description must be less than 255 characters")
    private String description;

    // Add other fields if needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/dto/SchoolRegistrationResponse.java

```java
package com.ngb.schoolfee.fr001.dto;

import lombok.Data;

@Data
public class SchoolRegistrationResponse {
    private String schoolId;
    private String status; // REGISTERED or FAILED
    private String message; // Optional additional message
}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/service/SchoolService.java

```java
package com.ngb.schoolfee.fr001.service;

import com.ngb.schoolfee.fr001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.fr001.dto.SchoolRegistrationResponse;
import com.ngb.schoolfee.fr001.exception.SchoolRegistrationException;
import com.ngb.schoolfee.fr001.model.School;
import com.ngb.schoolfee.fr001.model.FeeType;
import com.ngb.schoolfee.fr001.repository.SchoolRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class SchoolService {

    private static final Logger logger = LoggerFactory.getLogger(SchoolService.class);

    private final SchoolRepository schoolRepository;
    private final FeeTypeService feeTypeService; // Inject FeeType service

    @Autowired
    public SchoolService(SchoolRepository schoolRepository, FeeTypeService feeTypeService) {
        this.schoolRepository = schoolRepository;
        this.feeTypeService = feeTypeService;
    }


    @Transactional
    public SchoolRegistrationResponse registerSchool(SchoolRegistrationRequest request) {
        SchoolRegistrationResponse response = new SchoolRegistrationResponse();
        try {
            // Validate school eligibility -  Implementation omitted for brevity, but should include business rules checks
            boolean isEligible = validateSchoolEligibility(request);
            if (!isEligible) {
                throw new SchoolRegistrationException("School does not meet eligibility criteria.");
            }


            School school = new School();
            school.setSchoolId(UUID.randomUUID().toString());
            school.setName(request.getSchoolName());
            school.setLocation(request.getLocation());
            school.setAccountnumber(request.getAccountNumber());
            school.setRegistrationDate(LocalDateTime.now());
            school.setIsActive(true);

            List<FeeType> feeTypes = request.getFeeTypes().stream()
                    .map(req -> feeTypeService.createFeeType(req, school.getSchoolId())) //Use FeeTypeService
                    .collect(Collectors.toList());
            school.setFeeTypes(feeTypes);

            schoolRepository.save(school);
            response.setSchoolId(school.getSchoolId());
            response.setStatus("REGISTERED");
            response.setMessage("School registered successfully.");
            logger.info("School registered successfully: {}", school);

        } catch (SchoolRegistrationException e) {
            response.setStatus("FAILED");
            response.setMessage(e.getMessage());
            logger.error("School registration failed: {}", e.getMessage());
        } catch (Exception e) {
            response.setStatus("FAILED");
            response.setMessage("An unexpected error occurred.");
            logger.error("School registration failed due to an unexpected error: {}", e.getMessage());
        }
        return response;
    }


    // Implement validation of school eligibility based on business rules
    private boolean validateSchoolEligibility(SchoolRegistrationRequest request) {
        // Replace this with your actual eligibility checks based on business rules
        // ...
        return true; // Placeholder - replace with actual business rule validation logic
    }

}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/service/FeeTypeService.java

```java
package com.ngb.schoolfee.fr001.service;

import com.ngb.schoolfee.fr001.dto.FeeTypeRequest;
import com.ngb.schoolfee.fr001.model.FeeType;
import com.ngb.schoolfee.fr001.repository.FeeTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class FeeTypeService {

    private final FeeTypeRepository feeTypeRepository;

    @Autowired
    public FeeTypeService(FeeTypeRepository feeTypeRepository) {
        this.feeTypeRepository = feeTypeRepository;
    }

    public FeeType createFeeType(FeeTypeRequest request, String schoolId) {
        FeeType feeType = new FeeType();
        feeType.setFeeTypeId(UUID.randomUUID().toString());
        feeType.setName(request.getName());
        feeType.setDescription(request.getDescription());
        feeType.setSchoolId(schoolId); // Set school ID
        return feeTypeRepository.save(feeType);
    }

    // Add other methods for managing fee types as needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/repository/SchoolRepository.java

```java
package com.ngb.schoolfee.fr001.repository;

import com.ngb.schoolfee.fr001.model.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SchoolRepository extends JpaRepository<School, String> {
    Optional<School> findByName(String name);
    boolean existsByAccountnumber(String accountNumber);
    //Add other query methods as needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/repository/FeeTypeRepository.java

```java
package com.ngb.schoolfee.fr001.repository;

import com.ngb.schoolfee.fr001.model.FeeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeeTypeRepository extends JpaRepository<FeeType, String> {
    // Add custom query methods if needed
}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/model/School.java

```java
package com.ngb.schoolfee.fr001.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
public class School {
    @Id
    private String schoolId;
    private String name;
    private String location;
    private String accountnumber;
    private String ngbGlAccountConfig;
    private LocalDateTime registrationDate;
    private boolean isActive;
    private int minEnrolledStudents = 1000;
    private int operationalYears = 3;
    private double minAnnualFeeCollection = 500000.00;
    @OneToMany(mappedBy = "school", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeeType> feeTypes;

    // Add other fields as needed, getters and setters

    public boolean applyBusinessRules() {
        // Implement business rule checks here...
        return true; // Placeholder
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/model/FeeType.java

```java
package com.ngb.schoolfee.fr001.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
public class FeeType {
    @Id
    private String feeTypeId;
    private String name;
    private String description;
    @ManyToOne
    @JoinColumn(name = "school_id")
    private School school;
    private boolean isActive = true;


    // Add other fields, getters, setters
}
```


### FilePath: src/main/java/com/ngb/schoolfee/fr001/exception/SchoolRegistrationException.java

```java
package com.ngb.schoolfee.fr001.exception;

public class SchoolRegistrationException extends RuntimeException {
    public SchoolRegistrationException(String message) {
        super(message);
    }
}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/SchoolFeeApplication.java

```java
package com.ngb.schoolfee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolFeeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SchoolFeeApplication.class, args);
    }

}
```

### FilePath: src/main/resources/application.yaml

```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/school_fee_db
    username: your_db_user
    password: your_db_password
    driver-class-name: org.postgresql.Driver
  jpa:
    hibernate:
      ddl-auto: update # Set to validate, create, update, or none in production
    show-sql: true
    generate-ddl: true

```

### FilePath: src/test/java/com/ngb/schoolfee/fr001/SchoolServiceTest.java

```java
package com.ngb.schoolfee.fr001;


import com.ngb.schoolfee.fr001.dto.FeeTypeRequest;
import com.ngb.schoolfee.fr001.dto.SchoolRegistrationRequest;
import com.ngb.schoolfee.fr001.model.School;
import com.ngb.schoolfee.fr001.repository.SchoolRepository;
import com.ngb.schoolfee.fr001.service.FeeTypeService;
import com.ngb.schoolfee.fr001.service.SchoolService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class SchoolServiceTest {

    @Mock
    private SchoolRepository schoolRepository;
    @Mock
    private FeeTypeService feeTypeService;
    @InjectMocks
    private SchoolService schoolService;

    @Test
    void testRegisterSchoolSuccess() {
        SchoolRegistrationRequest request = new SchoolRegistrationRequest();
        request.setSchoolName("Test School");
        request.setLocation("Test Location");
        request.setAccountnumber("1234567890");
        request.setFeeTypes(List.of(new FeeTypeRequest()));

        School mockSchool = new School();
        mockSchool.setSchoolId("testSchoolId");
        // ... other fields ...


        when(schoolRepository.save(org.mockito.ArgumentMatchers.any(School.class))).thenReturn(mockSchool);
        when(feeTypeService.createFeeType(org.mockito.ArgumentMatchers.any(FeeTypeRequest.class), org.mockito.ArgumentMatchers.anyString())).thenReturn(new FeeType()); // Mock FeeType creation
        when(schoolService.validateSchoolEligibility(org.mockito.ArgumentMatchers.any(SchoolRegistrationRequest.class))).thenReturn(true); // Mock eligibility check

        var result = schoolService.registerSchool(request);
        assertEquals("REGISTERED", result.getStatus());
        assertEquals("testSchoolId", result.getSchoolId());
        assertEquals("School registered successfully.", result.getMessage());
    }



}
```

### FilePath: src/main/java/com/ngb/schoolfee/fr001/config/ExceptionHandlerConfig.java

```java
package com.ngb.schoolfee.fr001.config;

import com.ngb.schoolfee.fr001.exception.SchoolRegistrationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionHandlerConfig {

    @ExceptionHandler(SchoolRegistrationException.class)
    public ResponseEntity<String> handleSchoolRegistrationException(SchoolRegistrationException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    //Add more exception handlers as needed
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGenericException(Exception ex){
        return new ResponseEntity<>("An unexpected error occurred.", HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
```

### FilePath: pom.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.1.0</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <groupId>com.ngb</groupId>
    <artifactId>school-fee</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>school-fee</name>
    <description>School Fee Payment System</description>
    <properties>
        <java.version>17</java.version>
    </properties>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter-api</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.mockito</groupId>
            <artifactId>mockito-core</artifactId>
            <scope>test</scope>
        </dependency>

        <!-- Add other dependencies as needed -->
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <configuration>
                    <excludes>
                        <exclude>
                            <groupId>org.projectlombok</groupId>
                            <artifactId>lombok</artifactId>
                        </exclude>
                    </excludes>
                </configuration>
            </plugin>
        </plugins>
    </build>

</project>
```

### FilePath: README.md

```markdown
# School Fee Payment System

This project implements the backend for a school fee payment system using NGB credit cards.

## Requirements

- Java 17+
- Maven 

## Build and Run

1. Clone the repository.
2. Navigate to the project directory.
3. Run `mvn clean install` to build the project.
4. Create a PostgreSQL database named `school_fee_db` (or modify `application.yaml` to use a different database).
5. Configure database credentials in `application.yaml`.
6. Run `mvn spring-boot:run` to start the application.


## API Endpoints

- `/api/schools`:  For school registration and management.  See Swagger documentation for details after running the app.

## Testing

Run `mvn test` to execute JUnit tests.


```