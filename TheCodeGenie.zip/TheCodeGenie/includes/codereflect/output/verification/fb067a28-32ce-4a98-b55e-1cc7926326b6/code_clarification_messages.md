## High-Level Design (HLD) for School Fee Payment System using NGB Credit Cards

This document outlines the High-Level Design based on the provided Business Requirement Document (BRD).  Before proceeding, I need to clarify some points from the SRS to ensure 100% understanding.


**Step 1: Input Analysis and Clarification**

**a. Information Extraction from SRS and Requirements:**

* **Program Overview:** The program aims to enable school fee payments via NGB credit cards through various digital channels (Online Banking, Mobile Banking, IVR).  This is a pilot project starting with Europe School.

* **Main Functionalities:** School registration, student registration/amendment/deregistration, fee payment (across multiple channels), EPP conversion, fee posting, reporting.

* **Key Modules:**
    * **School Management Module:** Handles school registration and configuration.
    * **Student Management Module:** Handles student registration, amendment, and deregistration.
    * **Payment Processing Module:** Processes fee payments through Online Banking, Mobile Banking, and IVR.
    * **EPP Management Module:** Handles Easy Payment Plan conversion requests.
    * **Fee Posting Module:** Posts transactions to relevant accounts (Credit Card, GL Account, School Account).
    * **Reporting Module:** Generates and emails daily reports to schools.
    * **SMS Notification Module:** Sends SMS alerts for various events.


* **WORKING-STORAGE SECTION (Data Structures):**  The SRS lacks detailed data structures.  We need specifications on the following:

    * **School Data:** Detailed fields in the school registration form (beyond name, location, account number).  What constitutes "fee types"?  Are there any constraints on the data (e.g., character limits, data types)?  Do we need to store school contact information?
    * **Student Data:** Precise data fields for student registration. What data type is Student ID? Are there constraints on the format? What about address information, parent/guardian details etc.
    * **Transaction Data:**  Detailed fields to be stored for each transaction (e.g., transaction ID, date/time, amount, fee type, student ID, card details – masked, payment channel, status, remarks, EPP details). How long should transaction records be retained?
    * **User Data (Cardholders):**  Do we need to store additional information about the cardholder beyond what’s available in the Cards System? What level of access control will be implemented?
    * **GL Account Data:** How is this data structured and how will it be linked to schools and transaction types?  What are the details of "Visa Conventional / Visa Islamic / MasterCard"? Do these require different GL account mappings?

**b. Information Needed Before Proceeding:**

The missing information listed above under "WORKING-STORAGE SECTION" is crucial.  We also need details on:

* **Database Selection:** Which database will be used? (e.g., relational, NoSQL)
* **API Specifications:** Details on APIs for integration with existing systems (Online Banking, Mobile Banking, IVR, Cards System, CRM, ICRS).  Authentication mechanisms and data formats need clarification.
* **Security Considerations:**  Detailed security protocols beyond OTP verification and copy-paste restrictions (e.g., encryption, data masking, access control).
* **Error Handling:** How will system errors and exceptions be handled?  What error messages will be displayed to the user?  How will these errors be logged?
* **Deployment Environment:**  Will this be deployed on-premise or in the cloud? What are the infrastructure requirements?
* **Third-party Libraries/Frameworks:**  Are there any specific technologies or frameworks that need to be used?

**c. Clarification Questions:**

1.  Can you provide detailed descriptions of the data fields for School, Student, and Transaction data, including data types, constraints (length, format), and allowed values?  Please provide examples.
2.  What are the specific API endpoints and data formats for integration with Online Banking, Mobile Banking, IVR, Cards System, CRM and ICRS?
3.  Please describe the desired security measures in detail, including encryption methods, access control policies, and audit logging mechanisms.  Examples would be helpful.
4.  How should system errors and exceptions be handled, and what error messages should be displayed to the user and logged internally?  Provide examples of error scenarios and their desired handling.
5.  What is the planned deployment environment (on-premise or cloud) and its infrastructure requirements?
6.  Are there any specific technologies or frameworks that should be used for development?


**d. Confirmation of Understanding (Once Clarifications are Received):**

Once we have clarified the points above, I will summarize my understanding and seek your confirmation before proceeding to the detailed design phase.  I will present a consolidated list of all data structures (WORKING-STORAGE SECTION) along with examples for each field, API specifications with examples of requests and responses, security measures with examples of implementation and error handling strategies with examples.

**e. Assistance:**

Please don't hesitate to ask if you need help formulating answers or if any of these questions are unclear. I can provide suggestions and examples to aid your response.


This structured approach ensures we have a thorough understanding of the requirements before starting the HLD, minimizing the risk of rework and ensuring a robust and reliable system.
