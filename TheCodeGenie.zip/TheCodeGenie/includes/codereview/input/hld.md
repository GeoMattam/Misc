### 1.1 Purpose

This High-Level Design (HLD) document outlines the architecture and structure of a school fee payment system using New Gen Bank (NGB) credit cards.  It details the interactions between different system components, data flows, and key design decisions to meet the functional and non-functional requirements specified in the Business Requirement Document (BRD).  The purpose is to provide a comprehensive blueprint for the system's development and implementation, ensuring alignment with business needs and facilitating communication among stakeholders.


### 1.2 Scope

This HLD covers the design of the core components required for school fee payments via NGB's digital channels (Online Banking, Mobile Banking, and IVR).  This includes:

*   **School and Student Management:**  Registration, amendment, and de-registration processes for schools and students.
*   **Fee Payment Processing:**  Handling fee payments across different channels, including EPP conversion.
*   **Transaction Processing and Posting:**  Debit/credit entries to credit cards, GL accounts, and school accounts.
*   **Reporting and Notification:**  Generating daily reports and sending SMS notifications.
*   **Security and Authentication:**  Implementation of security measures to protect sensitive data and ensure secure transactions.

This HLD **does not** cover:

*   Detailed UI/UX design.
*   Specific technology choices (database, programming languages, etc.) – these will be addressed in the Low-Level Design (LLD).
*   Integration with school websites or third-party payment gateways (out of scope as per BRD).


### 1.3 Audience

This document is intended for:

*   Software developers
*   Database administrators
*   System architects
*   Project managers
*   Business analysts
*   NGB stakeholders involved in the project


### 1.4 References

*   Business Requirement Document (BRD) – School Fee Payment Using NGB Credit Cards (as provided).



## 2.1 System Description

This system facilitates school fee payments using New Gen Bank (NGB) credit cards. It allows schools to register, manage student fee information, and process payments through multiple channels (Online Banking, Mobile Banking, and IVR).  The system supports the conversion of fee payments into Easy Payment Plans (EPPs), manages GL account postings, and generates automated reports for schools.  Key features include student registration/amendment/de-registration, secure authentication (OTP), transaction logging, SMS notifications, and daily reporting capabilities.  The system is designed to be scalable, reliable, and compliant with security and audit requirements.


## 2.2 System Context

The system integrates with several existing NGB systems: Online Banking, Mobile Banking, IVR, Cards System, and CRM.  It interacts with these systems to authenticate users, process transactions, update account balances, and manage communication (SMS notifications).  The Cards Management, Direct Banking, and Contact Centre business units are involved in the operation and maintenance of the system.  The system's purpose is to expand NGB's card business into the school sector, providing a convenient and secure payment method for school fees, improving customer experience and increasing NGB's market share.  The pilot program begins with Europe School, with potential expansion to other schools in the future.


### 3.1 Architectural Overview

The system architecture for school fee payment using NGB credit cards will be a microservices-based architecture, promoting modularity, scalability, and maintainability.  The system will be divided into several independent services communicating via well-defined APIs (likely RESTful). This approach allows for independent development, deployment, and scaling of individual components.  Key services will include:

* **School Management Service:** Manages school registration, fee type configuration, and related data.  This service will interact with the core banking system to link schools with their designated GL accounts.
* **Student Management Service:** Handles student registration, amendment, and de-registration across all channels (online, mobile, IVR). This service will enforce business rules around student ID verification and data integrity.
* **Payment Processing Service:**  Processes fee payments from various channels (online banking, mobile banking, IVR). This service integrates with the NGB credit card processing system and handles EPP conversion requests.  It also interacts with the GL posting service.
* **GL Posting Service:** Responsible for debiting credit cards, debiting NGB GL accounts, and crediting school accounts. This service ensures accurate and timely financial postings.
* **Notification Service:** Manages SMS notifications for various events, such as registration, payment confirmation, and EPP status updates.
* **Reporting Service:** Generates daily Excel reports for each school and handles their distribution.
* **Security Service:** Enforces security measures like OTP verification and copy-paste restrictions.

These services will interact with existing systems such as Online Banking, Mobile Banking, IVR, CRM, and the core NGB Cards System.


### 3.2 Component Diagram

```plantuml
@startuml
!include <c4/C4_Context>
!include <c4/C4_Container>

System_Boundary(c1, "School Fee Payment System") {
    Person(customer, "Customer", "Pays school fees")
    Person(agent, "Contact Center Agent", "Registers and manages students via IVR")
    Person(admin, "Card Operations Team", "Registers schools")

    Container(schoolManagement, "School Management", "Java", "Manages school registration and fee types")
    Container(studentManagement, "Student Management", "Java", "Manages student registration and information")
    Container(paymentProcessing, "Payment Processing", "Java", "Processes fee payments and EPP conversions")
    Container(glPosting, "GL Posting", "Java", "Posts transactions to GL and school accounts")
    Container(notification, "Notification", "Java", "Sends SMS notifications")
    Container(reporting, "Reporting", "Java", "Generates and distributes reports")
    Container(security, "Security", "Java", "Handles OTP verification and security measures")


    Rel(customer, studentManagement, "Registers student", "Online/Mobile Banking")
    Rel(customer, paymentProcessing, "Pays school fees", "Online/Mobile Banking")
    Rel(agent, studentManagement, "Registers/Updates student", "IVR E-Form")
    Rel(agent, paymentProcessing, "Processes IVR payments", "IVR")
    Rel(admin, schoolManagement, "Registers school", "Web UI")

    Rel(schoolManagement, paymentProcessing, "Provides school and fee type data")
    Rel(studentManagement, paymentProcessing, "Provides student information")
    Rel(paymentProcessing, glPosting, "Initiates GL posting")
    Rel(paymentProcessing, notification, "Sends payment confirmation SMS")
    Rel(glPosting, reporting, "Provides transaction data")
    Rel(notification, customer, "Sends SMS notifications")
    Rel(reporting, admin, "Sends reports", "Email")
    Rel(paymentProcessing, security, "OTP Verification")


    Rel(studentManagement, studentManagement, "Amend/Deregister Student", "Online/Mobile Banking")
    Rel(studentManagement, studentManagement, "Amend/Deregister Student", "IVR E-Form")

}

System_Ext(onlineBanking, "Online Banking", "Provides access for customers")
System_Ext(mobileBanking, "Mobile Banking", "Provides mobile access for customers")
System_Ext(ivr, "IVR System", "Handles phone-based interactions")
System_Ext(cardsSystem, "NGB Cards System", "Processes credit card transactions")
System_Ext(crm, "CRM System", "Customer relationship management")
System_Ext(coreBanking,"Core Banking System", "Handles GL accounts and transactions")

Rel(paymentProcessing, cardsSystem, "Processes Credit Card Transactions")
Rel(schoolManagement, coreBanking, "Links schools to GL accounts")
Rel(glPosting, coreBanking, "Posts to GL accounts")


@enduml
```

### 3.3 Data Flow Diagram

```plantuml
@startuml
!include <c4/C4_Context>
!include <c4/C4_Container>

start

:School Registration (Admin);
:Student Registration (Customer/Agent);
:Fee Payment (Customer/Agent);
:EPP Conversion Request;

:Validate Data;
:Process Payment;
:Post to GL;
:Send Notifications;
:Generate Reports;

stop

@enduml
```

(Note: A more detailed DFD would show specific data elements flowing between components.  This is a high-level representation)


### 3.4 Deployment Diagram

```plantuml
@startuml
!include <c4/C4_Deployment>

System_Boundary(c1, "School Fee Payment System") {
    ContainerDb(database, "Database", "PostgreSQL", "Stores school, student, and transaction data")

    Container(schoolManagement, "School Management", "Java", "Manages school registration and fee types")
    Container(studentManagement, "Student Management", "Java", "Manages student registration and information")
    Container(paymentProcessing, "Payment Processing", "Java", "Processes fee payments and EPP conversions")
    Container(glPosting, "GL Posting", "Java", "Posts transactions to GL and school accounts")
    Container(notification, "Notification", "Java", "Sends SMS notifications")
    Container(reporting, "Reporting", "Java", "Generates and distributes reports")

    Rel(schoolManagement, database, "Read/Write", "JDBC")
    Rel(studentManagement, database, "Read/Write", "JDBC")
    Rel(paymentProcessing, database, "Read/Write", "JDBC")
    Rel(glPosting, database, "Write", "JDBC")
    Rel(reporting, database, "Read", "JDBC")


}

Deployment_Node(server1, "Application Server", "Linux", "Multiple instances for scalability")
Deployment_Node(databaseServer, "Database Server", "Linux", "PostgreSQL database")

Rel(schoolManagement, server1, "Deployed On")
Rel(studentManagement, server1, "Deployed On")
Rel(paymentProcessing, server1, "Deployed On")
Rel(glPosting, server1, "Deployed On")
Rel(notification, server1, "Deployed On")
Rel(reporting, server1, "Deployed On")

Rel(database, databaseServer, "Deployed On")

@enduml
```

(Note: This deployment diagram shows a basic setup.  A production environment would likely involve load balancers, message queues, and other infrastructure components for high availability and scalability.)


### 4.1 Module Overview

The system can be divided into the following main modules:

* **School Management Module:** Responsible for registering schools, managing school information (name, location, account number, fee types), and generating reports.  Interacts with the GL Account Configuration module internally.

* **Student Management Module:** Handles student registration, amendment, and de-registration across Online/Mobile Banking and Contact Center channels.  Maintains student records linked to schools and fee types.

* **Payment Processing Module:** Processes fee payments through Online Banking, Mobile Banking, and IVR channels.  Handles EPP conversion requests and integrates with the Fee Posting Module.

* **Fee Posting Module:** Responsible for debiting credit cards, GL accounts, and crediting school accounts for each transaction.  Ensures data integrity and compliance with description format constraints.  Generates daily reports.

* **Reporting Module:** Generates daily Excel reports for each school, detailing transactions. Sends these reports via email.

* **Security & Authentication Module:** Implements OTP verification for online/mobile transactions and restricts copy-paste functionality for sensitive fields.  Handles user authentication across all channels.

* **SMS Notification Module:** Sends SMS alerts for registration, amendment, de-registration, payment confirmations, and EPP related updates.


### 4.2 Module Input/Output Interfaces

| Module                  | Input                                                              | Output                                                                    | Explanation                                                                                                                               |
|--------------------------|----------------------------------------------------------------------|-----------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|
| **School Management**    | School registration data (UI input), product team email (Excel)       | School registration confirmation, internal GL account configuration, daily reports | UI provides input for registration; Excel import for bulk registrations; internal system updates GL accounts; reports summarize school data. |
| **Student Management**   | Student data (UI/IVR input), school ID, OTP, authentication details | Student registration confirmation, updated student records, SMS notifications   | User input through various channels; system updates records and triggers notifications.                                                     |
| **Payment Processing**   | Student ID, fee type, card details, EPP request, authentication     | Transaction details, unique reference ID, EPP form (if applicable), SMS confirmation, updated transaction logs | User selects payment options, system processes payment and generates confirmations.                                                        |
| **Fee Posting**         | Transaction details (from Payment Processing)                          | Updated GL accounts, school accounts, transaction logs, daily reports          | Payment data is processed to update financial accounts and generate reports.                                                              |
| **Reporting Module**     | Transaction logs from Fee Posting Module                             | Daily Excel reports (email)                                                  | Processes transaction logs to create reports for each school.                                                                             |
| **Security & Authentication** | User credentials, OTP                                                 | Authentication status, access control                                         | Verifies user identity and controls access to sensitive functionalities.                                                                   |
| **SMS Notification**    | Events (registration, payment, etc.)                               | SMS messages                                                              | Triggers SMS notifications based on system events.                                                                                          |


### 4.3 Module Interaction

1.  **School Registration:** The School Management Module receives school data via a UI (Card Operations Team) or email (Product Team).  It then configures the corresponding GL account internally.

2.  **Student Registration:**  The Student Management Module receives student data via Online/Mobile Banking UI or Contact Center E-Form. It verifies the data and updates the database. The Security & Authentication Module handles OTP verification.  The SMS Notification Module sends confirmation messages.

3.  **Fee Payment:** The Payment Processing Module receives payment requests from Online/Mobile Banking or IVR. It validates the student's registration, processes the payment using the selected card, and generates a unique reference ID. If an EPP is requested, an E-Form is generated.  The SMS Notification Module sends confirmation messages.

4.  **Fee Posting:** The Fee Posting Module receives transaction details from the Payment Processing Module.  It debits the credit card, debits the appropriate GL account (Visa Conventional/Visa Islamic/MasterCard), credits the school's account, and logs the transaction.

5.  **Reporting:** The Reporting Module retrieves transaction logs from the Fee Posting Module to generate daily Excel reports per school, which are then emailed to each school.


### 4.4 Module Diagrams

**(Due to the complexity of creating visual diagrams within this text-based format, detailed class and sequence diagrams are omitted.  However, a high-level description is provided below.)**

* **Class Diagram:**  A class diagram would show classes for School, Student, Transaction, GLAccount, and other relevant entities.  Relationships between these classes (e.g., a School has many Students, a Transaction involves a Student and a Payment) would be illustrated.  Modules would be represented as packages containing related classes.

* **Sequence Diagram (for Fee Payment via Online Banking):** A sequence diagram would illustrate the interaction between actors (Customer, Online Banking System) and modules (Security & Authentication, Payment Processing, Fee Posting, SMS Notification) during a fee payment transaction.  It would show the sequence of messages exchanged between these components to process the payment and send confirmations.  A similar sequence diagram would be created for IVR and Mobile Banking scenarios.  The diagram would clearly show how OTP verification, payment processing, and SMS notifications occur.


### 5.1 Data Model

The data model will center around several core entities and their relationships.  We'll use a relational model for clarity and ease of implementation within a Java environment.

**Entities:**

* **School:** `school_id (PK), school_name, location, account_number, ngb_gl_account`
* **Student:** `student_id (PK), school_id (FK), student_name, registration_date`
* **FeeType:** `fee_type_id (PK), school_id (FK), fee_type_name, amount`
* **CreditCard:** `card_number (PK), customer_id (FK), card_status`
* **Transaction:** `transaction_id (PK), student_id (FK), fee_type_id (FK), card_number (FK), transaction_date, amount, remarks, status, reference_id`
* **EasyPaymentPlan (EPP):** `epp_id (PK), transaction_id (FK), plan_details, status`
* **Customer:** `customer_id (PK), tin (unique)`


**Relationships:**

* **One-to-many** between School and Student: One school can have many students.
* **One-to-many** between School and FeeType: One school can have many fee types.
* **One-to-many** between Student and Transaction: One student can have many transactions.
* **One-to-many** between FeeType and Transaction: One fee type can be associated with many transactions.
* **One-to-many** between CreditCard and Transaction: One credit card can be used in many transactions.
* **One-to-one** between Transaction and EPP (optional): One transaction can have at most one EPP associated with it.
* **One-to-many** between Customer and CreditCard: One customer can have multiple credit cards.


### 5.2 Database Schema

The database schema will reflect the data model described above.  We can utilize a relational database management system (RDBMS) like PostgreSQL or MySQL.  A sample schema (PostgreSQL dialect) is shown below:


```sql
CREATE TABLE School (
    school_id SERIAL PRIMARY KEY,
    school_name VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    account_number VARCHAR(50) NOT NULL,
    ngb_gl_account VARCHAR(50) NOT NULL
);

CREATE TABLE Student (
    student_id SERIAL PRIMARY KEY,
    school_id INTEGER REFERENCES School(school_id) ON DELETE CASCADE,
    student_name VARCHAR(255) NOT NULL,
    registration_date TIMESTAMP WITH TIME ZONE
);

CREATE TABLE FeeType (
    fee_type_id SERIAL PRIMARY KEY,
    school_id INTEGER REFERENCES School(school_id) ON DELETE CASCADE,
    fee_type_name VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL
);

CREATE TABLE CreditCard (
    card_number VARCHAR(20) PRIMARY KEY,
    customer_id INTEGER REFERENCES Customer(customer_id) ON DELETE CASCADE,
    card_status VARCHAR(50) NOT NULL
);

CREATE TABLE Customer (
    customer_id SERIAL PRIMARY KEY,
    tin VARCHAR(20) UNIQUE NOT NULL
);


CREATE TABLE Transaction (
    transaction_id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES Student(student_id) ON DELETE CASCADE,
    fee_type_id INTEGER REFERENCES FeeType(fee_type_id) ON DELETE CASCADE,
    card_number VARCHAR(20) REFERENCES CreditCard(card_number) ON DELETE CASCADE,
    transaction_date TIMESTAMP WITH TIME ZONE NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    remarks VARCHAR(20),
    status VARCHAR(50) NOT NULL,
    reference_id VARCHAR(50) UNIQUE NOT NULL
);

CREATE TABLE EasyPaymentPlan (
    epp_id SERIAL PRIMARY KEY,
    transaction_id INTEGER REFERENCES Transaction(transaction_id) ON DELETE CASCADE,
    plan_details TEXT,
    status VARCHAR(50) NOT NULL
);

```

Indexes will be added to optimize query performance, particularly on foreign key columns.


### 5.3 Data Flow

Data flows through the system in several ways, depending on the operation:

**School Registration:**

1.  **Creation:** The Card Operations team inputs data via a UI, which is then persisted to the `School` table. An email containing the registration data in Excel format is sent to the product team.
2.  **Read:**  The system reads school data from the `School` table for display in various UI elements (online banking, mobile banking, etc.) and report generation.


**Student Registration/Amendment/De-registration:**

1.  **Creation/Update/Deletion:** Data is input via Online/Mobile Banking or Contact Center's E-form and updated in the `Student` table.
2.  **Read:**  Student data is read from the `Student` table for verification and display.


**Fee Payment:**

1.  **Creation:** Payment details (including student, fee type, card, and amount) are captured and a new entry is created in the `Transaction` table.  The `CreditCard` table is updated to reflect the transaction.  If an EPP is requested, an entry is created in the `EPP` table.
2.  **Read:** Transaction details are read for confirmation and history display.
3.  **Update:** Transaction status is updated to reflect successful debiting of the credit card and GL account and crediting of the school account.


**Fee Posting:**

1.  **Update:**  The `Transaction` table is updated with the posting status upon successful debiting/crediting of accounts.  This step involves integrating with the GL and school account systems.
2.  **Read:**  Transaction data is read to generate daily reports.


**Reporting:**

1.  **Read:**  Data is read from relevant tables (`School`, `Student`, `Transaction`, `FeeType`) to generate daily Excel reports.
2.  **Output:** Reports are emailed to registered schools.


The data flow involves both synchronous and asynchronous processes. Real-time GL postings require synchronous interactions with the GL system.  Report generation can be done asynchronously on a scheduled basis.  SMS notifications can be handled through an asynchronous messaging system (e.g., using a message queue like RabbitMQ).


## 6.1 User Interface Overview

The system will feature separate user interfaces for different user roles and channels:

**A. Card Operations Team (School Registration):** A web-based interface allowing the Card Operations team to register schools.  This interface will include forms for entering school details (name, location, account number) and managing fee types associated with each school.  A simple, intuitive design with clear input fields and validation messages is crucial.

**B. Customers (Online/Mobile Banking):**  A responsive, user-friendly interface integrated into the existing Online and Mobile Banking platforms. Key features include:

* **Student Management:**  Forms for student registration, amendment, and de-registration, including input validation (e.g., Student ID confirmation).  A dropdown for selecting registered schools.
* **Fee Payment:** Clear display of fee types associated with the selected student and school.  A dropdown for selecting the payment card.  An optional remark field (max 20 characters).  A payment history section displaying the last 6 months of transactions.  An option to convert the payment to an Easy Payment Plan (EPP).

**C. Contact Center Agents (E-Form):** A web-based E-Form accessible to Contact Center agents.  This interface will be used for student registration, amendment, and de-registration via phone calls.  It will include fields mirroring the online/mobile banking interface, but with enhanced security features to prevent copy-pasting of sensitive information like the Student ID.

**D. IVR System:** A voice-based interface with clear menu navigation and options for fee payment.  Text-to-speech (TTS) functionality for student names (optional).

## 6.2 External Interfaces

The system will integrate with several existing NGB systems and potentially external systems in the future:

* **Online Banking System:**  Interface for displaying student and fee information, processing payments, and accessing transaction history.  This will likely involve API calls to retrieve and update data.
* **Mobile Banking System:** Similar interface to Online Banking, potentially using the same APIs or a separate mobile-optimized API.
* **Cards System:**  Interface for verifying card details, processing payments, and updating account balances. This will be a crucial integration point for debiting the credit card.
* **General Ledger (GL) System:**  Interface for posting transactions to the appropriate GL accounts (Visa Conventional, Visa Islamic, MasterCard). Real-time integration is crucial for performance.
* **SMS Gateway:**  Interface for sending SMS notifications for registration, payment confirmations, and EPP status updates.
* **CRM System (Optional):**  Interface for integrating with customer relationship management data (potentially for enhanced customer profiling).
* **ICRS (Integrated Customer Relationship System):** Update ICRS with transaction records.
* **School System (Future Enhancement):** A potential future interface for automatic synchronization of student and fee data from school systems.  This is currently out of scope.

## 6.3 Interface Diagrams

**(Diagram 1: High-Level System Architecture)**

```
+-----------------+     +-----------------+     +-----------------+     +-----------------+
| Online Banking  |---->| Payment Gateway |---->| Cards System     |---->| GL System       |
+-----------------+     +-----------------+     +-----------------+     +-----------------+
       ^                                                                     |
       |                                                                     v
       +---------------------------------------------------------------------+
                                           |
                                           v
                               +-----------------+
                               | Mobile Banking  |
                               +-----------------+
                                           |
                                           v
                               +-----------------+
                               |    Contact Center (E-Form)      |
                               +-----------------+
                                           |
                                           v
                               +-----------------+
                               |       IVR        |
                               +-----------------+
                                           |
                                           v
                               +-----------------+
                               |     SMS Gateway   |
                               +-----------------+

```

**(Diagram 2: Fee Payment Flow - Online Banking)**

```
[Customer] --> [Online Banking UI] --> [Payment Gateway API] --> [Cards System API] --> [GL System API] --> [Confirmation/SMS Gateway] --> [Customer]
```


**(Diagram 3: Student Registration Flow - Contact Center)**

```
[Customer (Phone)] --> [IVR] --> [Contact Center Agent] --> [E-Form UI] --> [Cards System API/CRM API (optional)] --> [SMS Gateway] --> [Customer]
```

These diagrams provide a simplified overview.  Detailed sequence diagrams and interaction specifications would be required for a full architectural design.  The specific APIs and communication protocols (e.g., REST, SOAP) will need to be defined during the detailed design phase.


### 8.1 Performance Requirements

The system must meet the following performance requirements:

* **Real-time GL postings:**  GL account updates should occur with minimal latency (near real-time) to ensure accurate financial records.  A target latency of under 2 seconds for GL postings is recommended.
* **Near-instant transaction acknowledgment:** Users should receive confirmation of their transaction within a few seconds of completion. A target response time of under 5 seconds for transaction acknowledgment is recommended.  This includes SMS notification delivery.
* **High throughput:** The system should be able to handle a large volume of concurrent transactions during peak hours.  Specific throughput requirements (transactions per second/minute) need to be determined based on projected usage.
* **Transaction processing time:** Individual transaction processing, from initiation to completion (including GL posting and SMS notification), should be completed within a defined timeframe (e.g., under 10 seconds).  This should be tested across different transaction types (e.g., simple payment vs. EPP conversion).
* **Report Generation Time:** Daily excel reports should be generated within a reasonable timeframe (e.g., within 1 hour of the end of the day) to facilitate timely reporting to schools.


### 8.2 Scalability Plan

The system's scalability will be addressed through a multi-pronged approach:

* **Microservices Architecture:**  The system will be designed as a collection of independent microservices (e.g., School Management, Student Management, Payment Processing, GL Posting, SMS Notification). This allows for independent scaling of individual components based on their specific load.
* **Horizontal Scaling:**  Each microservice will be deployed across multiple instances, allowing the system to handle increased load by adding more instances as needed. Load balancers will distribute traffic evenly across these instances.
* **Database Scaling:**  The database will utilize a scalable solution (e.g., a cloud-based relational database with auto-scaling capabilities or a horizontally scalable NoSQL database for specific components) to handle increasing data volume and transaction rates.  Read replicas can also be used to improve read performance.
* **Caching:**  Caching mechanisms (e.g., Redis, Memcached) will be implemented to reduce database load and improve response times for frequently accessed data (e.g., school and student information).
* **Message Queue:** Asynchronous processing using a message queue (e.g., Kafka, RabbitMQ) will decouple various components (like payment processing and GL posting), improving overall throughput and resilience.  This will also help to prevent slow GL posting from impacting other parts of the system.
* **Cloud Infrastructure:** Leveraging cloud infrastructure (e.g., AWS, Azure, GCP) provides inherent scalability and elasticity.  Auto-scaling features can automatically adjust resources based on real-time demand.


### 8.3 Performance Testing and Tuning

A comprehensive performance testing plan will be implemented, including:

* **Load Testing:**  Simulate realistic user loads to determine the system's performance under stress.  This will involve using load testing tools (e.g., JMeter, Gatling) to simulate a large number of concurrent users performing various transactions.
* **Stress Testing:**  Push the system beyond its expected limits to identify breaking points and assess its resilience.
* **Endurance Testing:**  Run the system under sustained load for an extended period to identify performance degradation over time.
* **Spike Testing:**  Simulate sudden surges in traffic to evaluate the system's response to unexpected peaks in demand.
* **Unit Testing and Integration Testing:** Thorough unit and integration tests will be performed to ensure individual components and their interactions perform optimally before load testing.
* **Performance Monitoring:**  Implement robust monitoring tools (e.g., Prometheus, Grafana) to track key performance indicators (KPIs) such as response times, throughput, error rates, and resource utilization.  This will provide insights into performance bottlenecks.
* **Performance Tuning:**  Based on the results of performance testing, optimize the system's configuration, code, and database queries to improve performance. This may include database indexing, code optimization, and caching strategies.  Regular performance tuning will be necessary as the system grows.

This plan ensures the system is robust, scalable and performs optimally under various conditions.  Specific targets for KPIs will be established during the requirements gathering phase based on business needs and expected user volume.


### 9.1 Error Handling

The system will employ a multi-layered error handling strategy to ensure robustness and provide informative feedback to users and administrators.

**1. User-Level Error Handling:**  User interfaces (Online Banking, Mobile Banking, IVR) will present clear and concise error messages to the user in case of issues such as:

* **Invalid input:**  Incorrectly formatted student ID, insufficient funds, invalid school selection, etc. will result in specific error messages guiding the user to correct the input.
* **System errors:** Generic error messages will be displayed for unexpected system failures, while logging the detailed error for later investigation.  These messages will avoid technical jargon and focus on user-understandable language (e.g., "Transaction failed. Please try again later.").
* **Authentication failures:**  Clear messages will indicate incorrect OTPs or TINs.  Multiple failed attempts might trigger account lockouts with instructions for unlocking.

**2. Application-Level Error Handling:**  The application will utilize exception handling mechanisms (try-catch blocks) to catch and manage exceptions during processing.  This includes:

* **Data validation exceptions:**  Handling violations of business rules (e.g., mismatched student IDs, insufficient card balance).
* **Database exceptions:** Managing issues like connection failures or constraint violations.
* **External system exceptions:**  Handling failures in communication with external systems like the GL system or SMS gateway.  Retry mechanisms with exponential backoff will be implemented for transient failures.

**3. System-Level Error Handling:**  Monitoring tools will be implemented to track system performance and identify potential issues.  Alerts will be triggered for critical errors, allowing for proactive intervention.  This includes:

* **Monitoring of key metrics:**  Transaction success rate, latency, error rates, and resource utilization.
* **Centralized logging:**  Detailed logs will allow for root cause analysis.

**4. Recovery Mechanisms:**  For non-critical errors, the system will attempt automatic recovery where possible (e.g., retrying failed transactions).  For critical failures, administrators will be alerted and can manually intervene to resolve the issues.

### 9.2 Logging

A comprehensive logging strategy will be implemented to track system activity, diagnose errors, and meet audit requirements.

**1. Logging Levels:**  The system will utilize different logging levels (DEBUG, INFO, WARN, ERROR) to categorize log entries based on their severity.

**2. Log Information:**  Log entries will contain the following information:

* **Timestamp:** Precise time of the event.
* **Log level:**  Severity of the event (DEBUG, INFO, WARN, ERROR).
* **Transaction ID:** Unique identifier for each transaction.
* **User ID (if applicable):** Identifier of the user performing the action.
* **Module:**  Component of the system where the event occurred.
* **Message:**  Description of the event.
* **Error details (if applicable):**  Stack trace and other relevant details for errors.
* **School ID:** Identifier of the associated school.
* **Student ID:** Identifier of the associated student.

**3. Log Management:**  Logs will be stored in a centralized logging system (e.g., ELK stack, Splunk) for efficient searching, analysis, and reporting.  Logs will be retained according to a defined retention policy, complying with audit and regulatory requirements.

**4. Log Rotation:**  Log files will be rotated regularly to prevent them from growing excessively large.

**5. Security:**  Logs will be secured to prevent unauthorized access.  Appropriate access control mechanisms will be implemented.

**6. Alerting:**  Critical errors will trigger alerts to administrators via email or other notification mechanisms.




### 10.1 Assumptions

*   Schools have pre-existing accounts with NGB.
*   No loyalty points are awarded for transactions converted to Easy Payment Plans (EPP).
*   The system will provide SMS notifications for EPP rejections due to insufficient balance.
*   Existing SMS and email infrastructure is available and reliable for sending notifications and reports.
*   The necessary APIs and integration points exist for communication between the fee payment system and other involved systems (Online Banking, Mobile Banking, IVR, Cards System, CRM, GL).
*   Data formats for exchange between systems (e.g., Excel reports) are standardized and well-defined.
*   The Contact Center uses an E-form system compatible with the fee payment system's integration needs.

### 10.2 Dependencies

*   **Online Banking System:** For online fee payments and student registration/management functionalities.
*   **Mobile Banking System:** For mobile fee payments and student registration/management functionalities.
*   **IVR System:** For IVR-based fee payments and student management (via Contact Center).
*   **Cards System:** For credit card authorization, transaction processing, and balance checks.
*   **General Ledger (GL) System:** For accounting and financial postings.
*   **CRM System:**  Potentially for customer data integration and reporting.  The level of dependency depends on the chosen implementation.
*   **SMS Gateway:** For sending SMS notifications.
*   **Email System:** For sending reports and registration confirmations.
*   **Contact Center E-Form System:** For agent-assisted student registration, amendment, and de-registration.




### 4.1 Component List & Description

| Component Name             | Description                                                                                                         | Technology Stack                               |
|-----------------------------|---------------------------------------------------------------------------------------------------------------------|---------------------------------------------|
| **School Management Module** | Manages school registration, including details like name, location, and account number.  Handles fee type configuration. | Java Spring Boot, REST API, Database (e.g., PostgreSQL) |
| **Student Management Module** | Manages student registration, amendment, and de-registration across multiple channels (Online Banking, Mobile Banking, IVR). | Java Spring Boot, REST API, Database (e.g., PostgreSQL) |
| **Payment Gateway Module**   | Processes fee payments through various channels (Online Banking, Mobile Banking, IVR), integrating with the card system. | Java Spring Boot, REST API, Integration with NGB Card System |
| **EPP Conversion Module**    | Handles the conversion of fee payments to Easy Payment Plans (EPP).                                                    | Java Spring Boot, REST API, Integration with EPP System |
| **Fee Posting Module**       | Posts transactions to the general ledger (GL) accounts and credits the school accounts.                               | Java Spring Boot, REST API, Integration with GL System |
| **SMS Notification Module**  | Sends SMS alerts for registration, amendment, de-registration, and payment confirmations.                              | Java Spring Boot, REST API, SMS Gateway Integration |
| **Reporting Module**         | Generates daily Excel reports for each school, summarizing transactions.                                             | Java Spring Boot, REST API, Excel Library |
| **Security Module**          | Handles OTP verification, copy-paste restrictions, and other security measures.                                       | Java Spring Boot, Security Framework (e.g., Spring Security) |
| **Contact Center Integration Module** | Facilitates student management and fee payment processing through the contact center's E-Form.                     | Java Spring Boot, REST API, Integration with Contact Center System |
| **User Interface (UI) Modules** | Provides user interfaces for Online Banking, Mobile Banking, and IVR channels.                                     | React/Angular/other suitable frontend framework |


### 4.2 Component Interaction

The components interact primarily through RESTful APIs.  For example:

1.  **School Registration:** The Card Operations team uses the UI to interact with the School Management Module via REST API calls.
2.  **Student Registration:**  Online/Mobile Banking UI interacts with the Student Management Module. The Contact Center uses its E-Form to interact with the Student Management Module via the Contact Center Integration Module.
3.  **Fee Payment:** The Payment Gateway Module interacts with the Student Management Module to verify student registration and with the Card System to process the payment.  It also interacts with the EPP Conversion Module if the user selects that option.
4.  **Fee Posting:** The Payment Gateway Module sends transaction details to the Fee Posting Module for GL and school account updates.
5.  **SMS Notifications:** All relevant modules (Student Management, Payment Gateway, etc.) send notifications to the SMS Notification Module.
6.  **Reporting:** The Fee Posting Module provides data to the Reporting Module for generating daily reports.

### 4.3 Dependency Mapping

**External Dependencies:**

*   NGB Card System
*   NGB GL System
*   EPP System
*   SMS Gateway
*   Contact Center System
*   Database (PostgreSQL or similar)

**Internal Dependencies:**

*   All modules depend on the Security Module for authentication and authorization.
*   The Reporting Module depends on data from the Fee Posting Module.
*   The Payment Gateway Module depends on the Student Management Module and the EPP Conversion Module.


### 4.4 Component Diagram

```plantuml
@startuml
left to right direction

rectangle "Online Banking UI"
rectangle "Mobile Banking UI"
rectangle "IVR System"
rectangle "Contact Center"

rectangle "School Management Module"
rectangle "Student Management Module"
rectangle "Payment Gateway Module"
rectangle "EPP Conversion Module"
rectangle "Fee Posting Module"
rectangle "SMS Notification Module"
rectangle "Reporting Module"
rectangle "Security Module"
rectangle "Contact Center Integration Module"


"Online Banking UI" -- "Student Management Module"
"Mobile Banking UI" -- "Student Management Module"
"IVR System" -- "Student Management Module"
"Contact Center" -- "Contact Center Integration Module"

"School Management Module" -- "Payment Gateway Module"
"Student Management Module" -- "Payment Gateway Module"
"Payment Gateway Module" -- "EPP Conversion Module"
"Payment Gateway Module" -- "Fee Posting Module"
"Payment Gateway Module" -- "SMS Notification Module"
"Fee Posting Module" -- "Reporting Module"

"Student Management Module" -- "SMS Notification Module"
"Payment Gateway Module" -- "Security Module"
"Contact Center Integration Module" -- "Student Management Module"

rectangle "NGB Card System"
rectangle "NGB GL System"
rectangle "EPP System"
rectangle "SMS Gateway"
rectangle "Database"


"Payment Gateway Module" -- "NGB Card System"
"Fee Posting Module" -- "NGB GL System"
"EPP Conversion Module" -- "EPP System"
"SMS Notification Module" -- "SMS Gateway"
"School Management Module" .. "Database"
"Student Management Module" .. "Database"
"Payment Gateway Module" .. "Database"
"EPP Conversion Module" .. "Database"
"Fee Posting Module" .. "Database"
"Reporting Module" .. "Database"

@enduml
```


## 6.1 Deployment Diagram

```plantuml
@startuml
left to right direction

node "Online Banking" {
  component "Fee Payment Module"
  component "Student Management Module"
}

node "Mobile Banking" {
  component "Fee Payment Module"
  component "Student Management Module"
}

node "IVR System" {
  component "Fee Payment Module"
  component "Student Management Module"
}

node "Contact Center" {
  component "E-Form Module"
}

node "Cards System" {
  component "Card Authorization Module"
  component "Transaction Processing Module"
}

node "GL System" {
  component "Accounting Module"
}

node "School Database" {
}

Online Banking -- "Fee Payment Module" : Requests
Mobile Banking -- "Fee Payment Module" : Requests
IVR System -- "Fee Payment Module" : Requests
Contact Center -- "E-Form Module" : Requests
"Fee Payment Module" -- "Card Authorization Module" : Authorization Request
"Card Authorization Module" -- "Transaction Processing Module" : Transaction Data
"Transaction Processing Module" -- "GL System" : Posting Request
"Transaction Processing Module" -- "School Database" : Update School Data
"E-Form Module" -- "Transaction Processing Module" : Transaction Data
"Student Management Module" -- "School Database" : Data Access


@enduml
```

## 6.2 Deployment Diagram (Detailed View)

This diagram would be significantly more complex, showing specific hardware (servers, databases, load balancers), network configurations, and potentially cloud infrastructure components (e.g., cloud instances, message queues).  It would expand on the components shown in 6.1, specifying technologies (e.g.,  specific application servers, databases like Oracle or PostgreSQL, message brokers like Kafka or RabbitMQ).  A detailed diagram would require more information about the chosen infrastructure and technology stack.  It would also illustrate redundancy mechanisms (e.g., multiple instances of components, load balancing) and communication pathways (e.g., REST APIs, message queues). Due to the complexity, it's not feasible to create a comprehensive detailed diagram without further specifications.


## 6.3 Environment Strategy

We will employ a three-environment strategy: Development, Testing, and Production.

* **Development:** This environment will be used by developers for code development, testing, and debugging.  It should be a lightweight, easily disposable environment.  It might leverage containers (Docker) and orchestration (Kubernetes) for easy management and scalability.

* **Testing:**  This environment mirrors the Production environment as closely as possible.  It will be used for rigorous testing, including unit, integration, system, and user acceptance testing (UAT).  This environment should allow for load testing and performance benchmarking.

* **Production:** This is the live environment accessible to users.  High availability and disaster recovery mechanisms will be implemented in this environment.  This will include redundancy, failover mechanisms, and monitoring tools.

**Deployment Flow:**  A continuous integration/continuous deployment (CI/CD) pipeline will be implemented. Code changes will be automatically built, tested, and deployed to the environments, starting with Development, moving to Testing, and finally to Production.  Automated deployment scripts and configuration management tools (e.g., Ansible, Chef) will be used to streamline the process and reduce manual intervention.


## 6.4 Scalability/Resilience

Scalability and resilience will be achieved through several strategies:

* **Microservices Architecture:**  The system will be designed using a microservices architecture.  This allows individual components to be scaled independently based on demand.  If one service experiences high load, it can be scaled up without affecting other parts of the system.

* **Horizontal Scaling:**  Multiple instances of key components (e.g., application servers, databases) will be deployed across multiple servers.  This allows the system to handle increased traffic and workload by adding more instances.

* **Load Balancing:**  Load balancers will distribute traffic across multiple instances of the application servers, ensuring that no single server becomes overloaded.

* **Database Replication:**  The database will be replicated to provide high availability and redundancy.  In case of a primary database failure, the system can automatically failover to a secondary database.

* **Message Queues:** Asynchronous communication using message queues (e.g., Kafka, RabbitMQ) will decouple components and improve resilience.  This prevents failures in one component from cascading to others.

* **Monitoring and Alerting:**  Comprehensive monitoring and alerting systems will track system performance, resource utilization, and error rates.  This allows proactive identification and resolution of issues.

* **Disaster Recovery:**  A robust disaster recovery plan will be implemented, ensuring business continuity in case of major outages or disasters.  This might involve geographic redundancy (deploying the system across multiple data centers).


## 7.1 Use Case Diagram

This diagram will illustrate the interactions between various actors (users and systems) and the system's functionalities.  The actors include:

* **Card Operations Team:** Registers schools and manages school information.
* **School Administrator:** (Potentially)  Manages student information within the school's system (though this is out of scope for the current system).
* **Customer (Cardholder):** Registers students, makes fee payments, and views transaction history via Online Banking and Mobile Banking.
* **Contact Center Agent:** Registers, amends, and de-registers students via the E-Form and processes IVR fee payments.
* **IVR System:** Handles automated fee payments and authentication.
* **Online Banking System:** Provides an interface for online fee payments and student management.
* **Mobile Banking System:** Provides a mobile interface for fee payments and student management.
* **Cards System:** Processes credit card transactions and manages card information.
* **GL System (General Ledger):** Manages accounting entries for fee transactions.
* **SMS Gateway:** Sends SMS notifications.
* **Email System:** Sends email reports to schools.


**Use Cases:**

* **Register School:**  Initiated by the Card Operations Team.  Includes data validation and GL account configuration.
* **Register Student:** Initiated by the Customer (Online/Mobile) or Contact Center Agent (E-Form/IVR). Includes data validation and OTP authentication.
* **Amend Student Information:** Similar to Register Student, initiated by the same actors.
* **De-register Student:** Similar to Register Student, initiated by the same actors.
* **Make Fee Payment (Online/Mobile):** Initiated by the Customer. Includes card selection, fee type selection, and transaction processing.
* **Make Fee Payment (IVR):** Initiated by the Customer via IVR. Includes voice navigation and OTP authentication.
* **Convert to EPP:** Initiated by the Customer during a fee payment.  Triggers E-Form generation.
* **Process EPP Request:** Initiated by the Contact Center Agent. Includes manual review and confirmation.
* **Generate Reports:**  System automatically generates and sends daily Excel reports to schools via email.
* **Manage E-Form:** Used by the Contact Center Agent for student registration, amendment and de-registration.


The diagram would visually represent these actors and use cases, showing the relationships and interactions between them using standard UML notation (actors as stick figures, use cases as ellipses, and lines to indicate communication).  The relationships would clearly show which actors participate in which use cases.


### 8.1 Sequence Diagram: Fee Payment via Online Banking

```plantuml
@startuml
actor Customer
participant "Online Banking UI"
participant "Payment Gateway"
participant "Cards System"
participant "GL Account System"
participant "School Account System"
participant "SMS Gateway"

Customer -> "Online Banking UI": Accesses Fee Payment
"Online Banking UI" -> "Payment Gateway": Payment Request (Student ID, Fee Type, Card Details)
"Payment Gateway" -> "Cards System": Authorize Transaction
activate "Cards System"
"Cards System" -> "GL Account System": Debit GL Account
"Cards System" -> "School Account System": Credit School Account
"Cards System" --> "Payment Gateway": Transaction Authorized/Denied
deactivate "Cards System"
"Payment Gateway" -> "Online Banking UI": Transaction Result
"Online Banking UI" -> Customer: Display Result
if (Transaction Successful) then
    "Online Banking UI" -> "SMS Gateway": Send Confirmation SMS
    "SMS Gateway" -> Customer: Confirmation SMS
endif
@enduml
```

### 8.2 Activity Diagram: Student Registration

```plantuml
@startuml
start
:Customer accesses registration portal;
if (Online/Mobile Banking) then
    :Input Student details;
    :OTP verification;
    if (OTP valid) then
        :Register Student;
        :Send SMS confirmation;
    else
        :OTP invalid;
        stop
    endif
else if (Contact Center) then
    :IVR authentication;
    :Agent registers student via E-Form;
    :Send SMS confirmation;
else
    stop
endif
:Update database;
stop
@enduml
```

### 8.3 Class Diagram: Core Components

```plantuml
@startuml
class School {
    - schoolName : String
    - location : String
    - accountNumber : String
    + registerFeeType(feeType : FeeType)
}

class Student {
    - studentName : String
    - studentID : String
    - school : School
    + register()
    + deregister()
}

class FeeType {
    - feeName : String
    - amount : double
}

class Payment {
    - paymentID : String
    - student : Student
    - feeType : FeeType
    - amount : double
    - paymentDate : Date
    - remarks : String
    + processPayment()
}

class CreditCard {
    - cardNumber : String
    - cardHolder : Customer
    + authorizePayment(amount : double) : boolean
}

School "1" -- "*" Student : has
Student "1" -- "*" Payment : has
Payment "1" -- "1" FeeType : for
Payment "1" -- "1" CreditCard : paid with


@enduml
```

### 8.4 Package Diagram: System Organization

```plantuml
@startuml
package "UI Layer" {
    rectangle "Online Banking UI"
    rectangle "Mobile Banking UI"
    rectangle "IVR UI"
}

package "Business Logic Layer" {
    rectangle "School Management"
    rectangle "Student Management"
    rectangle "Payment Processing"
    rectangle "EPP Conversion"
}

package "Data Access Layer" {
    rectangle "Database"
}

package "External Systems" {
    rectangle "Cards System"
    rectangle "GL Account System"
    rectangle "School Account System"
    rectangle "SMS Gateway"
}


"UI Layer" --> "Business Logic Layer"
"Business Logic Layer" --> "Data Access Layer"
"Business Logic Layer" --> "External Systems"

@enduml
```


## 11. Identified Risks & Mitigation Plans

### 11.1 Identified Risks

| Risk | Description | Impact | Likelihood |
|---|---|---|---|
| **Integration Complexity** | Integrating with existing Online Banking, Mobile Banking, IVR, Cards System, and CRM systems might be complex and time-consuming due to varying APIs, data formats, and security protocols. | Delays in project delivery, increased development costs, potential integration failures. | High |
| **Data Security Breaches** | Sensitive student and financial data needs robust security measures to prevent unauthorized access and breaches.  | Reputational damage, legal liabilities, financial losses. | Medium |
| **Performance Bottlenecks** | High transaction volume during peak periods (e.g., beginning of school year) could lead to performance issues and slow response times. | User frustration, system unavailability. | Medium |
| **SMS Gateway Failures** | Reliance on SMS for notifications introduces a single point of failure.  Outages or delays in SMS delivery can disrupt user experience and impact critical communications. | User dissatisfaction, lack of transaction confirmation. | Medium |
| **EPP Conversion Errors** | Errors in EPP conversion logic (e.g., incorrect balance checks, inaccurate interest calculations) could lead to financial discrepancies and customer disputes. | Financial losses, customer complaints. | Low |
| **Insufficient Testing** | Inadequate testing could lead to undiscovered bugs and vulnerabilities in production, causing system instability and errors. | System downtime, financial losses, reputational damage. | Medium |
| **Lack of User Adoption** | Users (schools, parents, and bank staff) may be resistant to adopting the new system due to lack of training, intuitive design, or perceived inconvenience. | Low usage rates, project failure. | Medium |


### 11.2 Mitigation Plans

| Risk | Mitigation Plan |
|---|---|
| **Integration Complexity** |  Employ a phased integration approach, starting with pilot integration with one system before expanding.  Utilize robust API management tools and well-defined integration contracts. Thoroughly document APIs and data formats.  Conduct rigorous integration testing. |
| **Data Security Breaches** | Implement strong encryption (both in transit and at rest), access control mechanisms (role-based access control), regular security audits, and penetration testing.  Comply with relevant data privacy regulations (e.g., GDPR).  Use secure coding practices. |
| **Performance Bottlenecks** |  Employ performance testing and load testing throughout the development lifecycle.  Optimize database queries and application code.  Consider using caching mechanisms to improve response times. Implement horizontal scaling to handle increased load. |
| **SMS Gateway Failures** | Use a reliable and redundant SMS gateway provider with Service Level Agreements (SLAs) guaranteeing high uptime and delivery rates. Implement email or in-app notifications as fallback mechanisms. |
| **EPP Conversion Errors** |  Develop a robust EPP conversion module with thorough unit and integration testing. Implement rigorous validation checks on input data and calculations.  Include comprehensive error handling and logging. |
| **Insufficient Testing** |  Develop a comprehensive test plan encompassing unit, integration, system, and user acceptance testing (UAT).  Utilize automated testing wherever possible to increase test coverage and efficiency.  Conduct performance and security testing. |
| **Lack of User Adoption** |  Provide comprehensive training and support for all users (schools, parents, and bank staff).  Design a user-friendly interface with clear instructions and intuitive navigation.  Gather user feedback throughout the development process and incorporate it into the system design.  Offer incentives for early adoption. |



