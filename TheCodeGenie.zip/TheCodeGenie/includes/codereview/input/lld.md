## 1.1 Purpose

This Low-Level Design (LLD) document details the technical architecture and design of a school fee payment system integrated with New Gen Bank (NGB) credit cards.  It elaborates on the components, their interactions, data flow, and implementation specifics based on the provided Business Requirement Document (BRD). The purpose is to provide a blueprint for developers to implement the system effectively, ensuring adherence to functional and non-functional requirements.


## 1.2 Scope

This LLD covers the design of the core components necessary for school fee payments via NGB credit cards, encompassing:

* **School and Student Management:**  Including registration, amendment, and de-registration processes through online/mobile banking and contact center channels.
* **Fee Payment Processing:**  Handling transactions across Online Banking, Mobile Banking, and IVR channels. This includes payment processing logic, EPP conversion, and transaction logging.
* **Fee Posting and Reconciliation:**  Defining the process for debiting credit cards and GL accounts, crediting school accounts, and ensuring data integrity.
* **Reporting and Notification:**  Design of automated reporting mechanisms (daily Excel reports) and SMS notifications.
* **Security and Authentication:**  Implementation details for OTP verification and copy-paste restrictions.

**Out of Scope:**  Integration with school websites, third-party payment gateways, and detailed UI design are explicitly excluded from this LLD.


## 1.3 Audience

This document is primarily intended for:

* **Software Developers:** To guide the implementation of the system.
* **Database Administrators:** To understand the database schema and data structures.
* **System Integrators:** To understand the integration points between different systems.
* **Testers:** To define test cases and scenarios.


## 1.4 References

* Business Requirement Document (BRD) – School Fee Payment Using NGB Credit Cards (as provided).
* NGB Internal GL Account Configuration Procedures.
* NGB Credit Card Processing System Documentation.
* NGB SMS Gateway API Documentation.
* NGB E-Form Workflow Documentation.
* NGB Security and Compliance Standards.



## 2.1 System Description

This system facilitates school fee payments using New Gen Bank (NGB) credit cards.  It allows schools to register with the system, enabling their students' parents to pay fees through various NGB digital channels: Online Banking, Mobile Banking, and Interactive Voice Response (IVR). The system supports student registration, amendment, and de-registration,  and offers the option to convert fee payments into Easy Payment Plans (EPPs).  Key features include secure authentication (OTP), real-time GL postings, transaction logging with unique reference IDs, SMS notifications, and automated reporting for schools.


## 2.2 System Context

The system integrates with several existing NGB systems, including Online Banking, Mobile Banking, the Cards System, the CRM, and the IVR system.  It interacts with these systems to perform functions such as credit card authorization, account debiting/crediting, customer authentication, and transaction logging.  The system also generates automated reports for schools, requiring data extraction and formatting capabilities.  The system sits within the broader context of NGB's cards business, aiming to expand its reach into the school sector and enhance customer convenience. The system’s success depends on the reliable operation of these integrated systems and the accuracy of the data exchange between them.  The Cards Operations Team is responsible for school registration, while the Contact Center handles student management via an E-Form for cases managed through the IVR system.


## 3.1 Functional Overview

The system facilitates school fee payments using NGB credit cards through various channels: Online Banking, Mobile Banking, and IVR.  It comprises four main functional modules:

* **School Registration:** Allows the Card Operations team to register schools, specifying details like name, location, and account number.  The system internally configures the NGB GL account and allows for multiple fee types per school.  Bulk registration via Excel upload is supported.

* **Student Registration/Amendment/De-registration:** Enables parents/guardians to register, amend, or deregister students via Online/Mobile Banking (requiring OTP authentication) or through the Contact Center using an E-form.  Key data points include student name, ID, and school.  SMS alerts are sent for all actions.

* **Fee Payment:**  Supports fee payments across Online Banking, Mobile Banking, and IVR.  It validates student registration, allows selection of active cards, offers EPP conversion, logs transactions with unique IDs, and sends confirmation SMS.  Specific features include fee type selection based on registered school, optional remarks, payment history, and EPP form generation.

* **Fee Posting:**  Handles the financial aspects of transactions.  For each payment, it debits the credit card, debits the appropriate GL account (Visa Conventional, Visa Islamic, or MasterCard), credits the school account, and ensures adherence to description length constraints.  Individual postings are made for each student/fee combination.


## 3.2 Use Cases

**Use Case 1: School Registration (Card Operations Team)**

1. **Initiate Registration:** Card Operations team member accesses the school registration interface.
2. **Input School Details:** Enters school name, location, and account number.
3. **Specify Fee Types:** Defines multiple fee types (e.g., tuition, bus fee) for the school.
4. **Submit Registration:** System validates data and submits the registration request.
5. **System Confirmation:**  Confirmation message indicates successful registration and internal GL account configuration.
6. **Data Export (Optional):** System allows for export of registration data in Excel format.

**Use Case 2: Student Registration (Online Banking)**

1. **Login:** Customer logs into Online Banking with valid credentials.
2. **Access Student Registration:** Navigates to the student registration section.
3. **Select School:** Selects the school from a dropdown menu.
4. **Input Student Details:** Enters student name and ID (twice for verification).
5. **OTP Verification:**  Receives and enters an OTP sent to the registered mobile number.
6. **Submit Registration:** System validates data and registers the student.
7. **Confirmation:**  Receives confirmation message and SMS notification.

**Use Case 3: Fee Payment (Mobile Banking)**

1. **Login:** Customer logs into Mobile Banking.
2. **Select Payment Option:** Chooses "School Fee Payment".
3. **Select Student:** Selects the registered student.
4. **Select Fee Type:** Chooses the fee type.
5. **Select Payment Card:** Selects an active NGB credit card.
6. **Enter Amount (Optional):**  Amount may be pre-populated; customer can verify.
7. **Add Remarks (Optional):** Enters optional remarks (max 20 characters).
8. **Confirm Payment:** Authorizes the payment.
9. **Transaction Confirmation:** Receives confirmation message, SMS, and unique reference ID.

**Use Case 4: EPP Conversion (Online Banking)**

1. **During Payment:** Selects the "Convert to EPP" option during the fee payment process.
2. **EPP Eligibility Check:** System verifies eligibility and sufficient balance for EPP conversion.
3. **EPP Form Generation:** An E-form is generated.
4. **Customer Notification:** Customer receives notification about EPP form generation and next steps.


## 3.3 Flowcharts / Pseudocode

Due to the complexity, providing complete flowcharts for all use cases within this response is impractical.  However, a simplified example for the **Fee Payment (Online Banking)** use case is shown below using pseudocode:

```
FUNCTION FeePaymentOnlineBanking(customerID, studentID, feeType, cardID, amount, remarks):

  // Authentication and Validation
  IF NOT AuthenticateCustomer(customerID) THEN RETURN "Authentication Failed"
  IF NOT IsStudentRegistered(studentID) THEN RETURN "Student not registered"
  IF NOT IsCardActive(cardID) THEN RETURN "Card not active"
  IF amount > GetCardBalance(cardID) THEN RETURN "Insufficient funds"

  // Transaction Processing
  transactionID = GenerateUniqueTransactionID()
  debitCard(cardID, amount)
  debitGLAccount(feeType, amount)
  creditSchoolAccount(studentID, feeType, amount)
  logTransaction(transactionID, customerID, studentID, feeType, cardID, amount, remarks)
  sendConfirmationSMS(customerID, transactionID, amount)

  RETURN "Payment Successful"
END FUNCTION
```

More detailed flowcharts and pseudocode would be developed during the detailed design phase for each use case and module.  These would incorporate error handling, exception management, and detailed step-by-step logic for all system interactions.


### 4.1 Module Overview

| Module Name             | Purpose                                                                     | Functional Responsibilities                                                                                                                              |
|--------------------------|-----------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
| School Registration      | Onboard schools to the fee payment system.                                   | Collect school details (name, location, account number), configure NGB GL account, manage multiple fee types per school, send registration data to product team. |
| Student Registration    | Register, amend, or deregister students for fee payments.                   | Capture student details (name, ID, school), handle multiple student registrations, authenticate users (OTP, IVR TIN), send SMS alerts.                     |
| Fee Payment              | Process school fee payments through various channels.                       | Allow fee payments via online banking, mobile banking, and IVR, manage card selection, offer EPP conversion, log transactions, send confirmation SMS.      |
| Fee Posting              | Process the financial transactions related to fee payments.                 | Debit credit card, debit GL account, credit school account, ensure description format constraints, post individually for each student/fee.               |
| Reporting                | Generate reports on school fee transactions.                               | Generate daily Excel reports per school, including school details, student details, amount, transaction date, and remarks.                              |
| EPP Conversion           | Manage the conversion of fee payments to Easy Payment Plans (EPP).          | Trigger E-Form generation upon EPP conversion request, handle balance checks, send SMS notifications related to EPP status.                            |
| Authentication & Security| Secure user access and protect sensitive data.                              | Handle OTP verification for online/mobile transactions, restrict copy-paste for sensitive fields.                                                         |
| SMS Notification         | Send SMS alerts for various events within the system.                      | Send SMS alerts for registration, amendment, deregistration, payment confirmation, EPP status updates.                                                |


### 4.2 Internal Workflows

**A. School Registration Workflow:**

1.  Card Operations Team uses UI to input school details.
2.  System validates data and registers the school.
3.  System internally configures the NGB GL account.
4.  System sends registration data (Excel format) to the product team via email.

**B. Student Registration Workflow (Online/Mobile Banking):**

1.  Customer logs in using their NGB credentials.
2.  Customer enters student details and selects the school from a dropdown.
3.  System validates student ID (double entry).
4.  System sends an OTP to the customer's registered mobile number.
5.  Customer enters the OTP for authentication.
6.  System registers the student and sends an SMS confirmation.

**C. Fee Payment Workflow (Online Banking):**

1.  Customer selects registered student and fee type.
2.  System displays active cards for selection.
3.  Customer selects a card and enters payment amount.
4.  System verifies card balance.
5.  Upon successful payment, system generates a unique transaction ID.
6.  System debits the credit card and updates GL and school accounts.
7.  System sends a confirmation SMS.

**D. Fee Posting Workflow:**

1.  Upon successful payment, the system initiates the fee posting process.
2.  System debits the selected credit card.
3.  System debits the appropriate GL account (Visa Conventional/Visa Islamic/MasterCard).
4.  System credits the school's account.
5.  System ensures description format constraints (max 40 characters).
6.  System logs the transaction with a unique reference ID.


### 4.3 Data Dictionary

| Field Name          | Data Type    | Description                                      | Source/Target                                  | Constraints                                                                 |
|----------------------|---------------|--------------------------------------------------|-------------------------------------------------|-----------------------------------------------------------------------------|
| School Name          | VARCHAR(255)  | Name of the school                               | School Registration UI, Product Team Email       | Not Null                                                                   |
| School Location      | VARCHAR(255)  | Location of the school                            | School Registration UI, Product Team Email       | Not Null                                                                   |
| School Account Number | VARCHAR(50)   | Account number of the school                     | School Registration UI                            | Not Null, Unique                                                             |
| Student Name         | VARCHAR(255)  | Name of the student                              | Student Registration UI, IVR E-Form             | Not Null                                                                   |
| Student ID           | VARCHAR(50)   | Unique identifier of the student                 | Student Registration UI, IVR E-Form             | Not Null, Unique, Double Entry, Restriction on Copy-Paste                   |
| Fee Type             | VARCHAR(100)  | Type of fee (e.g., School Fee, Bus Fee)         | School Registration UI, Fee Payment UI           | Not Null                                                                   |
| Amount               | DECIMAL(10,2) | Amount of the fee payment                        | Fee Payment UI, IVR                             | Not Null, Positive                                                            |
| Transaction ID       | VARCHAR(50)   | Unique identifier for each transaction          | System Generated                               | Not Null, Unique                                                             |
| Transaction Date     | DATETIME      | Date and time of the transaction                 | System Generated                               | Not Null                                                                   |
| Remarks              | VARCHAR(20)   | Optional remarks from the user                  | Fee Payment UI                                   | Max Length 20                                                              |
| Card Number          | VARCHAR(20)   | Credit Card number used for payment              | Fee Payment UI                                   | Not Null, Masked for display, Validation against Card System                |
| OTP                  | VARCHAR(6)    | One-Time Password for authentication             | System Generated, User Input                     | Not Null, Length 6                                                             |
| GL Account           | VARCHAR(50)   | General Ledger account                          | System Generated                               | Not Null, depends on card type (Visa, MasterCard, Islamic)                    |
| EPP Request          | BOOLEAN        | Indicates if EPP conversion is requested          | Fee Payment UI                                   |                                                                             |
| SMS Message          | VARCHAR(255)  | SMS message sent to the user                     | System Generated                               | Varies based on event (registration, payment, EPP)                          |
| TIN                  | VARCHAR(50)   | Taxpayer Identification Number                   | IVR                                             | Not Null (for IVR authentication)                                          |


This data dictionary provides a comprehensive list of data elements, their types, descriptions, sources, and constraints.  Note that this is not exhaustive and additional fields may be required based on further system design and development.


## 5.1 Class Diagram

```plantuml
@startuml
class School {
    - schoolName : String
    - location : String
    - accountNumber : String
    + registerFeeType(feeType : FeeType) : void
    + getFeeTypes() : List<FeeType>
}

class Student {
    - studentName : String
    - studentID : String
    - school : School
    + register() : void
    + amend() : void
    + deRegister() : void
}

class FeeType {
    - feeTypeName : String
    - amount : double
    - school : School
}

class Payment {
    - paymentID : String
    - student : Student
    - feeType : FeeType
    - amount : double
    - paymentDate : Date
    - remarks : String
    - paymentStatus : String
    + processPayment() : void
}

class CreditCard {
    - cardNumber : String
    - cardHolder : Customer
    + isSufficientBalance(amount : double) : boolean
}

class Customer {
    - customerID : String
    - creditCards : List<CreditCard>
}

class Transaction {
    - transactionID : String
    - payment : Payment
    - debitGLAccount : GLAccount
    - creditSchoolAccount : GLAccount
    + postTransaction() : void
}


class GLAccount {
    - accountNumber : String
    - accountType : String
}

class EPPRequest {
    - requestID : String
    - payment : Payment
    + processEPPRequest() : void
}

School "1" -- "*" Student : has
School "1" -- "*" FeeType : has
Student "1" -- "*" Payment : made
Payment "1" -- "1" CreditCard : uses
Payment "1" -- "1" EPPRequest : canConvertTo
Transaction "1" -- "1" Payment : from
Transaction "1" -- "1" GLAccount : debits
Transaction "1" -- "1" GLAccount : credits
Customer "1" -- "*" CreditCard : owns


@enduml
```

## 5.2 Object Diagram (Example Scenario)

This diagram shows a snapshot of the system at runtime.  It's impossible to show *every* possible object instance, so this is a simplified example illustrating a single fee payment.

```plantuml
@startuml
object school1 : School
object student1 : Student
object feeType1 : FeeType
object payment1 : Payment
object creditCard1 : CreditCard
object customer1 : Customer
object transaction1 : Transaction
object glAccountVisa : GLAccount
object glAccountSchool : GLAccount


school1 : Name = Europe School
student1 : Name = John Doe, ID = 12345
feeType1 : Type = School Fee, Amount = 1000
payment1 : Amount = 1000, ID = TXN123456
creditCard1 : Number = 1111222233334444
customer1 : ID = CUST7890
transaction1 : ID = TRX987654

student1 -- school1
payment1 -- student1
payment1 -- feeType1
payment1 -- creditCard1
customer1 -- creditCard1
transaction1 -- payment1
transaction1 -- glAccountVisa
transaction1 -- glAccountSchool

@enduml
```

**Note:** The Object Diagram shows a simplified example.  A real-world object diagram would be much larger, showing multiple schools, students, fee types, payments, and transactions concurrently.  The relationships shown are illustrative of the key associations between the classes.


### 6.1 Sequence Diagram: Fee Payment via Online Banking

```plantuml
@startuml
actor Customer
participant "Online Banking UI"
participant "Payment Gateway"
participant "Cards System"
participant "GL Account System"
participant "School Account System"
participant "SMS Gateway"

Customer -> "Online Banking UI": Accesses Fee Payment
"Online Banking UI" -> "Payment Gateway": Payment Request (Student ID, Fee Type, Card Details)
"Payment Gateway" -> "Cards System": Authorize Transaction
activate "Cards System"
"Cards System" -> "GL Account System": Debit GL Account
"Cards System" -> "School Account System": Credit School Account
"Cards System" --> "Payment Gateway": Transaction Authorized/Declined
deactivate "Cards System"
"Payment Gateway" -> "Online Banking UI": Transaction Result
"Online Banking UI" -> Customer: Display Transaction Result
"Online Banking UI" -> "SMS Gateway": Send Confirmation SMS
@enduml
```

### 6.2 Communication Diagram: Student Registration via Contact Center

```plantuml
@startuml
actor Agent
participant "IVR System"
participant "E-Form"
participant "Student Registration System"
participant "SMS Gateway"

Agent -> "IVR System": Authenticates via TIN
"IVR System" -> Agent: Retrieves Customer Information
Agent -> "E-Form": Inputs Student Details
"E-Form" -> "Student Registration System": Submits Registration Request
activate "Student Registration System"
"Student Registration System" -> "Student Registration System": Validates Data
"Student Registration System" -> "SMS Gateway": Sends Confirmation SMS
"Student Registration System" --> "E-Form": Registration Successful/Failed
deactivate "Student Registration System"
"E-Form" -> Agent: Displays Result
@enduml
```

### 6.3 State Diagram: Student Registration

```plantuml
@startuml
[*] --> Unregistered
Unregistered --> Registered : Successful Registration
Registered --> Amended : Amendment
Amended --> Registered : Amendment Successful
Registered --> Deregistered : Deregistration
Deregistered --> [*]
Unregistered --> Pending : Registration Pending
Pending --> Registered : Registration Approved
Pending --> Unregistered : Registration Rejected

@enduml
```

### 6.4 Activity Diagram: Fee Payment Processing

```plantuml
@startuml
start
:Customer selects payment method;
if (Online/Mobile Banking) then (yes)
  :Authenticate;
  :Select student & fee type;
  :Enter payment details;
  :Process payment;
  :Send confirmation SMS;
else (IVR)
  :Authenticate via IVR;
  :Select student & fee type via IVR;
  :Verify payment details;
  :Process payment;
  :Generate E-Form;
  :Send confirmation SMS;
endif
:Debit Credit Card;
:Debit GL Account;
:Credit School Account;
:Generate transaction log;
:Generate daily report;
stop
@enduml
```


## 7.1 Package Diagram

The following package diagram outlines the proposed architecture, focusing on key packages and their interactions.  This is a high-level view and individual packages may contain further sub-packages.

```plantuml
@startuml
!include <c4/C4_Context>
!include <c4/C4_Container>
!include <c4/C4_Component>

System_Boundary(c1, "School Fee Payment System") {
  Person(cardholder, "Cardholder", "NGB Credit Card Holder")
  Person(agent, "Contact Center Agent", "Handles student registration/amendment via IVR")
  Person(admin, "Card Operations Team", "Registers schools")

  Container(onlineBanking, "Online Banking", "Web Application", "Provides online fee payment functionality")
  Container(mobileBanking, "Mobile Banking", "Mobile Application", "Provides mobile fee payment functionality")
  Container(ivr, "IVR System", "Telephony System", "Handles fee payments and student registration via voice interaction")
  Container(eform, "E-Form System", "Web Application", "Used by Contact Center agents and for EPP conversion")
  Container(schoolRegistration, "School Registration", "Web Application", "Allows school registration by Card Operations Team")
  Container(feePosting, "Fee Posting Service", "Microservice", "Processes fee posting transactions")
  Container(smsGateway, "SMS Gateway", "External Service", "Sends SMS notifications")
  Container(cardsSystem, "Cards System", "External System", "Manages credit card information")
  Container(glSystem, "GL System", "External System", "Manages general ledger accounts")
  Container(reportingService, "Reporting Service", "Microservice", "Generates daily reports for schools")


  Rel(cardholder, onlineBanking, "Pays school fees", "Web Browser")
  Rel(cardholder, mobileBanking, "Pays school fees", "Mobile App")
  Rel(agent, ivr, "Registers/amends student details", "IVR Interaction")
  Rel(agent, eform, "Processes E-Forms", "Web Browser")
  Rel(admin, schoolRegistration, "Registers schools", "Web Browser")

  Rel(onlineBanking, feePosting, "Submits fee payment", "API")
  Rel(mobileBanking, feePosting, "Submits fee payment", "API")
  Rel(ivr, feePosting, "Submits fee payment", "API")
  Rel(eform, feePosting, "Submits EPP conversion request", "API")
  Rel(feePosting, cardsSystem, "Debits credit card", "API")
  Rel(feePosting, glSystem, "Debits GL account, Credits School Account", "API")
  Rel(feePosting, smsGateway, "Sends confirmation SMS", "API")
  Rel(feePosting, reportingService, "Provides transaction data", "API")
  Rel(reportingService, admin, "Sends daily reports", "Email")

}

@enduml
```


## 8.1 API Definitions

This section outlines key API definitions for the School Fee Payment system.  We'll focus on internal APIs, as external APIs (e.g., to school systems) are out of scope.

**I. School Management APIs:**

* **`registerSchool(schoolData)`:**
    * **Method:** POST
    * **Parameters:** `schoolData` (JSON):
        * `schoolName` (String): Name of the school.
        * `location` (String): Location of the school.
        * `accountNumber` (String): NGB account number for the school.
        * `feeTypes` (Array of JSON):  Each element contains `feeTypeName` (String) and `feeDescription` (String).
    * **Data Type:** JSON
    * **Description:** Registers a new school. Returns a school ID upon successful registration.  Error handling includes insufficient data, duplicate account numbers, and invalid account numbers.

* **`updateSchool(schoolId, schoolData)`:**
    * **Method:** PUT
    * **Parameters:** `schoolId` (Integer), `schoolData` (JSON) – similar structure to `registerSchool`.
    * **Data Type:** JSON
    * **Description:** Updates existing school information.  Error handling includes invalid school ID and insufficient data.

* **`getSchool(schoolId)`:**
    * **Method:** GET
    * **Parameters:** `schoolId` (Integer)
    * **Data Type:** JSON
    * **Description:** Retrieves school information by ID. Returns a 404 error if the school ID is not found.

* **`deleteSchool(schoolId)`:**
    * **Method:** DELETE
    * **Parameters:** `schoolId` (Integer)
    * **Data Type:**  Void. Returns 204 (No Content) on success.
    * **Description:** Deletes a school record. Error handling includes invalid school ID and potential data dependencies (students registered).


**II. Student Management APIs:**

* **`registerStudent(studentId, studentName, schoolId, cardNumber)`:**
    * **Method:** POST
    * **Parameters:** `studentId` (String), `studentName` (String), `schoolId` (Integer), `cardNumber` (String).
    * **Data Type:** JSON (Returns student ID upon success)
    * **Description:** Registers a student.  Includes validation for student ID (duplicate check), school ID existence, and active card validation.

* **`updateStudent(studentId, studentData)`:**
    * **Method:** PUT
    * **Parameters:** `studentId` (String), `studentData` (JSON): Contains updatable fields (e.g., `studentName`).
    * **Data Type:** JSON
    * **Description:** Updates student information.

* **`deleteStudent(studentId)`:**
    * **Method:** DELETE
    * **Parameters:** `studentId` (String)
    * **Data Type:** Void. Returns 204 on success.
    * **Description:** Deletes a student record.


**III. Fee Payment APIs:**

* **`makePayment(cardNumber, studentId, schoolId, feeType, amount, remarks)`:**
    * **Method:** POST
    * **Parameters:** `cardNumber` (String), `studentId` (String), `schoolId` (Integer), `feeType` (String), `amount` (Decimal), `remarks` (String, max 40 characters).
    * **Data Type:** JSON (Returns transaction ID and status)
    * **Description:** Processes a fee payment.  Includes validation for card details, student registration, sufficient funds, and fee type validity.

* **`getPaymentHistory(cardNumber, startDate, endDate)`:**
    * **Method:** GET
    * **Parameters:** `cardNumber` (String), `startDate` (Date), `endDate` (Date).
    * **Data Type:** JSON (Array of transactions)
    * **Description:** Retrieves payment history for a given card within a date range.


**IV. EPP (Easy Payment Plan) APIs:**

* **`convertPaymentToEPP(transactionId)`:**
    * **Method:** POST
    * **Parameters:** `transactionId` (String)
    * **Data Type:** JSON (Returns EPP details or error message)
    * **Description:** Converts a completed transaction to an EPP.

**V. Reporting APIs:**

* **`generateDailyReport(schoolId, date)`:**
    * **Method:** GET
    * **Parameters:** `schoolId` (Integer), `date` (Date)
    * **Data Type:** Excel file (downloadable)
    * **Description:** Generates a daily report for a given school.


**VI. Internal GL Posting API:**

*   `postGLTransaction(transactionDetails)`:
    *   **Method:** POST
    *   **Parameters:** `transactionDetails` (JSON): Contains all debit/credit details for GL posting, including card account, GL account (Visa Conventional / Visa Islamic / MasterCard), school account, amount, description, and transaction ID.
    *   **Data Type:** JSON (Returns transaction status, including error codes).
    *   **Description:** Posts the transaction to the General Ledger.  Handles different GL accounts based on card type.



These APIs represent a high-level overview.  Each API would require detailed specification including error codes, authentication mechanisms (e.g., OAuth 2.0), and data formats (e.g., using specific JSON schemas).  The actual implementation would also include robust exception handling, logging, and security measures.


## 9.1 Schema Definitions

The following schema definitions outline the database tables required for the School Fee Payment system.  Primary keys are denoted with `PK`, and foreign keys with `FK`.  Data types are illustrative and may need adjustment based on the specific database system used.

**Table: Schools**

| Column Name        | Data Type    | Constraints                               | Description                                      |
|----------------------|---------------|-------------------------------------------|--------------------------------------------------|
| school_id           | INT           | PK, AUTO_INCREMENT                         | Unique identifier for each school                 |
| school_name         | VARCHAR(255)  | NOT NULL                                   | Name of the school                               |
| location           | VARCHAR(255)  |                                           | Location of the school                           |
| account_number      | VARCHAR(50)   | UNIQUE                                     | NGB account number for the school                |
| gl_account_number  | VARCHAR(50)   |                                           | Internal NGB GL account number                   |


**Table: Students**

| Column Name      | Data Type    | Constraints                               | Description                                  |
|-------------------|---------------|-------------------------------------------|----------------------------------------------|
| student_id       | INT           | PK, AUTO_INCREMENT                         | Unique identifier for each student             |
| school_id         | INT           | FK (Schools)                               | ID of the school the student belongs to        |
| student_name     | VARCHAR(255)  | NOT NULL                                   | Name of the student                           |
| registration_date | DATETIME      |                                           | Date of student registration                   |


**Table: FeeTypes**

| Column Name    | Data Type    | Constraints                               | Description                               |
|----------------|---------------|-------------------------------------------|-------------------------------------------|
| fee_type_id    | INT           | PK, AUTO_INCREMENT                         | Unique identifier for each fee type       |
| school_id      | INT           | FK (Schools)                               | ID of the school this fee type belongs to |
| fee_type_name  | VARCHAR(255)  | NOT NULL                                   | Name of the fee type (e.g., School Fee, Bus Fee) |


**Table: Transactions**

| Column Name        | Data Type    | Constraints                                               | Description                                                      |
|----------------------|---------------|-----------------------------------------------------------|------------------------------------------------------------------|
| transaction_id     | INT           | PK, AUTO_INCREMENT                                        | Unique identifier for each transaction                         |
| student_id         | INT           | FK (Students)                                            | ID of the student the transaction is for                         |
| fee_type_id        | INT           | FK (FeeTypes)                                             | ID of the fee type paid                                         |
| transaction_date   | DATETIME      |                                                           | Date and time of the transaction                               |
| amount             | DECIMAL(10,2) |                                                           | Amount paid                                                    |
| card_number        | VARCHAR(20)   |                                                           | Masked Credit Card Number used for the transaction              |
| transaction_status | VARCHAR(50)   |                                                           | Status of the transaction (e.g., Success, Failed, Pending)       |
| remarks            | VARCHAR(20)   |                                                           | Optional remarks entered by the user                             |
| reference_id       | VARCHAR(50)   | UNIQUE                                                    | Unique reference ID for the transaction                       |
| epp_converted      | BOOLEAN       | DEFAULT FALSE                                              | Indicates whether the transaction was converted to an EPP       |


**Table:  EPPRequests** (For Easy Payment Plans)

| Column Name      | Data Type    | Constraints                               | Description                                          |
|-------------------|---------------|-------------------------------------------|------------------------------------------------------|
| epp_request_id   | INT           | PK, AUTO_INCREMENT                         | Unique identifier for each EPP request                 |
| transaction_id   | INT           | FK (Transactions)                           | ID of the associated transaction                      |
| request_date     | DATETIME      |                                           | Date and time of the EPP request                       |
| approval_status  | VARCHAR(50)  |                                           | Status of the EPP request (e.g., Approved, Rejected) |


## 9.2 Data Mappings

The data mappings are straightforward, reflecting the relationships defined by the foreign keys in the schema definitions above.  For example:

*   **Schools Table:**  Represents a school and its associated details.  The `school_id` is the primary key.
*   **Students Table:** Represents a student.  The `school_id` is a foreign key referencing the `Schools` table, establishing a one-to-many relationship (one school can have many students).
*   **FeeTypes Table:** Represents different types of fees associated with a school.  `school_id` is a foreign key referencing `Schools`.
*   **Transactions Table:** Records individual fee payments.  `student_id` and `fee_type_id` are foreign keys referencing `Students` and `FeeTypes` respectively. This links a transaction to a specific student and fee type.
*   **EPPRequests Table:** Tracks requests to convert transactions into easy payment plans. `transaction_id` is a foreign key referencing `Transactions`.


This schema provides a relational database structure to manage school information, student details, fee types, and transaction history, supporting all the system’s functionalities.  Additional tables may be required depending on further requirements (e.g., for user accounts, audit logs, etc.).


### 10.1 Performance Requirements

The system should provide near-instant transaction acknowledgment for fee payments.  Real-time GL postings are required.  Specific response time targets (e.g., <2 seconds for online/mobile payments, <5 seconds for IVR payments) should be defined and tested during performance testing.  Throughput requirements (e.g., transactions per second) should be determined based on projected user load and peak transaction volumes.  Load testing will be crucial to validate performance under various load conditions.


### 10.2 Scalability Requirements

The architecture must support a growing number of schools, students, and concurrent transactions.  A microservices architecture with horizontal scalability is recommended.  Database solutions should be chosen to support high transaction volumes and large data sets.  Load balancing and caching mechanisms should be implemented to distribute the load and improve response times.  The system should be designed to easily accommodate future growth without significant performance degradation.


### 10.3 Security Measures

* **Authentication:** OTP verification for online/mobile transactions and IVR TIN authentication for contact center interactions are mandatory.  Secure storage of sensitive data (credit card information, student IDs) using encryption and tokenization techniques is crucial.
* **Authorization:** Access control mechanisms should be implemented to restrict access to sensitive data and functionalities based on user roles (e.g., card operations team, contact center agents).  Principle of least privilege should be applied.
* **Data Protection:**  Data at rest and in transit must be protected through encryption.  Regular security audits and penetration testing are necessary to identify and address vulnerabilities.  Compliance with relevant data privacy regulations (e.g., GDPR, PCI DSS) is mandatory.


### 10.4 Logging & Monitoring

Comprehensive logging is required to track all transactions, including successful and failed attempts.  Logs should include timestamps, transaction IDs, user IDs, relevant data fields, and error messages.  A centralized logging system with real-time monitoring capabilities is recommended.  Key performance indicators (KPIs) such as transaction success rate, average response time, error rates, and concurrent user count should be monitored.  Alerting mechanisms should be implemented to notify administrators of critical events or performance issues.


### 10.5 Maintainability & Extensibility

The system should be designed using modular architecture principles to ensure ease of maintenance and extensibility.  Well-defined APIs and interfaces should be used to facilitate integration with other systems.  Code should be well-documented and follow coding best practices.  Automated testing (unit, integration, and system tests) should be implemented to ensure code quality and prevent regressions.  A CI/CD pipeline should be established to streamline the deployment process and enable frequent releases.  The system should be designed to accommodate future enhancements and integrations (e.g., integration with school websites, support for new payment methods).


## 11.1 Error Scenarios and Handling

This section outlines common error scenarios and their handling mechanisms within the School Fee Payment system.

**A. School Registration:**

* **Error:** Duplicate school registration (same account number).
    * **Handling:**  System should prevent duplicate registration and display an appropriate error message to the user.  A unique identifier (e.g., UUID) for each school should be generated internally.
* **Error:** Invalid account number format.
    * **Handling:** Input validation should be implemented to check the account number format and provide feedback to the user.
* **Error:** Failure to configure NGB GL account.
    * **Handling:** System should log the error, notify the administrator, and prevent the school registration from completing until the GL account is successfully configured.  An automated retry mechanism with escalating alerts could be implemented.

**B. Student Registration/Amendment/De-registration:**

* **Error:** Mismatched Student IDs (Online/Mobile Banking).
    * **Handling:** Display an error message prompting the user to re-enter the Student ID correctly.
* **Error:** Invalid Student ID format.
    * **Handling:** Input validation should ensure the Student ID adheres to the defined format.  Error messages should guide the user.
* **Error:** Student not found.
    * **Handling:** Display an error message indicating that the student is not registered.
* **Error:** Failure to send SMS alert.
    * **Handling:** Log the error, attempt to resend the SMS after a delay, and notify the administrator if the issue persists.

**C. Fee Payment:**

* **Error:** Insufficient card balance.
    * **Handling:**  Display a clear message to the user indicating the insufficient balance.  Allow the user to select a different card or cancel the transaction.
* **Error:** Student not registered.
    * **Handling:** Display an error message.  The user may need to register the student first.
* **Error:** Payment gateway failure.
    * **Handling:** Log the error, attempt a retry (with exponential backoff), and notify the user and administrator.  Implement a mechanism for users to view the transaction status.
* **Error:** EPP conversion failure (insufficient balance).
    * **Handling:** Inform the user about the insufficient balance and provide options to add funds or cancel the EPP request.  An SMS notification should be sent.
* **Error:**  Invalid input in remark field (exceeding 20 characters).
    * **Handling:** Trim the remark field to 20 characters or display an error message indicating the character limit.


**D. Fee Posting:**

* **Error:** GL account debit failure.
    * **Handling:** Rollback the transaction, log the error, notify the administrator, and retry the posting after a period of time.
* **Error:** School account credit failure.
    * **Handling:** Similar to GL account debit failure, rollback the transaction and initiate recovery steps.
* **Error:** Description format constraint violation (over 40 characters).
    * **Handling:** Truncate the description to 40 characters before posting.


## 11.2 Recovery Mechanisms

The system will employ several recovery mechanisms to handle failures and ensure data integrity:

* **Transaction Rollback:**  In case of partial failures during fee posting (e.g., successful debit from the credit card but failure to credit the school account), a rollback mechanism will be implemented to reverse the completed steps.
* **Retry Mechanisms (with exponential backoff):**  For transient failures (e.g., network issues), the system will retry operations with increasing delays to avoid overwhelming the system.
* **Error Logging and Monitoring:**  Comprehensive logging will capture all errors, enabling administrators to identify and address issues proactively.  Monitoring dashboards will provide real-time visibility into system health and transaction processing.
* **Alerting System:** Automated alerts will be sent to administrators upon critical errors or failures, facilitating timely intervention.
* **Data Redundancy and Backup:**  Regular data backups and potentially database replication will ensure data availability and prevent data loss in case of system failures.
* **Compensation Transactions:** For failures that cannot be automatically resolved, manual compensation transactions may be required.  Clear procedures and user interfaces for manual intervention should be defined.
* **Circuit Breakers:** For external system integrations (e.g., SMS gateway), circuit breakers will be implemented to prevent cascading failures.  If a service consistently fails, the circuit breaker will temporarily block further requests, allowing the service to recover before resuming normal operation.


These error handling and recovery mechanisms are crucial for ensuring the system's reliability, stability, and data integrity.  The specific implementation details will be further defined during the detailed design phase.


## 12. Assumptions and Limitations

### 12.1 Assumptions

* **Existing Systems Integration:**  We assume the existence and availability of well-defined APIs for Online Banking, Mobile Banking, IVR, Cards System, and CRM systems.  These APIs should provide robust functionalities for transaction processing, authentication, and data retrieval.  Data formats and communication protocols for these APIs will need to be clearly defined and agreed upon.
* **School Account Management:**  We assume the existence of a mechanism to manage school accounts (account creation, updates, and closures) independent of this system.  The system will utilize the existing school account information, including account numbers, for crediting fee payments.
* **SMS Gateway Integration:**  A reliable and readily available SMS gateway is assumed for sending notifications.  This includes appropriate error handling and monitoring of the SMS delivery status.
* **Email Infrastructure:** The system assumes access to a reliable email infrastructure to send the daily Excel reports to schools and product registration data. Error handling and confirmation mechanisms for email delivery are also assumed to be in place.
* **EPP System Integration:** A functional EPP (Easy Payment Plan) system is assumed to be available, including APIs for initiating EPP requests and managing EPP plans.
* **Security Infrastructure:** The system relies on existing security infrastructure for authentication, authorization, and data encryption, including mechanisms for handling sensitive data (like credit card details and student IDs).
* **OTP Generation and Verification:**  A secure OTP generation and verification mechanism is assumed to be available for use across all channels (Online/Mobile Banking and IVR).
* **GL (General Ledger) System Integration:**  A robust and reliable General Ledger system is assumed to be in place, with defined APIs for debiting and crediting accounts.  The system will interface with the GL system to record financial transactions related to fee payments.

### 12.2 Limitations

* **Single School Pilot:** The initial scope is limited to a single pilot school (Europe School).  Expanding to multiple schools will require thorough testing and potential adjustments to system architecture and capacity.
* **Excel Reporting:** Reliance on Excel reports for school data might create limitations in terms of real-time data access and reporting flexibility.  A more sophisticated reporting solution might be needed in the future.
* **Manual Intervention for IVR EPP:** EPP requests initiated via IVR require manual agent intervention, introducing a potential bottleneck and inconsistency compared to automated processing in Online/Mobile Banking.
* **Single Payment Gateway Dependency:**  The current design does not account for the use of multiple payment gateways, potentially reducing resilience and flexibility for future growth.
* **Data Volume:**  The system architecture needs to consider the potential impact of increasing data volumes as more schools and students are registered and transactions are processed.  Appropriate scaling strategies and performance optimization techniques will be necessary.
* **Error Handling and Recovery:** While SMS confirmation and transaction logging contribute to reliability, comprehensive error handling and recovery mechanisms need to be implemented to manage failures and ensure data integrity.  Robust exception handling, transaction rollback capabilities, and audit trails are crucial.




